# ACCEPTANCE_RESULTS

Executed against the SYNTHETIC world through the real AUIF runtime. Not a result on the Anchor Engine. Categories follow the audited spec's `engine_dependency` field.

Run: Python 3.13.16 | 441 tests run, 441 passed, 0 failed | core tree sha256 `923de5100f95debbbf63d5ab6e960cee2091ee57abce403792403ff049ac7839` | mutation: 174/174 killed (0 survived, 0 invalid) | static checks clean: True

| Category | Count | Tests |
|---|---|---|
| BUILT BUT ENVIRONMENT-DEPENDENT | 10 | AT-01, AT-05, AT-12, AT-13, AT-20, AT-21, AT-24, AT-27, AT-29, AT-30 |
| BUILT AND VERIFIED | 19 | AT-02, AT-03, AT-04, AT-06, AT-07, AT-08, AT-09, AT-10, AT-11, AT-14, AT-16, AT-17, AT-18, AT-19, AT-22, AT-23, AT-25, AT-26, AT-28 |
| BLOCKED - AMIR REQUIRED | 1 | AT-15 |

| AT | Title | Category | Result | Tests passed |
|---|---|---|---|---|
| AT-01 | New Anchor Module Reuse | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 1/1 |
| AT-02 | New External System Reuse | BUILT AND VERIFIED | PASS on the synthetic world | 1/1 |
| AT-03 | Translation Pack Isolation | BUILT AND VERIFIED | PASS on the synthetic world | 1/1 |
| AT-04 | Bidirectional Translation | BUILT AND VERIFIED | PASS on the synthetic world | 5/5 |
| AT-05 | Schema Drift | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 6/6 |
| AT-06 | Translation Version Pinning | BUILT AND VERIFIED | PASS on the synthetic world | 3/3 |
| AT-07 | Ambiguous Mapping | BUILT AND VERIFIED | PASS on the synthetic world | 2/2 |
| AT-08 | Rate Limit | BUILT AND VERIFIED | PASS on the synthetic world | 3/3 |
| AT-09 | Out-of-Order Events | BUILT AND VERIFIED | PASS on the synthetic world | 11/11 |
| AT-10 | Duplicate Event | BUILT AND VERIFIED | PASS on the synthetic world | 5/5 |
| AT-11 | Unknown Action Outcome | BUILT AND VERIFIED | PASS on the synthetic world | 11/11 |
| AT-12 | Cross-Tenant Isolation | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 5/5 |
| AT-13 | Governor Boundary | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 12/12 |
| AT-14 | Hostile External Input | BUILT AND VERIFIED | PASS on the synthetic world | 3/3 |
| AT-15 | McGrath Proof | BLOCKED - AMIR REQUIRED | NOT EXECUTED: cannot run without McGrath access (XD-01) and the Anchor Real Estate module (ED-14). A guard test asserts it is not claimed. | 1/1 |
| AT-16 | Universality | BUILT AND VERIFIED | PASS on the synthetic world | 1/1 |
| AT-17 | Reverse Contamination | BUILT AND VERIFIED | PASS on the synthetic world | 2/2 |
| AT-18 | Failure Principle Distinguishability | BUILT AND VERIFIED | PASS on the synthetic world | 2/2 |
| AT-19 | No Silent Data Loss and Explicit Invalid Translation | BUILT AND VERIFIED | PASS on the synthetic world | 3/3 |
| AT-20 | Credential and Secret Boundary | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 2/2 |
| AT-21 | Data Boundary Enforcement | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 7/7 |
| AT-22 | Provenance Reconstruction | BUILT AND VERIFIED | PASS on the synthetic world | 2/2 |
| AT-23 | Pack Immutability and Substitution | BUILT AND VERIFIED | PASS on the synthetic world | 5/5 |
| AT-24 | Observability Without Leakage | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 1/1 |
| AT-25 | AI Cannot Establish Mappings | BUILT AND VERIFIED | PASS on the synthetic world | 3/3 |
| AT-26 | External System Is Not a Source of Truth | BUILT AND VERIFIED | PASS on the synthetic world | 1/1 |
| AT-27 | Governor Adapter Terms Unchanged | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 1/1 |
| AT-28 | Engine-Independence and Honest Dependency Register | BUILT AND VERIFIED | PASS on the synthetic world | 1/1 |
| AT-29 | Performance Measured, Not Assumed | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 1/1 |
| AT-30 | Rate-Limit Isolation (Tenant Fairness) | BUILT BUT ENVIRONMENT-DEPENDENT | PASS on the synthetic world; real-platform run is environment-dependent | 2/2 |

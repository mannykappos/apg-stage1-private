"""Shared helpers for the extensions: a credential wrapper that cannot leak, header hygiene, Retry-After parsing."""
import email.utils, re, time
from auif.errors import TransportError
class Secret:
    """Holds a credential so it cannot leak through repr, str, format, pickling or an exception message. reveal() is the only way out."""
    __slots__ = ("_v",)
    def __init__(self, value):
        if not isinstance(value, str): raise TypeError("a Secret holds a string")
        object.__setattr__(self, "_v", value)
    def __setattr__(self, k, v): raise AttributeError("a Secret is immutable")
    def reveal(self): return self._v
    def __repr__(self): return "Secret(<redacted>)"
    __str__ = __repr__
    def __format__(self, spec): return "<redacted>"
    def __bool__(self): return bool(self._v)
    def __reduce__(self): raise TypeError("a Secret cannot be pickled")
    def __copy__(self): return self
    def __deepcopy__(self, memo): return self
_TOKEN = re.compile(r"^[!#$%&'*+.^_`|~0-9A-Za-z-]+$"); _BAD_VALUE = re.compile(r"[\r\n\x00]")
def clean_header(name, value):
    """Refuse header injection: a name must be an RFC token and a value may not contain CR, LF or NUL."""
    if not isinstance(name, str) or not _TOKEN.match(name) or not isinstance(value, str) or _BAD_VALUE.search(value): raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="invalid header")
    return name, value
def retry_after_seconds(value, now=None, cap=3600.0):
    """Retry-After as delta-seconds OR an HTTP-date, clamped to [0, cap]; anything unparsable is None (never an exception)."""
    if value is None: return None
    v = str(value).strip()
    try:
        if re.fullmatch(r"[0-9]{1,9}(\.[0-9]{1,3})?", v): return min(float(v), cap)
        dt = email.utils.parsedate_to_datetime(v); return max(0.0, min(dt.timestamp() - (time.time() if now is None else now), cap))
    except (TypeError, ValueError, IndexError, OverflowError): return None

# Adding a connector to AUIF (extension route; no core change)

A new software system is added by writing DATA or a small connector module in `auif_ext/`, never by editing the audited core. The core already defines the contract (`auif.connector.Connector`), the translation layer (Translation Packs) and the governance boundary. This guide is the checklist for that route. It describes the first extension implementations; it is not a statement that REST, OAuth2, webhooks or CSV are architecture requirements.

## 1. Facts you must obtain from the system's owner (never assume them)
Record each answer with its source. Until an answer exists, that item is **blocked on the system owner**; do not guess.
1. A **sandbox** (not production) with test data, and its base URL.
2. **Authentication**: API key, OAuth2 client credentials, or something else (a different scheme needs a new connector module; refresh-token flows need a writable secret store, which the core does not offer).
3. **Pagination style**: cursor, offset, page number or `Link` header; the maximum page size; whether a short page can occur before the end.
4. **Rate limits** and what the system sends when exceeded (`429`, `Retry-After`).
5. **Writes**: which entities accept writes; whether an idempotency key is honoured and in which header; how to look a write up afterwards (for reconciliation).
6. **Errors**: the status codes and bodies for authentication failure, permission denial, validation failure and server failure.
7. **Events** (if any): webhook signing scheme (header names, algorithm, encoding, what is signed), timestamp tolerance, event id and ordering guarantees.
8. **Data semantics** for the Translation Pack: field meanings, identifiers, time zones, deletion model.

## 2. Choose a route
- **Route A, configuration only.** If the system is plain JSON over HTTPS with API-key or OAuth2 client-credentials authentication, build a `RestConfig` (entities, `Endpoint` paths, pagination style, idempotency header, lookup endpoint). No new code.
- **Route B, a new connector class.** For anything else, subclass `auif.connector.Connector` in a new module under `auif_ext/connectors/`, and do all network access through `HttpTransport` (the only module allowed to open a socket). Keep target-specific business logic out: connectors communicate, Translation Packs give meaning, modules provide intelligence.
- Webhooks: configure `WebhookConfig` for the provider's signing scheme; the receiver is host-wired (it opens no socket).

## 3. Prove it with the conformance kit (the gate)
1. Write a `Target` for the SANDBOX (protocol in `auif_ext/conformance/suite.py`): it can seed records, inject the standard faults, and report requests and write effects.
2. Subclass `ConnectorConformanceCases` with `unittest.TestCase`, set `target_factory` and `connector_modules` (your connector's module objects).
3. `python3 -m unittest` must pass: valid descriptor in the real runtime, normalised errors with correct `applied` flags, no secret in repr/errors/URLs, terminating duplicate-free paging, one-effect idempotent writes, working reconciliation if claimed, redirects never followed, disconnect forgets the credential.
4. `python3 tools/static_checks_ext.py` and `python3 tools/ext_reverse_contamination.py <core test count>` must pass: no forbidden imports, no real-system names in code, and the core still passes with `auif_ext` removed.
5. Add the connector's own mutation guards to `tools/mutation_ext.py` and show no survivors.
6. Independent audit before any use. No connector is production-ready on the strength of its own tests.

## 4. What this does not give you
It does not connect to a real system by itself, does not decide how AUIF authenticates to Governor (GD-05), does not bind to the Anchor Engine, and says nothing about TLS to a given vendor beyond the transport's verified defaults.

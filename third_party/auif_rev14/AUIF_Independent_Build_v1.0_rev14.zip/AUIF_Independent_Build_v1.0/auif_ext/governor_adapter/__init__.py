"""AUIF-side implementation of Governor's Universal Adapter Contract (v1.2 section 2). AUIF may implement that contract (architecture section 54); Governor stays sovereign."""
from .adapter import build_adapter_class, FabricObservationSource, check_binding, FORBIDDEN_METHODS

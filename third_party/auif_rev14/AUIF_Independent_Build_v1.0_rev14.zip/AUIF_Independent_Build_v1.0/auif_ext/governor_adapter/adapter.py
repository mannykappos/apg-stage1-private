"""AUIF as a governed target: an implementation of Governor's Universal Adapter Contract (v1.2 section 2) on top of AUIF. Governor's classes are INJECTED (build_adapter_class(binding)): AUIF never imports Governor, so the audited core stays
free of it and a Governor revision cannot silently change AUIF. An adapter OBSERVES and TRANSLATES; it is never an authority. By construction this class has none of Governor's authority operations (evaluate_policy, issue_promotion_token,
mutate_governor_state, assert_compliant, determine_materiality, resolve_conflict), and deliver_decision FAILS CLOSED: a decision is delivered only if an injected verifier authenticates it, because how AUIF authenticates Governor is an
OPEN decision (GD-05 / ED-11). Only metadata (identifiers, provenance, hashes) is forwarded to Governor, never business payloads."""
import hashlib, json, re, time
REQUIRED = ("TargetSystemAdapter", "RawObservation", "Attestation", "NormalizedObject", "TargetEvent", "Capability", "NeutralObject", "NeutralConcept", "SCHEMA_VERSION")
FORBIDDEN_METHODS = ("evaluate_policy", "issue_promotion_token", "mutate_governor_state", "assert_compliant", "determine_materiality", "resolve_conflict")
def check_binding(b):
    missing = [n for n in REQUIRED if not hasattr(b, n)]
    if missing: raise ValueError("the Governor binding lacks %s" % missing)
    return b
def _sha(o): return hashlib.sha256(json.dumps(o, sort_keys=True, default=str, separators=(",", ":")).encode()).hexdigest()
_SAFE = re.compile(r"[^a-z0-9_-]+")
class FabricObservationSource:
    """The practical observation source: AUIF's own stored observations for one integration, reduced to METADATA (what was observed, where, when, and its hash). Business payloads are never read."""
    def __init__(self, fabric, ctx, integration_id): self.fabric, self.ctx, self.iid = fabric, ctx, integration_id
    def __call__(self):
        tsid = self.fabric.integration(self.ctx, self.iid).target_system_id; out = []
        for _, o in self.fabric.store.list(self.ctx, "observations"):
            if o.get("target_system_id") != tsid: continue
            so = o.get("source_object") or {}
            out.append({"observation_id": o["observation_id"], "object_type": so.get("object_type"), "object_id": so.get("object_id"), "source_system": o.get("source_system"), "connector_id": o.get("connector_id"), "observed_at": o.get("observed_at"), "payload_hash": o.get("payload_hash"), "schema_fingerprint": o.get("schema_fingerprint")})
        return out
def build_adapter_class(gov):
    check_binding(gov); Cap = gov.Capability
    class AuifGovernorAdapter(gov.TargetSystemAdapter):
        def __init__(self, tenant_id, target_system_id, environment_id, *, source, adapter_id=None, adapter_version="0.1.0", declare_source=None, attester=None, id_namespace="auif.observed", id_field="observation_id", concept="RESOURCE", classification_field=None, decision_verifier=None, decision_sink=None, health_probe=None, clock=time.time):
            if not all(isinstance(x, str) and x for x in (tenant_id, target_system_id, environment_id)): raise ValueError("tenant, target system and environment ids are required")
            if id_namespace.count(".") < 1 or concept not in gov.NeutralConcept.__members__: raise ValueError("unacceptable namespace or concept")
            self._t, self._s, self._e, self._src, self._id, self._ver = tenant_id, target_system_id, environment_id, source, adapter_id or "auif:%s" % target_system_id, adapter_version
            self._declare, self._attester, self._ns, self._idf, self._concept, self._clsf, self._verify, self._sink, self._probe, self._clock = declare_source, attester, id_namespace, id_field, concept, classification_field, decision_verifier, decision_sink, health_probe, clock
        def identity(self): return {"adapter_id": self._id, "adapter_version": self._ver, "target_system_id": self._s}                    # informational only
        def declared_capabilities(self):                                                                                                    # a self-declaration, never evidence: Governor decides whether to trust it
            return {Cap.OBSERVATION: True, Cap.NORMALIZATION: True, Cap.MANIFEST_DECLARATION: self._declare is not None, Cap.ATTESTATION: self._attester is not None, Cap.DECISION_DELIVERY: callable(self._verify) and callable(self._sink)}
        def declare(self):                                                                                                                  # a PROPOSAL only
            base = {"tenant_id": self._t, "target_system_id": self._s, "components": []}
            if self._declare is not None:
                try: d = self._declare()
                except Exception: d = None
                if isinstance(d, dict): base.update({k: v for k, v in d.items() if k not in ("tenant_id", "target_system_id")})
            return base
        def observe(self):                                                                                                                  # RAW and untrusted: AUIF does not interpret, rank or filter it
            now = float(self._clock())
            def bad(why): return [gov.RawObservation(source_adapter_id=self._id, target_native_representation={}, observed_at=now, failure=why)]
            try: native = self._src()
            except TimeoutError: return bad("timeout")
            except Exception: return bad("crash")
            if not isinstance(native, list) or any(not isinstance(n, dict) for n in native): return bad("malformed")
            return [gov.RawObservation(source_adapter_id=self._id, target_native_representation=dict(n), observed_at=now) for n in native]
        def attest(self, observation):                                                                                                      # provenance, if capable; it is not trusted until Governor verifies it
            if self._attester is None or getattr(observation, "failure", None): return None
            try: prov = self._attester(observation.target_native_representation)
            except Exception: return None
            if not isinstance(prov, dict): return None
            return gov.Attestation(source_adapter_id=self._id, observation_ref=_sha(observation.target_native_representation)[:32], provenance=json.loads(json.dumps(prov, default=str)), signature=None)
        def normalize(self, observation):                                                                                                   # MECHANICAL translation to the Neutral Model: no policy evaluation, no materiality, no judgement
            n = getattr(observation, "target_native_representation", None)
            if getattr(observation, "failure", None) or not isinstance(n, dict) or not n: return None
            key = _SAFE.sub("-", str(n.get(self._idf, _sha(n)[:16])).lower()).strip("-")[:80] or _sha(n)[:16]; cls = n.get(self._clsf) if self._clsf else None
            obj = gov.NeutralObject(schema_version=gov.SCHEMA_VERSION, concept=gov.NeutralConcept[self._concept], id="%s.%s" % (self._ns, key), tenant_id=self._t, target_system_id=self._s, environment_id=self._e, declared_metadata=dict(n), classification=cls if isinstance(cls, str) else None)
            return gov.NormalizedObject(neutral_object=obj, target_declared_classification=cls if isinstance(cls, str) else None)           # the classification is only what the target declared
        def translate_event(self, native_event):                                                                                            # mechanical: a type string and the event, unchanged
            ev = native_event if isinstance(native_event, dict) else {}; t = ev.get("type"); return gov.TargetEvent(source_adapter_id=self._id, canonical_event_type=t if isinstance(t, str) and t else "unknown", payload=dict(ev))
        def deliver_decision(self, decision):                                                                                               # delivery ONLY, and fail-closed (GD-05 is open)
            if not callable(self._verify) or not callable(self._sink) or not isinstance(decision, dict): return False
            try:
                if self._verify(decision) is not True: return False
                self._sink(decision); return True
            except Exception: return False
        def health(self):
            if self._probe is None: return {"status": "unknown"}
            try: h = self._probe(); return h if isinstance(h, dict) else {"status": "unknown"}
            except Exception: return {"status": "unknown"}
    return AuifGovernorAdapter

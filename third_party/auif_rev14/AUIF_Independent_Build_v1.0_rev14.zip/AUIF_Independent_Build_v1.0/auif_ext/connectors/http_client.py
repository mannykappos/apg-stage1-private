"""A hardened HTTP transport (standard library only). It is the ONLY place in the extensions that opens a socket.
Posture: HTTPS only (plain http solely for explicit loopback testing); the destination host must be on an explicit allow-list; no userinfo in URLs; no redirect is ever followed; responses are size-bounded and never compressed;
header injection is refused; TLS verification is on by default. Failures are normalised to the core's TransportError with the right `applied` flag, which decides whether a write may ever be retried."""
import http.client, socket, ssl, threading, urllib.parse
from dataclasses import dataclass
from auif.errors import MalformedResponse, TransportError
from .. import common
LOOPBACK = frozenset({"127.0.0.1", "localhost", "::1"}); WRITE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"}); METHODS = WRITE_METHODS | {"GET", "HEAD"}
@dataclass(frozen=True)
class HttpResponse:
    status: int; headers: dict; body: bytes
class HttpTransport:
    def __init__(self, allowed_hosts, *, allow_insecure_loopback=False, connect_timeout=5.0, request_timeout=30.0, max_response_bytes=2_000_000, ssl_context=None, total_deadline=60.0):
        hosts = frozenset(str(h).lower() for h in allowed_hosts)
        if not (isinstance(total_deadline, (int, float)) and not isinstance(total_deadline, bool) and 0 < total_deadline < float("inf")): raise ValueError("total_deadline must be a positive finite number of seconds")
        if not hosts: raise ValueError("an explicit host allow-list is required")
        self.hosts, self.insecure_ok, self.ct, self.rt, self.max_bytes = hosts, bool(allow_insecure_loopback), float(connect_timeout), float(request_timeout), int(max_response_bytes); self.dl = float(total_deadline)
        self.ctx = ssl_context if ssl_context is not None else self._default_context()           # certificate and hostname verification ON; a supplied context is the host's own choice
    @staticmethod
    def _default_context():
        c = ssl.create_default_context(); c.minimum_version = ssl.TLSVersion.TLSv1_2             # rev8: stated, not inherited from the interpreter's or the OS's defaults (rev7 inherited them; on some platforms that is no floor at all)
        return c
    def _target(self, url):
        p = urllib.parse.urlsplit(url); host = (p.hostname or "").lower()
        if p.scheme not in ("https", "http") or not host or "@" in p.netloc or p.fragment or not p.path.startswith("/"): raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable URL")
        if p.scheme == "http" and not (self.insecure_ok and host in LOOPBACK): raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="plain http is refused")
        try: port = p.port
        except ValueError: raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable URL")
        if p.netloc.lower() not in self.hosts and host not in self.hosts: raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="host is not on the allow-list")
        return p.scheme, host, port, p.path + (("?" + p.query) if p.query else "")
    def request(self, method, url, *, headers=None, body=None):
        method = str(method).upper(); write = method in WRITE_METHODS
        if method not in METHODS: raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unsupported method")
        scheme, host, port, target = self._target(url); hdrs = {"accept-encoding": "identity", "connection": "close", "user-agent": "auif-ext/0.1"}
        for k, v in (headers or {}).items(): k, v = common.clean_header(k, v); hdrs[k.lower()] = v
        if body is not None and not isinstance(body, (bytes, bytearray)): raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="body must be bytes")
        conn = http.client.HTTPSConnection(host, port, timeout=self.ct, context=self.ctx) if scheme == "https" else http.client.HTTPConnection(host, port, timeout=self.ct)
        sent = False; expired = threading.Event(); held = []                                  # `held` keeps our own reference to the socket: http.client hands it to the response object for 'Connection: close' replies, and conn.sock is then None
        def _expire():                                                                          # a hard bound on the WHOLE exchange: a server that drips bytes slower than the per-operation timeout cannot hold a call open
            expired.set(); s = held[0] if held else conn.sock
            if s is not None:
                try: s.shutdown(socket.SHUT_RDWR)
                except OSError: pass
        timer = threading.Timer(self.dl, _expire); timer.daemon = True; timer.start()
        try:
            try: conn.connect()
            except socket.timeout: raise TransportError("TIMEOUT", applied="NOT_APPLIED", message="connect timed out")
            except (OSError, ssl.SSLError): raise TransportError("CONNECTION_FAILED", applied="NOT_APPLIED", message="connection failed")
            if expired.is_set(): raise TransportError("TIMEOUT", applied="NOT_APPLIED", message="request exceeded the total deadline")      # the deadline passed while connecting, when there was no socket to cut
            held.append(conn.sock); conn.sock.settimeout(self.rt)
            try: sent = True; conn.request(method, target, body=body, headers=hdrs); resp = conn.getresponse()
            except socket.timeout: raise TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", message="request timed out")
            except (OSError, http.client.HTTPException):
                if expired.is_set(): raise TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", message="request exceeded the total deadline")
                raise TransportError("CONNECTION_FAILED", applied="MAYBE" if (write and sent) else "NOT_APPLIED", message="connection lost")
            try: data = resp.read(self.max_bytes + 1)
            except socket.timeout: raise TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", message="response timed out")
            except (OSError, http.client.HTTPException):
                if expired.is_set(): raise TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", message="request exceeded the total deadline")
                raise TransportError("CONNECTION_FAILED", applied="MAYBE" if write else "NOT_APPLIED", message="connection lost")
            if expired.is_set(): raise TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", message="request exceeded the total deadline")          # a read cut short by the deadline can look like a clean end of stream: never accept it
            if len(data) > self.max_bytes: raise MalformedResponse("response exceeds the size limit")
            h = {}
            for k, v in resp.getheaders(): k = k.lower(); h[k] = (h[k] + ", " + v) if k in h else v
            return HttpResponse(resp.status, h, data)
        finally: timer.cancel(); conn.close()

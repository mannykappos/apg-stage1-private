"""OAuth2 client-credentials for extension connectors. The client id and secret arrive as ONE resolved secret ("client_id:client_secret", split on the first colon), through the core's secret boundary; they are never logged and never
appear in an exception. Tokens are cached in memory until shortly before expiry. NOT supported (documented limitation): authorization-code and refresh-token flows, because a rotating refresh token needs a way to write a secret back and the SecretPort is read-only."""
import base64, hashlib, json, threading, time, urllib.parse
from auif.errors import MalformedResponse, TransportError
from ..common import Secret, retry_after_seconds
def split_client_credentials(secret):
    if not isinstance(secret, str) or ":" not in secret: raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", message="credential is not in client_id:client_secret form")
    cid, _, csec = secret.partition(":")
    if not cid or not csec: raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", message="credential is not in client_id:client_secret form")
    return cid, csec
class OAuth2ClientCredentials:
    def __init__(self, transport, token_url, *, scope=None, auth_style="basic", clock=time.time, skew=30.0, default_lifetime=300.0, max_lifetime=86400.0):
        if auth_style not in ("basic", "body"): raise ValueError("auth_style must be 'basic' or 'body'")
        self.t, self.url, self.scope, self.style, self.clock, self.skew, self.default, self.maxlife = transport, token_url, scope, auth_style, clock, float(skew), float(default_lifetime), float(max_lifetime); self._cache = None
        self._state = threading.Lock(); self._gen = 0; self._flights = {}                  # rev8: safe for many threads; ONE fetch serves every caller waiting on the same credential (single flight)
    def invalidate(self):
        with self._state: self._cache = None; self._gen += 1
    def _fresh(self, key, now):
        with self._state: c = self._cache
        return c[1] if c and c[0] == key and c[2] > now else None
    def token(self, client_id, client_secret):
        key = hashlib.sha256((client_id + "\x00" + client_secret).encode()).hexdigest(); tok = self._fresh(key, self.clock())
        if tok is not None: return tok
        with self._state:
            fl = self._flights.get(key); leader = fl is None
            if leader: fl = self._flights[key] = {"done": threading.Event(), "ok": None, "err": None, "gen": self._gen}
        if not leader: fl["done"].wait()                                                  # a follower shares the leader's token OR its failure; a different credential never joins this flight
        else:
            try: fl["ok"] = self._fetch(client_id, client_secret, key, fl["gen"])
            except BaseException as e: fl["err"] = e
            finally:
                with self._state: self._flights.pop(key, None)
                fl["done"].set()
        if fl["err"] is not None: raise fl["err"]
        return fl["ok"]
    def _fetch(self, client_id, client_secret, key, gen):
        now = self.clock()
        form = {"grant_type": "client_credentials"}; hdrs = {"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"}
        if self.scope: form["scope"] = self.scope
        if self.style == "basic": hdrs["Authorization"] = "Basic " + base64.b64encode((client_id + ":" + client_secret).encode()).decode()
        else: form["client_id"], form["client_secret"] = client_id, client_secret
        r = self.t.request("POST", self.url, headers=hdrs, body=urllib.parse.urlencode(form).encode())
        if r.status == 429: raise TransportError("RATE_LIMITED", applied="NOT_APPLIED", retry_after=retry_after_seconds(r.headers.get("retry-after")), status=429, message="token endpoint rate limited")
        if r.status >= 500: raise TransportError("UNAVAILABLE", applied="NOT_APPLIED", status=r.status, message="token endpoint unavailable")
        if r.status != 200: raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", status=r.status, message="token request refused")
        try: body = json.loads(r.body.decode("utf-8"), parse_constant=lambda c: (_ for _ in ()).throw(ValueError(c)))
        except (ValueError, UnicodeDecodeError): raise MalformedResponse("token response is not valid JSON")
        tok = body.get("access_token") if isinstance(body, dict) else None
        if not isinstance(tok, str) or not tok or str(body.get("token_type", "bearer")).lower() != "bearer": raise MalformedResponse("token response is not a bearer token")
        try: life = float(body.get("expires_in", self.default))
        except (TypeError, ValueError): life = self.default
        life = min(max(life, 0.0), self.maxlife); secret = Secret(tok)
        with self._state:
            if self._gen == gen: self._cache = (key, secret, now + max(0.0, life - self.skew))               # an invalidate() that happened during the fetch wins: that token is returned to its caller but not cached
        return secret

"""A generic CSV / JSON file-import connector (read-only). Files are untrusted input: names are confined to one base directory, symlinks and non-regular files are refused, sizes and row counts are bounded, encodings are strict, and nothing is
type-guessed: a column is a string unless the configuration DECLARES a type, and a value that does not fit its declared type invalidates the page (it is never coerced silently)."""
import csv, io, json, os, re, stat, time
from dataclasses import dataclass, field
from auif.connector import Connector
from auif.errors import MalformedResponse, TransportError
from .descriptor import build_descriptor
NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$"); ENT = re.compile(r"^[A-Za-z][A-Za-z0-9_.-]{0,63}$"); INT = re.compile(r"^-?[0-9]{1,18}$"); DEC = re.compile(r"^-?[0-9]{1,18}(\.[0-9]{1,10})?$"); TYPES = ("string", "integer", "decimal", "boolean")
@dataclass
class FileSpec:
    filename: str; fmt: str = "csv"; types: dict = field(default_factory=dict); items_path: tuple = (); delimiter: str = ","; max_bytes: int = 5_000_000; max_rows: int = 100_000
def _refuse(c): raise ValueError(c)
class FileImportConnector(Connector):
    def __init__(self, base_dir, files, *, connector_id="generic-file-import", version="0.1.0", clock=time.time):
        if not isinstance(files, dict) or not files: raise ValueError("at least one file must be declared")
        for ent, sp in files.items():
            if not ENT.match(ent) or not NAME.match(sp.filename) or sp.fmt not in ("csv", "json") or len(sp.delimiter) != 1 or any(t not in TYPES for t in sp.types.values()): raise ValueError("file declaration for %r is not acceptable" % ent)
        self.base, self.files, self.connector_id, self.connector_version = os.path.realpath(base_dir), files, connector_id, version
    def __repr__(self): return "FileImportConnector(%s %s)" % (self.connector_id, self.connector_version)
    def descriptor(self): return build_descriptor(connector_id=self.connector_id, version=self.connector_version, protocol_class="EXTENSION", display_name="Generic file import (extension)", auth_handling="NONE", pagination="OFFSET")
    def connect(self, credentials):
        if not os.path.isdir(self.base): raise TransportError("CONNECTION_FAILED", applied="NOT_APPLIED", message="base directory is not available")
    def disconnect(self): return None
    def health(self): return {"status": "up" if os.path.isdir(self.base) else "down"}
    def capabilities(self): return {"read": True, "write": False, "discover": True}
    def subscribe(self, request): raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED")
    def unsubscribe(self, request): return {"unsubscribed": True}
    def write(self, request): raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED", message="file import is read-only")
    def _text(self, sp):
        path = os.path.join(self.base, sp.filename)
        try:
            st = os.lstat(path)
            if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode) or os.path.dirname(os.path.realpath(path)) != self.base: raise MalformedResponse("not a regular file inside the import directory")
            if st.st_size > sp.max_bytes: raise MalformedResponse("file exceeds the size limit")
            fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        except FileNotFoundError: raise TransportError("UNAVAILABLE", applied="NOT_APPLIED", message="file is not present")
        except OSError: raise MalformedResponse("file cannot be opened safely")
        with os.fdopen(fd, "rb") as f: data = f.read(sp.max_bytes + 1)
        if len(data) > sp.max_bytes: raise MalformedResponse("file exceeds the size limit")
        try: text = data.decode("utf-8-sig")
        except UnicodeDecodeError: raise MalformedResponse("file is not valid UTF-8")
        if "\x00" in text: raise MalformedResponse("file contains NUL bytes")
        return text
    def _typed(self, sp, rec):
        out = {}
        for k, v in rec.items():
            t = sp.types.get(k, "string")
            if t == "string" or not isinstance(v, str): out[k] = v; continue
            if v == "": out[k] = None
            elif t == "integer" and INT.match(v): out[k] = int(v)
            elif t == "decimal" and DEC.match(v): out[k] = v
            elif t == "boolean" and v.lower() in ("true", "false"): out[k] = v.lower() == "true"
            else: raise MalformedResponse("a value does not fit its declared type")
        return out
    def _rows(self, sp):
        text = self._text(sp)
        if sp.fmt == "csv":
            try:
                rd = csv.reader(io.StringIO(text, newline=""), delimiter=sp.delimiter, strict=True); rows = []; head = next(rd, None)
                if not head or any(not h.strip() for h in head) or len(set(head)) != len(head): raise MalformedResponse("the header is empty or has duplicate names")
                for i, r in enumerate(rd):
                    if i >= sp.max_rows: raise MalformedResponse("file exceeds the row limit")
                    if len(r) != len(head): raise MalformedResponse("a row does not match the header")
                    rows.append(self._typed(sp, dict(zip(head, r))))
                return head, rows
            except csv.Error: raise MalformedResponse("file is not valid CSV")
        try: obj = json.loads(text, parse_constant=_refuse)
        except (ValueError, RecursionError): raise MalformedResponse("file is not valid JSON")
        items = obj
        for k in sp.items_path: items = items.get(k) if isinstance(items, dict) else None
        if not isinstance(items, list) or len(items) > sp.max_rows or any(not isinstance(i, dict) for i in items): raise MalformedResponse("JSON is not a bounded list of objects")
        head = sorted({k for i in items for k in i}); return head, [self._typed(sp, i) for i in items]
    def discover(self):
        ents = []
        for ent, sp in self.files.items():
            head, rows = self._rows(sp); ents.append({"name": ent, "fields": [{"name": h, "type": sp.types.get(h, "string")} for h in head], "relationships": []})
        return {"system_version": "file-import-1", "generated_at": "volatile", "environment": "file", "auth_requirements": {"type": "none"}, "pagination": {"style": "OFFSET", "max_page_size": 200}, "rate_limits": {"requests_per_second": 10},
                "entities": ents, "operations": [{"name": "read_" + e["name"], "kind": "read", "entities": [e["name"]]} for e in ents], "events": [], "not_exposed": ["write", "webhook_support"]}
    def read(self, request):
        sp = self.files.get(request.get("entity")) if isinstance(request, dict) else None
        if sp is None: raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED", message="entity is not declared")
        try: start = int(request.get("cursor") or 0); size = max(1, min(int(request.get("page_size") or 50), 200))
        except (TypeError, ValueError): raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable cursor")
        if start < 0: raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable cursor")
        head, rows = self._rows(sp); chunk = rows[start:start + size]; nxt = str(start + size) if start + size < len(rows) else None
        return {"items": chunk, "next_cursor": nxt, "complete": nxt is None}

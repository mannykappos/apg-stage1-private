"""A generic webhook receiver. It authenticates a delivery BEFORE it parses or stores anything: the signature is an HMAC over the exact bytes received (plus an optional timestamp), compared in constant time against every currently valid
secret (so a secret can be rotated without dropping deliveries). A timestamp outside the tolerance is refused (bounds replay in time); a repeated event id is suppressed by the core's own sequencer (replay and duplicate protection), and an id
reused with a DIFFERENT payload is surfaced as a conflict. Nothing about a rejected delivery is echoed back. The scheme (header names, encoding, prefix, signed template) is configuration: no provider is named here.
Calls into the core are serialised per receiver (the core has no internal synchronisation; a host that also calls the same Fabric from other threads must serialise those itself).
The receiver does not open a socket: the host's HTTP layer calls handle() and wires `secrets` to the SecretPort and `ingest` to Fabric.ingest_events."""
import base64, hashlib, hmac, json, re, threading, time
from dataclasses import dataclass
from auif.errors import TenantContextError
_TOK = re.compile(r"(\{timestamp\}|\{body\})")
@dataclass
class WebhookConfig:
    signature_header: str = "x-signature"; algorithm: str = "sha256"; encoding: str = "hex"; signature_prefix: str = ""
    timestamp_header: str = None; signed_template: str = "{body}"; tolerance_seconds: float = 300.0; max_body_bytes: int = 1_000_000
    id_path: tuple = ("id",); type_path: tuple = ("type",); payload_path: tuple = ("data",); depends_on_path: tuple = None
@dataclass
class WebhookResult:
    status: int; body: dict
def _dig(o, path):
    for k in path:
        if not isinstance(o, dict) or k not in o: return None
        o = o[k]
    return o
class WebhookReceiver:
    def __init__(self, config, secrets, ingest, clock=time.time):
        if config.algorithm not in ("sha256", "sha512") or config.encoding not in ("hex", "base64"): raise ValueError("unsupported signature scheme")
        if "{timestamp}" in config.signed_template and not config.timestamp_header: raise ValueError("the signed template uses a timestamp but no timestamp_header is configured")
        self.c, self.secrets, self.ingest, self.clock = config, secrets, ingest, clock
        self._ingest_lock = threading.Lock()                                                  # rev8: the core has no internal synchronisation, so this receiver's calls into it never overlap (verification stays parallel)
    def _mac(self, secret, message):
        raw = hmac.new(secret, message, getattr(hashlib, self.c.algorithm)).digest()
        return raw.hex() if self.c.encoding == "hex" else base64.b64encode(raw).decode()
    def _verified(self, secrets, headers, body, ts):
        given = headers.get(self.c.signature_header.lower())
        if not given or len(given) > 4096: return False
        cands = [s.strip()[len(self.c.signature_prefix):] for s in given.split(",") if s.strip().startswith(self.c.signature_prefix)]
        msg = b"".join({"{timestamp}": (ts or "").encode(), "{body}": body}.get(p, p.encode()) for p in _TOK.split(self.c.signed_template) if p)
        ok = False
        for sec in secrets:                                                         # every secret and every candidate is compared: the work does not depend on which one matches
            sec = sec.encode() if isinstance(sec, str) else sec; mac = self._mac(sec, msg)
            for cand in cands: ok |= hmac.compare_digest(mac.encode(), cand.encode())
        return ok
    def handle(self, ctx, integration_id, headers, body):
        c = self.c; headers = {str(k).lower(): v for k, v in (headers or {}).items()}
        if not isinstance(body, (bytes, bytearray)) or len(body) > c.max_body_bytes: return WebhookResult(413, {"status": "too_large"})
        try: secrets = list(self.secrets(ctx, integration_id) or [])
        except Exception: return WebhookResult(503, {"status": "verification_unavailable"})
        if not secrets: return WebhookResult(503, {"status": "verification_unavailable"})          # cannot verify, so cannot accept (fail closed)
        ts = headers.get(c.timestamp_header.lower()) if c.timestamp_header else None
        if c.timestamp_header:
            try: t = float(ts); fresh = abs(self.clock() - t) <= c.tolerance_seconds
            except (TypeError, ValueError): fresh = False
            if not fresh: return WebhookResult(401, {"status": "unauthorised"})
        if not self._verified(secrets, headers, bytes(body), ts): return WebhookResult(401, {"status": "unauthorised"})
        try: obj = json.loads(bytes(body).decode("utf-8"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
        except (ValueError, UnicodeDecodeError, RecursionError): return WebhookResult(400, {"status": "malformed"})
        eid, typ, payload = _dig(obj, c.id_path), _dig(obj, c.type_path), (_dig(obj, c.payload_path) if c.payload_path else obj)
        if isinstance(eid, bool) or not isinstance(eid, (str, int)) or not str(eid) or len(str(eid)) > 128 or not isinstance(typ, str) or not typ or len(typ) > 128 or not isinstance(payload, dict): return WebhookResult(400, {"status": "malformed"})
        ev = {"event_id": str(eid), "type": typ, "payload": payload}
        if c.depends_on_path:
            dep = _dig(obj, c.depends_on_path)
            if dep is not None:
                if not isinstance(dep, list) or any(not isinstance(d, (str, int)) or isinstance(d, bool) for d in dep): return WebhookResult(400, {"status": "malformed"})
                ev["depends_on"] = [str(d) for d in dep]
        try:
            with self._ingest_lock: decisions = self.ingest(ctx, integration_id, [ev])
        except TenantContextError: return WebhookResult(401, {"status": "unauthorised"})
        except Exception: return WebhookResult(503, {"status": "unavailable"})                  # the provider will retry; nothing about the failure is echoed
        states = [d.get("ordering_state") for d in decisions if str(d.get("event_id", ev["event_id"])) == ev["event_id"]] or [d.get("ordering_state") for d in decisions]
        if "RECONCILIATION_PENDING" in states: return WebhookResult(409, {"status": "conflict"})
        if "REJECTED_BY_POLICY" in states: return WebhookResult(422, {"status": "rejected"})
        if "DUPLICATE_SUPPRESSED" in states: return WebhookResult(200, {"status": "duplicate"})
        if "QUEUED_AWAITING_PREDECESSOR" in states: return WebhookResult(202, {"status": "queued"})
        return WebhookResult(200, {"status": "accepted"})

"""A generic, declarative REST connector: ONE class configured by data, never subclassed per target system (so no target-specific logic ever enters it). It implements the audited Connector contract and normalises every failure
to the core's TransportError with the right `applied` flag. Read-only calls are never "maybe applied"; a write that times out or loses its connection is MAYBE applied and is therefore never blind-retried by the core (it reconciles
by idempotency key through lookup_by_idempotency_key). Hosts are allow-listed, redirects are never followed, path parameters are percent-encoded, and credentials are held in a Secret."""
import json, re, time, urllib.parse
from dataclasses import dataclass, field
from auif.connector import Connector
from auif.errors import MalformedResponse, TransportError
from ..common import Secret, retry_after_seconds
from .descriptor import build_descriptor
from .http_client import LOOPBACK, HttpTransport
from .oauth2 import OAuth2ClientCredentials, split_client_credentials
NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_.-]{0,63}$"); PLACE = re.compile(r"\{[^{}]*\}|[{}]"); IDEM = re.compile(r"^[\x21-\x7e]{1,200}$"); PAGINATIONS = ("cursor", "offset", "page", "link"); LINK = re.compile(r'<([^<>]{1,2048})>((?:\s*;\s*(?:[^;,<"]|"(?:[^"\\]|\\.)*")*)*)'); REL = re.compile(r'(?:^|[;\s])rel\s*=\s*(?:"([^"]*)"|([^\s;,]+))', re.I); NEXTISH = re.compile(r'rel\s*=\s*"?[^";,]*\bnext\b', re.I); WRITES = ("POST", "PUT", "PATCH", "DELETE"); AUTHS = ("NONE", "API_KEY", "OAUTH2_CLIENT_CREDENTIALS"); HEADER_NAME = re.compile(r"^[A-Za-z0-9-]{1,64}\Z"); TENANT_ID = re.compile(r"^[A-Za-z0-9._:-]{1,100}\Z")
RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})      # rev12: a tenant header may never be one the connector itself owns; PLACE finds every brace token in a path; only {id} and {key} are acceptable
@dataclass(frozen=True)
class Endpoint:
    method: str = "GET"; path: str = "/"; items_path: tuple = (); next_cursor_path: tuple = ("next_cursor",); cursor_param: str = "cursor"; page_size_param: str = "limit"; record_path: tuple = (); id_field: str = "id"
    pagination: str = "cursor"; offset_param: str = "offset"; page_param: str = "page"; total_items_path: tuple = None; total_pages_path: tuple = None            # rev8: 'cursor' (rev7 behaviour), 'offset', 'page' or 'link' (RFC 8288 rel=next)
@dataclass
class RestConfig:
    connector_id: str; version: str; base_url: str; allowed_hosts: tuple; credential_ref: str = None; auth: str = "NONE"; auth_header: str = "Authorization"; auth_prefix: str = "Bearer "; token_url: str = None; scope: str = None; token_auth_style: str = "basic"
    discover_path: str = "/metadata"; health_path: str = None; entities: dict = field(default_factory=dict); idempotency_header: str = "Idempotency-Key"; lookup: Endpoint = None; max_page_size: int = 200
    allow_insecure_loopback: bool = False; connect_timeout: float = 5.0; request_timeout: float = 30.0; max_response_bytes: int = 2_000_000; total_deadline: float = 60.0
    tenant_header: str = None; tenant_id: str = None             # rev12: the tenant (organisation) the connection is scoped to. NOT a credential: it is sent on every API call (never to the token endpoint) and is never part of, or derived from, the credential
def error_for_status(r, write):
    """The single status-to-error table. A read can never be 'maybe applied'; a write answered by a server error may have been."""
    s, ra = r.status, retry_after_seconds(r.headers.get("retry-after"))
    if s == 401: return TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", status=s, message="authentication failed")
    if s == 403: return TransportError("AUTHORIZATION_DENIED_BY_TARGET", applied="NOT_APPLIED", status=s, message="authorization denied by target")
    if s == 429: return TransportError("RATE_LIMITED", applied="NOT_APPLIED", retry_after=ra, status=s, message="rate limited")
    if s == 408: return TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", status=s, message="target timed out")
    if 500 <= s <= 599: return TransportError("UNAVAILABLE", applied="MAYBE" if write else "NOT_APPLIED", retry_after=ra, status=s, message="target unavailable")
    if 300 <= s <= 499: return TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", status=s, message="target rejected the request")
    return TransportError("UNKNOWN_EXTERNAL_ERROR", applied="MAYBE" if write else "NOT_APPLIED", status=s, message="unexpected response")
def _dig(obj, path):
    for k in path:
        if not isinstance(obj, dict) or k not in obj: return None
        obj = obj[k]
    return obj
def _plain(v): raise ValueError(v)
class RestConnector(Connector):
    def __init__(self, config, transport=None, clock=time.time):
        c = self.cfg = config; u = urllib.parse.urlsplit(c.base_url); host = (u.hostname or "").lower()
        if c.auth not in AUTHS: raise ValueError("auth must be one of %s" % (AUTHS,))
        if c.auth != "NONE" and not c.credential_ref: raise ValueError("authentication needs a credential_ref (a secret reference)")
        if c.auth == "OAUTH2_CLIENT_CREDENTIALS" and not c.token_url: raise ValueError("OAuth2 needs a token_url")
        if u.scheme != "https" and not (u.scheme == "http" and c.allow_insecure_loopback and host in LOOPBACK): raise ValueError("base_url must be https")
        if not host or "@" in u.netloc or u.query or u.fragment: raise ValueError("base_url is not acceptable")
        if not c.entities: raise ValueError("at least one entity must be declared")
        if (c.tenant_header is None) != (c.tenant_id is None): raise ValueError("tenant_header and tenant_id must be given together")
        if c.tenant_header is not None:
            h = c.tenant_header.lower() if isinstance(c.tenant_header, str) else None
            if not (isinstance(c.tenant_header, str) and HEADER_NAME.match(c.tenant_header)) or h in RESERVED_HEADERS: raise ValueError("tenant_header is not an acceptable header name")
            if h in {(c.auth_header or "").lower() if c.auth == "API_KEY" else None, (c.idempotency_header or "").lower() or None}: raise ValueError("tenant_header collides with a header the connector sets itself")
            if not (isinstance(c.tenant_id, str) and TENANT_ID.match(c.tenant_id)): raise ValueError("tenant_id is not acceptable")
        for name, e in c.entities.items():
            if not NAME.match(name): raise ValueError("entity name %r is not acceptable" % name)
            for ep in (e.get("list"), e.get("write"), c.lookup):
                if ep is not None and (ep.pagination not in PAGINATIONS or not all(isinstance(x, str) and x for x in (ep.cursor_param, ep.page_size_param, ep.offset_param, ep.page_param))): raise ValueError("endpoint %r has an unacceptable pagination setting" % (ep,))
                if ep is not None and (not ep.path.startswith("/") or ep.method not in ("GET",) + WRITES or set(PLACE.findall(ep.path)) - {"{id}", "{key}"}): raise ValueError("endpoint %r is not acceptable" % (ep,))
        self.connector_id, self.connector_version, self.clock = c.connector_id, c.version, clock
        self.t = transport or HttpTransport(c.allowed_hosts, allow_insecure_loopback=c.allow_insecure_loopback, connect_timeout=c.connect_timeout, request_timeout=c.request_timeout, max_response_bytes=c.max_response_bytes, total_deadline=c.total_deadline)
        self.oauth = OAuth2ClientCredentials(self.t, c.token_url, scope=c.scope, auth_style=c.token_auth_style, clock=clock) if c.auth == "OAUTH2_CLIENT_CREDENTIALS" else None; self._secret = None; self._cid = None
    def __repr__(self): return "RestConnector(%s %s)" % (self.connector_id, self.connector_version)
    def descriptor(self):
        c = self.cfg; return build_descriptor(connector_id=c.connector_id, version=c.version, protocol_class="REST", display_name="Generic REST connector (extension)", auth_handling=c.auth, credential_ref=c.credential_ref, idempotent_writes=bool(c.idempotency_header), reconciliation=c.lookup is not None, max_page_size=c.max_page_size)
    def connect(self, credentials):
        c = self.cfg; self._secret = self._cid = None
        if c.auth == "NONE": return
        sec = (credentials or {}).get("secret")
        if not isinstance(sec, str) or not sec: raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", message="no credential")
        if c.auth == "API_KEY": self._secret = Secret(sec); return
        self._cid, csec = split_client_credentials(sec); self._secret = Secret(csec); self.oauth.invalidate(); self.oauth.token(self._cid, csec)       # verify the credential now: a bad one fails at connect, before any call
    def disconnect(self): self._secret = self._cid = None; self.oauth and self.oauth.invalidate()
    def _auth_headers(self):
        c = self.cfg
        if c.auth == "NONE": return {}
        if self._secret is None: raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", message="not connected")
        if c.auth == "API_KEY": return {c.auth_header: c.auth_prefix + self._secret.reveal()}
        return {"Authorization": "Bearer " + self.oauth.token(self._cid, self._secret.reveal()).reveal()}
    def _url(self, path, **params):
        for k, v in params.items():
            v = str(v)
            if not v or v in (".", "..") or len(v) > 200 or "\x00" in v: raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable path parameter")
            path = path.replace("{%s}" % k, urllib.parse.quote(v, safe=""))
        return self.cfg.base_url.rstrip("/") + path
    def _json(self, r):
        if r.status == 204 or not r.body: return {}
        if "json" not in r.headers.get("content-type", "").lower(): raise MalformedResponse("response is not JSON")
        try: return json.loads(r.body.decode("utf-8"), parse_constant=_plain)
        except (ValueError, UnicodeDecodeError): raise MalformedResponse("response is not valid JSON")
    def _call(self, method, url, *, query=None, body=None, extra=None):
        write = method in WRITES; hdrs = {"Accept": "application/json"}
        if self.cfg.tenant_header: hdrs[self.cfg.tenant_header] = self.cfg.tenant_id
        hdrs.update(self._auth_headers()); hdrs.update(extra or {})
        if body is not None: hdrs["Content-Type"] = "application/json"
        if query: url += "?" + urllib.parse.urlencode(query)
        r = self.t.request(method, url, headers=hdrs, body=body)
        if r.status == 401 and self.oauth: self.oauth.invalidate()
        return r, write
    def _ok(self, r, write):
        if not (200 <= r.status <= 299): raise error_for_status(r, write)
        return r
    def health(self):
        if not self.cfg.health_path: return {"status": "unknown"}
        r, w = self._call("GET", self._url(self.cfg.health_path)); return {"status": "up" if 200 <= r.status <= 299 else "down", "http_status": r.status}
    def discover(self):
        r, w = self._call("GET", self._url(self.cfg.discover_path)); d = self._json(self._ok(r, w))
        if not isinstance(d, dict): raise MalformedResponse("discovery response is not an object")
        return d
    def _page_query(self, ep, size, cur):
        """The query for one page. cursor: as rev7. offset/page: a bounded decimal position. link: the server's own next-page query, replayed verbatim (never built from anything else)."""
        if ep.pagination == "cursor":
            q = {ep.page_size_param: size}
            if cur is not None: q[ep.cursor_param] = cur
            return q
        if ep.pagination == "link":
            if cur is None: return {ep.page_size_param: size}
            try: pairs = urllib.parse.parse_qsl(cur, keep_blank_values=True, strict_parsing=True, max_num_fields=20)
            except ValueError: raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable cursor")
            if not pairs or urllib.parse.urlencode(pairs) != cur: raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable cursor")
            return pairs
        n = self._position(cur, 0 if ep.pagination == "offset" else 1)
        return {ep.page_size_param: size, (ep.offset_param if ep.pagination == "offset" else ep.page_param): n}
    @staticmethod
    def _position(cur, first):
        if cur is None: return first
        if not (cur.isascii() and cur.isdigit()) or len(cur) > 10 or int(cur) < first or int(cur) > 10 ** 9: raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable cursor")
        return int(cur)
    def _next_cursor(self, ep, body, items, cur, r):
        if ep.pagination == "cursor":
            nxt = _dig(body, ep.next_cursor_path) if isinstance(body, dict) else None
            if isinstance(nxt, bool) or nxt in (None, "", 0): return None
            if isinstance(nxt, (str, int)): return str(nxt)
            raise MalformedResponse("next cursor is not a string or integer")
        if ep.pagination == "link": return self._link_cursor(ep, r.headers.get("link"))
        offset = ep.pagination == "offset"; here = self._position(cur, 0 if offset else 1); total = _dig(body, ep.total_items_path if offset else ep.total_pages_path) if (isinstance(body, dict) and (ep.total_items_path if offset else ep.total_pages_path)) else None
        if not items: return None                                                          # an empty page is always the end; a short page is NOT (a server may clamp the page size)
        if total is not None:
            if isinstance(total, bool) or not isinstance(total, int) or total < 0: raise MalformedResponse("total is not a non-negative integer")
            if (here + len(items) >= total) if offset else (here >= total): return None
        return str(here + len(items) if offset else here + 1)
    def _link_cursor(self, ep, header):
        """The query of a same-origin, same-endpoint rel=next link, or None. Anything else is refused: a server-supplied URL must never steer this connector to another host, path or scheme."""
        if header is None: return None
        if len(header) > 4096: raise MalformedResponse("link header is too long")
        for m in LINK.finditer(header):
            rel = REL.search(m.group(2))
            if not rel or "next" not in (rel.group(1) or rel.group(2) or "").lower().split(): continue
            base = urllib.parse.urlsplit(self._url(ep.path)); u = urllib.parse.urlsplit(urllib.parse.urljoin(self._url(ep.path), m.group(1)))
            if (u.scheme, u.netloc.lower(), u.path) != (base.scheme, base.netloc.lower(), base.path) or u.fragment or "@" in u.netloc or not u.query or len(u.query) > 2048: raise MalformedResponse("next link leaves the endpoint")
            try: pairs = urllib.parse.parse_qsl(u.query, keep_blank_values=True, strict_parsing=True, max_num_fields=20)
            except ValueError: raise MalformedResponse("next link query is not acceptable")
            cursor = urllib.parse.urlencode(pairs)                                           # canonical form, so the cursor handed back is exactly what _page_query will accept
            if not pairs or len(cursor) > 512: raise MalformedResponse("next link query is not acceptable")
            return cursor
        if NEXTISH.search(header): raise MalformedResponse("link header names a next page but could not be understood")                # never let a header we cannot read look like 'no more pages': that would silently truncate the data
        return None
    def read(self, request):
        c = self.cfg; e = c.entities.get(request.get("entity")) if isinstance(request, dict) else None
        if not e or not e.get("list"): raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED", message="entity is not readable")
        ep = e["list"]; size = max(1, min(int(request.get("page_size") or 50), c.max_page_size)); cur = request.get("cursor")
        if cur is not None and (not isinstance(cur, str) or not cur or len(cur) > 512): raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable cursor")
        q = self._page_query(ep, size, cur)
        r, w = self._call(ep.method, self._url(ep.path), query=q); body = self._json(self._ok(r, w)); items = body if (not ep.items_path and isinstance(body, list)) else _dig(body, ep.items_path)
        if not isinstance(items, list) or len(items) > c.max_page_size or any(not isinstance(i, dict) for i in items): raise MalformedResponse("page is not a bounded list of objects")
        nxt = self._next_cursor(ep, body, items, cur, r)
        return {"items": items, "next_cursor": nxt, "complete": nxt is None}
    def write(self, request):
        c = self.cfg; e = c.entities.get(request.get("entity")); ep = e.get("write") if e else None
        if not ep: raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED", message="entity is not writable")
        key, fields = request.get("idempotency_key"), request.get("fields")
        if not isinstance(fields, dict) or (c.idempotency_header and (not isinstance(key, str) or not IDEM.match(key))): raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable write request")
        rid = request.get("id"); body = json.dumps(fields, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        r, w = self._call(ep.method, self._url(ep.path, id=rid), body=body, extra={c.idempotency_header: key} if c.idempotency_header else None); data = self._json(self._ok(r, w))
        rec = _dig(data, ep.record_path) if ep.record_path else data; ref = rec.get(ep.id_field) if isinstance(rec, dict) else None
        return {"external_reference": str(ref if ref not in (None, "") else rid), "result": {"status": r.status}}
    def lookup_by_idempotency_key(self, key):
        ep = self.cfg.lookup
        if ep is None: raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED", message="reconciliation is not supported")
        if not isinstance(key, str) or not IDEM.match(key): raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", message="unacceptable key")
        r, w = self._call(ep.method, self._url(ep.path, key=key))
        if r.status == 404: return None
        d = self._json(self._ok(r, w)); rec = _dig(d, ep.record_path) if ep.record_path else d; ref = rec.get(ep.id_field) if isinstance(rec, dict) else None
        if ref in (None, ""): raise MalformedResponse("lookup response has no reference")
        return {"external_reference": str(ref), "result": {"status": r.status}}
    def subscribe(self, request): raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED", message="use the webhook receiver")
    def unsubscribe(self, request): return {"unsubscribed": True}
    def capabilities(self): return {"read": True, "write": any(e.get("write") for e in self.cfg.entities.values()), "discover": True}

"""The AUIF extension connector conformance suite (rev8). A new connector proves itself against a SANDBOX of the target system by subclassing `ConnectorConformanceCases` together with unittest.TestCase and supplying a Target.
It checks behaviour, not names: the descriptor is valid in the real ConnectorRuntime; every failure is normalised to the core's TransportError / MalformedResponse with the right `applied` flag (a read is never 'maybe applied'; a write that may have been sent is);
no secret reaches repr, an error or a URL; paging terminates without duplicates; an idempotent write has one effect; reconciliation works when it is claimed; redirects are never followed; disconnect forgets the credential.
No core change is needed to add a connector, and this suite is the gate a new connector must pass before it is used anywhere. Standard library only; it never contacts a real system unless the author's Target does, and AUIF's own tests use local loopback servers only.

Target protocol (the author implements it over THEIR sandbox):
  canary: str                     the credential value that must never leak            ENTITY: str              the readable entity name           ID_FIELD: str   the id key of a record
  WRITE: dict                     a valid write request WITHOUT idempotency_key
  faults: set                     the faults this target can inject (see FAULTS); at least MINIMUM_FAULTS are required
  start() / stop()                lifecycle                                           credentials() -> dict    what connector.connect() receives
  connector() -> Connector        a NEW, UNCONNECTED connector aimed at this target, with short timeouts (request timeout 1 s or less)
  seed(n)                         make exactly n records readable                     inject(fault, count=1)   the next `count` requests suffer this fault
  requests() -> list[dict]        every request the target saw: method, path, query (dict), headers (lowercase dict), body (bytes)
  effects(key) -> int             how many times a write carrying this idempotency key took effect"""
import ast, inspect, unittest
from auif.connector import ConnectorRuntime
from auif.errors import MalformedResponse, TransportError
FAULTS = ("unauthorized", "forbidden", "rate_limited", "server_error", "timeout", "malformed", "dropped_before_apply", "dropped_after_apply", "redirect")
MINIMUM_FAULTS = frozenset({"unauthorized", "server_error", "timeout", "malformed"})
METHODS = ("descriptor", "connect", "disconnect", "health", "discover", "read", "write", "lookup_by_idempotency_key", "subscribe", "unsubscribe", "capabilities")
EXPECT = {"unauthorized": ("AUTHENTICATION_FAILED", False), "forbidden": ("AUTHORIZATION_DENIED_BY_TARGET", False), "rate_limited": ("RATE_LIMITED", False), "server_error": ("UNAVAILABLE", True), "timeout": ("TIMEOUT", True), "redirect": ("TARGET_REJECTED_REQUEST", False)}   # code, may-be-applied-for-a-write
SOCKET_MODULES = frozenset({"socket", "ssl", "http", "urllib.request", "ftplib", "smtplib", "telnetlib", "xmlrpc", "asyncio"})
def texts(exc):
    out = [str(exc), repr(exc), getattr(exc, "message", "") or ""] + [str(a) for a in exc.args] + [str(v) for v in getattr(exc, "__dict__", {}).values()]
    if exc.__cause__: out += texts(exc.__cause__)
    if exc.__context__: out += texts(exc.__context__)
    return out
class ConnectorConformanceCases:
    """Mix in with unittest.TestCase and set `target_factory` (a zero-argument callable returning a Target) and, optionally, `connector_modules` (the connector's MODULE OBJECTS to screen for sockets)."""
    target_factory = None; connector_modules = ()
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        if cls.target_factory is None: raise unittest.SkipTest("abstract conformance cases: no target_factory")
    def setUp(self):
        self.t = type(self).target_factory(); self.t.start(); self.addCleanup(self.t.stop); self.fresh = []
    def conn(self, connected=True):
        c = self.t.connector(); self.fresh.append(c)
        if connected: c.connect(self.t.credentials())
        return c
    def declared(self, fault): return fault in self.t.faults
    def raised(self, fn):
        try: fn()
        except (TransportError, MalformedResponse) as e: return e
        except Exception as e: self.fail("a failure escaped as %s (it must be TransportError or MalformedResponse): %s" % (type(e).__name__, str(e)[:100]))
        self.fail("the call succeeded although a fault was injected")
    def read(self, c, **kw): return c.read(dict({"entity": self.t.ENTITY, "page_size": 5}, **kw))
    def write_req(self, key): return dict(self.t.WRITE, idempotency_key=key)
    # --- the declaration, the descriptor and the interface -------------------------------------------------------------------------------------------------------------------------
    def test_the_target_declares_at_least_the_minimum_faults_and_only_known_ones(self):
        self.assertTrue(MINIMUM_FAULTS <= set(self.t.faults), "undeclared minimum faults: %s" % sorted(MINIMUM_FAULTS - set(self.t.faults))); self.assertTrue(set(self.t.faults) <= set(FAULTS))
    def test_every_contract_method_exists_and_capabilities_are_declared(self):
        c = self.conn(False)
        for m in METHODS: self.assertTrue(callable(getattr(c, m, None)), "missing connector method: " + m)
        caps = c.capabilities(); self.assertIsInstance(caps, dict); self.assertTrue(all(isinstance(v, bool) for v in caps.values()), "capabilities must be booleans")
    def test_the_descriptor_is_valid_in_the_real_connector_runtime_and_holds_no_secret(self):
        from auif.clock import FakeClock; from auif.observability import Telemetry; from auif.throttle import Throttle
        c = self.conn(False); d = c.descriptor(); clk = FakeClock()
        ConnectorRuntime(c, secrets=None, throttle=Throttle(clk, default_rate=10, default_burst=10), telemetry=Telemetry(), clock=clk)          # raises ContractViolation if the descriptor breaks the audited contract
        self.assertNotIn(self.t.canary, repr(d)); self.assertFalse(d["authentication"]["secrets_in_descriptor"]); self.assertFalse(d["isolation"]["target_specific_business_logic"])
    # --- failure normalisation and the `applied` flag -------------------------------------------------------------------------------------------------------------------------
    def test_a_failed_read_is_normalised_and_never_maybe_applied(self):
        for fault, (code, _) in EXPECT.items():
            if not self.declared(fault): continue
            with self.subTest(fault):
                c = self.conn(); self.t.inject(fault); e = self.raised(lambda: self.read(c)); self.assertIsInstance(e, TransportError); self.assertEqual((e.code, e.applied), (code, "NOT_APPLIED"))
        if self.declared("rate_limited"):
            c = self.conn(); self.t.inject("rate_limited"); self.assertIsNotNone(self.raised(lambda: self.read(c)).retry_after, "a 429 with Retry-After must carry retry_after")
        if self.declared("malformed"): c = self.conn(); self.t.inject("malformed"); self.assertIsInstance(self.raised(lambda: self.read(c)), MalformedResponse)
        for fault in ("dropped_before_apply", "dropped_after_apply"):
            if self.declared(fault): c = self.conn(); self.t.inject(fault); e = self.raised(lambda: self.read(c)); self.assertEqual((e.code, e.applied), ("CONNECTION_FAILED", "NOT_APPLIED"))
    def test_a_failed_write_is_maybe_applied_exactly_when_the_request_may_have_reached_the_target(self):
        for fault, (code, maybe) in EXPECT.items():
            if not self.declared(fault): continue
            with self.subTest(fault):
                c = self.conn(); self.t.inject(fault); e = self.raised(lambda: c.write(self.write_req("k-" + fault))); self.assertEqual((e.code, e.applied), (code, "MAYBE" if maybe else "NOT_APPLIED"))
        for fault in ("dropped_before_apply", "dropped_after_apply"):
            if self.declared(fault):
                with self.subTest(fault): c = self.conn(); self.t.inject(fault); e = self.raised(lambda: c.write(self.write_req("k-" + fault))); self.assertEqual((e.code, e.applied), ("CONNECTION_FAILED", "MAYBE"))
        if self.declared("malformed"): c = self.conn(); self.t.inject("malformed"); self.assertIsInstance(self.raised(lambda: c.write(self.write_req("k-malformed"))), MalformedResponse)
    def test_a_redirect_is_never_followed(self):
        if not self.declared("redirect"): return                                                                        # not declared: nothing to check (test_the_target_declares_at_least_the_minimum_faults... bounds what may be left out)
        c = self.conn(); self.t.inject("redirect"); before = len(self.t.requests()); self.raised(lambda: self.read(c)); self.assertEqual(len(self.t.requests()) - before, 1, "the connector followed a redirect")
    # --- secrets ----------------------------------------------------------------------------------------------------------------------------------------------------------
    def test_the_credential_never_appears_in_repr_errors_or_urls(self):
        c = self.conn(); seen = [repr(c), str(c)]
        for fault in self.t.faults:
            self.t.inject(fault)
            for call in (lambda: self.read(c), lambda: c.write(self.write_req("leak-" + fault))):
                try: call()
                except (TransportError, MalformedResponse) as e: seen += texts(e)
                except Exception as e: self.fail("a failure escaped as %s" % type(e).__name__)
        for s in seen: self.assertNotIn(self.t.canary, s)
        for r in self.t.requests(): self.assertNotIn(self.t.canary, r["path"] + repr(r["query"]), "the credential was sent in a URL")
    def test_an_unconnected_or_disconnected_connector_sends_nothing(self):
        if self.conn(False).descriptor()["authentication"]["handling"] == "NONE": return                                  # no authentication declared: there is no credential to forget
        c = self.conn(False); before = len(self.t.requests()); e = self.raised(lambda: self.read(c)); self.assertEqual((e.code, e.applied), ("AUTHENTICATION_FAILED", "NOT_APPLIED")); self.assertEqual(len(self.t.requests()), before)
        c = self.conn(); c.disconnect(); before = len(self.t.requests()); e = self.raised(lambda: self.read(c)); self.assertEqual(e.code, "AUTHENTICATION_FAILED"); self.assertEqual(len(self.t.requests()), before)
    # --- reading, writing, reconciling -------------------------------------------------------------------------------------------------------------------------------------
    def test_paging_terminates_has_no_duplicates_and_never_returns_a_stuck_cursor(self):
        self.t.seed(23); c = self.conn(); ids, cur, pages = [], None, 0
        while True:
            r = self.read(c, cursor=cur); pages += 1; self.assertLessEqual(pages, 40, "paging did not terminate"); self.assertIsInstance(r["items"], list); self.assertLessEqual(len(r["items"]), c.descriptor()["pagination"]["max_page_size"])
            self.assertEqual(r["complete"], r["next_cursor"] is None); ids += [i[self.t.ID_FIELD] for i in r["items"]]
            if r["next_cursor"] is None: break
            self.assertNotEqual(r["next_cursor"], cur, "the connector returned the cursor it was given: a caller would loop forever"); cur = r["next_cursor"]
        self.assertEqual((len(ids), len(set(ids))), (23, 23))
    def test_a_read_of_nothing_is_a_complete_empty_page(self):
        self.t.seed(0); r = self.read(self.conn()); self.assertEqual((r["items"], r["next_cursor"], r["complete"]), ([], None, True))
    def test_an_idempotent_write_takes_effect_once_and_sends_its_key(self):
        c = self.conn(); a = c.write(self.write_req("idem-1")); b = c.write(self.write_req("idem-1")); self.assertEqual(self.t.effects("idem-1"), 1); self.assertEqual(a["external_reference"], b["external_reference"])
        self.assertTrue(any("idem-1" in repr(r["headers"]) or "idem-1" in r["body"].decode("utf-8", "replace") for r in self.t.requests() if r["method"] != "GET"), "the idempotency key was never sent")
    def test_a_write_whose_answer_was_lost_can_be_reconciled_when_the_connector_claims_it_can(self):
        c = self.conn(); claims = c.descriptor()["idempotency"]["outcome_reconciliation_supported"]
        if claims and self.declared("dropped_after_apply"):
            self.t.inject("dropped_after_apply"); e = self.raised(lambda: c.write(self.write_req("lost-1"))); self.assertEqual(e.applied, "MAYBE"); self.assertEqual(self.t.effects("lost-1"), 1)
            found = c.lookup_by_idempotency_key("lost-1"); self.assertTrue(found and found["external_reference"], "reconciliation did not find the applied write"); self.assertIsNone(c.lookup_by_idempotency_key("never-sent"))
        elif not claims:
            e = self.raised(lambda: c.lookup_by_idempotency_key("k")); self.assertEqual((e.code, e.applied), ("UNSUPPORTED_OPERATION", "NOT_APPLIED"))
    # --- source hygiene (a quick screen; tools/static_checks_ext.py is the full gate) -------------------------------------------------------------------------------------------
    def test_connector_modules_open_no_sockets_of_their_own(self):
        for mod in type(self).connector_modules:
            name = mod.__name__; tree = ast.parse(inspect.getsource(mod))
            for n in ast.walk(tree):
                mods = [a.name for a in n.names] if isinstance(n, ast.Import) else [n.module or ""] if isinstance(n, ast.ImportFrom) and not n.level else []
                for m in mods: self.assertFalse(m in SOCKET_MODULES or m.split(".")[0] in {"socket", "ssl", "http", "asyncio"}, "%s imports %s: use auif_ext.connectors.http_client, the only module that opens a socket" % (name, m))

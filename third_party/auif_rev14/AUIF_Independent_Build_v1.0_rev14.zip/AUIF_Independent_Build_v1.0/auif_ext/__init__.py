"""AUIF extensions (rev8 candidate, building on the rev7 extension candidate). Concrete, reusable implementations that OPERATIONALISE the audited AUIF contracts: a connector kit, a module client and a Governor adapter.
They are EXTENSION implementations, not locked architecture requirements, and they live OUTSIDE the audited core: the core (auif/) imports nothing from here, and nothing here modifies it.
Python standard library plus the audited auif package only. No real external system is named anywhere in this package; real systems are added later as one connector + translation pack each."""
EXTENSION_VERSION = "0.1.0"

"""A fault-injecting loopback 'sandbox' of a generic REST system, used to run the conformance suite against the RestConnector (TEST-ONLY)."""
import threading, time, urllib.parse
from auif_ext.connectors.rest import Endpoint, RestConfig, RestConnector
from auif_ext.tests.loopback import DROP, LoopbackServer, jresp
from auif_ext.conformance.suite import FAULTS
CANARY = "CANARY-s3cr3t-7731"
class RestSandbox:
    ENTITY, ID_FIELD, WRITE = "Account", "id", {"entity": "Account", "id": "r1", "fields": {"name": "x"}}; faults = set(FAULTS); canary = CANARY
    def __init__(self, style="cursor", auth="API_KEY"):
        self.style, self.auth, self.records, self.fault_q, self.store, self.lock = style, auth, [], [], {}, threading.Lock(); self.srv = None
    def start(self): self.srv = LoopbackServer(self.handle).start()
    def stop(self): self.srv.stop()
    def credentials(self): return {"secret": CANARY} if self.auth != "NONE" else {}
    def seed(self, n): self.records = [{"id": "r%d" % i} for i in range(1, n + 1)]
    def inject(self, fault, count=1):
        assert fault in FAULTS
        with self.lock: self.fault_q += [fault] * count
    def requests(self): return list(self.srv.requests)
    def effects(self, key): return 1 if key in self.store else 0
    def connector(self):
        ep = dict(items_path=("items",), pagination=self.style, total_items_path=("total",) if self.style == "offset" else None)
        return RestConnector(RestConfig(connector_id="conf-rest", version="1.0.0", base_url=self.srv.url, allowed_hosts=(self.srv.host,), credential_ref="secretref:conf", auth=self.auth, allow_insecure_loopback=True, connect_timeout=0.4, request_timeout=0.4, total_deadline=1.0,
            entities={"Account": {"list": Endpoint(path="/accounts", **ep), "write": Endpoint(method="PATCH", path="/accounts/{id}", id_field="external_reference")}}, lookup=Endpoint(path="/idempotency/{key}", id_field="external_reference")))
    def handle(self, method, path, q, h, body):
        with self.lock: fault = self.fault_q.pop(0) if self.fault_q else None
        if fault == "unauthorized": return jresp({"error": "no"}, 401)
        if fault == "forbidden": return jresp({"error": "no"}, 403)
        if fault == "rate_limited": return jresp({"error": "slow"}, 429, {"Retry-After": "7"})
        if fault == "server_error": return jresp({"error": "down"}, 503)
        if fault == "timeout": time.sleep(1.2); return jresp({})
        if fault == "malformed": return 200, {"Content-Type": "text/html"}, b"<html>oops</html>"
        if fault == "redirect": return 302, {"Location": "/elsewhere"}, b""
        if fault == "dropped_before_apply" or (fault == "dropped_after_apply" and method == "GET"): return DROP                 # a read has nothing to apply: it is simply lost
        if self.auth != "NONE" and h.get("authorization") != "Bearer " + CANARY: return jresp({"error": "unauthorised"}, 401)
        if method == "GET" and path == "/accounts": return self.page(q)
        if method == "PATCH" and path.startswith("/accounts/"):
            key = h.get("idempotency-key"); ref = self.store.setdefault(key, "ext-" + urllib.parse.unquote(path.rsplit("/", 1)[1]))            # a repeated key does not take effect twice
            return DROP if fault == "dropped_after_apply" else jresp({"external_reference": ref})
        if method == "GET" and path.startswith("/idempotency/"):
            ref = self.store.get(urllib.parse.unquote(path.rsplit("/", 1)[1])); return jresp({"external_reference": ref}) if ref else jresp({"error": "none"}, 404)
        return jresp({"error": "not found"}, 404)
    def page(self, q):
        lim = int(q.get("limit", 5)); n = len(self.records)
        if fault_free := True:
            if self.style == "cursor": a = int(q.get("cursor", 0)); b = a + lim; return jresp({"items": self.records[a:b], "next_cursor": str(b) if b < n else None})
            if self.style == "offset": a = int(q["offset"]); return jresp({"items": self.records[a:a + lim], "total": n})
            pg = int(q.get("page", 1)); a = (pg - 1) * lim; items = self.records[a:a + lim]
            if self.style == "page": return jresp({"items": items})
            link = {"Link": '<%s/accounts?page=%d&limit=%d>; rel="next"' % (self.srv.url, pg + 1, lim)} if a + lim < n else None; return jresp({"items": items}, headers=link)

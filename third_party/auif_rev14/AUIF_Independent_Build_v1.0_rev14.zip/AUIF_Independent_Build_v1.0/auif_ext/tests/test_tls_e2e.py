"""rev8: REAL TLS, end to end, over loopback with throwaway test certificates (see fixtures/tls/README.md). rev7 proved only that a TLS context is honoured; these tests perform genuine handshakes."""
import os, ssl, unittest
from auif.errors import TransportError
from auif_ext.connectors.http_client import HttpTransport
from auif_ext.connectors.rest import Endpoint, RestConfig, RestConnector
import time
from auif_ext.tests.loopback import DripServer, LoopbackServer, jresp
FIX = os.path.join(os.path.dirname(__file__), "fixtures", "tls")
def pair(name): return os.path.join(FIX, name + ".cert.pem"), os.path.join(FIX, name + ".key.pem")
def trusting(name): return ssl.create_default_context(cafile=pair(name)[0])                # the client trusts exactly this certificate and still verifies hostname and dates
def serve(name, handler=None): return LoopbackServer(handler or (lambda *a: jresp({"ok": True})), tls=pair(name))
class TestRealTls(unittest.TestCase):
    def test_a_verified_https_exchange_succeeds_end_to_end(self):
        with serve("good") as s:
            self.assertTrue(s.url.startswith("https://")); r = HttpTransport([s.host], ssl_context=trusting("good")).request("GET", s.url + "/x")
            self.assertEqual((r.status, r.body), (200, b'{"ok": true}')); self.assertEqual(len(s.requests), 1)
    def test_the_default_trust_store_refuses_an_untrusted_certificate_and_nothing_is_sent(self):
        with serve("good") as s:
            for method, body in (("GET", None), ("POST", b"{}")):
                with self.subTest(method), self.assertRaises(TransportError) as e: HttpTransport([s.host]).request(method, s.url + "/x", body=body)          # no ssl_context: the system trust store, which does not know the fixture
                self.assertEqual((e.exception.code, e.exception.applied), ("CONNECTION_FAILED", "NOT_APPLIED"))                                           # a WRITE that fails the handshake is still NOT_APPLIED
            self.assertEqual(s.requests, [])
    def test_a_certificate_for_another_host_is_refused_even_when_trusted(self):
        with serve("wronghost") as s:
            with self.assertRaises(TransportError) as e: HttpTransport([s.host], ssl_context=trusting("wronghost")).request("POST", s.url + "/x", body=b"{}")
            self.assertEqual((e.exception.code, e.exception.applied), ("CONNECTION_FAILED", "NOT_APPLIED")); self.assertEqual(s.requests, [])
    def test_an_expired_certificate_is_refused_even_when_trusted(self):
        with serve("expired") as s:
            with self.assertRaises(TransportError) as e: HttpTransport([s.host], ssl_context=trusting("expired")).request("GET", s.url + "/x")
            self.assertEqual((e.exception.code, e.exception.applied), ("CONNECTION_FAILED", "NOT_APPLIED")); self.assertEqual(s.requests, [])
    def test_https_to_a_plaintext_server_fails_and_a_tls_server_is_not_reachable_as_plain_http_by_policy(self):
        with LoopbackServer(lambda *a: jresp({})) as plain:
            with self.assertRaises(TransportError) as e: HttpTransport([plain.host], ssl_context=trusting("good")).request("GET", "https://" + plain.host + "/x")
            self.assertEqual((e.exception.code, e.exception.applied), ("CONNECTION_FAILED", "NOT_APPLIED"))
        with serve("good") as s:
            with self.assertRaises(TransportError) as e: HttpTransport([s.host]).request("GET", "http://" + s.host + "/x")                     # no insecure flag: refused by policy before any socket opens
            self.assertEqual(e.exception.message, "plain http is refused"); self.assertEqual(s.requests, [])
    def test_tls_errors_reveal_nothing_about_the_certificate_the_host_or_the_request(self):
        with serve("wronghost") as s:
            with self.assertRaises(TransportError) as e: HttpTransport([s.host], ssl_context=trusting("wronghost")).request("GET", s.url + "/secret-path?token=abc")
            text = (str(e.exception) + e.exception.message).lower()
            for leak in ("127.0.0.1", "other.example", "secret-path", "abc", "certificate", "pem", "verify"): self.assertNotIn(leak, text)
    def test_the_default_context_verifies_certificates_and_hostnames_and_requires_modern_tls(self):
        c = HttpTransport(["h.test"]).ctx; self.assertTrue(c.check_hostname); self.assertEqual(c.verify_mode, ssl.CERT_REQUIRED); self.assertGreaterEqual(c.minimum_version, ssl.TLSVersion.TLSv1_2)
    def test_a_rest_connector_works_over_verified_tls_with_an_api_key_and_refuses_an_untrusted_server(self):
        ents = {"Account": {"list": Endpoint(path="/accounts", items_path=("items",))}}
        seen = []
        def api(m, p, q, h, b): seen.append(h.get("authorization")); return jresp({"items": [{"id": "1"}], "next_cursor": None})
        with serve("good", api) as s:
            def conn(tr): return RestConnector(RestConfig(connector_id="tls-rest", version="1", base_url=s.url, allowed_hosts=(s.host,), credential_ref="secretref:x", auth="API_KEY", entities=ents), transport=tr)
            c = conn(HttpTransport([s.host], ssl_context=trusting("good"))); c.connect({"secret": "key-123"}); self.assertEqual(c.read({"entity": "Account"})["items"], [{"id": "1"}]); self.assertEqual(seen, ["Bearer key-123"])
            u = conn(HttpTransport([s.host])); u.connect({"secret": "key-456"})
            with self.assertRaises(TransportError) as e: u.read({"entity": "Account"})
            self.assertEqual((e.exception.code, e.exception.applied), ("CONNECTION_FAILED", "NOT_APPLIED")); self.assertEqual(seen, ["Bearer key-123"])               # the credential never reached the untrusted server
class TestTotalDeadlineOverRealTls(unittest.TestCase):
    """The deadline cuts a socket from a timer thread; an SSL socket reacts differently from a plain one, so it is proven over a real TLS session."""
    LEAD = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 400\r\nConnection: close\r\n\r\n"
    def timed(self, method, lead, drip):
        with DripServer(lead, drip, interval=0.15, tls=pair("good")) as s:
            t0 = time.monotonic()
            with self.assertRaises(TransportError) as e: HttpTransport([s.host], ssl_context=trusting("good"), request_timeout=5.0, total_deadline=1.0).request(method, s.url + "/x", body=b"{}" if method != "GET" else None)
            return e.exception, time.monotonic() - t0
    def test_a_slow_body_over_tls_is_cut_off_and_is_a_normalised_timeout(self):
        for method, applied in (("GET", "NOT_APPLIED"), ("POST", "MAYBE")):
            with self.subTest(method): e, dt = self.timed(method, self.LEAD, b"x" * 400); self.assertEqual((e.code, e.applied), ("TIMEOUT", applied)); self.assertLess(dt, 3.0)
    def test_slow_headers_over_tls_are_cut_off_too(self):
        for method, applied in (("GET", "NOT_APPLIED"), ("POST", "MAYBE")):
            with self.subTest(method): e, dt = self.timed(method, b"", self.LEAD + b"x" * 400); self.assertEqual((e.code, e.applied), ("TIMEOUT", applied)); self.assertLess(dt, 3.0)
    def test_a_body_with_no_length_framing_cut_short_over_tls_is_never_accepted(self):
        lead = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n"
        e, dt = self.timed("POST", lead, b'{"a": 1' + b" " * 300); self.assertEqual((e.code, e.applied), ("TIMEOUT", "MAYBE"))
if __name__ == "__main__": unittest.main()

"""A Governor contract TEST DOUBLE (TEST-ONLY). It mirrors the NAMES and SHAPES of Governor's Universal Adapter Contract (v1.2 section 2) as implemented in the R14 reference code, so the adapter can be tested without Governor present.
It contains no Governor logic. The same checks also run against the real R14 code when AUIF_GOVERNOR_R14_ZIP is supplied (see test_governor_adapter.py)."""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from types import SimpleNamespace
from typing import Any, Dict, List, Optional
SCHEMA_VERSION = "1.2.0"
class Capability(str, Enum):
    OBSERVATION = "observation"; ATTESTATION = "attestation"; RUNTIME_STATE_OBSERVATION = "runtime_state_observation"; EVENT_STREAM = "event_stream"; MANIFEST_DECLARATION = "manifest_declaration"; NORMALIZATION = "normalization"; DECISION_DELIVERY = "decision_delivery"
class NeutralConcept(str, Enum):
    COMPONENT = "Component"; CONTRACT = "Contract"; DEPENDENCY = "Dependency"; RESOURCE = "Resource"; OBSERVATION = "Observation"; EVIDENCE = "Evidence"; CHANGE = "Change"; ENVIRONMENT = "Environment"; CAPABILITY = "Capability"
@dataclass(frozen=True)
class NeutralObject:
    schema_version: str; concept: NeutralConcept; id: str; tenant_id: str; target_system_id: str; environment_id: str; declared_metadata: Dict[str, Any] = field(default_factory=dict); classification: Optional[str] = None; observed_at: float = 0.0
@dataclass(frozen=True)
class RawObservation:
    source_adapter_id: str; target_native_representation: Dict[str, Any]; observed_at: float; failure: Optional[str] = None
@dataclass(frozen=True)
class Attestation:
    source_adapter_id: str; observation_ref: str; provenance: Dict[str, Any]; signature: Optional[str] = None
@dataclass(frozen=True)
class NormalizedObject:
    neutral_object: Any; target_declared_classification: Optional[str] = None
@dataclass(frozen=True)
class TargetEvent:
    source_adapter_id: str; canonical_event_type: str; payload: Dict[str, Any]
class TargetSystemAdapter(ABC):
    @abstractmethod
    def identity(self) -> Dict[str, Any]: ...
    @abstractmethod
    def declared_capabilities(self) -> Dict[Capability, bool]: ...
    @abstractmethod
    def declare(self) -> Dict[str, Any]: ...
    @abstractmethod
    def observe(self) -> List[RawObservation]: ...
    @abstractmethod
    def attest(self, observation: RawObservation) -> Optional[Attestation]: ...
    @abstractmethod
    def normalize(self, observation: RawObservation) -> Optional[NormalizedObject]: ...
    @abstractmethod
    def translate_event(self, native_event: Dict[str, Any]) -> TargetEvent: ...
    @abstractmethod
    def deliver_decision(self, decision: Dict[str, Any]) -> bool: ...
    @abstractmethod
    def health(self) -> Dict[str, Any]: ...
def binding(): return SimpleNamespace(TargetSystemAdapter=TargetSystemAdapter, RawObservation=RawObservation, Attestation=Attestation, NormalizedObject=NormalizedObject, TargetEvent=TargetEvent, Capability=Capability, NeutralObject=NeutralObject, NeutralConcept=NeutralConcept, SCHEMA_VERSION=SCHEMA_VERSION)
def structurally_valid(obj):
    """The double's version of Governor's structural check (the real one is neutral_model.validate): required fields present, identifiers are strings, the concept is a NeutralConcept, the id has at least three dotted parts."""
    return all(isinstance(getattr(obj, f), str) and getattr(obj, f) for f in ("schema_version", "id", "tenant_id", "target_system_id", "environment_id")) and isinstance(obj.concept, NeutralConcept) and obj.id.count(".") >= 2

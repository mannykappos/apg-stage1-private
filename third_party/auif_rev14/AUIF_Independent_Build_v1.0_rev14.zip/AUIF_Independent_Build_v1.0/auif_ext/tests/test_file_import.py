"""The file-import connector: correct imports, and hostile files."""
import json, os, tempfile, unittest
from auif.clock import FakeClock
from auif.connector import ConnectorRuntime
from auif.contracts import validate
from auif.errors import MalformedResponse, TransportError
from auif.observability import Telemetry
from auif.tenancy import TenantAuthority
from auif.throttle import Throttle
from auif_ref.secrets import InMemorySecretStore
from auif_ext.connectors.file_import import FileImportConnector, FileSpec
class Base(unittest.TestCase):
    def setUp(self): self.d = tempfile.mkdtemp(); self.addCleanup(__import__("shutil").rmtree, self.d, True)
    def put(self, name, data, mode="w", enc=None):
        with open(os.path.join(self.d, name), mode, **({"encoding": enc} if enc and "b" not in mode else {})) as f: f.write(data)
    def c(self, **spec): self.spec = FileSpec(**dict(dict(filename="data.csv"), **spec)); return FileImportConnector(self.d, {"Thing": self.spec})
    def rows(self, c=None):
        c = c or self.c(); out, cur = [], None
        while True:
            p = c.read({"entity": "Thing", "cursor": cur, "page_size": 2}); out += p["items"]; cur = p["next_cursor"]
            if p["complete"]: return out
class TestCsv(Base):
    def test_a_csv_is_read_page_by_page(self):
        self.put("data.csv", "id,name\n1,Ann\n2,Bo\n3,Cy\n"); self.assertEqual(self.rows(), [{"id": "1", "name": "Ann"}, {"id": "2", "name": "Bo"}, {"id": "3", "name": "Cy"}])
        p = self.c().read({"entity": "Thing", "page_size": 2}); self.assertEqual((len(p["items"]), p["next_cursor"], p["complete"]), (2, "2", False))
    def test_values_are_strings_unless_a_type_is_declared_and_never_guessed(self):
        self.put("data.csv", "id,age,price,ok,note\n007,34,12.50,TRUE,5\n"); r = self.rows(self.c(types={"age": "integer", "price": "decimal", "ok": "boolean"}))[0]
        self.assertEqual(r, {"id": "007", "age": 34, "price": "12.50", "ok": True, "note": "5"})                      # '007' and the undeclared '5' stay strings
    def test_an_empty_typed_cell_is_none_and_a_value_that_does_not_fit_invalidates_the_page(self):
        self.put("data.csv", "id,age\n1,\n"); self.assertEqual(self.rows(self.c(types={"age": "integer"}))[0]["age"], None)
        for bad, t in (("abc", "integer"), ("1.5", "integer"), ("12.3.4", "decimal"), ("yes", "boolean"), ("1e5", "decimal"), ("9" * 20, "integer")):
            with self.subTest((bad, t)):
                self.put("data.csv", "id,v\n1,%s\n" % bad)
                with self.assertRaises(MalformedResponse): self.c(types={"v": t}).read({"entity": "Thing"})
    def test_bom_delimiter_and_quoting(self):
        self.put("data.csv", "\ufeffid;name\n1;\"A; B\"\n", enc="utf-8"); self.assertEqual(self.rows(self.c(delimiter=";")), [{"id": "1", "name": "A; B"}])
    def test_discovery_describes_columns_with_declared_types_and_validates_as_a_descriptor_source(self):
        self.put("data.csv", "id,age\n1,2\n"); c = self.c(types={"age": "integer"}); d = c.discover(); self.assertEqual(d["entities"][0]["fields"], [{"name": "id", "type": "string"}, {"name": "age", "type": "integer"}]); self.assertEqual(d["operations"][0], {"name": "read_Thing", "kind": "read", "entities": ["Thing"]}); validate("connector#ConnectorDescriptor", c.descriptor())
class TestJson(Base):
    def test_a_json_list_and_a_nested_items_path(self):
        self.put("data.json", json.dumps([{"id": 1, "n": "a"}, {"id": 2}])); self.assertEqual(self.rows(self.c(filename="data.json", fmt="json")), [{"id": 1, "n": "a"}, {"id": 2}])
        self.put("data.json", json.dumps({"payload": {"records": [{"id": 1}]}})); self.assertEqual(self.rows(self.c(filename="data.json", fmt="json", items_path=("payload", "records"))), [{"id": 1}])
    def test_hostile_json_is_refused(self):
        for label, text in (("not json", "{oops"), ("NaN", '[{"a": NaN}]'), ("Infinity", '[{"a": Infinity}]'), ("not a list", '{"a": 1}'), ("items not objects", "[1, 2]"), ("scalar", "5"), ("deep nesting", "[" * 100000)):
            with self.subTest(label):
                self.put("data.json", text)
                with self.assertRaises(MalformedResponse): self.c(filename="data.json", fmt="json").read({"entity": "Thing"})
    def test_a_missing_items_path_is_refused(self):
        self.put("data.json", '{"a": []}')
        with self.assertRaises(MalformedResponse): self.c(filename="data.json", fmt="json", items_path=("x",)).read({"entity": "Thing"})
class TestHostileFiles(Base):
    def test_unsafe_file_names_are_refused_at_construction(self):
        for name in ("../x.csv", "/etc/passwd", "a/b.csv", ".hidden", "", "a b.csv", "x" * 200 + ".csv", "..", "a\x00.csv", "-rf"):
            with self.subTest(name):
                with self.assertRaises(ValueError): FileImportConnector(self.d, {"Thing": FileSpec(name)})
    def test_unacceptable_declarations_are_refused(self):
        for label, files in (("none", {}), ("bad entity", {"../e": FileSpec("a.csv")}), ("bad format", {"T": FileSpec("a.csv", fmt="xml")}), ("bad delimiter", {"T": FileSpec("a.csv", delimiter=";;")}), ("bad type", {"T": FileSpec("a.csv", types={"x": "blob"})})):
            with self.subTest(label):
                with self.assertRaises(ValueError): FileImportConnector(self.d, files)
    def test_a_symlink_is_refused_even_when_it_points_inside_the_directory(self):
        self.put("real.csv", "id\n1\n"); os.symlink(os.path.join(self.d, "real.csv"), os.path.join(self.d, "data.csv"))
        with self.assertRaises(MalformedResponse): self.c().read({"entity": "Thing"})
    def test_a_symlink_to_a_file_outside_the_directory_is_refused(self):
        outside = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False); outside.write("id\nSECRET\n"); outside.close(); self.addCleanup(os.unlink, outside.name); os.symlink(outside.name, os.path.join(self.d, "data.csv"))
        with self.assertRaises(MalformedResponse): self.c().read({"entity": "Thing"})
    def test_a_directory_or_special_file_in_place_of_the_file_is_refused(self):
        os.mkdir(os.path.join(self.d, "data.csv"))
        with self.assertRaises(MalformedResponse): self.c().read({"entity": "Thing"})
    def test_size_and_row_limits(self):
        self.put("data.csv", "id\n" + "1\n" * 50)
        with self.assertRaises(MalformedResponse): self.c(max_bytes=20).read({"entity": "Thing"})
        with self.assertRaises(MalformedResponse): self.c(max_rows=10).read({"entity": "Thing"})
        self.assertEqual(len(self.rows(self.c(max_rows=50))), 50)                                                      # exactly at the limit is fine
    def test_malformed_csv_is_refused(self):
        for label, text in (("ragged long", "a,b\n1,2,3\n"), ("ragged short", "a,b\n1\n"), ("duplicate header", "a,a\n1,2\n"), ("empty header name", "a,\n1,2\n"), ("no header", ""), ("unterminated quote", 'a,b\n"x,2\n'), ("NUL byte", "a,b\n1,\x002\n")):
            with self.subTest(label):
                self.put("data.csv", text)
                with self.assertRaises(MalformedResponse): self.c().read({"entity": "Thing"})
    def test_invalid_utf8_is_refused(self):
        self.put("data.csv", b"a,b\n\xff\xfe,2\n", mode="wb")
        with self.assertRaises(MalformedResponse): self.c().read({"entity": "Thing"})
    def test_an_oversized_csv_field_is_refused(self):
        self.put("data.csv", "a\n" + "x" * 200000 + "\n")
        with self.assertRaises(MalformedResponse): self.c().read({"entity": "Thing"})
    def test_a_missing_file_is_unavailable_and_not_applied(self):
        with self.assertRaises(TransportError) as e: self.c().read({"entity": "Thing"})
        self.assertEqual((e.exception.code, e.exception.applied), ("UNAVAILABLE", "NOT_APPLIED"))
    def test_cursors_and_entities_are_validated(self):
        self.put("data.csv", "id\n1\n"); c = self.c()
        for cur in ("-1", "abc", "1.5", [1]):
            with self.subTest(cur):
                with self.assertRaises(TransportError) as e: c.read({"entity": "Thing", "cursor": cur})
                self.assertEqual(e.exception.applied, "NOT_APPLIED")
        with self.assertRaises(TransportError) as e: c.read({"entity": "Other"})
        self.assertEqual(e.exception.code, "UNSUPPORTED_OPERATION"); self.assertEqual(c.read({"entity": "Thing", "cursor": "99"}), {"items": [], "next_cursor": None, "complete": True})
    def test_the_page_size_is_clamped(self):
        self.put("data.csv", "id\n" + "1\n" * 500); c = self.c(); self.assertEqual(len(c.read({"entity": "Thing", "page_size": 10 ** 6})["items"]), 200); self.assertEqual(len(c.read({"entity": "Thing", "page_size": 0})["items"]), 50)
class TestContractSurface(Base):
    def test_writes_subscriptions_and_credentials_behave_as_a_read_only_connector(self):
        c = self.c()
        for fn in (lambda: c.write({"entity": "Thing", "id": "1", "fields": {}, "idempotency_key": "k"}), lambda: c.subscribe({})):
            with self.assertRaises(TransportError) as e: fn()
            self.assertEqual((e.exception.code, e.exception.applied), ("UNSUPPORTED_OPERATION", "NOT_APPLIED"))
        self.assertEqual((c.capabilities(), c.unsubscribe({}), c.health()), ({"read": True, "write": False, "discover": True}, {"unsubscribed": True}, {"status": "up"})); c.connect(None); c.disconnect()
    def test_a_missing_base_directory_fails_to_connect_and_reports_down(self):
        c = FileImportConnector(os.path.join(self.d, "gone"), {"Thing": FileSpec("data.csv")})
        with self.assertRaises(TransportError) as e: c.connect(None)
        self.assertEqual(e.exception.code, "CONNECTION_FAILED"); self.assertEqual(c.health(), {"status": "down"})
    def test_under_the_core_runtime_data_no_data_and_invalid_outcomes_are_distinguished(self):
        clk = FakeClock(); ctx = TenantAuthority().issue("tenant-a", "s"); self.put("data.csv", "id\n1\n")
        def rt(c): return ConnectorRuntime(c, secrets=InMemorySecretStore(), throttle=Throttle(clk, default_rate=1000, default_burst=1000), telemetry=Telemetry(), clock=clk)
        r = rt(self.c()); self.assertEqual(r.call(ctx, "i", "s", "e", "read", {"entity": "Thing"}).result["outcome_kind"], "DATA_OBTAINED")
        self.assertEqual(r.call(ctx, "i", "s", "e", "read", {"entity": "Thing", "cursor": "5"}).result["outcome_kind"], "NO_DATA")
        self.put("data.csv", "a,a\n1,2\n"); o = r.call(ctx, "i", "s", "e", "read", {"entity": "Thing"}); self.assertEqual((o.result["outcome_kind"], o.result["error"]["code"]), ("DATA_INVALID", "MALFORMED_RESPONSE"))
        os.unlink(os.path.join(self.d, "data.csv")); o = r.call(ctx, "i", "s", "e", "read", {"entity": "Thing"}); self.assertEqual(o.result["outcome_kind"], "COULD_NOT_OBTAIN")
    def test_a_write_through_the_runtime_is_refused_without_side_effects(self):
        clk = FakeClock(); ctx = TenantAuthority().issue("tenant-a", "s"); r = ConnectorRuntime(self.c(), secrets=InMemorySecretStore(), throttle=Throttle(clk, default_rate=1000, default_burst=1000), telemetry=Telemetry(), clock=clk)
        o = r.call(ctx, "i", "s", "e", "write", {"entity": "Thing", "id": "1", "fields": {}}); self.assertEqual((o.result["error"]["code"], o.may_have_applied), ("UNSUPPORTED_OPERATION", False))
if __name__ == "__main__": unittest.main()

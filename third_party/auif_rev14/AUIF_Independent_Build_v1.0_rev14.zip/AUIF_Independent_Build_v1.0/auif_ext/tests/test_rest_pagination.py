"""rev8: offset, page-number and Link-header pagination for the generic REST connector, over real loopback HTTP. The Link style is checked hardest, because the next URL comes from the server."""
import json, unittest, urllib.parse
from auif.errors import MalformedResponse, TransportError
from auif_ext.connectors.rest import Endpoint, RestConfig, RestConnector
from auif_ext.tests.loopback import LoopbackServer, jresp
DATA = [{"id": "r%d" % i} for i in range(1, 8)]                                       # 7 records
def conn(srv, **ep):
    return RestConnector(RestConfig(connector_id="pg", version="1", base_url=srv.url, allowed_hosts=(srv.host,), auth="NONE", allow_insecure_loopback=True, entities={"Account": {"list": Endpoint(path="/accounts", items_path=("items",), **ep)}}))
def walk(c, size=3, limit=20):
    ids, cur, n = [], None, 0
    while True:
        r = c.read({"entity": "Account", "page_size": size, "cursor": cur}); ids += [i["id"] for i in r["items"]]; n += 1; cur = r["next_cursor"]
        assert r["complete"] == (cur is None); assert n <= limit, "did not terminate"
        if cur is None: return ids, n
def window(q, start, size, clamp=None):
    size = min(size, clamp) if clamp else size; return DATA[start:start + size]
class TestOffset(unittest.TestCase):
    def srv(self, total=True, clamp=None):
        def h(m, p, q, hd, b): off, lim = int(q["offset"]), int(q["limit"]); body = {"items": window(q, off, lim, clamp)}; body.update({"total": len(DATA)} if total else {}); return jresp(body)
        return LoopbackServer(h)
    def test_with_a_total_the_walk_stops_exactly_at_the_end_with_no_extra_request(self):
        with self.srv() as s: ids, n = walk(conn(s, pagination="offset", total_items_path=("total",))); self.assertEqual((ids, n, len(s.requests)), ([d["id"] for d in DATA], 3, 3))
    def test_the_first_request_asks_for_offset_zero_and_later_ones_for_the_running_offset(self):
        with self.srv() as s: walk(conn(s, pagination="offset", total_items_path=("total",))); self.assertEqual([(r["query"]["offset"], r["query"]["limit"]) for r in s.requests], [("0", "3"), ("3", "3"), ("6", "3")])
    def test_without_a_total_only_an_empty_page_ends_the_walk(self):
        with self.srv(total=False) as s: ids, n = walk(conn(s, pagination="offset")); self.assertEqual((ids, n), ([d["id"] for d in DATA], 4))     # 3 + 3 + 1 + the empty page
    def test_a_server_that_clamps_the_page_size_loses_nothing(self):
        with self.srv(total=False, clamp=2) as s: ids, n = walk(conn(s, pagination="offset")); self.assertEqual(ids, [d["id"] for d in DATA])           # a short page is NOT the end
        with self.srv(total=True, clamp=2) as s: ids, n = walk(conn(s, pagination="offset", total_items_path=("total",))); self.assertEqual(ids, [d["id"] for d in DATA])
    def test_unacceptable_offsets_are_refused_before_any_request(self):
        with self.srv() as s:
            c = conn(s, pagination="offset")
            for bad in ("abc", "-1", "1e3", "1.5", " 3", "\u0663", "12345678901", "1000000001", "3 "):
                with self.subTest(bad), self.assertRaises(TransportError) as e: c.read({"entity": "Account", "cursor": bad})
                self.assertEqual((e.exception.code, e.exception.applied), ("TARGET_REJECTED_REQUEST", "NOT_APPLIED"))
            self.assertEqual(s.requests, []); self.assertEqual(c.read({"entity": "Account", "cursor": "0"})["items"], DATA[:50] if False else window({}, 0, 50))
    def test_a_malformed_total_is_refused(self):
        for bad in ('"7"', "-1", "true", "7.5", "null"):
            with self.subTest(bad), LoopbackServer(lambda *a, b=bad: (200, {"Content-Type": "application/json"}, ('{"items": [{"id": "r1"}], "total": %s}' % b).encode())) as s:
                c = conn(s, pagination="offset", total_items_path=("total",))
                if bad == "null": self.assertEqual(c.read({"entity": "Account"})["next_cursor"], "1")        # absent or null total: fall back to the empty-page rule
                else:
                    with self.assertRaises(MalformedResponse): c.read({"entity": "Account"})
class TestPage(unittest.TestCase):
    def srv(self, pages=True):
        def h(m, p, q, hd, b): pg, lim = int(q["page"]), int(q["limit"]); body = {"items": window(q, (pg - 1) * lim, lim)}; body.update({"total_pages": -(-len(DATA) // lim)} if pages else {}); return jresp(body)
        return LoopbackServer(h)
    def test_with_total_pages_the_walk_stops_at_the_last_page(self):
        with self.srv() as s: ids, n = walk(conn(s, pagination="page", total_pages_path=("total_pages",))); self.assertEqual((ids, n, len(s.requests)), ([d["id"] for d in DATA], 3, 3)); self.assertEqual([r["query"]["page"] for r in s.requests], ["1", "2", "3"])
    def test_without_a_total_an_empty_page_ends_it(self):
        with self.srv(pages=False) as s: ids, n = walk(conn(s, pagination="page")); self.assertEqual((ids, n), ([d["id"] for d in DATA], 4))
    def test_page_numbers_start_at_one_and_other_values_are_refused(self):
        with self.srv() as s:
            c = conn(s, pagination="page")
            for bad in ("0", "-2", "x", "", "99999999999"):
                with self.subTest(bad), self.assertRaises(TransportError): c.read({"entity": "Account", "cursor": bad}) if bad else c.read({"entity": "Account", "cursor": bad})
            self.assertEqual(s.requests, [])
    def test_custom_parameter_names_are_used(self):
        seen = []
        def h(m, p, q, hd, b): seen.append(dict(q)); return jresp({"items": []})
        with LoopbackServer(h) as s: conn(s, pagination="page", page_param="p", page_size_param="per").read({"entity": "Account", "page_size": 5}); self.assertEqual(seen, [{"per": "5", "p": "1"}])
class TestLink(unittest.TestCase):
    def srv(self, link_for):
        holder = {}
        def h(m, p, q, hd, b):
            pg, lim = int(q.get("page", 1)), int(q.get("limit", 3)); items = window(q, (pg - 1) * lim, lim); link = link_for(holder["s"], pg, lim, bool(DATA[pg * lim:]))
            return jresp({"items": items}, headers={"Link": link} if link else None)
        s = holder["s"] = LoopbackServer(h); return s
    absolute = staticmethod(lambda s, pg, lim, more: '<%s/accounts?page=%d&limit=%d>; rel="next"' % (s.url, pg + 1, lim) if more else None)
    relative = staticmethod(lambda s, pg, lim, more: '</accounts?page=%d&limit=%d>; rel=next' % (pg + 1, lim) if more else None)
    def test_an_absolute_same_origin_next_link_is_followed_to_the_end(self):
        with self.srv(self.absolute) as s: ids, n = walk(conn(s, pagination="link")); self.assertEqual((ids, n), ([d["id"] for d in DATA], 3)); self.assertEqual([r["query"] for r in s.requests], [{"limit": "3"}, {"page": "2", "limit": "3"}, {"page": "3", "limit": "3"}])
    def test_a_relative_next_link_works_and_the_server_query_is_replayed_verbatim_not_extended(self):
        with self.srv(self.relative) as s: ids, n = walk(conn(s, pagination="link")); self.assertEqual(ids, [d["id"] for d in DATA]); self.assertTrue(all(len(r["path"]) and r["path"] == "/accounts" for r in s.requests)); self.assertEqual(s.requests[1]["query"], {"page": "2", "limit": "3"})
    def test_a_link_header_with_several_links_and_multi_token_rel(self):
        def link(s, pg, lim, more): return ('</accounts?page=1&limit=3>; rel="prev", </accounts?page=%d&limit=3>; title="more, \\"x\\""; rel="last next"' % (pg + 1)) if more else '</accounts?page=1&limit=3>; rel="prev"'
        with self.srv(link) as s: ids, n = walk(conn(s, pagination="link")); self.assertEqual(ids, [d["id"] for d in DATA])
    def test_no_next_link_means_complete_and_a_prev_only_link_is_not_next(self):
        with self.srv(lambda *a: None) as s: self.assertEqual(conn(s, pagination="link").read({"entity": "Account"})["next_cursor"], None)
        with self.srv(lambda *a: '<%s/accounts?page=1>; rel="prev"' % a[0].url) as s: self.assertIsNone(conn(s, pagination="link").read({"entity": "Account"})["next_cursor"])
    def test_a_next_link_that_leaves_the_endpoint_is_refused_and_never_becomes_a_cursor(self):
        def hostile(target): return lambda s, pg, lim, more: '<%s>; rel="next"' % target.replace("SELF", s.host)
        bad = ["http://evil.example.test/accounts?page=2", "http://SELF/other?page=2", "https://SELF/accounts?page=2", "http://user:pw@SELF/accounts?page=2", "http://SELF/accounts?page=2#frag", "http://SELF/accounts", "http://SELF/accounts?", "http://SELF/accounts/../admin?page=2", "http://SELF:1/accounts?page=2", "//evil.example.test/accounts?page=2", "javascript:alert(1)", "http://SELF/accounts?" + "a=1&" * 30 + "b=2", "http://SELF/accounts?x=" + "y" * 600, "http://SELF/accounts?noequals"]
        for target in bad:
            with self.subTest(target[:60]), self.srv(hostile(target)) as s:
                with self.assertRaises(MalformedResponse): conn(s, pagination="link").read({"entity": "Account"})
                self.assertEqual(len(s.requests), 1)
    def test_a_header_that_names_a_next_page_but_cannot_be_read_fails_loudly_instead_of_ending_the_walk(self):
        for header in ('http://127.0.0.1/accounts?page=2; rel="next"', '<http://127.0.0.1/accounts?page=2 rel="next"', '</accounts?page=2>; rel="next', 'garbage rel=next'):
            with self.subTest(header), self.srv(lambda *a, hd=header: hd) as s:
                with self.assertRaises(MalformedResponse): conn(s, pagination="link").read({"entity": "Account"})
        with self.srv(lambda *a: "something unrelated") as s: self.assertIsNone(conn(s, pagination="link").read({"entity": "Account"})["next_cursor"])      # a header with no next at all is simply the end
    def test_an_oversized_link_header_is_refused(self):
        with self.srv(lambda s, *a: '<%s/accounts?page=2>; rel="next"; x="%s"' % (s.url, "y" * 5000)) as s:
            with self.assertRaises(MalformedResponse): conn(s, pagination="link").read({"entity": "Account"})
    def test_a_caller_supplied_link_cursor_must_be_a_canonical_query(self):
        with self.srv(self.absolute) as s:
            c = conn(s, pagination="link")
            for bad in ("", "noequals", "a=1&&b=2", "x=%zz", "a=b c", "&".join("k%d=v" % i for i in range(25))):
                with self.subTest(bad[:30]):
                    with self.assertRaises(TransportError) as e: c.read({"entity": "Account", "cursor": bad})
                    self.assertEqual(e.exception.applied, "NOT_APPLIED")
            self.assertEqual(s.requests, [])
    def test_an_encoded_query_round_trips_through_the_cursor(self):
        with self.srv(lambda s, pg, lim, more: '</accounts?page=%d&limit=3&q=a%%20b%%2Fc>; rel="next"' % (pg + 1) if more else None) as s:
            ids, n = walk(conn(s, pagination="link")); self.assertEqual(ids, [d["id"] for d in DATA]); self.assertEqual(s.requests[1]["query"]["q"], "a b/c")
class TestConfig(unittest.TestCase):
    def test_bad_pagination_settings_are_refused_at_construction(self):
        class S: url = "http://127.0.0.1:1"; host = "127.0.0.1:1"
        for kw in ({"pagination": "weird"}, {"pagination": ""}, {"pagination": None}, {"offset_param": ""}, {"page_param": None}, {"cursor_param": ""}, {"page_size_param": 5}):
            with self.subTest(kw), self.assertRaises(ValueError): conn(S, **kw)
    def test_the_default_is_the_rev7_cursor_behaviour(self): self.assertEqual(Endpoint().pagination, "cursor")
if __name__ == "__main__": unittest.main()

"""Direct tests of auif_ext.common: the Secret wrapper, header hygiene and Retry-After parsing (TEST-ONLY)."""
import copy, email.utils, pickle, unittest
from auif.errors import TransportError
from auif_ext.common import Secret, clean_header, retry_after_seconds
RAW = "s3cr3t-value-123"
class TestSecret(unittest.TestCase):
    def test_no_leak_through_any_rendering(self):
        s = Secret(RAW)
        for rendered in (repr(s), str(s), format(s), format(s, ""), format(s, ">40"), f"{s}", f"{s!r}", "%s" % s, "%r" % (s,), "{}".format(s), "{0:s}".format(s), str([s]), str({"k": s})):
            self.assertNotIn(RAW, rendered); self.assertNotIn("s3cr3t", rendered)
    def test_pickle_refused(self):
        for proto in range(pickle.HIGHEST_PROTOCOL + 1):
            with self.assertRaises(TypeError): pickle.dumps(Secret(RAW), protocol=proto)
    def test_copy_returns_same_object(self):
        s = Secret(RAW); self.assertIs(copy.copy(s), s); self.assertIs(copy.deepcopy(s), s); self.assertIs(copy.deepcopy({"a": s})["a"], s)
    def test_immutable_and_slotted(self):
        s = Secret(RAW)
        with self.assertRaises(AttributeError): s._v = "other"
        with self.assertRaises(AttributeError): s.extra = 1
        self.assertFalse(hasattr(s, "__dict__")); self.assertEqual(s.reveal(), RAW)
    def test_bool(self): self.assertTrue(Secret(RAW)); self.assertFalse(Secret(""))
    def test_rejects_non_str(self):
        for v in (None, 1, b"bytes", ["x"], Secret(RAW)):
            with self.assertRaises(TypeError): Secret(v)
    def test_secret_not_in_exception_text(self):
        try: clean_header("X-Key", Secret(RAW).reveal() + "\r\nInjected: 1")
        except TransportError as e: self.assertNotIn(RAW, str(e)); self.assertNotIn(RAW, repr(e))
        else: self.fail("header injection accepted")
class TestCleanHeader(unittest.TestCase):
    def test_accepts_token_and_plain_value(self): self.assertEqual(clean_header("X-Api-Key", "abc def"), ("X-Api-Key", "abc def"))
    def test_refuses_bad_values(self):
        for v in ("a\rb", "a\nb", "a\x00b", "a\r\nX: y"):
            with self.assertRaises(TransportError) as c: clean_header("X-H", v)
            self.assertEqual(c.exception.code, "TARGET_REJECTED_REQUEST"); self.assertEqual(c.exception.applied, "NOT_APPLIED")
    def test_refuses_bad_names(self):
        for n in ("", "X H", "X:H", "X\nH", "Ü", None, 5):
            with self.assertRaises(TransportError): clean_header(n, "v")
    def test_refuses_non_str_value(self):
        for v in (None, 5, b"v"):
            with self.assertRaises(TransportError): clean_header("X-H", v)
class TestRetryAfter(unittest.TestCase):
    def test_delta_seconds_and_cap(self):
        self.assertEqual(retry_after_seconds("120"), 120.0); self.assertEqual(retry_after_seconds("1.5"), 1.5); self.assertEqual(retry_after_seconds(" 7 "), 7.0)
        self.assertEqual(retry_after_seconds("999999999"), 3600.0); self.assertEqual(retry_after_seconds("500", cap=60.0), 60.0)
    def test_http_date_is_clamped(self):
        self.assertEqual(retry_after_seconds("Wed, 21 Oct 2099 07:28:00 GMT", now=0), 3600.0)
        self.assertEqual(retry_after_seconds("Wed, 21 Oct 2099 07:28:00 GMT", now=0, cap=10.0), 10.0)
    def test_http_date_in_range_and_past(self):
        future = email.utils.formatdate(1_000_000_090, usegmt=True); self.assertAlmostEqual(retry_after_seconds(future, now=1_000_000_000), 90.0, places=3)
        past = email.utils.formatdate(1_000_000_000, usegmt=True); self.assertEqual(retry_after_seconds(past, now=1_000_000_500), 0.0)
    def test_unparsable_is_none_never_an_exception(self):
        self.assertIsNone(retry_after_seconds(None))
        for v in ("", "soon", "-5", "1e3", "12abc", "NaN", "inf", "Mon, 99 Foo 2099 99:99:99 GMT", "1234567890123"): self.assertIsNone(retry_after_seconds(v), v)
if __name__ == "__main__": unittest.main()

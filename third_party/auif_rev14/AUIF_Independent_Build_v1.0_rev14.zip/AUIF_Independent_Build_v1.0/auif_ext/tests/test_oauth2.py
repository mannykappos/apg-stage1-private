"""OAuth2 client-credentials over a real loopback identity provider."""
import base64, json, time, unittest, urllib.parse
from auif.errors import MalformedResponse, TransportError
from auif_ext.connectors.http_client import HttpTransport
from auif_ext.connectors.oauth2 import OAuth2ClientCredentials, split_client_credentials
from auif_ext.tests.loopback import LoopbackServer, jresp
class Clock:
    def __init__(self): self.t = 1000.0
    def __call__(self): return self.t
class Idp:
    def __init__(self, cid="the-id", sec="the-secret", style="basic"): self.cid, self.sec, self.style, self.n, self.life, self.override = cid, sec, style, 0, 3600, None
    def __call__(self, m, p, q, h, b):
        self.n += 1
        if self.override: return self.override
        form = dict(urllib.parse.parse_qsl(b.decode()))
        if self.style == "basic": ok = h.get("authorization") == "Basic " + base64.b64encode(("%s:%s" % (self.cid, self.sec)).encode()).decode()
        else: ok = (form.get("client_id"), form.get("client_secret")) == (self.cid, self.sec)
        if not ok or form.get("grant_type") != "client_credentials": return jresp({"error": "invalid_client"}, 401)
        return jresp({"access_token": "tok-%d" % self.n, "token_type": "Bearer", "expires_in": self.life})
def make(srv, style="basic", clock=None, **kw): return OAuth2ClientCredentials(HttpTransport([srv.host], allow_insecure_loopback=True), srv.url + "/token", auth_style=style, clock=clock or Clock(), **kw)
class TestClientCredentials(unittest.TestCase):
    def test_both_credential_styles_fetch_a_token(self):
        for style in ("basic", "body"):
            with self.subTest(style), LoopbackServer(Idp(style=style)) as s:
                self.assertEqual(make(s, style).token("the-id", "the-secret").reveal(), "tok-1")
    def test_the_secret_travels_only_where_the_style_says(self):
        with LoopbackServer(Idp(style="basic")) as s:
            make(s, "basic").token("the-id", "the-secret"); r = s.requests[0]; self.assertNotIn(b"the-secret", r["body"]); self.assertIn("authorization", r["headers"]); self.assertNotIn("the-secret", r["path"])
        with LoopbackServer(Idp(style="body")) as s:
            make(s, "body").token("the-id", "the-secret"); r = s.requests[0]; self.assertNotIn("authorization", r["headers"]); self.assertIn(b"client_secret=the-secret", r["body"])
    def test_a_token_is_cached_until_shortly_before_it_expires_then_refreshed(self):
        clk = Clock(); idp = Idp(); idp.life = 100
        with LoopbackServer(idp) as s:
            o = make(s, clock=clk, skew=30); o.token("the-id", "the-secret"); o.token("the-id", "the-secret"); self.assertEqual(idp.n, 1)
            clk.t += 69; o.token("the-id", "the-secret"); self.assertEqual(idp.n, 1); clk.t += 2; self.assertEqual(o.token("the-id", "the-secret").reveal(), "tok-2"); self.assertEqual(idp.n, 2)
    def test_changed_credentials_never_reuse_another_credentials_token(self):
        idp = Idp()
        with LoopbackServer(idp) as s:
            o = make(s); o.token("the-id", "the-secret")
            with self.assertRaises(TransportError): o.token("the-id", "other-secret")
    def test_invalidate_forces_a_new_token(self):
        idp = Idp()
        with LoopbackServer(idp) as s: o = make(s); o.token("the-id", "the-secret"); o.invalidate(); o.token("the-id", "the-secret"); self.assertEqual(idp.n, 2)
    def test_lifetime_is_clamped_and_a_bad_lifetime_falls_back_to_the_default(self):
        for life, expect_cached in ((10 ** 9, True), ("x", True), (-5, False), (0, False)):
            with self.subTest(life):
                idp = Idp(); idp.life = life; clk = Clock()
                with LoopbackServer(idp) as s: o = make(s, clock=clk); o.token("the-id", "the-secret"); o.token("the-id", "the-secret"); self.assertEqual(idp.n, 1 if expect_cached else 2)
    def test_a_huge_lifetime_is_capped_at_the_maximum_and_the_token_is_refetched(self):
        clk = Clock(); idp = Idp(); idp.life = 10 ** 9
        with LoopbackServer(idp) as s:
            o = make(s, clock=clk); o.token("the-id", "the-secret"); clk.t += 86000; o.token("the-id", "the-secret"); self.assertEqual(idp.n, 1)        # inside max_lifetime minus skew: cached
            clk.t += 4000; self.assertEqual(o.token("the-id", "the-secret").reveal(), "tok-2"); self.assertEqual(idp.n, 2)                              # beyond the 86400 s cap: refetched
class TestFailures(unittest.TestCase):
    def call(self, override, **kw):
        idp = Idp(); idp.override = override
        with LoopbackServer(idp) as s:
            with self.assertRaises((TransportError, MalformedResponse)) as e: make(s).token("the-id", "the-secret")
        return e.exception
    def test_bad_credentials_are_authentication_failed_and_not_applied(self):
        for status in (400, 401, 403, 404):
            with self.subTest(status):
                e = self.call(jresp({"error": "x"}, status)); self.assertEqual((e.code, e.applied), ("AUTHENTICATION_FAILED", "NOT_APPLIED"))
    def test_rate_limiting_and_outages_are_distinguished(self):
        e = self.call(jresp({}, 429, {"Retry-After": "7"})); self.assertEqual((e.code, e.retry_after), ("RATE_LIMITED", 7.0))
        self.assertEqual(self.call(jresp({}, 503)).code, "UNAVAILABLE")
    def test_malformed_token_responses_are_refused(self):
        for body in (b"not json", b'{"access_token": ""}', b'{"access_token": 5}', b'{"token_type": "bearer"}', b'{"access_token": "x", "token_type": "mac"}', b'{"access_token": NaN}', b"[]"):
            with self.subTest(body): e = self.call((200, {"Content-Type": "application/json"}, body)); self.assertIsInstance(e, MalformedResponse)
    def test_non_finite_numbers_anywhere_in_a_token_response_are_refused(self):
        for body in (b'{"access_token": "x", "token_type": "bearer", "expires_in": NaN}', b'{"access_token": "x", "token_type": "bearer", "expires_in": Infinity}', b'{"access_token": "x", "token_type": "bearer", "expires_in": -Infinity}', b'{"access_token": "x", "token_type": "bearer", "extra": [NaN]}'):
            with self.subTest(body): e = self.call((200, {"Content-Type": "application/json"}, body)); self.assertIsInstance(e, MalformedResponse)
    def test_errors_never_contain_the_credentials(self):
        e = self.call(jresp({"error": "invalid_client", "echo": "the-secret"}, 401)); self.assertNotIn("the-secret", str(e) + e.message)
    def test_the_credential_format_is_validated(self):
        for bad in ("", "nocolon", ":secret", "id:", None, 5):
            with self.subTest(bad):
                with self.assertRaises(TransportError) as e: split_client_credentials(bad)
                self.assertEqual(e.exception.code, "AUTHENTICATION_FAILED")
        self.assertEqual(split_client_credentials("a:b:c"), ("a", "b:c"))                                            # split on the FIRST colon
    def test_an_unknown_auth_style_is_refused(self):
        with self.assertRaises(ValueError): OAuth2ClientCredentials(None, "x", auth_style="query")

class GatedTransport:
    """A fake transport whose token endpoint blocks until released, so concurrent callers are provably waiting on one fetch. TEST-ONLY."""
    def __init__(self, status=200, hook=None):
        import threading; self.gate, self.status, self.hook, self.calls, self.lock = threading.Event(), status, hook, [], threading.Lock()
    def request(self, method, url, *, headers=None, body=None):
        from auif_ext.connectors.http_client import HttpResponse
        with self.lock: self.calls.append(headers.get("Authorization")); n = len(self.calls)
        self.gate.wait(5)
        if self.hook: self.hook()
        tok = "tok-%s" % base64.b64decode(headers["Authorization"][6:]).decode().split(":")[0]
        return HttpResponse(self.status, {"content-type": "application/json"}, json.dumps({"access_token": tok, "token_type": "bearer", "expires_in": 3600}).encode())
def run_threads(fn, n):
    import threading
    out, errs = [], []
    def go():
        try: out.append(fn())
        except Exception as e: errs.append(e)
    ts = [threading.Thread(target=go) for _ in range(n)]; [t.start() for t in ts]; return ts, out, errs
class TestConcurrency(unittest.TestCase):
    """rev8: callers on many threads share one token cache and one in-flight fetch."""
    def make(self, tr, **kw): return OAuth2ClientCredentials(tr, "https://idp.test/token", clock=kw.get("clock", Clock()))
    def test_concurrent_callers_cause_exactly_one_fetch_and_all_get_that_token(self):
        tr = GatedTransport(); o = self.make(tr); ts, out, errs = run_threads(lambda: o.token("cid", "sec").reveal(), 12); time.sleep(0.4); self.assertEqual(len(tr.calls), 1)       # 12 callers, ONE request in flight
        tr.gate.set(); [t.join() for t in ts]; self.assertEqual((errs, len(tr.calls), set(out), len(out)), ([], 1, {"tok-cid"}, 12))
        o.token("cid", "sec"); self.assertEqual(len(tr.calls), 1)                                                                                          # and the result was cached for later callers
    def test_a_failed_fetch_is_shared_with_every_waiting_caller_and_not_cached(self):
        tr = GatedTransport(status=401); o = self.make(tr); ts, out, errs = run_threads(lambda: o.token("cid", "sec"), 8); time.sleep(0.4); tr.gate.set(); [t.join() for t in ts]
        self.assertEqual((out, len(tr.calls)), ([], 1)); self.assertEqual(len(errs), 8); self.assertTrue(all(isinstance(e, TransportError) and e.code == "AUTHENTICATION_FAILED" for e in errs))
        tr.status = 200; self.assertEqual(o.token("cid", "sec").reveal(), "tok-cid"); self.assertEqual(len(tr.calls), 2)                                  # a failure left no poisoned cache behind
    def test_a_different_credential_never_joins_or_receives_another_credentials_token(self):
        tr = GatedTransport(); o = self.make(tr); t1, o1, e1 = run_threads(lambda: o.token("alice", "s1").reveal(), 4); t2, o2, e2 = run_threads(lambda: o.token("bob", "s2").reveal(), 4); time.sleep(0.4)
        tr.gate.set(); [t.join() for t in t1 + t2]; self.assertEqual((e1, e2, set(o1), set(o2), len(tr.calls)), ([], [], {"tok-alice"}, {"tok-bob"}, 2))
    def test_an_invalidate_during_a_fetch_is_not_undone_by_that_fetch(self):
        holder = {}; tr = GatedTransport(hook=lambda: holder["o"].invalidate()); tr.gate.set(); o = holder["o"] = self.make(tr)
        self.assertEqual(o.token("cid", "sec").reveal(), "tok-cid"); self.assertEqual(len(tr.calls), 1)                                               # the caller still gets its token ...
        o.token("cid", "sec"); self.assertEqual(len(tr.calls), 2)                                                                                          # ... but it was not cached over the invalidation
    def test_a_late_caller_after_an_error_starts_a_new_fetch(self):
        tr = GatedTransport(status=500); tr.gate.set(); o = self.make(tr)
        for _ in range(2):
            with self.assertRaises(TransportError): o.token("cid", "sec")
        self.assertEqual(len(tr.calls), 2); self.assertEqual(o._flights, {})                                                                               # no flight is left behind to wedge later callers
if __name__ == "__main__": unittest.main()

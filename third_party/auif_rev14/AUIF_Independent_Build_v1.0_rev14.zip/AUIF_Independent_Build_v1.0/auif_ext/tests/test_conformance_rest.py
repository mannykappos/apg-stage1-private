"""rev8: the connector conformance kit, proven by running it against the generic REST connector in four configurations."""
import unittest
from auif_ext.conformance.suite import ConnectorConformanceCases
from auif_ext.tests.conformance_rest_sandbox import RestSandbox
from auif_ext.connectors import file_import, oauth2, rest, webhook
MODS = (rest, oauth2, webhook, file_import)
class TestRestCursorApiKey(ConnectorConformanceCases, unittest.TestCase): target_factory = staticmethod(lambda: RestSandbox("cursor", "API_KEY")); connector_modules = MODS
class TestRestOffsetApiKey(ConnectorConformanceCases, unittest.TestCase): target_factory = staticmethod(lambda: RestSandbox("offset", "API_KEY"))
class TestRestPageNoAuth(ConnectorConformanceCases, unittest.TestCase): target_factory = staticmethod(lambda: RestSandbox("page", "NONE"))
class TestRestLinkNoAuth(ConnectorConformanceCases, unittest.TestCase): target_factory = staticmethod(lambda: RestSandbox("link", "NONE"))
class TestTheAbstractSuiteIsNotRunOnItsOwn(unittest.TestCase):
    def test_the_mixin_alone_has_no_target(self): self.assertIsNone(ConnectorConformanceCases.target_factory)
if __name__ == "__main__": unittest.main()

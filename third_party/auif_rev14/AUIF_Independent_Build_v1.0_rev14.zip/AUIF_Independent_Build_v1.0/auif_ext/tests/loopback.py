"""Test infrastructure: a real HTTP server on 127.0.0.1 (standard library) so extension tests exercise genuine sockets, not mocks. TEST-ONLY: nothing outside auif_ext/tests imports this."""
import http.server, json, socket, ssl, threading, time, urllib.parse
DROP = object()                                             # a handler returns DROP to close the connection WITHOUT answering
class LoopbackServer:
    def __init__(self, handler, tls=None):                           # tls=(certfile, keyfile) serves HTTPS on the same loopback socket
        self.handler, self.requests, self.tls = handler, [], tls; owner = self
        class H(http.server.BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            def log_message(self, *a): pass
            def _go(self):
                n = int(self.headers.get("content-length") or 0); body = self.rfile.read(n) if n else b""; u = urllib.parse.urlsplit(self.path); hdrs = {k.lower(): v for k, v in self.headers.items()}
                owner.requests.append({"method": self.command, "path": u.path, "query": dict(urllib.parse.parse_qsl(u.query)), "headers": hdrs, "body": body}); out = owner.handler(self.command, u.path, dict(urllib.parse.parse_qsl(u.query)), hdrs, body)
                if out is DROP: self.close_connection = True; self.connection.close(); return
                status, headers, data = out; self.send_response(status)
                for k, v in headers.items(): self.send_header(k, v)
                self.send_header("Content-Length", str(len(data))); self.send_header("Connection", "close"); self.end_headers(); self.wfile.write(data); self.close_connection = True
            do_GET = do_POST = do_PATCH = do_PUT = do_DELETE = _go
        self.httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H); self.httpd.daemon_threads = True; self.httpd.handle_error = lambda request, client_address: None      # a client that gave up (timeout test) is not an error here
        if tls:
            sc = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); sc.load_cert_chain(*tls); self.httpd.socket = sc.wrap_socket(self.httpd.socket, server_side=True)
        self.thread = threading.Thread(target=lambda: self.httpd.serve_forever(poll_interval=0.005), daemon=True)
    def start(self): self.thread.start(); return self
    def stop(self): self.httpd.shutdown(); self.httpd.server_close(); self.thread.join(timeout=5)
    @property
    def host(self): return "127.0.0.1:%d" % self.httpd.server_address[1]
    @property
    def url(self): return ("https://" if self.tls else "http://") + self.host
    def __enter__(self): return self.start()
    def __exit__(self, *a): self.stop()
def jresp(obj, status=200, headers=None): return status, dict({"Content-Type": "application/json"}, **(headers or {})), json.dumps(obj).encode()
class SystemAHandler:
    """Serves a synthetic SystemA over HTTP. `faults` is a list consumed one per request: ("status", code, headers) or ("drop_after_apply",)."""
    def __init__(self, sa, token): self.sa, self.token, self.faults = sa, token, []
    def __call__(self, method, path, query, headers, body):
        if headers.get("authorization") != "Bearer " + self.token: return jresp({"error": "unauthorised"}, 401)
        fault = self.faults.pop(0) if self.faults else None
        if fault and fault[0] == "status": return jresp({"error": "injected"}, fault[1], fault[2] if len(fault) > 2 else None)
        if method == "GET" and path == "/metadata": return jresp(self.sa.metadata())
        if method == "GET" and path in ("/accounts", "/properties"): return jresp(self.sa.list("Account" if path == "/accounts" else "Property", query.get("cursor"), int(query.get("limit", 3))))
        if method == "GET" and path.startswith("/idempotency/"):
            rec = self.sa.lookup(urllib.parse.unquote(path.rsplit("/", 1)[1])); return jresp(rec) if rec else jresp({"error": "none"}, 404)
        if method == "PATCH" and path.startswith("/accounts/"):
            rec = self.sa.update("Account", urllib.parse.unquote(path.rsplit("/", 1)[1]), json.loads(body), headers.get("idempotency-key"))
            return DROP if fault and fault[0] == "drop_after_apply" else jresp(rec)
        return jresp({"error": "not found"}, 404)

class DripServer:
    """A raw-socket server that answers SLOWLY: it sends `lead` at once and then one byte every `interval` seconds, so no single socket operation ever times out while the whole exchange drags on. TEST-ONLY."""
    def __init__(self, lead, drip, interval=0.1, tls=None):                                      # tls=(certfile, keyfile): the same slow server, over a real TLS session
        self.lead, self.drip, self.interval, self.accepted, self.stopped, self.tls = lead, drip, interval, 0, False, tls
        self.ctx = None
        if tls: self.ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); self.ctx.load_cert_chain(*tls)
        self.sock = socket.socket(); self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); self.sock.bind(("127.0.0.1", 0)); self.sock.listen(8); self.sock.settimeout(0.05)
        self.thread = threading.Thread(target=self._run, daemon=True)
    def _serve(self, c):
        try:
            c.settimeout(2.0)
            if self.ctx: c = self.ctx.wrap_socket(c, server_side=True)
            try: c.recv(65536)
            except OSError: pass
            if self.lead: c.sendall(self.lead)
            for b in self.drip:
                if self.stopped: return
                time.sleep(self.interval); c.sendall(bytes([b]))
        except OSError: pass
        finally:
            try: c.close()
            except OSError: pass
    def _run(self):
        while not self.stopped:
            try: c, _ = self.sock.accept()
            except socket.timeout: continue
            except OSError: return
            self.accepted += 1; threading.Thread(target=self._serve, args=(c,), daemon=True).start()
    def start(self): self.thread.start(); return self
    def stop(self): self.stopped = True; self.sock.close(); self.thread.join(timeout=5)
    @property
    def host(self): return "127.0.0.1:%d" % self.sock.getsockname()[1]
    @property
    def url(self): return ("https://" if self.tls else "http://") + self.host
    def __enter__(self): return self.start()
    def __exit__(self, *a): self.stop()

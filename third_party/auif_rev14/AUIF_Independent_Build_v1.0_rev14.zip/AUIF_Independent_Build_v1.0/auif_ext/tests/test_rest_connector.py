"""The generic REST connector: configuration safety, error mapping, retry semantics under the core runtime, credential hygiene, and an end-to-end run through the real Fabric over real HTTP."""
import unittest
from auif.contracts import validate
from auif.errors import MalformedResponse, TenantContextError, TransportError
from auif_ext.connectors.http_client import HttpTransport
from auif_ext.connectors.rest import Endpoint, RestConfig, RestConnector, error_for_status
from auif_ext.connectors.http_client import HttpResponse
from auif_ext.tests.loopback import DROP, LoopbackServer, SystemAHandler, jresp
from auif_ext.tests.support import TOKEN, Rig, account_entities, rest_cfg
from auif_ext.tests.test_oauth2 import Idp
def conn(srv, token=TOKEN, **kw):
    c = RestConnector(rest_cfg(srv, **kw)); c.connect({"secret": token}); return c
class TestConfiguration(unittest.TestCase):
    def cfg(self, **kw):
        base = dict(connector_id="g", version="0.1.0", base_url="https://api.example.test/v1", allowed_hosts=("api.example.test",), credential_ref="secretref:a/b", auth="API_KEY", entities=account_entities()); base.update(kw); return RestConfig(**base)
    def test_a_valid_configuration_builds_and_its_descriptor_validates_against_the_audited_contract(self):
        c = RestConnector(self.cfg(lookup=Endpoint(path="/i/{key}"))); validate("connector#ConnectorDescriptor", c.descriptor()); d = c.descriptor()
        self.assertEqual((d["authentication"]["handling"], d["idempotency"]["supported"], d["idempotency"]["outcome_reconciliation_supported"], d["protocol_class"]), ("API_KEY", True, True, "REST"))
        self.assertFalse(RestConnector(self.cfg(idempotency_header=None, lookup=None)).descriptor()["idempotency"]["supported"])
    def test_unsafe_or_incomplete_configurations_are_refused(self):
        for label, kw in (("plain http", dict(base_url="http://api.example.test")), ("userinfo", dict(base_url="https://u:p@api.example.test")), ("query in base", dict(base_url="https://api.example.test/?x=1")), ("auth without a credential ref", dict(credential_ref=None)), ("oauth without a token url", dict(auth="OAUTH2_CLIENT_CREDENTIALS")),
                          ("unknown auth", dict(auth="MAGIC")), ("no entities", dict(entities={})), ("bad entity name", dict(entities={"../x": {"list": Endpoint()}})), ("bad endpoint path", dict(entities={"A": {"list": Endpoint(path="relative")}})), ("unknown placeholder", dict(entities={"A": {"list": Endpoint(path="/x/{other}")}})), ("bad method", dict(entities={"A": {"list": Endpoint(method="TRACE")}}))):
            with self.subTest(label):
                with self.assertRaises(ValueError): RestConnector(self.cfg(**kw))
    def test_insecure_http_is_accepted_only_for_loopback_when_explicitly_enabled(self):
        RestConnector(self.cfg(base_url="http://127.0.0.1:9", allowed_hosts=("127.0.0.1:9",), allow_insecure_loopback=True))
        with self.assertRaises(ValueError): RestConnector(self.cfg(base_url="http://api.example.test", allow_insecure_loopback=True))
    def test_the_connector_repr_and_config_hold_no_secret(self):
        c = RestConnector(self.cfg()); c.connect({"secret": "SUPERSECRETVALUE"}); self.assertNotIn("SUPERSECRETVALUE", repr(c) + repr(c.cfg) + repr(c.__dict__)); c.disconnect(); self.assertIsNone(c._secret)
class TestStatusMapping(unittest.TestCase):
    def r(self, status, headers=None): return HttpResponse(status, headers or {}, b"")
    def test_the_status_table(self):
        T = [(401, "AUTHENTICATION_FAILED", "NOT_APPLIED", "NOT_APPLIED"), (403, "AUTHORIZATION_DENIED_BY_TARGET", "NOT_APPLIED", "NOT_APPLIED"), (429, "RATE_LIMITED", "NOT_APPLIED", "NOT_APPLIED"), (408, "TIMEOUT", "NOT_APPLIED", "MAYBE"),
             (500, "UNAVAILABLE", "NOT_APPLIED", "MAYBE"), (502, "UNAVAILABLE", "NOT_APPLIED", "MAYBE"), (503, "UNAVAILABLE", "NOT_APPLIED", "MAYBE"), (504, "UNAVAILABLE", "NOT_APPLIED", "MAYBE"), (599, "UNAVAILABLE", "NOT_APPLIED", "MAYBE"),
             (400, "TARGET_REJECTED_REQUEST", "NOT_APPLIED", "NOT_APPLIED"), (404, "TARGET_REJECTED_REQUEST", "NOT_APPLIED", "NOT_APPLIED"), (409, "TARGET_REJECTED_REQUEST", "NOT_APPLIED", "NOT_APPLIED"), (422, "TARGET_REJECTED_REQUEST", "NOT_APPLIED", "NOT_APPLIED"), (301, "TARGET_REJECTED_REQUEST", "NOT_APPLIED", "NOT_APPLIED"), (302, "TARGET_REJECTED_REQUEST", "NOT_APPLIED", "NOT_APPLIED"), (101, "UNKNOWN_EXTERNAL_ERROR", "NOT_APPLIED", "MAYBE")]
        for s, code, read, write in T:
            with self.subTest(s):
                a, b = error_for_status(self.r(s), False), error_for_status(self.r(s), True); self.assertEqual((a.code, a.applied, b.code, b.applied), (code, read, code, write)); self.assertEqual(a.status, s)
    def test_retry_after_is_parsed_as_seconds_or_an_http_date_and_clamped(self):
        self.assertEqual(error_for_status(self.r(429, {"retry-after": "12"}), False).retry_after, 12.0); self.assertEqual(error_for_status(self.r(503, {"retry-after": "99999"}), False).retry_after, 3600.0)
        self.assertIsNone(error_for_status(self.r(429, {"retry-after": "soon"}), False).retry_after); self.assertIsNone(error_for_status(self.r(429, {}), False).retry_after)
        self.assertGreater(error_for_status(self.r(429, {"retry-after": "Wed, 21 Oct 2099 07:28:00 GMT"}), False).retry_after, 0)
    def test_the_table_is_applied_to_real_responses_for_reads_and_writes(self):
        for status in (401, 403, 429, 500, 503, 400, 404):
            with self.subTest(status), LoopbackServer(lambda m, p, q, h, b, s=status: jresp({"error": "x"}, s)) as srv:
                c = conn(srv)
                with self.assertRaises(TransportError) as e: c.read({"entity": "Account"})
                self.assertEqual(e.exception.applied, "NOT_APPLIED")
                with self.assertRaises(TransportError) as e: c.write({"entity": "Account", "id": "1", "fields": {"a": 1}, "idempotency_key": "idem-1"})
                self.assertEqual(e.exception.applied, "MAYBE" if status >= 500 else "NOT_APPLIED")
    def test_a_redirect_is_a_rejection_never_a_success_even_with_a_valid_body(self):
        for status in (301, 302, 303, 307, 308):
            with self.subTest(status), LoopbackServer(lambda m, p, q, h, b, s=status: (s, {"Content-Type": "application/json", "Location": "/elsewhere"}, b'{"items": [], "next_cursor": null, "external_reference": "r"}')) as srv:
                c = conn(srv)
                with self.assertRaises(TransportError) as e: c.read({"entity": "Account"})
                self.assertEqual((e.exception.code, e.exception.applied, e.exception.status), ("TARGET_REJECTED_REQUEST", "NOT_APPLIED", status))
                with self.assertRaises(TransportError) as e: c.write({"entity": "Account", "id": "1", "fields": {"a": 1}, "idempotency_key": "idem-1"})
                self.assertEqual((e.exception.code, e.exception.applied), ("TARGET_REJECTED_REQUEST", "NOT_APPLIED"))
                with self.assertRaises(TransportError): c.discover()
                self.assertEqual(len(srv.requests), 3)                                                                            # never followed
class TestTotalDeadlineThroughTheConfig(unittest.TestCase):
    def test_the_configured_total_deadline_reaches_the_transport_and_bounds_a_slow_read(self):
        import time
        from auif_ext.tests.loopback import DripServer
        lead = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 400\r\nConnection: close\r\n\r\n"
        with DripServer(lead, b"x" * 400, interval=0.15) as s:
            c = RestConnector(RestConfig(connector_id="dl", version="1.0.0", base_url=s.url, allowed_hosts=(s.host,), auth="NONE", allow_insecure_loopback=True, request_timeout=5.0, total_deadline=0.8, entities={"Account": {"list": Endpoint(path="/accounts", items_path=("items",))}}))
            t0 = time.monotonic()
            with self.assertRaises(TransportError) as e: c.read({"entity": "Account"})
            self.assertEqual((e.exception.code, e.exception.applied), ("TIMEOUT", "NOT_APPLIED")); self.assertLess(time.monotonic() - t0, 3.0)
        self.assertEqual(RestConfig(connector_id="a", version="1.0.0", base_url="https://h.test", allowed_hosts=("h.test",)).total_deadline, 60.0)
class TestReadAndDiscover(unittest.TestCase):
    def setUp(self): self.rig = Rig(); self.c = self.rig.connector; self.c.connect({"secret": TOKEN})
    def tearDown(self): self.rig.close()
    def test_discovery_returns_the_targets_metadata_over_http(self): d = self.c.discover(); self.assertEqual({e["name"] for e in d["entities"]}, {"Account", "Property"})
    def test_pages_are_followed_through_cursors_until_complete(self):
        seen, cur = [], None
        while True:
            p = self.c.read({"entity": "Account", "cursor": cur, "page_size": 3}); seen += [i["id"] for i in p["items"]]; cur = p["next_cursor"]
            if p["complete"]: break
        self.assertEqual(sorted(seen, key=int), sorted(self.rig.sa.rows["Account"], key=int)); self.assertEqual(len(self.rig.srv.requests), 3)                                                  # 7 rows at 3 per page: exactly three pages
    def test_the_page_size_is_clamped_and_sent_as_configured(self):
        self.c.read({"entity": "Account", "page_size": 10 ** 6}); self.assertEqual(self.rig.srv.requests[-1]["query"]["limit"], "200"); self.c.read({"entity": "Account", "page_size": 0}); self.assertEqual(self.rig.srv.requests[-1]["query"]["limit"], "50")
    def test_unknown_entities_and_unacceptable_cursors_are_refused(self):
        with self.assertRaises(TransportError) as e: self.c.read({"entity": "Nope"})
        self.assertEqual((e.exception.code, e.exception.applied), ("UNSUPPORTED_OPERATION", "NOT_APPLIED"))
        for cur in ("", "x" * 513, 5, ["a"]):
            with self.subTest(cur):
                with self.assertRaises(TransportError): self.c.read({"entity": "Account", "cursor": cur})
    def test_malformed_pages_are_refused(self):
        bad = {"not a list": {"items": "x"}, "items not objects": {"items": [1, 2]}, "too many": {"items": [{"id": str(i)} for i in range(201)]}, "bad cursor type": {"items": [], "next_cursor": ["x"]}}
        for label, body in bad.items():
            with self.subTest(label), LoopbackServer(lambda m, p, q, h, b, bd=body: jresp(bd)) as srv:
                with self.assertRaises(MalformedResponse): conn(srv).read({"entity": "Account"})
    def test_non_json_and_invalid_json_are_refused(self):
        for ct, body in (("text/html", b"<html>"), ("application/json", b"{broken"), ("application/json", b"\xff\xfe"), ("application/json", b'{"items": [NaN]}')):
            with self.subTest((ct, body)), LoopbackServer(lambda m, p, q, h, b, ct=ct, body=body: (200, {"Content-Type": ct}, body)) as srv:
                with self.assertRaises(MalformedResponse): conn(srv).read({"entity": "Account"})
    def test_valid_json_with_a_non_json_content_type_is_refused(self):
        for ct in ("text/html", "text/plain", "application/octet-stream", ""):
            with self.subTest(ct), LoopbackServer(lambda m, p, q, h, b, ct=ct: (200, {"Content-Type": ct} if ct else {}, b'{"items": []}')) as srv:
                with self.assertRaises(MalformedResponse): conn(srv).read({"entity": "Account"})
        with LoopbackServer(lambda *a: (200, {"Content-Type": "application/problem+json; charset=utf-8"}, b'{"items": []}')) as srv: self.assertEqual(conn(srv).read({"entity": "Account"})["items"], [])
    def test_non_finite_numbers_anywhere_in_a_response_are_refused(self):
        for body in (b'{"items": [], "extra": NaN}', b'{"items": [], "extra": Infinity}', b'{"items": [], "extra": -Infinity}', b'{"items": [{"id": "1", "v": NaN}]}'):
            with self.subTest(body), LoopbackServer(lambda m, p, q, h, b, bd=body: (200, {"Content-Type": "application/json"}, bd)) as srv:
                with self.assertRaises(MalformedResponse): conn(srv).read({"entity": "Account"})
    def test_next_cursor_normalisation(self):
        for raw, want in ((7, "7"), ("abc", "abc"), (None, None), ("", None), (0, None), (False, None)):
            with self.subTest(raw), LoopbackServer(lambda m, p, q, h, b, r=raw: jresp({"items": [], "next_cursor": r})) as srv: self.assertEqual(conn(srv).read({"entity": "Account"})["next_cursor"], want)
    def test_health_subscribe_unsubscribe_and_capabilities(self):
        self.assertEqual(self.c.health(), {"status": "unknown"}); self.assertEqual(self.c.capabilities(), {"read": True, "write": True, "discover": True}); self.assertEqual(self.c.unsubscribe({}), {"unsubscribed": True})
        with self.assertRaises(TransportError) as e: self.c.subscribe({})
        self.assertEqual(e.exception.code, "UNSUPPORTED_OPERATION")
        with LoopbackServer(lambda *a: jresp({}, 503)) as srv: self.assertEqual(conn(srv, health_path="/h").health(), {"status": "down", "http_status": 503})
        with LoopbackServer(lambda *a: jresp({})) as srv: self.assertEqual(conn(srv, health_path="/h").health(), {"status": "up", "http_status": 200})
class TestWrite(unittest.TestCase):
    def setUp(self): self.rig = Rig(); self.c = self.rig.connector; self.c.connect({"secret": TOKEN})
    def tearDown(self): self.rig.close()
    def w(self, **kw): return self.c.write(dict({"entity": "Account", "id": "1", "fields": {"status": "act"}, "idempotency_key": "idem-1"}, **kw))
    def test_a_write_sends_the_key_the_body_and_the_encoded_path_and_returns_the_reference(self):
        out = self.w(); r = self.rig.srv.requests[-1]; self.assertEqual((r["method"], r["path"], r["headers"]["idempotency-key"], r["headers"]["content-type"]), ("PATCH", "/accounts/1", "idem-1", "application/json")); self.assertEqual(r["body"], b'{"status":"act"}'); self.assertTrue(out["external_reference"].startswith("A-"))
    def test_path_parameters_are_percent_encoded_and_traversal_is_refused(self):
        with self.assertRaises(Exception): self.w(id="a/../b")                                                        # the server has no such row, but the point is the request path
        self.assertEqual(self.rig.srv.requests[-1]["path"], "/accounts/a%2F..%2Fb")
        n = len(self.rig.srv.requests)
        for bad in ("..", ".", "", "x" * 201, "a\x00b"):
            with self.subTest(bad):
                with self.assertRaises(TransportError): self.w(id=bad)
        self.assertEqual(len(self.rig.srv.requests), n)
    def test_unacceptable_write_requests_are_refused_before_any_request(self):
        n = len(self.rig.srv.requests)
        for kw in ({"idempotency_key": None}, {"idempotency_key": ""}, {"idempotency_key": "has space"}, {"idempotency_key": "k" * 201}, {"idempotency_key": "tab\t"}, {"fields": "x"}, {"fields": None}):
            with self.subTest(kw):
                with self.assertRaises(TransportError): self.w(**kw)
        with self.assertRaises(TransportError) as e: self.w(entity="Property")
        self.assertEqual(e.exception.code, "UNSUPPORTED_OPERATION"); self.assertEqual(len(self.rig.srv.requests), n)
    def test_an_unreadable_write_response_still_returns_the_id_as_the_reference(self):
        with LoopbackServer(lambda *a: (204, {}, b"")) as srv: self.assertEqual(conn(srv).write({"entity": "Account", "id": "77", "fields": {}, "idempotency_key": "idem-9"}), {"external_reference": "77", "result": {"status": 204}})
    def test_lookup_by_idempotency_key(self):
        self.assertIsNone(self.c.lookup_by_idempotency_key("idem-never")); out = self.w(); self.assertEqual(self.c.lookup_by_idempotency_key("idem-1")["external_reference"], out["external_reference"])
        with self.assertRaises(TransportError): self.c.lookup_by_idempotency_key("bad key")
        with LoopbackServer(lambda *a: jresp({"nothing": 1})) as srv:
            with self.assertRaises(MalformedResponse): conn(srv).lookup_by_idempotency_key("idem-1")
        with LoopbackServer(lambda *a: jresp({})) as srv:
            with self.assertRaises(TransportError) as e: conn(srv, lookup=None).lookup_by_idempotency_key("idem-1")
        self.assertEqual(e.exception.code, "UNSUPPORTED_OPERATION")
    def test_a_connector_without_an_idempotency_header_does_not_demand_a_key(self):
        with LoopbackServer(lambda *a: jresp({"id": "5"})) as srv: self.assertEqual(conn(srv, idempotency_header=None).write({"entity": "Account", "id": "5", "fields": {}})["external_reference"], "5"); self.assertNotIn("idempotency-key", srv.requests[0]["headers"])
class TestAuthentication(unittest.TestCase):
    def test_the_api_key_goes_in_the_configured_header_and_nowhere_else(self):
        with LoopbackServer(lambda *a: jresp({"items": []})) as srv:
            c = conn(srv, token="KEYVALUE", auth_header="X-Api-Key", auth_prefix=""); c.read({"entity": "Account"}); r = srv.requests[0]; self.assertEqual(r["headers"]["x-api-key"], "KEYVALUE"); self.assertNotIn("KEYVALUE", r["path"] + str(r["query"]) + r["body"].decode())
    def test_requests_without_a_connection_are_refused_for_authenticated_connectors(self):
        with LoopbackServer(lambda *a: jresp({})) as srv:
            with self.assertRaises(TransportError) as e: RestConnector(rest_cfg(srv)).discover()
            self.assertEqual(e.exception.code, "AUTHENTICATION_FAILED"); self.assertEqual(srv.requests, [])
    def test_connecting_without_a_credential_fails(self):
        with LoopbackServer(lambda *a: jresp({})) as srv:
            for creds in (None, {}, {"secret": ""}, {"secret": 5}):
                with self.subTest(creds):
                    with self.assertRaises(TransportError) as e: RestConnector(rest_cfg(srv)).connect(creds)
                    self.assertEqual(e.exception.code, "AUTHENTICATION_FAILED")
    def test_a_connector_with_no_authentication_needs_no_credential(self):
        with LoopbackServer(lambda *a: jresp({"items": []})) as srv: c = RestConnector(rest_cfg(srv, auth="NONE", credential_ref=None)); c.connect(None); c.read({"entity": "Account"}); self.assertNotIn("authorization", srv.requests[0]["headers"])
    def test_oauth2_a_bad_credential_fails_at_connect_before_any_api_call(self):
        idp = Idp(cid="cid", sec="csec"); api = LoopbackServer(lambda *a: jresp({"items": []})).start(); ip = LoopbackServer(idp).start()
        try:
            cfg = rest_cfg(api, auth="OAUTH2_CLIENT_CREDENTIALS", token_url=ip.url + "/token", allowed_hosts=(api.host, ip.host)); c = RestConnector(cfg)
            with self.assertRaises(TransportError) as e: c.connect({"secret": "cid:WRONG"})
            self.assertEqual(e.exception.code, "AUTHENTICATION_FAILED"); self.assertEqual(api.requests, [])
            c.connect({"secret": "cid:csec"}); c.read({"entity": "Account"}); self.assertEqual(api.requests[0]["headers"]["authorization"], "Bearer tok-%d" % idp.n)
        finally: api.stop(); ip.stop()
    def test_oauth2_a_401_invalidates_the_cached_token_without_any_reconnect(self):
        idp = Idp(cid="cid", sec="csec"); state = {"n": 0}
        def api(m, p, q, h, b):
            state["n"] += 1
            return jresp({"error": "expired"}, 401) if state["n"] == 1 else jresp({"items": [{"id": "1"}], "next_cursor": None})
        a = LoopbackServer(api).start(); i = LoopbackServer(idp).start()
        try:
            c = RestConnector(rest_cfg(a, auth="OAUTH2_CLIENT_CREDENTIALS", token_url=i.url + "/token", allowed_hosts=(a.host, i.host))); c.connect({"secret": "cid:csec"}); self.assertEqual(idp.n, 1)
            with self.assertRaises(TransportError) as e: c.read({"entity": "Account"})
            self.assertEqual(e.exception.code, "AUTHENTICATION_FAILED"); self.assertEqual(idp.n, 1)
            self.assertEqual(len(c.read({"entity": "Account"})["items"]), 1); self.assertEqual(idp.n, 2)                                   # the SAME connector, no reconnect: a new token was fetched
            self.assertEqual(a.requests[1]["headers"]["authorization"], "Bearer tok-2"); self.assertEqual(a.requests[0]["headers"]["authorization"], "Bearer tok-1")
        finally: a.stop(); i.stop()
    def test_oauth2_a_401_invalidates_the_token_and_the_runtime_reconnects_through_the_secret_boundary(self):
        idp = Idp(cid="cid", sec="csec"); state = {"n": 0}
        def api(m, p, q, h, b):
            state["n"] += 1
            return jresp({"error": "expired"}, 401) if state["n"] == 1 else jresp({"items": [{"id": "1"}], "next_cursor": None})
        a = LoopbackServer(api).start(); i = LoopbackServer(idp).start()
        try:
            from auif.clock import FakeClock
            from auif.connector import ConnectorRuntime
            from auif.observability import Telemetry
            from auif.tenancy import TenantAuthority
            from auif.throttle import Throttle
            from auif_ref.secrets import InMemorySecretStore
            clk = FakeClock(); sec = InMemorySecretStore(); sec.put("tenant-a", "secretref:ext/http", "cid:csec"); ctx = TenantAuthority().issue("tenant-a", "s")
            c = RestConnector(rest_cfg(a, auth="OAUTH2_CLIENT_CREDENTIALS", token_url=i.url + "/token", allowed_hosts=(a.host, i.host))); rt = ConnectorRuntime(c, secrets=sec, throttle=Throttle(clk, default_rate=1000, default_burst=1000), telemetry=Telemetry(), clock=clk)
            o1 = rt.call(ctx, "i1", "s", "e", "read", {"entity": "Account"}); self.assertEqual(o1.result["error"]["code"], "AUTHENTICATION_FAILED"); o2 = rt.call(ctx, "i1", "s", "e", "read", {"entity": "Account"}); self.assertEqual(o2.result["outcome_kind"], "DATA_OBTAINED"); self.assertEqual(idp.n, 2)
        finally: a.stop(); i.stop()
class TestUnderTheCoreRuntime(unittest.TestCase):
    """The connector wrapped by the audited ConnectorRuntime: the core's retry, backoff and unknown-outcome rules applied to real HTTP."""
    def setUp(self): self.rig = Rig()
    def tearDown(self): self.rig.close()
    def test_a_503_on_a_read_is_retried_and_succeeds(self):
        self.rig.h.faults += [("status", 503), ("status", 503)]; o = self.rig.call("read", {"entity": "Account", "page_size": 3}); self.assertEqual((o.result["outcome_kind"], o.attempts), ("DATA_OBTAINED", 3)); self.assertEqual(len(o.data["items"]), 3)
    def test_a_429_honours_retry_after_on_the_clock(self):
        self.rig.h.faults += [("status", 429, {"Retry-After": "30"})]; t0 = self.rig.clock.now; o = self.rig.call("read", {"entity": "Account"}); self.assertEqual(o.result["outcome_kind"], "DATA_OBTAINED"); self.assertGreaterEqual(self.rig.clock.now - t0, 30)
    def test_a_persistent_outage_is_reported_not_hidden(self):
        self.rig.h.faults += [("status", 503)] * 10; o = self.rig.call("read", {"entity": "Account"}); self.assertEqual((o.result["outcome_kind"], o.error["code"]), ("COULD_NOT_OBTAIN", "UNAVAILABLE"))
    def test_a_write_that_gets_a_503_is_maybe_applied_and_is_never_blind_retried(self):
        self.rig.h.faults += [("status", 503)]; n0 = len(self.rig.sa.effects); o = self.rig.call("write", {"entity": "Account", "id": "1", "fields": {"status": "act"}}, key="idem-w1")
        self.assertEqual((o.attempts, o.may_have_applied), (1, True)); self.assertEqual(len(self.rig.sa.effects), n0)
    def test_a_lost_reply_applies_exactly_once_and_reconciles_by_idempotency_key(self):
        self.rig.h.faults += [("drop_after_apply",)]; o = self.rig.call("write", {"entity": "Account", "id": "1", "fields": {"status": "act"}}, key="idem-w2"); self.assertTrue(o.may_have_applied); self.assertEqual(len(self.rig.sa.effects), 1)
        found = self.rig.rt.lookup(self.rig.ctx, "i1", "idem-w2"); self.assertTrue(found["external_reference"].startswith("A-")); self.assertEqual(len(self.rig.sa.effects), 1)
    def test_a_write_without_an_idempotency_key_is_refused_by_the_core(self):
        from auif.errors import AuifError
        with self.assertRaises(AuifError): self.rig.call("write", {"entity": "Account", "id": "1", "fields": {}}, key=None)
    def test_a_bad_credential_is_authentication_failed_and_not_retried(self):
        self.rig.secrets.put("tenant-a", "secretref:ext/http", "WRONG"); o = self.rig.call("read", {"entity": "Account"}); self.assertEqual((o.result["error"]["code"], o.attempts), ("AUTHENTICATION_FAILED", 1))
    def test_the_credential_never_appears_in_any_result_or_request_line(self):
        self.rig.call("read", {"entity": "Account"}); o = self.rig.call("discover")
        for r in self.rig.srv.requests: self.assertNotIn(TOKEN, r["path"] + str(r["query"]) + r["body"].decode())
        self.assertNotIn(TOKEN, repr(o.result) + repr(o.data))
class TestEndToEndThroughTheFabric(unittest.TestCase):
    """The real Fabric, the real core, real HTTP: activation, sync, governed write, lost reply, reconciliation, drift."""
    def setUp(self):
        from synthetic.world import World, ref
        from tests.acceptance_support import act
        self.act = act; self.w = World(); self.A = "tenant-a"; self.ctx = self.w.ctx[self.A]; self.sa = __import__("synthetic.systems", fromlist=["SystemA"]).SystemA(secret="x"); self.h = SystemAHandler(self.sa, TOKEN); self.srv = LoopbackServer(self.h).start()
        self.w.secrets.put(self.A, "secretref:ext/http", TOKEN); self.c = self.w.fabric.add_integration(self.ctx, integration_id="ia-http", anchor_module="synthetic-module-1", connector=RestConnector(rest_cfg(self.srv)), pack_ref=ref(self.w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", governed_operations=["updateAccount"], entities=["Account", "Property"]); self.w.integrations[(self.A, "http")] = self.c
    def tearDown(self): self.srv.stop()
    def test_activation_sync_and_delivery(self):
        self.assertEqual(self.c.activate()["state"], "ACTIVE"); rep = self.w.fabric.sync(self.ctx, "ia-http", "Account"); self.assertEqual((rep["delivered"], rep["invalid"], rep["failed"]), (7, 0, None)); self.assertEqual(len(self.w.m1.by_tenant[self.A]["entities"]), 7)
    def test_a_governed_write_is_applied_once_and_a_lost_reply_is_reconciled_without_a_second_effect(self):
        self.c.activate(); a = self.act(self.w, self.A, 1, {"display_name": "Zed"}, integ="http"); self.assertEqual(self.w.fabric.request_action(self.ctx, "synthetic-module-1", a)["execution_state"], "COMPLETED"); self.assertEqual(len(self.sa.effects), 1)
        self.h.faults += [("drop_after_apply",)]; b = self.act(self.w, self.A, 2, {"display_name": "Yan"}, integ="http"); self.assertEqual(self.w.fabric.request_action(self.ctx, "synthetic-module-1", b)["execution_state"], "UNKNOWN_OUTCOME"); self.assertEqual(len(self.sa.effects), 2)
        self.assertEqual(self.w.fabric.actions.reconcile(self.ctx, "act-0002")["execution_state"], "COMPLETED"); self.assertEqual(len(self.sa.effects), 2)
    def test_a_schema_change_on_the_real_target_is_detected_as_drift(self):
        self.c.activate(); self.sa.drift_rename_field("Account", "balance_cents", "balance_minor"); self.c.check_drift(); self.assertEqual(self.c.state(), "SCHEMA_DRIFT")
    def test_a_target_outage_never_loses_or_invents_data(self):
        self.c.activate(); self.h.faults += [("status", 503)] * 12; rep = self.w.fabric.sync(self.ctx, "ia-http", "Account"); self.assertEqual(rep["delivered"], 0); self.assertIsNotNone(rep["failed"])
    def test_the_credential_stays_inside_the_secret_boundary_end_to_end(self):
        self.c.activate(); self.w.fabric.sync(self.ctx, "ia-http", "Account")
        for r in self.srv.requests: self.assertNotIn(TOKEN, r["path"] + str(r["query"]) + r["body"].decode())
        self.assertNotIn(TOKEN, repr([v for _, v in self.w.store.list(self.ctx, "observations")]) + repr(self.w.tel.__dict__))
    def test_a_tenant_cannot_use_another_tenants_integration(self):
        with self.assertRaises(Exception): self.w.fabric.sync(self.w.ctx["tenant-b"], "ia-http", "Account")
if __name__ == "__main__": unittest.main()

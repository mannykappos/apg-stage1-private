"""The hardened HTTP transport, over real loopback sockets."""
import socket, ssl, threading, time, unittest
from auif.errors import MalformedResponse, TransportError
from auif_ext.connectors.http_client import HttpTransport
from auif_ext.tests.loopback import DROP, DripServer, LoopbackServer, jresp
def tr(srv, **kw): return HttpTransport([srv.host], allow_insecure_loopback=True, **kw)
class TestUrlAndHostPolicy(unittest.TestCase):
    def test_a_host_outside_the_allow_list_is_refused_and_no_connection_is_made(self):
        with LoopbackServer(lambda *a: jresp({})) as s:
            with self.assertRaises(TransportError) as e: HttpTransport(["other.test:1"], allow_insecure_loopback=True).request("GET", s.url + "/x")
            self.assertEqual((e.exception.code, e.exception.applied), ("TARGET_REJECTED_REQUEST", "NOT_APPLIED")); self.assertEqual(s.requests, [])
    def test_plain_http_is_refused_unless_explicitly_allowed_for_loopback(self):
        with LoopbackServer(lambda *a: jresp({})) as s:
            with self.assertRaises(TransportError): HttpTransport([s.host]).request("GET", s.url + "/x")                       # default: https only
            with self.assertRaises(TransportError): HttpTransport(["api.example.test"], allow_insecure_loopback=True).request("GET", "http://api.example.test/x")      # insecure is for loopback ONLY
            self.assertEqual(s.requests, [])
    def test_unacceptable_urls_are_refused(self):
        with LoopbackServer(lambda *a: jresp({})) as s:
            t = tr(s)
            for bad in ("http://user:pw@%s/x" % s.host, s.url + "/x#frag", s.url, "ftp://%s/x" % s.host, "file:///etc/passwd", "http://%s:notaport/x" % "127.0.0.1", "//%s/x" % s.host, "/relative"):
                with self.subTest(bad):
                    with self.assertRaises(TransportError): t.request("GET", bad)
            self.assertEqual(s.requests, [])
    def test_insecure_flag_never_permits_plain_http_to_a_non_loopback_host(self):
        for host in ("api.example.test", "10.0.0.1", "example.test:8080"):
            with self.subTest(host):
                with self.assertRaises(TransportError) as e: HttpTransport([host], allow_insecure_loopback=True).request("GET", "http://%s/x" % host)
                self.assertEqual((e.exception.code, e.exception.applied), ("TARGET_REJECTED_REQUEST", "NOT_APPLIED")); self.assertIn("plain http", e.exception.message)    # refused by policy, not by a failed DNS lookup
    def test_userinfo_is_refused_even_when_the_bare_host_is_allowed(self):
        with LoopbackServer(lambda *a: jresp({})) as s:
            t = HttpTransport([s.host.rsplit(":", 1)[0]], allow_insecure_loopback=True)                                       # a bare-host allow-list, so the allow-list check cannot hide the userinfo check
            self.assertEqual(t.request("GET", s.url + "/ok").status, 200); n = len(s.requests)
            for bad in ("http://user:pw@%s/x" % s.host, "http://user@%s/x" % s.host, "http://:pw@%s/x" % s.host):
                with self.subTest(bad):
                    with self.assertRaises(TransportError) as e: t.request("GET", bad)
                    self.assertEqual((e.exception.code, e.exception.applied), ("TARGET_REJECTED_REQUEST", "NOT_APPLIED")); self.assertNotIn("pw", str(e.exception) + e.exception.message)
            self.assertEqual(len(s.requests), n)
    def test_an_allow_list_is_mandatory(self):
        with self.assertRaises(ValueError): HttpTransport([])
    def test_unsupported_methods_and_non_bytes_bodies_are_refused(self):
        with LoopbackServer(lambda *a: jresp({})) as s:
            with self.assertRaises(TransportError): tr(s).request("TRACE", s.url + "/x")
            with self.assertRaises(TransportError): tr(s).request("POST", s.url + "/x", body="text")
    def test_tls_verification_is_on_by_default_and_a_supplied_context_is_honoured(self):
        t = HttpTransport(["api.example.test"]); self.assertEqual((t.ctx.verify_mode, t.ctx.check_hostname), (ssl.CERT_REQUIRED, True))
        c = ssl.create_default_context(); self.assertIs(HttpTransport(["a.test"], ssl_context=c).ctx, c)
class TestHeaders(unittest.TestCase):
    def test_header_injection_is_refused(self):
        with LoopbackServer(lambda *a: jresp({})) as s:
            for name, val in (("X-A", "v\r\nX-Evil: 1"), ("X-A", "v\nx"), ("X-A", "v\x00"), ("Bad Name", "v"), ("X:A", "v"), ("", "v")):
                with self.subTest((name, val)):
                    with self.assertRaises(TransportError): tr(s).request("GET", s.url + "/x", headers={name: val})
            self.assertEqual(s.requests, [])
    def test_requests_ask_for_no_compression_and_close_the_connection(self):
        with LoopbackServer(lambda *a: jresp({})) as s:
            tr(s).request("GET", s.url + "/x", headers={"X-One": "1"}); h = s.requests[0]["headers"]; self.assertEqual((h["accept-encoding"], h["connection"], h["x-one"]), ("identity", "close", "1")); self.assertTrue(h["user-agent"].startswith("auif-ext/"))
class TestResponses(unittest.TestCase):
    def test_redirects_are_never_followed(self):
        with LoopbackServer(lambda m, p, q, h, b: (302, {"Location": "/elsewhere"}, b"")) as s:
            r = tr(s).request("GET", s.url + "/x"); self.assertEqual(r.status, 302); self.assertEqual(len(s.requests), 1)
    def test_an_oversized_response_is_refused(self):
        with LoopbackServer(lambda *a: (200, {"Content-Type": "application/json"}, b"x" * 5000)) as s:
            with self.assertRaises(MalformedResponse): tr(s, max_response_bytes=1000).request("GET", s.url + "/x")
            self.assertEqual(tr(s, max_response_bytes=5000).request("GET", s.url + "/x").status, 200)               # exactly at the limit is fine
    def test_response_headers_are_lowercased_and_duplicates_joined(self):
        with LoopbackServer(lambda *a: (200, {"X-Dup": "a", "Content-Type": "application/json"}, b"{}")) as s: r = tr(s).request("GET", s.url + "/x"); self.assertEqual(r.headers["content-type"], "application/json"); self.assertEqual(r.body, b"{}")
class TestFailureMapping(unittest.TestCase):
    def test_a_refused_connection_is_connection_failed_and_definitely_not_applied(self):
        s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
        for m in ("GET", "POST"):
            with self.subTest(m):
                with self.assertRaises(TransportError) as e: HttpTransport(["127.0.0.1:%d" % port], allow_insecure_loopback=True, connect_timeout=1).request(m, "http://127.0.0.1:%d/x" % port, body=b"x" if m == "POST" else None)
                self.assertEqual((e.exception.code, e.exception.applied), ("CONNECTION_FAILED", "NOT_APPLIED"))
    def test_a_read_that_times_out_is_not_applied_and_a_write_that_times_out_is_maybe_applied(self):
        def slow(*a): time.sleep(0.6); return jresp({})
        with LoopbackServer(slow) as s:
            for m, want in (("GET", "NOT_APPLIED"), ("POST", "MAYBE"), ("PATCH", "MAYBE"), ("DELETE", "MAYBE")):
                with self.subTest(m):
                    with self.assertRaises(TransportError) as e: tr(s, request_timeout=0.2).request(m, s.url + "/x", body=b"{}" if m != "GET" else None)
                    self.assertEqual((e.exception.code, e.exception.applied), ("TIMEOUT", want))
    def test_a_connection_dropped_after_the_request_was_sent(self):
        with LoopbackServer(lambda *a: DROP) as s:
            for m, want in (("GET", "NOT_APPLIED"), ("POST", "MAYBE")):
                with self.subTest(m):
                    with self.assertRaises(TransportError) as e: tr(s).request(m, s.url + "/x", body=b"{}" if m == "POST" else None)
                    self.assertEqual((e.exception.code, e.exception.applied), ("CONNECTION_FAILED", want))
    def test_error_messages_never_contain_the_url_or_headers(self):
        with LoopbackServer(lambda *a: DROP) as s:
            with self.assertRaises(TransportError) as e: tr(s).request("POST", s.url + "/secret-path?token=abc", headers={"Authorization": "Bearer SECRETVALUE"}, body=b"{}")
            text = str(e.exception) + repr(e.exception.message)
            for leak in ("SECRETVALUE", "secret-path", "token=abc"): self.assertNotIn(leak, text)
class TestTotalDeadline(unittest.TestCase):
    """rev8: a hard bound on the WHOLE exchange. A server that drips bytes slower than the per-operation timeout must not hold a call open."""
    LEAD = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 400\r\nConnection: close\r\n\r\n"
    def timed(self, srv, method, **kw):
        t0 = time.monotonic()
        with self.assertRaises(TransportError) as e: HttpTransport([srv.host], allow_insecure_loopback=True, request_timeout=5.0, **kw).request(method, srv.url + "/x", body=b"{}" if method != "GET" else None)
        return e.exception, time.monotonic() - t0
    def test_a_slow_body_is_cut_off_at_the_deadline_even_though_no_single_read_times_out(self):
        with DripServer(self.LEAD, b"x" * 400, interval=0.15) as s:                                      # 400 bytes would take 60 s; every read arrives within 0.15 s, far under the 5 s read timeout
            e, dt = self.timed(s, "GET", total_deadline=1.0)
        self.assertEqual((e.code, e.applied), ("TIMEOUT", "NOT_APPLIED")); self.assertLess(dt, 3.0); self.assertGreaterEqual(dt, 0.9)
    def test_slow_headers_are_cut_off_too(self):
        with DripServer(b"", self.LEAD + b"x" * 400, interval=0.15) as s: e, dt = self.timed(s, "GET", total_deadline=1.0)
        self.assertEqual((e.code, e.applied), ("TIMEOUT", "NOT_APPLIED")); self.assertLess(dt, 3.0)
    def test_a_write_cut_off_by_the_deadline_is_maybe_applied(self):
        with DripServer(self.LEAD, b"x" * 400, interval=0.15) as s: e, dt = self.timed(s, "POST", total_deadline=1.0)
        self.assertEqual((e.code, e.applied), ("TIMEOUT", "MAYBE"))
    def test_a_body_with_no_content_length_cut_short_is_never_accepted_as_complete(self):
        lead = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n"                # read-until-close framing: a cut looks like a clean end of stream
        with DripServer(lead, b'{"a": 1' + b" " * 300, interval=0.15) as s: e, dt = self.timed(s, "GET", total_deadline=1.0)
        self.assertEqual(e.code, "TIMEOUT")
    def test_a_write_with_slow_headers_or_no_length_framing_is_maybe_applied_not_a_clean_end(self):
        nolen = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n"
        for lead, drip in ((b"", self.LEAD + b"x" * 400), (nolen, b'{"a": 1' + b" " * 300)):
            with self.subTest(len(lead)), DripServer(lead, drip, interval=0.15) as s: e, dt = self.timed(s, "POST", total_deadline=1.0); self.assertEqual((e.code, e.applied), ("TIMEOUT", "MAYBE")); self.assertLess(dt, 3.0)
    def test_a_chunked_body_cut_mid_chunk_is_a_timeout_with_the_right_applied_flag(self):
        lead = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n190\r\n"                     # a 400-byte chunk, then it drips: http.client RAISES IncompleteRead here instead of returning short data
        for method, applied in (("GET", "NOT_APPLIED"), ("POST", "MAYBE")):
            with self.subTest(method), DripServer(lead, b"x" * 400, interval=0.15) as s: e, dt = self.timed(s, method, total_deadline=1.0); self.assertEqual((e.code, e.applied), ("TIMEOUT", applied)); self.assertLess(dt, 3.0)
    def test_a_fast_response_is_unaffected_and_the_deadline_is_per_call(self):
        with LoopbackServer(lambda *a: jresp({"ok": True})) as s:
            t = HttpTransport([s.host], allow_insecure_loopback=True, total_deadline=1.0)
            for _ in range(3): self.assertEqual(t.request("GET", s.url + "/x").status, 200)
            time.sleep(1.2); self.assertEqual(t.request("GET", s.url + "/x").status, 200)               # a timer from an earlier call must not poison a later one
    def test_a_deadline_that_expires_while_connecting_is_honoured_before_any_request_is_sent(self):
        from unittest import mock
        class Immediate:                                                                                    # a timer that fires synchronously, i.e. BEFORE connect() returns and before any socket is held
            def __init__(self, interval, fn): self.fn = fn; self.daemon = False
            def start(self): self.fn()
            def cancel(self): pass
        with LoopbackServer(lambda *a: jresp({"ok": True})) as s, mock.patch("auif_ext.connectors.http_client.threading.Timer", Immediate):
            with self.assertRaises(TransportError) as e: tr(s).request("POST", s.url + "/x", body=b"{}")
            self.assertEqual((e.exception.code, e.exception.applied), ("TIMEOUT", "NOT_APPLIED")); self.assertEqual(s.requests, [])               # nothing was sent, so even a write is NOT_APPLIED
    def test_the_deadline_must_be_a_positive_finite_number(self):
        for bad in (0, -1, float("inf"), float("nan"), None, "5", True):
            with self.subTest(bad):
                with self.assertRaises(ValueError): HttpTransport(["h:1"], total_deadline=bad)
    def test_the_deadline_error_text_contains_nothing_from_the_request(self):
        with DripServer(self.LEAD, b"x" * 400, interval=0.15) as s:
            e, _ = self.timed(s, "GET", total_deadline=0.5); self.assertNotIn("127.0.0.1", str(e) + e.message); self.assertNotIn("/x", str(e) + e.message)
if __name__ == "__main__": unittest.main()

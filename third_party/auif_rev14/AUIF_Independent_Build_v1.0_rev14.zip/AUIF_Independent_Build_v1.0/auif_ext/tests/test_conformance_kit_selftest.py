"""rev8: a conformance kit that cannot fail proves nothing. Each deliberately broken connector below MUST be caught by the specific check that guards that behaviour."""
import io, time, unittest
from auif.errors import TransportError
from auif_ext.conformance.suite import ConnectorConformanceCases
from auif_ext.connectors import http_client
from auif_ext.connectors.rest import RestConnector
from auif_ext.tests.conformance_rest_sandbox import CANARY, RestSandbox
class Leaky(RestConnector):
    def read(self, request):
        try: return super().read(request)
        except TransportError as e: raise TransportError(e.code, applied=e.applied, message="failed with key " + (self._secret.reveal() if self._secret else "?"))
class WriteTimeoutNotMaybe(RestConnector):
    def write(self, request):
        try: return super().write(request)
        except TransportError as e: raise TransportError(e.code, applied="NOT_APPLIED" if e.code == "TIMEOUT" else e.applied, message=e.message)
class ReadMaybeApplied(RestConnector):
    def read(self, request):
        try: return super().read(request)
        except TransportError as e: raise TransportError(e.code, applied="MAYBE", message=e.message)
class RawException(RestConnector):
    def read(self, request):
        try: return super().read(request)
        except TransportError as e: raise RuntimeError("boom " + e.code)
class StuckCursor(RestConnector):
    def read(self, request): r = super().read(request); cur = request.get("cursor"); return dict(r, next_cursor=cur, complete=False) if cur and r["next_cursor"] else r
class NotIdempotent(RestConnector):
    def write(self, request): return super().write(dict(request, idempotency_key="%s-%f" % (request["idempotency_key"], time.time())))
class SecretInUrl(RestConnector):
    def _url(self, path, **params): return super()._url(path, **params) + ("?key=" + self._secret.reveal() if self._secret else "")
class RemembersCredentials(RestConnector):
    def disconnect(self): pass
class RemoteFile:                                                                                              # a connector module that opens its own socket
    pass
def broken(cls, style="cursor"):
    class T(RestSandbox):
        def connector(self):
            good = super().connector(); return cls(good.cfg)
    return lambda: T(style)
CASES = ((Leaky, "test_the_credential_never_appears_in_repr_errors_or_urls"), (WriteTimeoutNotMaybe, "test_a_failed_write_is_maybe_applied_exactly_when_the_request_may_have_reached_the_target"), (ReadMaybeApplied, "test_a_failed_read_is_normalised_and_never_maybe_applied"),
         (RawException, "test_a_failed_read_is_normalised_and_never_maybe_applied"), (StuckCursor, "test_paging_terminates_has_no_duplicates_and_never_returns_a_stuck_cursor"), (NotIdempotent, "test_an_idempotent_write_takes_effect_once_and_sends_its_key"),
         (SecretInUrl, "test_the_credential_never_appears_in_repr_errors_or_urls"), (RemembersCredentials, "test_an_unconnected_or_disconnected_connector_sends_nothing"))
def run_one(factory, name):
    class C(ConnectorConformanceCases, unittest.TestCase): target_factory = staticmethod(factory)
    res = unittest.TextTestRunner(stream=io.StringIO(), verbosity=0).run(unittest.TestSuite([C(name)])); return res
class TestTheKitCatchesBrokenConnectors(unittest.TestCase):
    def test_each_broken_connector_is_caught_by_its_guarding_check(self):
        for cls, name in CASES:
            with self.subTest(cls.__name__): self.assertFalse(run_one(broken(cls), name).wasSuccessful(), "%s was NOT caught by %s" % (cls.__name__, name))
    def test_the_unbroken_connector_passes_the_same_checks(self):
        for name in sorted({n for _, n in CASES}):
            with self.subTest(name): res = run_one(lambda: RestSandbox("cursor", "API_KEY"), name); self.assertTrue(res.wasSuccessful(), res.failures[:1] or res.errors[:1])
    def test_a_connector_module_that_opens_its_own_socket_is_caught(self):
        class C(ConnectorConformanceCases, unittest.TestCase): target_factory = staticmethod(lambda: RestSandbox()); connector_modules = (http_client,)
        self.assertFalse(unittest.TextTestRunner(stream=io.StringIO()).run(unittest.TestSuite([C("test_connector_modules_open_no_sockets_of_their_own")])).wasSuccessful())              # the one module allowed to use sockets is exactly what the screen forbids elsewhere
    def test_a_target_that_declares_too_few_faults_is_refused(self):
        class Few(RestSandbox): faults = {"unauthorized"}
        self.assertFalse(run_one(lambda: Few(), "test_the_target_declares_at_least_the_minimum_faults_and_only_known_ones").wasSuccessful())
if __name__ == "__main__": unittest.main()

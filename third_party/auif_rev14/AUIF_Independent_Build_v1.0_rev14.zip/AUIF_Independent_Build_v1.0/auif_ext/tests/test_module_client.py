"""The module client and its two worked examples, running against the real Fabric over the synthetic world."""
import unittest
from auif.errors import AuifError
from auif_ext.module_client.client import BaseModule, ModuleClient, derive_idempotency_key
from auif_ext.module_client.examples import ExampleDirectoryModule, ExampleUpdaterModule
from synthetic.connectors import SyntheticRestConnector
from synthetic.systems import SystemA
from synthetic.world import World, ref
def add_integration(w, module_id, iid, tenant="tenant-a", governed=("updateAccount",)):
    ctx = w.ctx[tenant]; sa = SystemA(secret="s-" + iid); w.secrets.put(tenant, "secretref:synthetic/" + iid, sa.secret)
    c = w.fabric.add_integration(ctx, integration_id=iid, anchor_module=module_id, connector=SyntheticRestConnector(sa, "secretref:synthetic/" + iid), pack_ref=ref(w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", governed_operations=list(governed), entities=["Account", "Property"]); c.activate(); return c, sa
class TestBaseModule(unittest.TestCase):
    def test_requirements_and_module_id_are_validated(self):
        for mid, req in (("", [{"concept": "P", "attributes": []}]), (None, []), ("m", "x"), ("m", [{"concept": 5, "attributes": []}]), ("m", [{"concept": "P"}]), ("m", [{"concept": "P", "attributes": "a"}]), ("m", ["P"])):
            with self.subTest((mid, req)):
                with self.assertRaises(ValueError): BaseModule(mid, req)
    def test_the_descriptor_is_a_copy_so_a_caller_cannot_change_what_the_module_declared(self):
        req = [{"concept": "Party", "attributes": ["a"]}]; m = BaseModule("m", req); req[0]["attributes"].append("EVIL"); self.assertEqual(m.semantic_requirements(), [{"concept": "Party", "attributes": ["a"]}]); self.assertEqual(m.module_capabilities(), {"consumes": ["Party"]}); self.assertEqual(BaseModule("m", req, {"x": 1}).module_capabilities(), {"x": 1})
    def test_handlers_are_routed_by_kind_and_can_be_decorators(self):
        m = BaseModule("m", []); got = []
        @m.on("entity")
        def e(ctx, o): got.append(("entity", o))
        m.on("observation", lambda c, o: got.append(("observation", o))); m.on("event", lambda c, o: got.append(("event", o))); m.on("state", lambda c, o: got.append(("state", o))); m.on("error", lambda c, o: got.append(("error", o)))
        m.ingest_canonical_entity(None, 1); m.ingest_canonical_observation(None, 2); m.ingest_canonical_event(None, 3); m.receive_integration_state(None, 4); m.receive_integration_error(None, 5); self.assertEqual(got, [("entity", 1), ("observation", 2), ("event", 3), ("state", 4), ("error", 5)]); self.assertIs(e.__name__, "e")
        with self.assertRaises(ValueError): m.on("bogus", lambda *a: None)
    def test_a_failing_handler_never_stops_the_others_and_its_message_is_not_kept(self):
        m = BaseModule("m", []); got = []; m.on("entity", lambda c, o: (_ for _ in ()).throw(RuntimeError("contains PRIVATE data"))); m.on("entity", lambda c, o: got.append(o)); m.ingest_canonical_entity(None, "x")
        self.assertEqual(got, ["x"]); self.assertEqual(m.handler_errors, [{"kind": "entity", "error": "RuntimeError"}]); self.assertNotIn("PRIVATE", repr(m.handler_errors))
class TestExampleDirectoryModule(unittest.TestCase):
    def setUp(self):
        self.w = World(); self.mod = ExampleDirectoryModule(); self.client = ModuleClient(self.w.fabric, self.mod); self.ctx = self.w.ctx["tenant-a"]; self.c, self.sa = add_integration(self.w, self.mod.module_id, "ex-dir")
    def test_a_sync_mirrors_every_canonical_party_into_the_module_without_it_knowing_the_source_system(self):
        rep = self.client.sync(self.ctx, "ex-dir", "Account"); self.assertEqual(rep["delivered"], 7); m = self.mod.mirror["tenant-a"]; self.assertEqual(len(m), 7); self.assertTrue(all(k.startswith("party:") for k in m)); self.assertTrue(all(v["canonical_type"] == "Party" for v in m.values()))
    def test_state_changes_reach_the_module_and_other_tenants_data_never_does(self):
        self.client.sync(self.ctx, "ex-dir", "Account"); self.assertTrue(self.mod.states); self.assertEqual(set(self.mod.mirror), {"tenant-a"}); self.assertTrue(all(t == "tenant-a" for t, _ in self.mod.states))
    def test_a_module_cannot_reach_another_tenants_integration(self):
        with self.assertRaises(Exception): self.client.sync(self.w.ctx["tenant-b"], "ex-dir", "Account")
    def test_two_modules_on_two_integrations_share_the_unchanged_core(self):
        other = ExampleUpdaterModule(); ModuleClient(self.w.fabric, other); add_integration(self.w, other.module_id, "ex-upd"); self.client.sync(self.ctx, "ex-dir", "Account"); self.assertEqual(len(self.mod.mirror["tenant-a"]), 7)
class TestActions(unittest.TestCase):
    def setUp(self):
        self.w = World(); self.mod = ExampleUpdaterModule(); self.client = ModuleClient(self.w.fabric, self.mod); self.ctx = self.w.ctx["tenant-a"]; self.c, self.sa = add_integration(self.w, self.mod.module_id, "ex-upd"); self.n = 0
    def rename(self, name, intent="intent-1", ctx=None):
        self.n += 1; return self.mod.rename(self.client, ctx or self.ctx, integration_id="ex-upd", canonical_id="party:synthetic-system-a:3", new_name=name, intent_id=intent, action_id="act-%04d" % self.n, correlation_id="corr-%04d" % self.n)
    def test_a_rename_is_applied_to_the_target_system_through_the_core(self):
        r = self.rename("Renamed Corp"); self.assertEqual(r["execution_state"], "COMPLETED"); self.assertEqual(self.sa.rows["Account"]["3"]["profile"]["name"], "Renamed Corp"); self.assertEqual(self.client.action_status(self.ctx, "act-0001")["execution_state"], "COMPLETED")
    def test_a_retry_of_the_same_intent_never_acts_twice(self):
        self.rename("Once", intent="same"); n = len(self.sa.effects); r2 = self.rename("Once", intent="same"); self.assertEqual(len(self.sa.effects), n); self.assertEqual(r2["execution_state"], "COMPLETED")
    def test_a_different_intent_is_a_different_action(self):
        self.rename("A", intent="i1"); n = len(self.sa.effects); self.rename("B", intent="i2"); self.assertEqual(len(self.sa.effects), n + 1)
    def test_the_built_action_is_contract_valid_tenant_bound_and_carries_no_decision_reference(self):
        a = self.client.build_action(self.ctx, integration_id="ex-upd", action_type="synthetic.update_party", canonical_type="Party", canonical_id="party:synthetic-system-a:1", attributes={"display_name": "X"}, action_id="act-9", correlation_id="corr-9", intent_id="i")
        self.assertEqual((a["tenant_id"], a["source_module"], a["target_system_id"], a["environment_id"]), ("tenant-a", self.mod.module_id, "synthetic-system-a", "env-sandbox")); self.assertIsNone(a["governance"]["governor_decision_ref"]); self.assertEqual(a["manifest_ref"], self.c.manifest_ref())
    def governed(self, setup=None):
        if setup: setup(self.w.gov)
        r = self.client.request_action(self.ctx, integration_id="ex-upd", action_type="synthetic.update_party", canonical_type="Party", canonical_id="party:synthetic-system-a:3", attributes={"display_name": "Gov"}, action_id="act-0099", correlation_id="corr-99", intent_id="g", governance_required=True)
        return r, self.client.action_status(self.ctx, "act-0099")
    def test_a_granted_governed_request_carries_a_decision_issued_by_governor_never_by_the_module(self):
        built = self.client.build_action(self.ctx, integration_id="ex-upd", action_type="synthetic.update_party", canonical_type="Party", canonical_id="party:synthetic-system-a:3", attributes={"display_name": "Gov"}, action_id="act-0098", correlation_id="corr-98", intent_id="g", governance_required=True)
        self.assertIsNone(built["governance"]["governor_decision_ref"])                                                  # the module asserted no decision
        r, rec = self.governed(); self.assertEqual((r["execution_state"], len(self.sa.effects), rec["governance"]["governor_decision_ref"]), ("COMPLETED", 1, "gov-dec-0001")); self.assertEqual(len(self.w.gov.decisions), 1)
    def test_a_denied_governed_request_never_reaches_the_target(self):
        r, rec = self.governed(lambda g: g.deny.add("synthetic.update_party")); self.assertEqual((r["execution_state"], len(self.sa.effects), rec["governance"]["governor_decision_ref"]), ("FAILED", 0, None))
    def test_a_pending_or_unavailable_governor_holds_the_action_without_acting_fail_closed(self):
        r, rec = self.governed(lambda g: g.pending.add("synthetic.update_party")); self.assertEqual((r["execution_state"], len(self.sa.effects)), ("QUEUED", 0))
    def test_an_unavailable_governor_holds_the_action_without_acting(self):
        r, rec = self.governed(lambda g: setattr(g, "unavailable", True)); self.assertEqual((r["execution_state"], len(self.sa.effects), rec["governance"]["governor_decision_ref"]), ("QUEUED", 0, None))
    def test_the_idempotency_key_is_deterministic_tenant_specific_and_content_specific(self):
        c = self.ctx; k = derive_idempotency_key(c, "i", "Party", "p:1", {"a": 1}); self.assertEqual(k, derive_idempotency_key(c, "i", "Party", "p:1", {"a": 1})); self.assertEqual(k, derive_idempotency_key(c, "i", "Party", "p:1", {"a": 1}))
        for other in (derive_idempotency_key(self.w.ctx["tenant-b"], "i", "Party", "p:1", {"a": 1}), derive_idempotency_key(c, "j", "Party", "p:1", {"a": 1}), derive_idempotency_key(c, "i", "Task", "p:1", {"a": 1}), derive_idempotency_key(c, "i", "Party", "p:2", {"a": 1}), derive_idempotency_key(c, "i", "Party", "p:1", {"a": 2})): self.assertNotEqual(k, other)
        self.assertRegex(k, r"^idem-[0-9a-f]{40}$"); self.assertEqual(derive_idempotency_key(c, "i", "Party", "p:1", {"a": 1, "b": 2}), derive_idempotency_key(c, "i", "Party", "p:1", {"b": 2, "a": 1}))
    def test_an_explicit_idempotency_key_is_used_as_given(self):
        a = self.client.build_action(self.ctx, integration_id="ex-upd", action_type="synthetic.update_party", canonical_type="Party", canonical_id="party:synthetic-system-a:1", attributes={"display_name": "X"}, action_id="act-9", correlation_id="corr-9", idempotency_key="idem-explicit-0001"); self.assertEqual(a["idempotency_key"], "idem-explicit-0001")
    def test_another_tenants_context_cannot_act_on_this_integration(self):
        with self.assertRaises(Exception): self.rename("Hijack", ctx=self.w.ctx["tenant-b"])
        self.assertEqual(self.sa.effects, [])
    def test_a_forged_context_is_refused_by_the_core(self):
        from auif.tenancy import TenantAuthority
        forged = TenantAuthority(secret=b"another-authority-secret").issue("tenant-a", "svc")
        with self.assertRaises(AuifError): self.rename("Forged", ctx=forged)
        self.assertEqual(self.sa.effects, [])
if __name__ == "__main__": unittest.main()

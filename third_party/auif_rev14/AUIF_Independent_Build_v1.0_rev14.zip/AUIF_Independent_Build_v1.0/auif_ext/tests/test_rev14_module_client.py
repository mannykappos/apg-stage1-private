"""rev14 (finding M8-F4): BaseModule no longer swallows a handler's failure. It still keeps delivering to its other handlers and still keeps only the exception's type name, but it returns a failure
marker that the fabric reads: the delivery is counted as failed, recorded, and the module is told.  Every test here except the healthy-module guard fails on rev13."""
import unittest
from auif_ext.module_client.client import BaseModule
from synthetic.connectors import SyntheticRestConnector
from synthetic.world import World, ref
A = "tenant-a"
def boom(ctx, x): raise ValueError("detail that must not be kept")
class TestBaseModuleReportsHandlerFailures(unittest.TestCase):
    def test_a_failing_handler_returns_a_marker_and_the_other_handlers_still_run(self):
        m = BaseModule("x", []); seen = []; m.on("entity", boom); m.on("entity", lambda c, o: seen.append(o))
        self.assertEqual(m.ingest_canonical_entity(None, {"k": 1}), {"handler_failures": 1}); self.assertEqual(seen, [{"k": 1}])
        self.assertEqual(m.handler_errors, [{"kind": "entity", "error": "ValueError"}])
    def test_every_delivery_kind_returns_the_marker(self):
        m = BaseModule("x", [])
        for k in ("entity", "observation", "event", "state", "error"): m.on(k, boom)
        for call in (m.ingest_canonical_entity, m.ingest_canonical_observation, m.ingest_canonical_event, m.receive_integration_state, m.receive_integration_error): self.assertEqual(call(None, {}), {"handler_failures": 1}, call.__name__)
    def test_a_healthy_module_returns_nothing(self):
        m = BaseModule("x", []); m.on("entity", lambda c, o: None); self.assertIsNone(m.ingest_canonical_entity(None, {})); self.assertIsNone(BaseModule("y", []).ingest_canonical_entity(None, {}))
    def test_the_fabric_counts_a_basemodule_failure_and_does_not_report_the_delivery_as_made(self):
        w = World(); m = BaseModule("rev14-base", [{"concept": "Party", "attributes": ["display_name"]}]); errs = []; m.on("entity", boom); m.on("error", lambda c, e: errs.append(e["kind"])); w.fabric.register_module(m)
        w.fabric.add_integration(w.ctx[A], "ia-base", anchor_module="rev14-base", connector=SyntheticRestConnector(w.sys[A]["A"], "secretref:synthetic/rest"), pack_ref=ref(w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", entities=["Account"]).activate()
        rep = w.fabric.sync(w.ctx[A], "ia-base", "Account"); self.assertEqual((rep["delivered"], rep["module_failed"]), (0, 7))
        self.assertEqual(w.tel.counters[(A, "ia-base", "module_failures")], 7); self.assertEqual(errs.count("MODULE_DELIVERY_FAILED"), 7); self.assertEqual(len(w.store.list(w.ctx[A], "module_delivery_failures")), 7)
if __name__ == "__main__": unittest.main()

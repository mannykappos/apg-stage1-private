"""AUIF as a governed target: the Governor adapter, checked per method (AUIF-AT-27) against a Governor contract double, and, when AUIF_GOVERNOR_R14_ZIP is supplied, against the REAL R14 Governor code including its full pipeline."""
import hashlib, importlib, json, os, re, sys, tempfile, unittest, zipfile
from types import SimpleNamespace
from auif_ext.governor_adapter import FORBIDDEN_METHODS, FabricObservationSource, build_adapter_class, check_binding
from auif_ext.tests import gov_double
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); R14_SHA = "e6f299ca51fc10d4a0a95ca2a9e3086c72aacff71b6a9bf8eb08587859c3ee42"
CONTRACT = {"identity", "declared_capabilities", "declare", "observe", "attest", "normalize", "translate_event", "deliver_decision", "health"}
NATIVE = [{"observation_id": "obs-000001", "object_type": "Account", "object_id": "1", "payload_hash": "ab12"}, {"observation_id": "obs-000002", "object_type": "Account", "object_id": "2", "payload_hash": "cd34", "classification": "restricted"}]
class BoundaryChecks:
    """AT-27 step 2: per-method boundary checks. Runs against whichever Governor binding `self.gov` provides."""
    def make(self, **kw):
        base = dict(source=lambda: [dict(n) for n in NATIVE], clock=lambda: 1234.5); base.update(kw); return build_adapter_class(self.gov)("tenant-a", "synthetic-system-a", "env-sandbox", **base)
    def valid(self, normalized): return gov_double.structurally_valid(normalized.neutral_object)
    def test_the_adapter_is_exactly_the_contract_and_has_no_authority_operations(self):
        a = self.make(); self.assertIsInstance(a, self.gov.TargetSystemAdapter); public = {n for n in dir(a) if not n.startswith("_") and callable(getattr(a, n))}; self.assertEqual(public, CONTRACT)
        for n in FORBIDDEN_METHODS: self.assertFalse(hasattr(a, n), n); self.assertFalse(hasattr(type(a), n), n)
    def test_identity_and_health_are_informational(self):
        a = self.make(adapter_id="auif:x", adapter_version="9.9.9"); self.assertEqual(a.identity(), {"adapter_id": "auif:x", "adapter_version": "9.9.9", "target_system_id": "synthetic-system-a"}); self.assertEqual(a.health(), {"status": "unknown"})
        self.assertEqual(self.make(health_probe=lambda: {"status": "healthy"}).health(), {"status": "healthy"})
        for probe in (lambda: 5, lambda: (_ for _ in ()).throw(RuntimeError("x"))): self.assertEqual(self.make(health_probe=probe).health(), {"status": "unknown"})
    def test_capabilities_are_an_honest_self_declaration(self):
        C = self.gov.Capability; d = self.make().declared_capabilities(); self.assertEqual(d, {C.OBSERVATION: True, C.NORMALIZATION: True, C.MANIFEST_DECLARATION: False, C.ATTESTATION: False, C.DECISION_DELIVERY: False})
        d = self.make(declare_source=lambda: {}, attester=lambda n: {}, decision_verifier=lambda d: True, decision_sink=lambda d: None).declared_capabilities(); self.assertTrue(all(d.values()) and len(d) == 5)
        self.assertFalse(self.make(decision_verifier=lambda d: True).declared_capabilities()[C.DECISION_DELIVERY]); self.assertFalse(self.make(decision_sink=lambda d: None).declared_capabilities()[C.DECISION_DELIVERY])
        for undeclared in (C.RUNTIME_STATE_OBSERVATION, C.EVENT_STREAM): self.assertNotIn(undeclared, self.make().declared_capabilities())
    def test_declare_is_a_proposal_whose_identity_fields_the_source_cannot_override(self):
        a = self.make(declare_source=lambda: {"tenant_id": "EVIL", "target_system_id": "EVIL", "components": ["x.y.z"]}); p = a.declare(); self.assertEqual((p["tenant_id"], p["target_system_id"], p["components"]), ("tenant-a", "synthetic-system-a", ["x.y.z"])); self.assertEqual(a.declare(), p)
        self.assertEqual(self.make().declare(), {"tenant_id": "tenant-a", "target_system_id": "synthetic-system-a", "components": []})
        for src in (lambda: (_ for _ in ()).throw(RuntimeError("x")), lambda: "not a dict", lambda: None): self.assertEqual(self.make(declare_source=src).declare()["components"], [])
    def test_observe_is_raw_untrusted_and_unmodified(self):
        a = self.make(); obs = a.observe(); self.assertEqual([o.target_native_representation for o in obs], NATIVE); self.assertTrue(all(o.failure is None and o.observed_at == 1234.5 and o.source_adapter_id == "auif:synthetic-system-a" for o in obs)); self.assertIsInstance(obs[0], self.gov.RawObservation)
        obs[0].target_native_representation["observation_id"] = "MUTATED"; self.assertEqual(a.observe()[0].target_native_representation["observation_id"], "obs-000001"); self.assertEqual(self.make(source=lambda: []).observe(), [])
    def test_observe_never_raises_and_reports_failures_in_the_contracts_vocabulary(self):
        def src(exc): return lambda: (_ for _ in ()).throw(exc)
        for source, want in ((src(TimeoutError()), "timeout"), (src(RuntimeError("boom")), "crash"), (src(KeyError("k")), "crash"), (lambda: "str", "malformed"), (lambda: None, "malformed"), (lambda: [1], "malformed"), (lambda: [{}, "x"], "malformed")):
            with self.subTest(want):
                obs = self.make(source=source).observe(); self.assertEqual((len(obs), obs[0].failure, obs[0].target_native_representation), (1, want, {}))
    def test_attest_is_provenance_only_unsigned_and_never_invented(self):
        o = self.make().observe()[0]; self.assertIsNone(self.make().attest(o)); a = self.make(attester=lambda n: {"connector_id": "c1", "payload_hash": n["payload_hash"]}); att = a.attest(o)
        self.assertEqual((att.provenance, att.signature, att.source_adapter_id), ({"connector_id": "c1", "payload_hash": "ab12"}, None, "auif:synthetic-system-a")); self.assertEqual(len(att.observation_ref), 32); self.assertEqual(a.attest(o).observation_ref, att.observation_ref)
        for bad in (lambda n: None, lambda n: "x", lambda n: (_ for _ in ()).throw(RuntimeError("x"))): self.assertIsNone(self.make(attester=bad).attest(o))
        failed = self.make(source=lambda: (_ for _ in ()).throw(RuntimeError("x"))).observe()[0]; self.assertIsNone(a.attest(failed))
    def test_normalize_is_mechanical_translation_with_no_policy_evaluation(self):
        a = self.make(); n = a.normalize(a.observe()[0]); no = n.neutral_object; self.assertTrue(self.valid(n)); self.assertEqual((no.id, no.tenant_id, no.target_system_id, no.environment_id, no.concept, no.classification), ("auif.observed.obs-000001", "tenant-a", "synthetic-system-a", "env-sandbox", self.gov.NeutralConcept.RESOURCE, None)); self.assertEqual(no.declared_metadata, NATIVE[0])
        self.assertEqual(self.make(concept="OBSERVATION").normalize(a.observe()[0]).neutral_object.concept, self.gov.NeutralConcept.OBSERVATION)
    def test_the_target_cannot_override_the_tenant_target_or_environment(self):
        a = self.make(source=lambda: [{"observation_id": "x", "tenant_id": "EVIL", "target_system_id": "EVIL", "environment_id": "EVIL"}]); no = a.normalize(a.observe()[0]).neutral_object; self.assertEqual((no.tenant_id, no.target_system_id, no.environment_id), ("tenant-a", "synthetic-system-a", "env-sandbox"))
    def test_a_classification_is_only_what_the_target_declared_and_is_never_computed(self):
        a = self.make(classification_field="classification"); obs = a.observe(); self.assertIsNone(a.normalize(obs[0]).target_declared_classification); n = a.normalize(obs[1]); self.assertEqual((n.target_declared_classification, n.neutral_object.classification), ("restricted", "restricted"))
        self.assertIsNone(self.make(source=lambda: [{"observation_id": "x", "classification": 5}], classification_field="classification").normalize(self.make(source=lambda: [{"observation_id": "x", "classification": 5}]).observe()[0]).target_declared_classification)
        self.assertIsNone(self.make().normalize(self.make().observe()[1]).target_declared_classification)                      # a classification field the adapter was not told to read is ignored
    def test_normalize_declines_failed_or_empty_observations_and_always_yields_a_valid_id(self):
        for src in (lambda: (_ for _ in ()).throw(RuntimeError("x")), lambda: "bad"):
            a = self.make(source=src); self.assertIsNone(a.normalize(a.observe()[0]))
        a = self.make(); self.assertIsNone(a.normalize(self.gov.RawObservation(source_adapter_id="s", target_native_representation={}, observed_at=0.0)))
        for weird in ("Has Spaces & Symbols!", "../../etc/passwd", "ÜNÏ", "", "x" * 500, 12345, None, "a.b.c"):
            with self.subTest(weird):
                a = self.make(source=lambda w=weird: [{"observation_id": w, "k": 1}]); n = a.normalize(a.observe()[0]); self.assertTrue(self.valid(n)); self.assertRegex(n.neutral_object.id, r"^auif\.observed\.[a-z0-9_-]{1,80}$")
    def test_namespace_and_concept_are_validated(self):
        for kw in ({"id_namespace": "nodot"}, {"concept": "Nonsense"}, {"concept": "resource"}):
            with self.assertRaises(ValueError): self.make(**kw)
        with self.assertRaises(ValueError): build_adapter_class(self.gov)("", "t", "e", source=lambda: [])
    def test_translate_event_is_mechanical(self):
        a = self.make(); e = a.translate_event({"type": "ticket.opened", "x": 1}); self.assertEqual((e.canonical_event_type, e.payload, e.source_adapter_id), ("ticket.opened", {"type": "ticket.opened", "x": 1}, "auif:synthetic-system-a")); self.assertIsInstance(e, self.gov.TargetEvent)
        for ev in ({}, {"type": 5}, {"type": ""}, None, "x", [1]): self.assertEqual(a.translate_event(ev).canonical_event_type, "unknown")
        src = {"type": "t", "n": 1}; a.translate_event(src).payload["n"] = 2; self.assertEqual(src["n"], 1)
    def test_deliver_decision_fails_closed_and_is_delivery_only(self):
        sunk = []; ok = {"token_id": "t1"}
        for label, kw, dec in (("no verifier or sink", {}, ok), ("verifier only", {"decision_verifier": lambda d: True}, ok), ("sink only", {"decision_sink": sunk.append}, ok), ("verifier says False", {"decision_verifier": lambda d: False, "decision_sink": sunk.append}, ok), ("truthy is not True", {"decision_verifier": lambda d: "yes", "decision_sink": sunk.append}, ok),
                               ("None is not True", {"decision_verifier": lambda d: None, "decision_sink": sunk.append}, ok), ("verifier raises", {"decision_verifier": lambda d: (_ for _ in ()).throw(RuntimeError("x")), "decision_sink": sunk.append}, ok), ("not a dict", {"decision_verifier": lambda d: True, "decision_sink": sunk.append}, "token"), ("a list", {"decision_verifier": lambda d: True, "decision_sink": sunk.append}, [ok])):
            with self.subTest(label): self.assertIs(self.make(**kw).deliver_decision(dec), False)
        self.assertEqual(sunk, [])                                                                                      # nothing was delivered by any refused case
        self.assertIs(self.make(decision_verifier=lambda d: d == ok, decision_sink=sunk.append).deliver_decision(ok), True); self.assertEqual(sunk, [ok])
        self.assertIs(self.make(decision_verifier=lambda d: True, decision_sink=lambda d: (_ for _ in ()).throw(RuntimeError("x"))).deliver_decision(ok), False)
    def test_incomplete_delivery_wiring_consults_nothing(self):
        calls = []
        def verifier(d): calls.append(("v", d)); return True
        for kw in ({"decision_verifier": verifier}, {"decision_verifier": verifier, "decision_sink": None}, {"decision_verifier": verifier, "decision_sink": "not callable"}, {"decision_verifier": "not callable", "decision_sink": lambda d: calls.append(("s", d))}, {"decision_verifier": True, "decision_sink": lambda d: calls.append(("s", d))}):
            with self.subTest(sorted(kw)): self.assertIs(self.make(**kw).deliver_decision({"token_id": "t1"}), False)
        self.assertEqual(calls, [])                                                                                     # fail closed BEFORE consulting the verifier or touching the sink
    def test_a_failed_observation_is_never_normalised_even_if_it_carries_data(self):
        a = self.make()
        for failure in ("timeout", "crash", "malformed"):
            with self.subTest(failure): self.assertIsNone(a.normalize(self.gov.RawObservation(source_adapter_id="s", target_native_representation={"observation_id": "x", "k": 1}, observed_at=0.0, failure=failure)))
        self.assertIsNotNone(a.normalize(self.gov.RawObservation(source_adapter_id="s", target_native_representation={"observation_id": "x", "k": 1}, observed_at=0.0)))
    def test_a_non_string_classification_never_reaches_the_neutral_object(self):
        for cls in (5, 1.5, True, None, ["restricted"], {"level": "restricted"}):
            with self.subTest(cls):
                a = self.make(source=lambda c=cls: [{"observation_id": "x", "classification": c}], classification_field="classification"); n = a.normalize(a.observe()[0])
                self.assertTrue(self.valid(n)); self.assertIsNone(n.target_declared_classification); self.assertIsNone(n.neutral_object.classification)
    def test_deliver_decision_does_not_interpret_the_decision(self):
        seen = []; a = self.make(decision_verifier=lambda d: seen.append(("v", d)) or True, decision_sink=lambda d: seen.append(("s", d))); dec = {"token_id": "t", "authorized": False, "anything": [1, {"x": 2}]}; self.assertTrue(a.deliver_decision(dec)); self.assertEqual(seen, [("v", dec), ("s", dec)])
class TestAgainstTheGovernorContractDouble(BoundaryChecks, unittest.TestCase):
    gov = gov_double.binding()
    def test_a_binding_missing_a_required_name_is_refused(self):
        b = gov_double.binding(); del b.NeutralConcept
        with self.assertRaises(ValueError): check_binding(b)
        with self.assertRaises(ValueError): build_adapter_class(SimpleNamespace())
class TestObservationSourceFromTheFabric(unittest.TestCase):
    def setUp(self):
        from synthetic.world import World
        self.w = World(); self.w.activate_all(); self.w.fabric.sync(self.w.ctx["tenant-a"], "ia-rest", "Account"); self.w.fabric.sync(self.w.ctx["tenant-b"], "ib-rest", "Account")
    def test_only_metadata_is_forwarded_never_business_payloads(self):
        src = FabricObservationSource(self.w.fabric, self.w.ctx["tenant-a"], "ia-rest"); out = src(); self.assertEqual(len(out), 7)
        for o in out: self.assertEqual(set(o), {"observation_id", "object_type", "object_id", "source_system", "connector_id", "observed_at", "payload_hash", "schema_fingerprint"})
        text = json.dumps(out)
        for payload_word in ("TenantB Account", "@", "balance"): self.assertNotIn(payload_word, text)
    def test_the_source_is_tenant_scoped_and_integration_scoped(self):
        a = {o["observation_id"] for o in FabricObservationSource(self.w.fabric, self.w.ctx["tenant-a"], "ia-rest")()}; b = {o["observation_id"] for o in FabricObservationSource(self.w.fabric, self.w.ctx["tenant-b"], "ib-rest")()}; self.assertEqual(len(a), 7); self.assertEqual(len(b), 7)
        with self.assertRaises(Exception): FabricObservationSource(self.w.fabric, self.w.ctx["tenant-b"], "ia-rest")()                                    # another tenant's integration is not reachable
        self.assertEqual(FabricObservationSource(self.w.fabric, self.w.ctx["tenant-a"], "ia-db")(), [])                                                   # an integration that observed nothing yields nothing
    def test_the_whole_chain_observe_attest_normalize_over_real_aif_observations(self):
        gov = gov_double.binding(); src = FabricObservationSource(self.w.fabric, self.w.ctx["tenant-a"], "ia-rest")
        a = build_adapter_class(gov)("tenant-a", "synthetic-system-a", "env-sandbox", source=src, attester=lambda n: {"connector_id": n["connector_id"], "payload_hash": n["payload_hash"]}, classification_field="never-present"); obs = a.observe(); self.assertEqual(len(obs), 7); self.assertTrue(all(o.failure is None for o in obs))
        ns = [a.normalize(o) for o in obs]; self.assertTrue(all(n is not None and gov_double.structurally_valid(n.neutral_object) for n in ns)); self.assertEqual(len({n.neutral_object.id for n in ns}), 7); self.assertTrue(all(a.attest(o).provenance["connector_id"] == "synthetic-rest-connector" for o in obs))
class TestNoAuifOperationReusesAnAdapterMethodName(unittest.TestCase):
    """AT-27 step 3, as a static scan of the audited core."""
    def test_no_core_function_is_named_like_an_adapter_method_with_a_different_meaning(self):
        names = ("declare", "observe", "attest", "normalize", "translate_event", "deliver_decision", "declared_capabilities", "identity"); hits = []
        for r, _, fs in os.walk(os.path.join(ROOT, "auif")):
            for f in fs:
                if f.endswith(".py"):
                    for i, line in enumerate(open(os.path.join(r, f)), 1):
                        m = re.match(r"\s*def (\w+)\(", line)
                        if m and m.group(1) in names: hits.append((f, i, m.group(1)))
        self.assertEqual(hits, [])
    def test_health_is_informational_wherever_the_core_defines_it(self):
        for r, _, fs in os.walk(os.path.join(ROOT, "auif")):
            for f in fs:
                if f.endswith(".py"):
                    for line in open(os.path.join(r, f)):
                        if re.match(r"\s*def health\(", line): self.assertEqual(f, "connector.py")                  # only the connector contract (and its runtime) has a health(), and it reports status
@unittest.skipUnless(os.environ.get("AUIF_GOVERNOR_R14_ZIP"), "set AUIF_GOVERNOR_R14_ZIP to the R14 Governor zip to run the conformance checks against the real Governor")
class TestAgainstTheRealGovernorR14(BoundaryChecks, unittest.TestCase):
    @staticmethod
    def tree(d): return {os.path.relpath(os.path.join(r, f), d): hashlib.sha256(open(os.path.join(r, f), "rb").read()).hexdigest() for r, _, fs in os.walk(d) for f in sorted(fs) if "__pycache__" not in r and not f.endswith(".pyc")}
    @classmethod
    def setUpClass(cls):
        z = os.environ["AUIF_GOVERNOR_R14_ZIP"]; cls.assertEqual = unittest.TestCase.assertEqual; assert hashlib.sha256(open(z, "rb").read()).hexdigest() == R14_SHA, "this is not the R14 zip that the conformance checks are written against"
        cls.tmp = tempfile.mkdtemp(); zipfile.ZipFile(z).extractall(cls.tmp); cls.before = cls.tree(cls.tmp); cls._path = list(sys.path); sys.path.insert(0, cls.tmp); cls._mods = set(sys.modules)
        ac, cr, nm = (importlib.import_module("governor_core." + n) for n in ("adapter_contract", "capability_registry", "neutral_model")); cls.nm, cls.cr = nm, cr
        cls.gov = SimpleNamespace(TargetSystemAdapter=ac.TargetSystemAdapter, RawObservation=ac.RawObservation, Attestation=ac.Attestation, NormalizedObject=ac.NormalizedObject, TargetEvent=ac.TargetEvent, Capability=cr.Capability, NeutralObject=nm.NeutralObject, NeutralConcept=nm.NeutralConcept, SCHEMA_VERSION=nm.NEUTRAL_MODEL_SCHEMA_VERSION)
    @classmethod
    def tearDownClass(cls):
        after = cls.tree(cls.tmp); sys.path[:] = cls._path
        for m in set(sys.modules) - cls._mods: sys.modules.pop(m, None)
        import shutil; shutil.rmtree(cls.tmp, True); assert after == cls.before, "the locked Governor artefacts changed during the run"            # AT-27 step 4: negative scope
    def valid(self, normalized):
        res = self.nm.validate(normalized.neutral_object); self.assertTrue(res.valid, res.errors); return res.valid
    def test_declared_capabilities_are_not_trusted_by_governors_own_trust_engine_without_verification(self):
        a = self.make(attester=lambda n: {}, decision_verifier=lambda d: True, decision_sink=lambda d: None); eng = self.cr.CapabilityTrustEngine()
        for cap, declared in a.declared_capabilities().items(): self.assertFalse(eng.verify(a, cap, declared).trusted, cap)
    def test_the_full_governor_pipeline_governs_the_auif_adapter_end_to_end(self):
        gc, pol, ten = (importlib.import_module("governor_core." + n) for n in ("governor", "policy", "tenancy")); delivered = []
        meta = pol.MetaConstitution(permitted_actions=frozenset({"promote", "read"})); g = gc.GovernorCore(meta)
        g.tenants.register_tenant(ten.Tenant(tenant_id="tenant-a", name="A", target_systems={"synthetic-system-a": ten.TargetSystem("synthetic-system-a", "auif", environments={"env-sandbox": ten.Environment("env-sandbox", "Sandbox")})})); g.tenants.grant_credential("tenant-a", "cred-a")
        g.register_manifest(pol.TargetManifest(tenant_id="tenant-a", target_system_id="synthetic-system-a", environment_id="env-sandbox", permitted_actions=frozenset({"promote", "read"})), credential="cred-a"); g.register_policy(pol.GovernancePolicy(tenant_id="tenant-a", permitted_actions=frozenset({"promote", "read"})), credential="cred-a")
        token_ids = []; a = self.make(source=lambda: [{"observation_id": "obs-1", "connector_id": "c1"}, {"observation_id": "obs-2", "connector_id": "c1"}], attester=lambda n: {"connector_id": n["connector_id"]}, decision_verifier=lambda d: d.get("token_id") in token_ids, decision_sink=delivered.append)
        g.register_adapter("tenant-a", "synthetic-system-a", "env-sandbox", a, credential="cred-a"); obs = a.observe(); self.assertEqual(g.resolve_or_fail_closed(tenant_id="tenant-a", fact_key="connector_id", observations=obs, decision_context="promote-1", credential="cred-a"), "c1")
        d = g.authorize("tenant-a", "synthetic-system-a", "env-sandbox", a, action="promote", change_ref="CHG-1", credential="cred-a"); self.assertTrue(d.authorized and d.token is not None)
        self.assertIs(a.deliver_decision({"token_id": d.token.token_id}), False); token_ids.append(d.token.token_id); self.assertIs(a.deliver_decision({"token_id": d.token.token_id}), True); self.assertEqual(delivered, [{"token_id": d.token.token_id}])        # fail-closed until the host's verifier recognises the Governor-issued token
if __name__ == "__main__": unittest.main()

"""The webhook receiver: authentication before parsing, replay and duplicate protection, fail-closed behaviour, and signed events over real HTTP into the core."""
import base64, hashlib, hmac, json, threading, time, unittest
from unittest import mock
from auif.errors import TenantContextError
from auif_ext.connectors.webhook import WebhookConfig, WebhookReceiver
from auif_ext.tests.loopback import LoopbackServer
SECRET = b"whsec-test-secret"
def cfg(**kw): return WebhookConfig(**dict(dict(signature_header="x-signature", signature_prefix="sha256=", timestamp_header="x-timestamp", signed_template="{timestamp}.{body}"), **kw))
class Clock:
    t = 5000.0
    def __call__(self): return self.t
def sign(body, ts, secret=SECRET, c=None, template="{timestamp}.{body}", enc="hex", prefix="sha256=", alg="sha256"):
    msg = template.replace("{timestamp}", ts).encode().split(b"{body}"); msg = body.join(msg) if len(msg) == 2 else msg[0]
    raw = hmac.new(secret, msg, getattr(hashlib, alg)).digest(); return prefix + (raw.hex() if enc == "hex" else base64.b64encode(raw).decode())
def event(i="e1", t="ticket.opened", d=None): return json.dumps({"id": i, "type": t, "data": d if d is not None else {"id": "t1", "title": "x", "state": "open"}}).encode()
class Rig:
    def __init__(self, config=None, secrets=lambda ctx, i: [SECRET], states=("IN_ORDER",)):
        self.got, self.clock, self.states = [], Clock(), list(states)
        def ingest(ctx, i, evs): self.got.append(evs); return [{"event_id": evs[0]["event_id"], "ordering_state": self.states.pop(0) if len(self.states) > 1 else self.states[0]}]
        self.r = WebhookReceiver(config or cfg(), secrets, ingest, clock=self.clock)
    def post(self, body=None, ts=None, sig=None, headers=None, **kw):
        body = body if body is not None else event(); ts = ts if ts is not None else str(self.clock.t); h = {"x-timestamp": ts, "x-signature": sig if sig is not None else sign(body, ts, **kw)}; h.update(headers or {}); return self.r.handle(None, "i1", h, body)
class TestAuthentication(unittest.TestCase):
    def test_a_correctly_signed_delivery_reaches_the_core_in_the_expected_shape(self):
        g = Rig(); res = g.post(); self.assertEqual((res.status, res.body), (200, {"status": "accepted"})); self.assertEqual(g.got, [[{"event_id": "e1", "type": "ticket.opened", "payload": {"id": "t1", "title": "x", "state": "open"}}]])
    def test_every_kind_of_tampering_is_refused_and_nothing_reaches_the_core(self):
        g = Rig(); body = event(); ts = str(g.clock.t); good = sign(body, ts)
        cases = {"altered body, original signature": dict(body=body + b" ", sig=good), "altered signature": dict(body=body, sig=good[:-1] + ("0" if good[-1] != "0" else "1")), "wrong secret": dict(body=body, secret=b"other"), "missing signature": dict(body=body, sig=""), "wrong prefix": dict(body=body, prefix="v1="),
                 "signature for another timestamp": dict(body=body, sig=sign(body, "1")), "wrong algorithm": dict(body=body, alg="sha512"), "base64 for hex": dict(body=body, enc="base64"), "empty secret": dict(body=body, secret=b""), "oversized signature header": dict(body=body, sig="sha256=" + "a" * 5000)}
        for label, kw in cases.items():
            with self.subTest(label): res = g.post(**kw); self.assertEqual((res.status, res.body), (401, {"status": "unauthorised"}))
        self.assertEqual(g.got, [])
    def test_the_signature_prefix_is_enforced_not_just_stripped(self):
        g = Rig(); body = event(); ts = str(g.clock.t); hexsig = sign(body, ts)[len("sha256="):]
        for junk in ("XXXXXXX", "sha512=", "SHA256=", "sha256:", "       "):                                                        # each the same length as "sha256=", so stripping by length alone would leave the valid hex
            with self.subTest(junk): res = g.post(body=body, ts=ts, sig=junk + hexsig); self.assertEqual((res.status, res.body), (401, {"status": "unauthorised"}))
        res = g.post(body=body, ts=ts, sig=hexsig); self.assertEqual(res.status, 401)                                                     # no prefix at all
        self.assertEqual(g.got, []); self.assertEqual(g.post(body=body, ts=ts, sig="sha256=" + hexsig).status, 200)
    def test_a_missing_signature_header_is_refused(self):
        g = Rig(); res = g.r.handle(None, "i1", {"x-timestamp": str(g.clock.t)}, event()); self.assertEqual(res.status, 401); self.assertEqual(g.got, [])
    def test_header_names_are_case_insensitive(self):
        g = Rig(); body = event(); ts = str(g.clock.t); self.assertEqual(g.r.handle(None, "i1", {"X-Signature": sign(body, ts), "X-TIMESTAMP": ts}, body).status, 200)
    def test_secret_rotation_either_secret_is_accepted_and_either_signature_in_the_header(self):
        g = Rig(secrets=lambda c, i: [b"new-secret", b"old-secret"]); body = event(); ts = str(g.clock.t)
        for sec in (b"new-secret", b"old-secret"):
            with self.subTest(sec): self.assertEqual(g.post(body=body, secret=sec).status, 200)
        both = sign(body, ts, secret=b"unknown") + "," + sign(body, ts, secret=b"old-secret"); self.assertEqual(g.post(body=body, sig=both).status, 200)
    def test_the_comparison_is_constant_time_and_checks_every_secret_and_candidate(self):
        g = Rig(secrets=lambda c, i: [SECRET, b"other"]); body = event(); ts = str(g.clock.t); sig = sign(body, ts) + "," + sign(body, ts, secret=b"x")
        with mock.patch("hmac.compare_digest", wraps=hmac.compare_digest) as cmp: self.assertEqual(g.post(body=body, sig=sig).status, 200)
        self.assertEqual(cmp.call_count, 4)                                                                       # 2 secrets x 2 candidates, even though the first pair already matched
    def test_other_schemes_base64_sha512_and_a_body_only_template(self):
        for kw, extra in ((dict(encoding="base64"), dict(enc="base64")), (dict(algorithm="sha512"), dict(alg="sha512")), (dict(signed_template="{body}", timestamp_header=None), dict(template="{body}"))):
            with self.subTest(kw):
                g = Rig(config=cfg(**kw)); body = event(); ts = str(g.clock.t); self.assertEqual(g.r.handle(None, "i1", {"x-signature": sign(body, ts, **extra), "x-timestamp": ts}, body).status, 200)
class TestTimestampAndReplayWindow(unittest.TestCase):
    def test_a_stale_or_future_timestamp_is_refused_even_with_a_valid_signature(self):
        g = Rig(); body = event()
        for ts in (str(g.clock.t - 301), str(g.clock.t + 301), "0", "-1", "abc", "", "nan", "inf"):
            with self.subTest(ts): self.assertEqual(g.post(body=body, ts=ts).status, 401)
        for ts in (str(g.clock.t - 299), str(g.clock.t + 299)): self.assertEqual(g.post(body=body, ts=ts).status, 200)
    def test_the_timestamp_is_part_of_what_is_signed(self):
        g = Rig(); body = event(); old = sign(body, str(g.clock.t - 10)); self.assertEqual(g.post(body=body, ts=str(g.clock.t), sig=old).status, 401)
    def test_a_missing_timestamp_header_is_refused_when_one_is_configured(self):
        g = Rig(); body = event(); self.assertEqual(g.r.handle(None, "i1", {"x-signature": sign(body, "")}, body).status, 401)
    def test_a_template_that_needs_a_timestamp_must_configure_a_header(self):
        with self.assertRaises(ValueError): WebhookReceiver(WebhookConfig(signed_template="{timestamp}.{body}"), lambda c, i: [SECRET], lambda *a: [])
    def test_an_unsupported_scheme_is_refused_at_construction(self):
        for kw in (dict(algorithm="md5"), dict(encoding="rot13")):
            with self.assertRaises(ValueError): WebhookReceiver(WebhookConfig(**kw), lambda c, i: [SECRET], lambda *a: [])
class TestBodyHandling(unittest.TestCase):
    def test_an_oversized_or_non_bytes_body_is_refused_before_any_secret_is_looked_up(self):
        calls = []; g = Rig(secrets=lambda c, i: calls.append(1) or [SECRET], config=cfg(max_body_bytes=100))
        self.assertEqual(g.post(body=b"x" * 101).status, 413); self.assertEqual(g.r.handle(None, "i1", {}, "text").status, 413); self.assertEqual(calls, []); self.assertEqual(g.post(body=event(d={"a": "x"})).status, 200)
    def test_a_valid_signature_over_malformed_json_is_a_400(self):
        g = Rig()
        for body in (b"not json", b"\xff\xfe", b"[]", b"5", b"null", b'{"id": NaN}', b"[" * 100000):
            with self.subTest(body[:12]): self.assertEqual(g.post(body=body).status, 400)
        self.assertEqual(g.got, [])
    def test_events_missing_required_fields_are_refused(self):
        g = Rig(); bad = [{"type": "t", "data": {}}, {"id": "", "type": "t", "data": {}}, {"id": "x" * 129, "type": "t", "data": {}}, {"id": True, "type": "t", "data": {}}, {"id": [1], "type": "t", "data": {}}, {"id": "a", "data": {}}, {"id": "a", "type": "", "data": {}}, {"id": "a", "type": 5, "data": {}}, {"id": "a", "type": "t"}, {"id": "a", "type": "t", "data": "x"}, {"id": "a", "type": "t", "data": [1]}]
        for b in bad:
            with self.subTest(b): self.assertEqual(g.post(body=json.dumps(b).encode()).status, 400)
        self.assertEqual(g.got, []); self.assertEqual(g.post(body=json.dumps({"id": 7, "type": "t", "data": {}}).encode()).status, 200)
    def test_depends_on_is_validated_and_passed_through(self):
        g = Rig(config=cfg(depends_on_path=("after",)))
        for bad in ("x", {"a": 1}, [True], [[1]], [None]):
            with self.subTest(bad): self.assertEqual(g.post(body=json.dumps({"id": "a", "type": "t", "data": {}, "after": bad}).encode()).status, 400)
        self.assertEqual(g.post(body=json.dumps({"id": "b", "type": "t", "data": {}, "after": ["e0", 5]}).encode()).status, 200); self.assertEqual(g.got[-1][0]["depends_on"], ["e0", "5"])
    def test_an_empty_payload_path_uses_the_whole_object(self):
        g = Rig(config=cfg(payload_path=())); self.assertEqual(g.post(body=json.dumps({"id": "a", "type": "t", "x": 1}).encode()).status, 200); self.assertEqual(g.got[0][0]["payload"], {"id": "a", "type": "t", "x": 1})
class TestFailClosed(unittest.TestCase):
    def test_no_secret_means_no_acceptance(self):
        for secrets in (lambda c, i: [], lambda c, i: None, lambda c, i: (_ for _ in ()).throw(RuntimeError("store down"))):
            with self.subTest(): g = Rig(secrets=secrets); res = g.post(); self.assertEqual((res.status, res.body), (503, {"status": "verification_unavailable"})); self.assertEqual(g.got, [])
    def test_a_failure_in_the_core_is_a_503_that_leaks_nothing(self):
        def boom(ctx, i, evs): raise RuntimeError("database password is hunter2")
        g = WebhookReceiver(cfg(), lambda c, i: [SECRET], boom, clock=Clock()); body = event(); ts = str(Clock.t); res = g.handle(None, "i1", {"x-signature": sign(body, ts), "x-timestamp": ts}, body); self.assertEqual((res.status, res.body), (503, {"status": "unavailable"})); self.assertNotIn("hunter2", repr(res))
    def test_a_tenant_context_failure_is_a_401(self):
        def deny(ctx, i, evs): raise TenantContextError("forged")
        g = WebhookReceiver(cfg(), lambda c, i: [SECRET], deny, clock=Clock()); body = event(); ts = str(Clock.t); self.assertEqual(g.handle(None, "i1", {"x-signature": sign(body, ts), "x-timestamp": ts}, body).status, 401)
    def test_rejected_deliveries_echo_nothing_from_the_request(self):
        g = Rig(); body = event(d={"secret_field": "PRIVATE-DATA"}); res = g.post(body=body, secret=b"wrong"); self.assertEqual(set(res.body), {"status"}); self.assertNotIn("PRIVATE-DATA", repr(res))
class TestOrderingDecisionsMapToStatuses(unittest.TestCase):
    def test_the_mapping(self):
        for state, status, word in (("IN_ORDER", 200, "accepted"), ("DUPLICATE_SUPPRESSED", 200, "duplicate"), ("QUEUED_AWAITING_PREDECESSOR", 202, "queued"), ("REJECTED_BY_POLICY", 422, "rejected"), ("RECONCILIATION_PENDING", 409, "conflict"), ("SOMETHING_NEW", 200, "accepted")):
            with self.subTest(state): res = Rig(states=(state,)).post(); self.assertEqual((res.status, res.body["status"]), (status, word))
class TestConcurrentDeliveries(unittest.TestCase):
    """rev8: the core has no internal synchronisation (core limitation 8), so the receiver serialises ITS OWN calls into it. The stub below deliberately races: it checks, pauses, then records, exactly the shape of an unsynchronised sequencer."""
    def rig(self):
        seen, state = set(), {"in": 0, "max": 0}; guard = threading.Lock()
        def ingest(ctx, i, evs):
            with guard: state["in"] += 1; state["max"] = max(state["max"], state["in"])
            eid = evs[0]["event_id"]; dup = eid in seen; time.sleep(0.05); seen.add(eid)                    # check ... pause ... record
            with guard: state["in"] -= 1
            return [{"event_id": eid, "ordering_state": "DUPLICATE_SUPPRESSED" if dup else "IN_ORDER"}]
        clock = Clock(); return WebhookReceiver(cfg(), lambda c, i: [SECRET], ingest, clock=clock), clock, state
    def burst(self, r, clock, body, n=12):
        ts = str(clock.t); h = {"x-timestamp": ts, "x-signature": sign(body, ts)}; out = []
        def go(): out.append(r.handle(None, "i1", h, body))
        th = [threading.Thread(target=go) for _ in range(n)]; [t.start() for t in th]; [t.join() for t in th]; return out
    def test_concurrent_identical_deliveries_are_accepted_exactly_once(self):
        r, clock, state = self.rig(); out = self.burst(r, clock, event("c1")); statuses = sorted(x.body["status"] for x in out)
        self.assertEqual(statuses, ["accepted"] + ["duplicate"] * 11); self.assertEqual(state["max"], 1)
    def test_calls_into_the_core_never_overlap_even_for_different_events(self):
        r, clock, state = self.rig(); ts = str(clock.t); out = []
        def go(i): b = event("d%d" % i); out.append(r.handle(None, "i1", {"x-timestamp": ts, "x-signature": sign(b, ts)}, b).status)
        th = [threading.Thread(target=go, args=(i,)) for i in range(8)]; [t.start() for t in th]; [t.join() for t in th]
        self.assertEqual((out, state["max"]), ([200] * 8, 1))
    def test_signature_verification_is_not_serialised_so_bad_deliveries_do_not_queue_behind_a_slow_ingest(self):
        r, clock, state = self.rig(); gate = threading.Event(); orig = r.ingest
        def slow(ctx, i, evs): gate.wait(2); return orig(ctx, i, evs)
        r.ingest = slow; ts = str(clock.t); good = event("g1"); t = threading.Thread(target=lambda: r.handle(None, "i1", {"x-timestamp": ts, "x-signature": sign(good, ts)}, good)); t.start(); time.sleep(0.2)
        t0 = time.monotonic(); res = r.handle(None, "i1", {"x-timestamp": ts, "x-signature": "sha256=" + "0" * 64}, event("g2")); dt = time.monotonic() - t0
        gate.set(); t.join(); self.assertEqual(res.status, 401); self.assertLess(dt, 0.5)                           # the forged delivery was refused immediately while an ingest was stuck
    def test_a_failing_ingest_releases_the_lock(self):
        r, clock, state = self.rig(); calls = []
        def boom(ctx, i, evs): calls.append(1); raise RuntimeError("down")
        r.ingest = boom; ts = str(clock.t); b = event("f1")
        for _ in range(3): self.assertEqual(r.handle(None, "i1", {"x-timestamp": ts, "x-signature": sign(b, ts)}, b).status, 503)
        self.assertEqual(len(calls), 3)                                                                                  # a stuck lock would have hung the second call
class TestSignedEventsOverRealHttpIntoTheCore(unittest.TestCase):
    """A real HTTP server hosting the receiver, posting signed events into the real Fabric's event integration."""
    def setUp(self):
        from synthetic.world import World
        self.w = World(); self.w.activate_all(); self.A = "tenant-a"; self.ctx = self.w.ctx[self.A]; self.clock = Clock(); self.mod = self.w.m2
        self.r = WebhookReceiver(cfg(), lambda ctx, i: [SECRET], lambda ctx, i, evs: self.w.fabric.ingest_events(ctx, i, evs), clock=self.clock)
        def handler(m, p, q, h, b): res = self.r.handle(self.ctx, "ia-evt", h, b); return res.status, {"Content-Type": "application/json"}, json.dumps(res.body).encode()
        self.srv = LoopbackServer(handler).start()
    def tearDown(self): self.srv.stop()
    def post(self, body, ts=None, secret=SECRET):
        import http.client
        ts = ts or str(self.clock.t); c = http.client.HTTPConnection(self.srv.host); c.request("POST", "/hooks", body=body, headers={"x-signature": sign(body, ts, secret=secret), "x-timestamp": ts}); r = c.getresponse(); out = (r.status, json.loads(r.read())); c.close(); return out
    def delivered(self): return len(self.mod.by_tenant.get(self.A, {}).get("entities", []))
    def test_a_signed_event_is_accepted_delivered_once_and_a_replay_is_suppressed(self):
        self.assertEqual(self.post(event("w1")), (200, {"status": "accepted"})); n = self.delivered(); self.assertGreaterEqual(n, 1)
        self.assertEqual(self.post(event("w1")), (200, {"status": "duplicate"})); self.assertEqual(self.post(event("w1")), (200, {"status": "duplicate"})); self.assertEqual(self.delivered(), n)
    def test_reusing_an_event_id_with_a_different_payload_is_a_conflict_not_a_second_delivery(self):
        self.post(event("w2")); n = self.delivered(); self.assertEqual(self.post(event("w2", d={"id": "t1", "title": "CHANGED", "state": "closed"}))[0], 409); self.assertEqual(self.delivered(), n)
    def test_a_forged_a_stale_and_a_wrong_secret_delivery_never_reach_the_core(self):
        n = self.delivered(); self.assertEqual(self.post(event("w3"), secret=b"forged")[0], 401); self.assertEqual(self.post(event("w4"), ts=str(self.clock.t - 3600))[0], 401); self.assertEqual(self.delivered(), n)
        self.assertEqual(self.post(event("w3"))[0], 200)                                                           # the same id later, properly signed, is still new: the forged attempt left no trace
    def test_an_event_that_depends_on_a_missing_predecessor_is_queued_not_invented(self):
        self.r.c.depends_on_path = ("after",); body = json.dumps({"id": "w5", "type": "ticket.updated", "data": {"id": "t2", "title": "x", "state": "open"}, "after": ["never-seen"]}).encode(); n = self.delivered(); res = self.post(body); self.assertEqual(res[0], 202); self.assertEqual(self.delivered(), n)
if __name__ == "__main__": unittest.main()

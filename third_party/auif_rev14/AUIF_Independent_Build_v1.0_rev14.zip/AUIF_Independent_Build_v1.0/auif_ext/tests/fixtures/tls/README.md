# TLS test fixtures (TEST-ONLY)

Throwaway self-signed certificates and their private keys, generated on 2026-10-03 with OpenSSL 3.0, used only by `test_tls_e2e.py` against a loopback server. **The private keys here protect nothing and must never be used anywhere else.** No production code reads this directory.

| Fixture | Subject alternative names | Validity | Purpose |
|---|---|---|---|
| `good` | `DNS:localhost`, `IP:127.0.0.1` | 2026-01-01 to 2126-01-01 | the success path, when the client trusts it |
| `wronghost` | `DNS:other.example.test` | 2026-01-01 to 2126-01-01 | hostname mismatch must fail even when the client trusts the certificate |
| `expired` | `DNS:localhost`, `IP:127.0.0.1` | 2020-01-01 to 2020-01-02 | an expired certificate must fail even when the client trusts it |

Regenerate with `openssl req` plus `openssl ca -selfsign -startdate ... -enddate ...` (the expired one needs `ca`, because `req -days` cannot backdate).

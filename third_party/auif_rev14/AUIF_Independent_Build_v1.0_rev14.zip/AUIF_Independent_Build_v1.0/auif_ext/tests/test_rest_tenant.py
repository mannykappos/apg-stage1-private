"""rev12: tenant-scoped connections and the wrapped, page-numbered list shape, over real loopback HTTP.
A tenant (organisation) identifier is NOT a credential: it is configured separately, sent on every API call (never to the token endpoint), and never part of, derived from, or equal to the credential."""
import json, unittest
from auif.errors import MalformedResponse, TransportError
from auif_ext.connectors.rest import Endpoint, RestConfig, RestConnector
from auif_ext.tests.loopback import LoopbackServer, jresp
from auif_ext.tests.test_oauth2 import Idp
TENANT = "11111111-2222-3333-4444-555555555555"
def cfg(srv, **kw):
    base = dict(connector_id="t", version="1", base_url=srv.url + "/api", allowed_hosts=(srv.host,), credential_ref="secretref:ext/t", auth="API_KEY", allow_insecure_loopback=True, tenant_header="X-Tenant-Id", tenant_id=TENANT, idempotency_header="Idempotency-Key", lookup=Endpoint(path="/idem/{key}"),
                entities={"Account": {"list": Endpoint(path="/accounts", items_path=("items",)), "write": Endpoint(method="POST", path="/accounts/{id}", id_field="id")}})
    base.update(kw); return RestConfig(**base)
def echo(m, p, q, h, b):
    if p.endswith("/metadata") or p.endswith("/health"): return jresp({})
    if m == "GET" and p.startswith("/api/idem/"): return jresp({"id": "r1"})
    if m == "GET": return jresp({"items": [{"id": "a1"}]})
    return jresp({"id": "w1"})
class TestTenantHeader(unittest.TestCase):
    def run_all(self, **kw):
        with LoopbackServer(echo) as s:
            c = RestConnector(cfg(s, health_path="/health", **kw)); c.connect({"secret": "the-api-key"})
            c.discover(); c.health(); c.read({"entity": "Account", "page_size": 5}); c.write({"entity": "Account", "id": "a1", "fields": {"x": 1}, "idempotency_key": "k1"}); c.lookup_by_idempotency_key("k1"); return s.requests
    def test_the_tenant_header_is_sent_on_every_kind_of_api_call_with_the_exact_value(self):
        reqs = self.run_all(); self.assertEqual(len(reqs), 5)
        for r in reqs: self.assertEqual(r["headers"].get("x-tenant-id"), TENANT, (r["method"], r["path"]))
    def test_a_connector_without_a_tenant_sends_no_tenant_header(self):
        for r in self.run_all(tenant_header=None, tenant_id=None): self.assertNotIn("x-tenant-id", r["headers"])
    def test_the_tenant_header_never_replaces_or_weakens_the_credential_headers(self):
        for r in self.run_all(): self.assertEqual(r["headers"].get("authorization"), "Bearer the-api-key"); self.assertNotIn("the-api-key", json.dumps({k: v for k, v in r["headers"].items() if k != "authorization"}))
    def test_the_tenant_header_is_not_sent_to_the_token_endpoint_but_the_api_calls_carry_it(self):
        idp = Idp(cid="cid", sec="csec")
        with LoopbackServer(echo) as api, LoopbackServer(idp) as ip:
            c = RestConnector(cfg(api, auth="OAUTH2_CLIENT_CREDENTIALS", token_url=ip.url + "/token", allowed_hosts=(api.host, ip.host))); c.connect({"secret": "cid:csec"}); c.read({"entity": "Account", "page_size": 5})
            self.assertTrue(ip.requests and all("x-tenant-id" not in r["headers"] for r in ip.requests)); self.assertEqual([r["headers"].get("x-tenant-id") for r in api.requests], [TENANT])
    def test_the_header_and_the_value_must_be_given_together(self):
        with LoopbackServer(echo) as s:
            for kw in (dict(tenant_id=None), dict(tenant_header=None)):
                with self.subTest(kw), self.assertRaises(ValueError): RestConnector(cfg(s, **kw))
    def test_unacceptable_header_names_are_refused(self):
        with LoopbackServer(echo) as s:
            for name in ("Authorization", "authorization", "Host", "Content-Type", "content-length", "Accept", "Cookie", "Proxy-Authorization", "Connection", "Transfer-Encoding", "Upgrade", "Expect", "TE", "Trailer", "X Tenant", "X-Tenant\r\nX-Evil: 1", "", "X" * 65, "X-Té", "X_Tenant", 5, ["X-T"]):
                with self.subTest(name), self.assertRaises(ValueError): RestConnector(cfg(s, tenant_header=name))
    def test_every_reserved_header_name_is_refused_whatever_the_authentication_mode(self):
        with LoopbackServer(echo) as s:
            for name in ("authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"):
                for variant in (name, name.upper(), name.title()):
                    with self.subTest(variant), self.assertRaises(ValueError): RestConnector(cfg(s, auth="NONE", credential_ref=None, idempotency_header=None, tenant_header=variant))
    def test_a_trailing_newline_is_not_tolerated_in_the_header_name_or_the_value(self):
        with LoopbackServer(echo) as s:
            with self.assertRaises(ValueError): RestConnector(cfg(s, tenant_header="X-Tenant-Id\n"))
            with self.assertRaises(ValueError): RestConnector(cfg(s, tenant_id=TENANT + "\n"))
    def test_the_header_may_not_collide_with_the_connectors_own_headers(self):
        with LoopbackServer(echo) as s:
            with self.assertRaises(ValueError): RestConnector(cfg(s, auth_header="X-Api-Key", tenant_header="x-api-key"))
            with self.assertRaises(ValueError): RestConnector(cfg(s, tenant_header="idempotency-key"))
            RestConnector(cfg(s, auth_header="Authorization", tenant_header="X-Api-Key"))                    # a name that is only an auth_header default of another auth mode is not a collision
            RestConnector(cfg(s, auth="NONE", credential_ref=None, auth_header="X-Tenant-Id", idempotency_header=None))
    def test_unacceptable_tenant_values_are_refused(self):
        with LoopbackServer(echo) as s:
            for v in ("", " ", "a b", "a\r\nb", "a/b", "é", "x" * 101, 5, ["a"], "a;b", "a,b"):
                with self.subTest(v), self.assertRaises(ValueError): RestConnector(cfg(s, tenant_id=v))
            for v in ("a", "x" * 100, "A.b_c:d-e", TENANT): RestConnector(cfg(s, tenant_id=v))
    def test_the_tenant_value_is_configuration_not_credential_and_appears_in_no_descriptor_or_error(self):
        with LoopbackServer(lambda *a: jresp({"e": 1}, 403)) as s:
            c = RestConnector(cfg(s)); c.connect({"secret": "the-api-key"}); self.assertNotIn(TENANT, json.dumps(c.descriptor()))
            with self.assertRaises(TransportError) as ctx: c.read({"entity": "Account", "page_size": 5})
            self.assertNotIn(TENANT, repr(ctx.exception) + str(ctx.exception)); self.assertEqual(ctx.exception.code, "AUTHORIZATION_DENIED_BY_TARGET")
class TestWrappedPagedList(unittest.TestCase):
    """The common 'wrapped list' shape: {Things: [...], Warnings: [...], pagination: {page, pageSize, pageCount, itemCount}} walked with page / pageSize."""
    RECS = [{"ThingID": "t%d" % i} for i in range(1, 8)]
    def srv(self, with_total=True):
        def h(m, p, q, hd, b):
            page, size = int(q["page"]), int(q["pageSize"]); a = (page - 1) * size; body = {"Things": self.RECS[a:a + size], "Warnings": [{"Message": "w"}]}
            if with_total: body["pagination"] = {"page": page, "pageSize": size, "pageCount": -(-len(self.RECS) // size), "itemCount": len(self.RECS)}
            return jresp(body)
        return LoopbackServer(h)
    def conn(self, s, **ep): return RestConnector(RestConfig(connector_id="w", version="1", base_url=s.url, allowed_hosts=(s.host,), auth="NONE", allow_insecure_loopback=True, entities={"Thing": {"list": Endpoint(path="/Things", items_path=("Things",), pagination="page", page_size_param="pageSize", **ep)}}))
    def walk(self, c):
        ids, cur, n = [], None, 0
        while True:
            r = c.read({"entity": "Thing", "page_size": 3, "cursor": cur}); ids += [i["ThingID"] for i in r["items"]]; n += 1; cur = r["next_cursor"]; self.assertLess(n, 10)
            if cur is None: return ids, n
    def test_the_walk_uses_the_page_count_from_the_response_and_stops_with_no_extra_request(self):
        with self.srv() as s: ids, n = self.walk(self.conn(s, total_pages_path=("pagination", "pageCount"))); self.assertEqual((ids, n, len(s.requests)), ([r["ThingID"] for r in self.RECS], 3, 3)); self.assertEqual([(r["query"]["page"], r["query"]["pageSize"]) for r in s.requests], [("1", "3"), ("2", "3"), ("3", "3")])
    def test_without_a_page_count_an_empty_page_ends_the_walk(self):
        with self.srv(with_total=False) as s: ids, n = self.walk(self.conn(s)); self.assertEqual((ids, n), ([r["ThingID"] for r in self.RECS], 4))
    def test_the_warnings_array_beside_the_records_is_never_returned_as_records(self):
        with self.srv() as s: r = self.conn(s, total_pages_path=("pagination", "pageCount")).read({"entity": "Thing", "page_size": 3}); self.assertTrue(all("ThingID" in i for i in r["items"]))
    def test_a_page_count_that_is_not_a_non_negative_integer_is_refused_not_trusted(self):
        for bad in ("3", -1, True, 1.5):
            with self.subTest(bad), LoopbackServer(lambda m, p, q, h, b, bad=bad: jresp({"Things": [{"ThingID": "t1"}], "pagination": {"pageCount": bad}})) as s:
                with self.assertRaises(MalformedResponse): self.conn(s, total_pages_path=("pagination", "pageCount")).read({"entity": "Thing", "page_size": 3})
if __name__ == "__main__": unittest.main()

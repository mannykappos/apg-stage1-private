"""The extension boundary: the audited core is untouched and independent of the extensions, the extensions depend only on the standard library and the core, and no real system, authority or unsafe construct is present."""
import ast, json, os, re, subprocess, sys, tempfile, unittest
from synthetic.world import World, ref
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); EXT = os.path.join(ROOT, "auif_ext"); CORE_HASH = "923de5100f95debbbf63d5ab6e960cee2091ee57abce403792403ff049ac7839"          # rev14: the core was revised (M8-F1 to M8-F6); rev10 to rev13 pinned 74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d; rev10: the core was revised (CF-4); rev9 pinned a18fd7aa98fdbb4a7ca28fa25b4b98275e2d2c3f3b100629a6300c46128e7146, rev8 pinned 5f27396249ea4f036fbc51bc9dad69134389d667a46a9962e8948d819bdb84d9
def ext_files():
    """Production extension files: everything under auif_ext except the tests."""
    out = []
    for r, ds, fs in os.walk(EXT):
        ds[:] = [d for d in ds if d not in ("tests", "__pycache__")]
        out += [os.path.join(r, f) for f in fs if f.endswith(".py")]
    return sorted(out)
def rel(p): return os.path.relpath(p, ROOT)
class TestTheCoreIsUntouched(unittest.TestCase):
    def test_the_core_hash_and_the_core_static_checks_are_exactly_as_audited(self):
        out = subprocess.run([sys.executable, "tools/static_checks.py"], cwd=ROOT, capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1")); r = eval(out.stdout.strip().splitlines()[-1])
        self.assertEqual(r["core_tree_sha256"], CORE_HASH); self.assertEqual((r["core_import_violations"], r["forbidden_token_hits"], r["authority_api_hits"]), ([], [], []))
    def test_the_core_never_mentions_the_extensions(self):
        hits = []
        for r, _, fs in os.walk(os.path.join(ROOT, "auif")):
            for f in fs:
                if f.endswith(".py") and "auif_ext" in open(os.path.join(r, f)).read(): hits.append(f)
        self.assertEqual(hits, [])
    def test_importing_the_core_never_imports_the_extensions(self):
        code = "import sys, auif, auif.fabric, auif.connector, auif.action; assert not [m for m in sys.modules if m.startswith('auif_ext')], 'extension imported by the core'"
        r = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1")); self.assertEqual((r.returncode, r.stderr), (0, ""))
class TestExtensionImports(unittest.TestCase):
    def imports(self, path):
        out = []
        for n in ast.walk(ast.parse(open(path).read())):
            if isinstance(n, ast.Import): out += [(a.name, 0) for a in n.names]
            elif isinstance(n, ast.ImportFrom): out.append((n.module or "", n.level))
        return out
    def test_the_extensions_import_only_the_standard_library_the_core_and_themselves(self):
        bad = []
        for p in ext_files():
            for mod, level in self.imports(p):
                if level: continue
                top = mod.split(".")[0]
                if top not in sys.stdlib_module_names and top not in ("auif", "auif_ext"): bad.append((rel(p), mod))
        self.assertEqual(bad, [])
    def test_no_governor_synthetic_reference_or_test_code_is_imported_by_production_extension_code(self):
        bad = [(rel(p), mod) for p in ext_files() for mod, lvl in self.imports(p) if not lvl and mod.split(".")[0] in ("governor_core", "adapters", "synthetic", "auif_ref", "tests", "port_contracts", "tools")]
        self.assertEqual(bad, [])
    def test_only_the_http_transport_opens_sockets_or_speaks_a_network_protocol(self):
        net = {"socket", "ssl", "http.client", "http.server", "urllib.request", "ftplib", "smtplib", "telnetlib", "poplib", "imaplib", "xmlrpc", "socketserver", "asyncio", "select", "selectors"}; bad = []
        for p in ext_files():
            if rel(p) == os.path.join("auif_ext", "connectors", "http_client.py"): continue
            bad += [(rel(p), m) for m, lvl in self.imports(p) if not lvl and (m in net or m.split(".")[0] in {"socket", "ssl", "ftplib", "smtplib", "telnetlib", "xmlrpc", "socketserver", "asyncio"})]
        self.assertEqual(bad, [])
class TestNothingUnsafeOrReal(unittest.TestCase):
    NAMES = ("xero", "myob", "salesforce", "hubspot", "mcgrath", "reapit", "vaultre", "ndis", "quickbooks", "stripe", "netsuite", "sap", "dynamics", "zoho", "pipedrive", "freshbooks", "mindbody", "westlab", "tasso")
    def test_no_real_external_system_is_named_in_the_production_extension_code(self):
        hits = []
        for p in ext_files():
            for i, line in enumerate(open(p), 1):
                for n in self.NAMES:
                    if re.search(r"\b%s\b" % n, line, re.I): hits.append((rel(p), i, n))
        self.assertEqual(hits, [])
    def test_no_logging_printing_deserialisation_or_process_execution_in_production_extension_code(self):
        bad_calls = {"print", "eval", "exec", "compile", "__import__", "breakpoint"}; bad_attrs = {("os", "system"), ("os", "popen"), ("os", "execv"), ("os", "execl"), ("os", "spawnl"), ("os", "fork")}; bad_modules = {"logging", "pickle", "cPickle", "marshal", "subprocess", "shelve", "yaml", "ctypes", "multiprocessing", "importlib"}; hits = []
        for p in ext_files():
            tree = ast.parse(open(p).read())
            for n in ast.walk(tree):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in bad_calls: hits.append((rel(p), n.lineno, n.func.id))              # a real builtin call; re.compile is an attribute call and is not flagged
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and (n.func.value.id, n.func.attr) in bad_attrs: hits.append((rel(p), n.lineno, n.func.attr))
                if isinstance(n, ast.Import): hits += [(rel(p), n.lineno, a.name) for a in n.names if a.name.split(".")[0] in bad_modules]
                if isinstance(n, ast.ImportFrom) and not n.level and (n.module or "").split(".")[0] in bad_modules: hits.append((rel(p), n.lineno, n.module))
        self.assertEqual(hits, [])
    def test_no_credential_like_literal_is_embedded_in_production_extension_code(self):
        hits = []
        for p in ext_files():
            for i, line in enumerate(open(p), 1):
                if re.search(r"(?i)(password|secret|token|api[_-]?key)\s*=\s*['\"][A-Za-z0-9+/_\-]{8,}['\"]", line): hits.append((rel(p), i))
        self.assertEqual(hits, [])
    def test_no_authority_operation_exists_anywhere_in_the_extensions(self):
        forbidden = {"evaluate_policy", "issue_promotion_token", "mutate_governor_state", "assert_compliant", "determine_materiality", "resolve_conflict", "issue_cpt", "authorize", "grant_decision", "decide"}; hits = []
        for p in ext_files():
            for n in ast.walk(ast.parse(open(p).read())):                    # identifiers, definitions and attribute accesses; strings and docstrings that merely NAME an absent operation are not code
                name = n.name if isinstance(n, (ast.FunctionDef, ast.ClassDef)) else n.id if isinstance(n, ast.Name) else n.attr if isinstance(n, ast.Attribute) else None
                if name in forbidden: hits.append((rel(p), getattr(n, "lineno", 0), name))
        self.assertEqual(hits, [])
class TestUniversality(unittest.TestCase):
    """Three different kinds of connector (a synthetic one, a REST connector over real HTTP, a file importer) run on ONE unchanged core at the same time."""
    def test_three_connector_kinds_run_side_by_side_and_the_core_is_still_byte_identical(self):
        from auif.discovery import fingerprint
        from auif.translation import pack_hash
        from auif_ext.connectors.file_import import FileImportConnector, FileSpec
        from auif_ext.connectors.rest import RestConnector
        from auif_ext.tests.loopback import LoopbackServer, SystemAHandler
        from auif_ext.tests.support import TOKEN, rest_cfg
        from synthetic.packs import pack_b
        from synthetic.systems import SystemA
        w = World(); w.activate_all(); ctx = w.ctx["tenant-a"]; d = tempfile.mkdtemp(); open(os.path.join(d, "customers.csv"), "w").write("cust_id,full_name,email_addr,state_code,amount_dollars\n1,Ann Lee,ann@example.test,1,10.50\n2,Bo Kay,bo@example.test,0,0.00\n")
        fc = FileImportConnector(d, {"customers": FileSpec("customers.csv", types={"cust_id": "integer", "state_code": "integer"})}); pk = pack_b([fingerprint(fc.discover())["value"]]); pk["pack_id"] = "ext-file-pack"; pk["artifact_hash"] = pack_hash(pk); w.packs.register(pk)
        with LoopbackServer(SystemAHandler(SystemA(secret="x"), TOKEN)) as srv:
            w.secrets.put("tenant-a", "secretref:ext/http", TOKEN)
            w.fabric.add_integration(ctx, integration_id="ia-http", anchor_module="synthetic-module-1", connector=RestConnector(rest_cfg(srv)), pack_ref=ref(w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", entities=["Account", "Property"]).activate()
            w.fabric.add_integration(ctx, integration_id="ia-file", anchor_module="synthetic-module-1", connector=fc, pack_ref=ref(pk), target_system_id="synthetic-file-system", environment_id="env-sandbox", entities=["customers"], identity_fields={"customers": "cust_id"}).activate()      # rev14 (M8-F2, product owner decision): an identity is declared, never a silent content hash
            synthetic = w.fabric.sync(ctx, "ia-rest", "Account"); http = w.fabric.sync(ctx, "ia-http", "Account"); file = w.fabric.sync(ctx, "ia-file", "customers")
        self.assertEqual((synthetic["delivered"], http["delivered"], file["delivered"]), (7, 7, 2)); kinds = {w.fabric.integration(ctx, i).runtime.desc["protocol_class"] for i in ("ia-rest", "ia-http", "ia-file")}; self.assertEqual(kinds, {"REST", "EXTENSION"})
        r = subprocess.run([sys.executable, "tools/static_checks.py"], cwd=ROOT, capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1")); self.assertEqual(eval(r.stdout.strip().splitlines()[-1])["core_tree_sha256"], CORE_HASH)
class TestDocumentation(unittest.TestCase):
    def test_the_extensions_are_documented_as_extension_implementations_not_locked_architecture(self):
        doc = open(os.path.join(ROOT, "AUIF_EXTENSIONS.md")).read()
        for phrase in ("not locked architecture requirements", "does not change the audited core", "GD-05", "fail closed", "no real external system"): self.assertIn(phrase, doc, phrase)
    def test_the_known_limitations_state_the_extension_limits(self):
        lim = open(os.path.join(ROOT, "KNOWN_LIMITATIONS.md")).read(); self.assertIn("Extension limitations", lim)
if __name__ == "__main__": unittest.main()

"""Shared fixtures for the extension tests (TEST-ONLY)."""
import json
from auif.clock import FakeClock
from auif.connector import ConnectorRuntime
from auif.observability import Telemetry
from auif.tenancy import TenantAuthority
from auif.throttle import Throttle
from auif_ref.secrets import InMemorySecretStore
from auif_ext.connectors.rest import Endpoint, RestConfig, RestConnector
from auif_ext.tests.loopback import LoopbackServer, SystemAHandler, jresp
from synthetic.systems import SystemA
TOKEN = "tok-123"
def account_entities(): return {"Account": {"list": Endpoint(path="/accounts", items_path=("items",)), "write": Endpoint(method="PATCH", path="/accounts/{id}", id_field="external_reference")}, "Property": {"list": Endpoint(path="/properties", items_path=("items",))}}
def rest_cfg(srv, **kw):
    base = dict(connector_id="generic-rest", version="0.1.0", base_url=srv.url, allowed_hosts=(srv.host,), credential_ref="secretref:ext/http", auth="API_KEY", allow_insecure_loopback=True, entities=account_entities(), lookup=Endpoint(path="/idempotency/{key}", id_field="external_reference"))
    base.update(kw); return RestConfig(**base)
class Rig:
    """A SystemA behind a real HTTP server, a RestConnector, and a core ConnectorRuntime with the secret in a real secret store."""
    def __init__(self, **cfg):
        self.sa = SystemA(secret="x"); self.h = SystemAHandler(self.sa, TOKEN); self.srv = LoopbackServer(self.h).start(); self.clock = FakeClock(); self.auth = TenantAuthority(); self.ctx = self.auth.issue("tenant-a", "svc")
        self.connector = RestConnector(rest_cfg(self.srv, **cfg)); self.secrets = InMemorySecretStore(); self.secrets.put("tenant-a", "secretref:ext/http", TOKEN)
        self.rt = ConnectorRuntime(self.connector, secrets=self.secrets, throttle=Throttle(self.clock, default_rate=1000, default_burst=1000), telemetry=Telemetry(), clock=self.clock)
    def call(self, method, request=None, key=None): return self.rt.call(self.ctx, "i1", "sys", "env", method, request, idempotency_key=key)
    def close(self): self.srv.stop()

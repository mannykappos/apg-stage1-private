"""Two worked examples of an Anchor module consuming AUIF. They name no real system and no real Anchor module; they use the generic canonical concepts the integration was configured with."""
from .client import BaseModule, ModuleClient
class ExampleDirectoryModule(BaseModule):
    """Example 1: a READ-side module. It declares the concepts and attributes it needs, mirrors every canonical entity AUIF delivers, and keeps a log of integration state changes and errors."""
    def __init__(self, module_id="example-directory-module"):
        super().__init__(module_id, [{"concept": "Party", "attributes": ["display_name", "lifecycle_state"]}]); self.mirror, self.states, self.errors = {}, [], []
        self.on("entity", lambda ctx, obj: self.mirror.setdefault(ctx.tenant_id, {}).__setitem__(obj["canonical_id"], obj)); self.on("state", lambda ctx, st: self.states.append((ctx.tenant_id, st))); self.on("error", lambda ctx, er: self.errors.append((ctx.tenant_id, er)))
class ExampleUpdaterModule(BaseModule):
    """Example 2: a WRITE-side module. It asks AUIF to apply a change to whatever system is behind an integration; AUIF handles idempotency, governance holds, retries and reconciliation."""
    def __init__(self, module_id="example-updater-module"): super().__init__(module_id, [{"concept": "Party", "attributes": ["display_name"]}])
    def rename(self, client, ctx, *, integration_id, canonical_id, new_name, intent_id, action_id, correlation_id):
        return client.request_action(ctx, integration_id=integration_id, action_type="synthetic.update_party", canonical_type="Party", canonical_id=canonical_id, attributes={"display_name": new_name}, action_id=action_id, correlation_id=correlation_id, intent_id=intent_id)

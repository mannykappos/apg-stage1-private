"""The module client: the one way an Anchor module consumes AUIF. A module declares what it needs, registers handlers for what AUIF delivers, and asks for actions; it never learns which external system is behind an integration.
BaseModule is a ready-made ModulePort (the audited core contract); ModuleClient is a thin convenience over the Fabric's public entry points. Business logic stays in the module's handlers. This layer adds no authority: it never sets a Governor
decision reference, it binds every action to the authenticated tenant context, and it leaves governance, idempotency and recovery to the core."""
import hashlib, json
from auif.contracts import validate
from auif.ports import ModulePort
KINDS = ("entity", "observation", "event", "state", "error")
class BaseModule(ModulePort):
    def __init__(self, module_id, requirements, capabilities=None):
        if not isinstance(module_id, str) or not module_id: raise ValueError("a module must declare a module_id")
        if not isinstance(requirements, list) or any(not isinstance(r, dict) or not isinstance(r.get("concept"), str) or not isinstance(r.get("attributes"), list) for r in requirements): raise ValueError("requirements must be a list of {concept, attributes}")
        self.module_id, self._req = module_id, json.loads(json.dumps(requirements)); self._cap = dict(capabilities) if capabilities is not None else {"consumes": [r["concept"] for r in self._req]}; self._h = {k: [] for k in KINDS}; self.handler_errors = []
    def on(self, kind, fn=None):
        """Register a handler: module.on('entity', fn) or as a decorator: @module.on('entity')."""
        if kind not in KINDS: raise ValueError("kind must be one of %s" % (KINDS,))
        def reg(f): self._h[kind].append(f); return f
        return reg(fn) if fn is not None else reg
    def _dispatch(self, kind, ctx, payload):
        failed = 0
        for fn in list(self._h[kind]):
            try: fn(ctx, payload)
            except Exception as e: self.handler_errors.append({"kind": kind, "error": type(e).__name__}); failed += 1      # a module bug never breaks delivery to other handlers, and its message (which may hold data) is not kept
        return {"handler_failures": failed} if failed else None      # rev14 (M8-F4): the failure is no longer swallowed: the fabric reads this marker, counts it and tells the module
    def ingest_canonical_entity(self, ctx, obj): return self._dispatch("entity", ctx, obj)
    def ingest_canonical_observation(self, ctx, observation): return self._dispatch("observation", ctx, observation)
    def ingest_canonical_event(self, ctx, observation): return self._dispatch("event", ctx, observation)
    def semantic_requirements(self): return self._req
    def module_capabilities(self): return self._cap
    def receive_integration_state(self, ctx, state): return self._dispatch("state", ctx, state)
    def receive_integration_error(self, ctx, error): return self._dispatch("error", ctx, error)
def derive_idempotency_key(ctx, intent_id, canonical_type, canonical_id, attributes):
    """A deterministic key: the SAME intent for the same tenant and content always yields the same key, so a retry deduplicates instead of acting twice."""
    h = hashlib.sha256(json.dumps([ctx.tenant_id, intent_id, canonical_type, canonical_id, attributes], sort_keys=True, separators=(",", ":")).encode()).hexdigest(); return "idem-%s" % h[:40]
class ModuleClient:
    def __init__(self, fabric, module):
        self.fabric, self.module = fabric, module; fabric.register_module(module)
    def activate(self, ctx, integration_id): return self.fabric.integration(ctx, integration_id).activate()
    def sync(self, ctx, integration_id, entity, **kw): return self.fabric.sync(ctx, integration_id, entity, **kw)
    def build_action(self, ctx, *, integration_id, action_type, canonical_type, canonical_id, attributes, action_id, correlation_id, intent_id=None, idempotency_key=None, governance_required=False, requested_at=None):
        """Builds a contract-valid CanonicalAction bound to the authenticated tenant. It never sets a Governor decision reference (the core would discard it anyway)."""
        c = self.fabric.integration(ctx, integration_id); key = idempotency_key or derive_idempotency_key(ctx, intent_id or action_id, canonical_type, canonical_id, attributes); clock = getattr(self.fabric, "clock", None)
        a = {"contract_kind": "CanonicalAction", "action_id": action_id, "tenant_id": ctx.tenant_id, "source_module": self.module.module_id, "target_system_id": c.target_system_id, "environment_id": c.environment_id, "manifest_ref": c.manifest_ref(), "idempotency_key": key, "correlation_id": correlation_id,
             "requested_at": requested_at or (clock.iso() if clock is not None else None), "canonical_action": {"action_type": action_type, "payload": {"canonical_type": canonical_type, "canonical_id": canonical_id, "attributes": attributes}},
             "governance": {"governance_required": governance_required, "governance_required_source": "UNKNOWN" if governance_required == "UNKNOWN" else "MODULE_DECLARED", "governor_decision_ref": None}}
        return validate("action#CanonicalAction", a)
    def request_action(self, ctx, *, dispatch=True, **kw): return self.fabric.request_action(ctx, self.module.module_id, self.build_action(ctx, **kw), dispatch=dispatch)
    def action_status(self, ctx, action_id): return self.fabric.actions.ledger.get(ctx, action_id)

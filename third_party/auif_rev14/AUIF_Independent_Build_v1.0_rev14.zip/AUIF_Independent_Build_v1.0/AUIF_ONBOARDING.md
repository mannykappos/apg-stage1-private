# AUIF Onboarding Accelerator (`auif_onboard`, rev11)

**A drafting and review accelerator. Not an onboarding authority.**

```
Discover -> Draft -> Propose -> Validate (synthetic only) -> Present for human approval
NOT:  Discover -> Decide -> Approve -> Deploy
```

Each new target system needs a connector configuration (endpoints, authentication, entities) and a translation pack (its fields mapped to the canonical model). Both are data. Writing them by hand is slow; deciding them by machine would be wrong. The accelerator does the slow, mechanical part (reading an API description and drafting both artefacts) and puts the decisions in front of a named human.

It is a standalone package that sits **above** the audited core (`auif/`) and the extensions (`auif_ext/`). Nothing in either imports it, it changes neither, and it imports nothing that opens a socket. Standard library only. Authority held: **NONE**.

## What it does

| Stage | Module | Output |
|---|---|---|
| Discover | `openapi.py` | Parses an OpenAPI 3.x or Swagger 2.0 **JSON** document the integrator supplies (local file; no network). Descriptions, examples, defaults and `x-` extensions are ignored, so a secret pasted into a spec is never read. |
| Draft config | `config_gen.py`, `rest_adapter.py` | A draft connector configuration for the generic REST connector (`auif_ext`): base URL, authentication scheme (NONE, API_KEY, OAUTH2_CLIENT_CREDENTIALS), entities, pagination style, write operations. Every setting is classified **determined** (read from the spec), **assumed default** or **undetermined**; undetermined fields are listed explicitly, blocking ones are flagged. `credential_ref` is always `null`. |
| Draft pack | `planner.py`, `matching.py`, `proposer.py`, `pack_draft.py` | A candidate translation pack. The deterministic stdlib proposer names a canonical concept and attributes by generic name matching and hands every proposal to the **existing** mapping boundary (`AIMappingService.propose`). Everything starts as a CANDIDATE; ambiguities and ties stay unresolved. A model-backed proposer can be plugged in later; it is **not** part of this milestone. |
| Validate | `validate.py` | A strictly **synthetic** report: runs the drafted connector against the synthetic loopback vendors (conformance kit, read-all paging, shadow translation of the vendor's records, write round trips). It needs no real-system fact, credential, behaviour or access, and refuses anything that is not a local synthetic vendor (`RealSystemRefused`). The report states `synthetic_only: true`, `real_system_validated: false`. |
| Present / sign off | `review.py` | The **only** module that can approve anything. See below. |

`python -m auif_onboard draft --spec API.json --canonical-model MODEL.json --out DIR` writes `config_draft.json`, `pack_draft.json` and `SUMMARY.txt` (never overwriting, secrets-screened before anything is written, no network, approves nothing).

## Human review and sign-off

* The generator has **no capability to promote or approve**. Only `auif_onboard/review.py` imports the approval machinery; a static check fails the build if any other module does, or if any other module uses approval vocabulary.
* An approval is a `HumanApproval`: a named reviewer (automated or placeholder names such as *system*, *bot*, *claude*, *auif* are refused), a statement of at least four words and 20 characters saying what was approved, an ISO timestamp, a decision, the parameters of every choice made, and the **hash of the exact item shown**. An approval of anything else, or of an item that changed since it was shown, is refused.
* Two routes, both deterministic-validated:
  * **BOUNDARY**: an unmodified FIELD candidate is promoted through the audited AI boundary (`resolve_ambiguity` / `promote`), inbound-only, evidence `val-ai-…`.
  * **HUMAN**: everything the boundary cannot carry (ENTITY and ACTION mappings, outbound halves, hand-written or modified mappings): the human adopts the definition, `proposed_by` is `HUMAN`, evidence `val-hr-…` binds the whole mapping together with the approval. rev10's `PackRegistry` has no hook for this evidence, so an integrator runs `ReviewSession.verify_human_evidence(mapping)`.
* The configuration is approved separately (`approve_config`), with the human supplying `credential_ref` as `secretref:<name>`. The pack is assembled (`assemble_pack`) only from approved mappings and only on a further hash-bound approval; everything not approved is reported as **left out**.

## Secrets

Never read, generated, inferred, persisted or emitted. `secrets_scan.py` is a backstop run over every artefact before it is written or reported; it reports **paths and rule names, never matched text**. Approvals and logs carry only references.

## Hard gates the build enforces (and the tests that prove them)

Core unchanged (hash `74cec87a…`, equal to rev10's); no Governor, GD-05 or Layer 2 change; the generator cannot promote; no secret in any artefact, log or report; no real-system fact needed; the extension acquires no Governor authority. Evidence: `evidence/onboard_verification.json`, `tools/static_checks_onboard.py`, `tools/onboard_reverse_contamination.py`, `tools/mutation_onboard.py`.

## Known limitations (also in `KNOWN_LIMITATIONS.md`, items O-1 onwards)

* **O-1. Code cannot authenticate a human.** A `HumanApproval` proves a name, a statement and hash binding were supplied, not that a person is behind them. Sign-in, identity and four-eyes control belong to the integrator's process.
* **O-2. JSON only.** YAML specifications are refused (`SpecRejected`); convert first.
* **O-3. No PATTERN constraints.** The generator never produces them, and a human-supplied PATTERN is refused.
* **O-4. rev10's registry has no verification hook for human-route evidence**; `ReviewSession.verify_human_evidence` is the integrator's check. The core was deliberately not changed.
* **O-5. Ambiguous-entity field coverage covers only the main concept** of an entity; fields belonging to other concepts remain for a human.
* **O-6. ENUM_MAP keys are text**, so integer-coded enumerations cannot be written back to a vendor.
* **O-7. Drafts carry a fixed timestamp** (a fake clock) so that a draft is reproducible byte for byte.
* **O-8. The proposer holds a copy of the canonical-model definition** it was given; it does not follow later changes.
* **O-9. The fabric end-to-end test uses the discovery document drafted by the accelerator**, so it is circular: it shows the pieces fit together, not that the discovery document is independently right.
* **O-10. Bare passwords with no context are undetectable by the scanner.** The design avoids needing it: fields that could carry them are never read.
* **O-11. Synthetic only.** Three materially different synthetic vendors (cursor paging with an API key; offset paging with OAuth2 client credentials; link paging from a Swagger 2.0 document). Validation against a real system is a separate, gated phase that has not started and needs a named sandbox target.
* **O-12. Name matching is generic English vocabulary.** A proposal is a suggestion. Systems whose field names share no vocabulary with the canonical model will produce few or no proposals, which is the safe failure.
* **O-13. Correction of an earlier statement:** API_KEY authentication **is** supported by the generic REST connector and by the generator; an earlier claim that it was unsupported was wrong.

## rev12 additions (found by the first real-API draft)
Details, the approval recipe and the hypotheses the live phase must test are in `CHANGES_rev12.md`.
* **Wrapped lists.** `{Records: [...], Warnings: [...]}` is read: envelope-named arrays are set aside; else the array named like the path; recorded as an assumed default.
* **Same-name endpoints.** The endpoint whose path names the entity is used; otherwise none (all listed, non-blocking). Records with no identifier are reported.
* **Tenant header.** If every used operation requires a tenant-scoping header, its NAME is drafted and the tenant identifier is a blocking question for the human (`tenant_id`); the value is configuration, never part of the credential.
* **Unpaged endpoints.** Still blocking; `single_page` is offered as the choice a human may make.
* **Exclusion.** `entities.<E>.list: null` excludes an entity at configuration approval; its blocking questions fall away; the pack can no longer approve mappings for it.
* **Unchanged:** the generator approves nothing; secrets are never read; validation stays synthetic-only.

## rev13 addition (audit finding REV12-AUD-01)
* **Write endpoint removal.** A configuration approval that removes an entity's write endpoint (`entities.<E>.write: null`) is refused while an outbound mapping (ENTITY, FIELD or ACTION) is already approved for that entity. The mapping is not stripped silently: the reviewer keeps the endpoint, or resolves the conflict by rejecting the mapping first. The reverse order was already refused.

## rev14 change (finding M8-F1)
* **Module-concept field references.** The shadow translation (`validate.py`) and the review's consistency check (`review.py`) read a field reference as `<concept>.<attribute>` with the attribute after the last dot, so a field into a MODULE concept (whose name contains dots) is measured and assembled correctly. A field into another concept than its entity's is still refused. Tests: `auif_onboard/tests/test_rev14_module_refs.py`; mutants V119 and V120; mutant V86 re-anchored on the new line (same guard).

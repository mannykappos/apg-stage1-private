"""The AUIF runtime: wires connectors, discovery, translation, observations, sequencing, boundary enforcement, actions, the state machine and the module/Governor ports into end-to-end flows."""
from types import SimpleNamespace
from .action import ActionService
from .classification import BoundaryEnforcer
from .connector import ConnectorRuntime
from .contracts import validate
from .discovery import DiscoveryEngine
from .errors import *
from .integration import IntegrationController, IntegrationRegistry
from .modules import ModuleRegistry
from .observation import ObservationFactory, Sequencer
from .security import InputGuard
from .translation import Translator
from .util import sha
class Fabric:
    def __init__(self, *, store, authority, secrets, governor, policy, clock, telemetry, ids, model, packs, throttle, guard=None, sequencer_policy=None):
        self.store, self.auth, self.secrets, self.gov, self.clock, self.tel, self.ids, self.model, self.packs, self.th, self.guard = store, authority, secrets, governor, clock, telemetry, ids, model, packs, throttle, guard or InputGuard()
        self.discovery, self.translator, self.modules, self.registry = DiscoveryEngine(clock, ids), Translator(model, packs, ids, clock), ModuleRegistry(), IntegrationRegistry(); self.sequencer, self.obs, self.sot, self.cfg = Sequencer(store, clock, sequencer_policy or {"*": {"on_missing": "QUEUE", "wait_seconds": 30}}), ObservationFactory(store, ids, clock), {}, {}
        self.deps = SimpleNamespace(store=store, clock=clock, ids=ids, tel=telemetry, discovery=self.discovery, packs=packs, model=model, governor=governor, notify=self._notify); self.actions = ActionService(store, clock, ids, telemetry, self.translator, BoundaryEnforcer(policy), governor, self.registry, self.guard)
    def register_module(self, module): self.modules.register(module)
    def _notify(self, ctx, module_id, state):
        try: self.modules.get(module_id).receive_integration_state(ctx, state)
        except NotFound: pass
    def add_integration(self, ctx, integration_id, *, anchor_module, connector, pack_ref, target_system_id, environment_id, governed_operations=(), entities=(), destination_kind="customer-system", event_entities=None, identity_fields=None):
        self.auth.require(ctx); rt = ConnectorRuntime(connector, secrets=self.secrets, throttle=self.th, telemetry=self.tel, clock=self.clock, guard=self.guard)
        c = IntegrationController(self.deps, ctx, integration_id, anchor_module, target_system_id, environment_id, rt, pack_ref, governed_operations=governed_operations, entities=entities, destination_kind=destination_kind); self.registry.add(c); self.cfg[(ctx.tenant_id, integration_id)] = {"event_entities": event_entities or {}, "identity": identity_fields or {}}; return c
    def integration(self, ctx, integration_id): self.auth.require(ctx); return self.registry.get(ctx, integration_id)
    def _error(self, ctx, module_id, kind, **d):
        self.tel.inc(ctx.tenant_id, d.get("integration", "-"), "failures")
        try: self.modules.get(module_id).receive_integration_error(ctx, dict({"kind": kind}, **d))
        except NotFound: pass
    def _canonical_apply(self, ctx, obj, source_system):
        """Single owning source per canonical id unless a source of truth is explicitly declared. Observations never write governance state: this store holds canonical DATA only (AT-26)."""
        key = obj["canonical_id"]; cur = self.store.get(ctx, "canonical_objects", key)
        if cur and cur["source_system"] != source_system and self.sot.get(obj["canonical_type"]) != source_system:
            self.store.put(ctx, "canonical_conflicts", "%s:%06d" % (key, self.store.next_sequence(ctx, "canonical-conflicts")), {"canonical_id": key, "owner": cur["source_system"], "claimant": source_system}); return False
        self.store.put(ctx, "canonical_objects", key, {"object": obj, "source_system": source_system}); return True
    def _ingest_record(self, ctx, c, entity, record, *, event=False, ordering_state="IN_ORDER", source_sequence=None, causal=None):
        cfg = self.cfg[(ctx.tenant_id, c.integration_id)]; sid = str(record.get(cfg["identity"].get(entity, "id"), sha(record)[:12])); oid = self.ids.next("obs"); mod = self.modules.get(c.anchor_module)
        try: obj = self.translator.translate_inbound(ctx, c.pack_ref, entity, record, source_system=c.target_system_id, observation_id=oid, schema_fingerprint=c.fp["value"], source_id=sid)
        except TranslationFailure as e: self._error(ctx, c.anchor_module, "TRANSLATION_FAILURE", integration=c.integration_id, entity=entity, reason=str(e)); return None
        except PackError as e: self._error(ctx, c.anchor_module, "PACK_INTEGRITY_FAILURE", integration=c.integration_id, entity=entity, reason=str(e)[:200]); return None
        ok = obj["validation_state"] == "VALID"
        ob = self.obs.build(ctx, c.integration_id, observation_id=oid, anchor_module=c.anchor_module, target_system_id=c.target_system_id, environment_id=c.environment_id, connector_id=c.runtime.desc["connector_id"], source_system=c.target_system_id, source_object={"object_type": entity, "object_id": sid}, source_version=None, pack_ref=c.pack_ref,
                            schema_fingerprint=c.fp["value"], payload=record, classification=obj["classification"], confidence={"value": 1.0 if ok else 0.0, "basis": "deterministic pack translation" if ok else "translation did not produce a valid object"}, provenance=obj["provenance_chain"], causal=causal, source_sequence=source_sequence, ordering_state=ordering_state, manifest_version=c.manifest_ref())
        self.store.put(ctx, "observations", oid, ob)
        if not ok: self._error(ctx, c.anchor_module, obj["validation_state"], integration=c.integration_id, canonical_id=obj["canonical_id"], diagnostics=obj["diagnostics"]); return obj
        if self._canonical_apply(ctx, obj, c.target_system_id):
            mod.ingest_canonical_entity(ctx, obj); (mod.ingest_canonical_event if event else mod.ingest_canonical_observation)(ctx, ob)
        return obj
    def sync(self, ctx, integration_id, entity, max_pages=10, page_size=3):
        c = self.integration(ctx, integration_id); rep = {"pages": 0, "delivered": 0, "invalid": 0, "ambiguous": 0, "empty": False, "failed": None, "not_allowed": False}
        if not c.entity_readable(entity): rep["not_allowed"] = True; return rep
        cursor = None
        for _ in range(max_pages):
            out = c.runtime.call(ctx, integration_id, c.target_system_id, c.environment_id, "read", {"entity": entity, "cursor": cursor, "page_size": page_size}); k = out.result["outcome_kind"]
            if k == "NO_DATA": rep["empty"] = True; break
            if k != "DATA_OBTAINED": rep["failed"] = out.error["code"]; self._error(ctx, c.anchor_module, "SOURCE_UNAVAILABLE" if k == "COULD_NOT_OBTAIN" else "SOURCE_DATA_INVALID", integration=integration_id, error=out.error); break
            rep["pages"] += 1
            for item in out.data["items"]:
                o = self._ingest_record(ctx, c, entity, item)
                if o is None: continue
                rep["delivered" if o["validation_state"] == "VALID" else ("ambiguous" if o["validation_state"] == "AMBIGUOUS" else "invalid")] += 1
            cursor = out.data["next_cursor"]
            if cursor is None: break
        return rep
    def ingest_events(self, ctx, integration_id, events):
        c = self.integration(ctx, integration_id); cfg = self.cfg[(ctx.tenant_id, integration_id)]; results = []
        for ev in events:
            try: self.guard.check(ev)
            except UntrustedInput as e: self._error(ctx, c.anchor_module, "EVENT_REJECTED", integration=integration_id, reasons=e.reasons[:3]); results.append({"event_id": str(ev.get("event_id"))[:40], "ordering_state": "REJECTED_BY_POLICY"}); continue
            for d in self.sequencer.receive(ctx, integration_id, ev): results.append(self._record_decision(ctx, c, cfg, d))
        for d in self.sequencer.tick(ctx, integration_id): results.append(self._record_decision(ctx, c, cfg, d))
        return results
    def tick(self, ctx, integration_id):
        c = self.integration(ctx, integration_id); cfg = self.cfg[(ctx.tenant_id, integration_id)]; return [self._record_decision(ctx, c, cfg, d) for d in self.sequencer.tick(ctx, integration_id)]
    def _record_decision(self, ctx, c, cfg, d):
        ev, st = d["event"], d["ordering_state"]; entity = cfg["event_entities"].get(ev["type"]); causal = {"event_id": ev["event_id"]}
        if ev.get("depends_on"): causal["parent_id"] = ev["depends_on"][0]
        if st == "QUEUED_AWAITING_PREDECESSOR": causal["expected_predecessor"] = d["waiting_on"][0]
        if st == "IN_ORDER" and entity:
            o = self._ingest_record(ctx, c, entity, ev["payload"], event=True, ordering_state=st, source_sequence=ev.get("source_sequence"), causal=causal); return {"event_id": ev["event_id"], "ordering_state": st, "delivered": bool(o and o["validation_state"] == "VALID")}
        ob = self.obs.build(ctx, c.integration_id, anchor_module=c.anchor_module, target_system_id=c.target_system_id, environment_id=c.environment_id, connector_id=c.runtime.desc["connector_id"], source_system=c.target_system_id, source_object={"object_type": entity or "Event", "object_id": ev["event_id"]}, source_version=None, pack_ref=c.pack_ref, schema_fingerprint=c.fp["value"],
                            payload=ev.get("payload"), classification="INTERNAL", confidence={"value": 0.0, "basis": "event not applied: %s" % st}, provenance=[{"step_kind": "SOURCE_SYSTEM", "ref": c.target_system_id}, {"step_kind": "SOURCE_OBJECT", "ref": ev["event_id"]}, {"step_kind": "SOURCE_FIELD", "ref": "event.payload"}, {"step_kind": "TRANSLATION_PACK", "ref": c.pack_ref["id"], "version": c.pack_ref["version"], "hash": c.pack_ref["hash"]}, {"step_kind": "SCHEMA_FINGERPRINT", "ref": "fp", "hash": c.fp["value"]}, {"step_kind": "OBSERVATION", "ref": "pending"}],
                            causal=causal, ordering_state=st)
        self.store.put(ctx, "observations", ob["observation_id"], ob); self.tel.set(ctx.tenant_id, c.integration_id, "queue_depth", len(self.sequencer.pending(ctx, c.integration_id)))
        return {"event_id": ev["event_id"], "ordering_state": st, "delivered": False}
    def poll_events(self, ctx, integration_id):
        c = self.integration(ctx, integration_id); out = c.runtime.call(ctx, integration_id, c.target_system_id, c.environment_id, "read", {})
        if out.result["outcome_kind"] == "NO_DATA": return []
        if out.result["outcome_kind"] != "DATA_OBTAINED": self._error(ctx, c.anchor_module, "SOURCE_UNAVAILABLE" if out.result["outcome_kind"] == "COULD_NOT_OBTAIN" else "SOURCE_DATA_INVALID", integration=integration_id, error=out.error); return []
        return self.ingest_events(ctx, integration_id, out.data["items"])
    def request_action(self, ctx, module_id, action, dispatch=True):
        self.auth.require(ctx)
        if action["source_module"] != module_id or action["tenant_id"] != ctx.tenant_id: raise TenantContextError("action does not belong to the requesting module or tenant")
        rec = self.actions.submit(ctx, action)
        if dispatch and rec["execution_state"] == "QUEUED":
            try: rec = self.actions.dispatch(ctx, rec["action_id"])
            except GovernanceHold: rec = self.actions.ledger.get(ctx, rec["action_id"])
        return rec

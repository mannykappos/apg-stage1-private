"""Action delivery, Action Execution Ledger, idempotency and reconciliation (architecture AR-13). AUIF carries a Governor decision reference and hash; it never issues, verifies or substitutes for a decision.
FINDING F-1 (contract gap): ActionExecutionRecord.error uses the EXTERNAL error code set, which has no code for an AUIF-side refusal (governance denial, boundary rejection, outbound-validation failure).
This build uses CANCELLED with an explicit message_redacted ('refused before transmission: <reason>'). Reported to the auditor; the audited contract is not changed here."""
from .canonical import top
from .contracts import validate
from .errors import *
from .security import InputGuard
from .util import sha, evidence
ACTION_TRANSITIONS = {("CREATED", "QUEUED"), ("CREATED", "FAILED"), ("QUEUED", "SENT"), ("QUEUED", "FAILED"), ("SENT", "ACKNOWLEDGED"), ("SENT", "COMPLETED"), ("SENT", "FAILED"), ("SENT", "UNKNOWN_OUTCOME"), ("ACKNOWLEDGED", "COMPLETED"), ("ACKNOWLEDGED", "FAILED"),
                      ("UNKNOWN_OUTCOME", "RECONCILIATION_REQUIRED"), ("RECONCILIATION_REQUIRED", "COMPLETED"), ("RECONCILIATION_REQUIRED", "FAILED")}
TERMINAL = {"COMPLETED", "FAILED"}
class Ledger:
    def __init__(self, store, clock): self.store, self.clock = store, clock
    def get(self, ctx, action_id):
        r = self.store.get(ctx, "action_ledger", action_id)
        if r is None: raise NotFound("action %s" % action_id)
        return r
    def create(self, ctx, rec): validate("action#ActionExecutionRecord", rec); self.store.put(ctx, "action_ledger", rec["action_id"], rec, if_absent=True); return rec
    def transition(self, ctx, action_id, to, **fields):
        def fn(old):
            if (old["execution_state"], to) not in ACTION_TRANSITIONS: raise IllegalTransition("%s -> %s" % (old["execution_state"], to))
            new = dict(old); new.update(fields); new["execution_state"] = to; validate("action#ActionExecutionRecord", new); return new      # a contract violation rolls the update back
        return self.store.update(ctx, "action_ledger", action_id, fn)
    def patch(self, ctx, action_id, **fields):
        def fn(old):
            if old["execution_state"] in TERMINAL: raise IllegalTransition("terminal record is immutable")
            new = dict(old); new.update(fields); validate("action#ActionExecutionRecord", new); return new
        return self.store.update(ctx, "action_ledger", action_id, fn)
    def event(self, ctx, action_id, kind, **detail):
        n = self.store.next_sequence(ctx, "action-events:" + action_id); self.store.put(ctx, "action_events", "%s:%04d" % (action_id, n), dict({"kind": kind, "at": self.clock.iso()}, **detail))
    def events(self, ctx, action_id): return [v for _, v in self.store.list(ctx, "action_events", action_id + ":")]
class ActionService:
    def __init__(self, store, clock, ids, telemetry, translator, boundary, governor, integrations, guard=None):
        self.store, self.clock, self.ids, self.tel, self.tr, self.boundary, self.gov, self.integrations, self.guard = store, clock, ids, telemetry, translator, boundary, governor, integrations, guard or InputGuard(); self.ledger = Ledger(store, clock)
    def _refuse(self, ctx, rec, reason, **extra):
        err = {"code": "CANCELLED", "retryable": False, "message_redacted": "refused before transmission: %s" % reason}; self.ledger.event(ctx, rec["action_id"], "REFUSED", reason=reason); return self.ledger.transition(ctx, rec["action_id"], "FAILED", error=err, **extra)
    def submit(self, ctx, action):
        validate("action#CanonicalAction", action); self.guard.check(action["canonical_action"]["payload"]); key, h = action["idempotency_key"], sha(action["canonical_action"])
        if not self.store.put(ctx, "action_idem", key, {"action_id": action["action_id"], "content_hash": h}, if_absent=True):
            prev = self.store.get(ctx, "action_idem", key)
            if prev["content_hash"] != h: raise AuifError("idempotency key reused with different content")
            return self.ledger.get(ctx, prev["action_id"])                                         # duplicate submission: the existing record, no second action
        self.store.put(ctx, "action_payloads", "canon:" + action["action_id"], {"payload": action["canonical_action"]}); supplied = action["governance"].get("governor_decision_ref")
        rec = {"contract_kind": "ActionExecutionRecord", "action_id": action["action_id"], "tenant_id": ctx.tenant_id, "source_module": action["source_module"], "target_system_id": action["target_system_id"], "environment_id": action["environment_id"],
               "canonical_action_ref": evidence("canonical-action", action["canonical_action"], "canon-" + action["action_id"]), "payload_hash": h, "idempotency_key": key, "correlation_id": action["correlation_id"], "attempt_count": 0, "created_at": self.clock.iso(), "execution_state": "CREATED", "governance": {k: v for k, v in action["governance"].items() if k not in ("governor_decision_ref", "governor_decision_hash")} | {"governor_decision_ref": None}}
        self.ledger.create(ctx, rec); self.store.put(ctx, "action_manifest_ref", action["action_id"], action["manifest_ref"])
        if supplied: self.ledger.event(ctx, action["action_id"], "IGNORED_SUPPLIED_DECISION_REF", note="AUIF does not trust or verify a decision reference supplied by a module; it obtains the decision from the Governor port itself (OD-04 / GD-03 / GD-05 open)")
        return self.ledger.transition(ctx, action["action_id"], "QUEUED")
    def supply_governance_requirement(self, ctx, action_id, required, source):
        """A determination PROVIDED by its source (module, Governor policy or manifest). AUIF does not decide it (GD-03)."""
        if source not in ("MODULE_DECLARED", "GOVERNOR_POLICY", "MANIFEST_DECLARED"): raise AuifError("unknown governance source")
        rec = self.ledger.get(ctx, action_id); g = dict(rec["governance"], governance_required=bool(required), governance_required_source=source); return self.ledger.patch(ctx, action_id, governance=g)
    def dispatch(self, ctx, action_id):
        rec = self.ledger.get(ctx, action_id)
        if rec["execution_state"] != "QUEUED": return rec
        gov = rec["governance"]
        if gov["governance_required"] == "UNKNOWN": self.ledger.event(ctx, action_id, "HELD", reason="governance requirement undetermined"); raise GovernanceHold("governance requirement undetermined: action held, never sent")
        h = self.integrations.resolve(ctx, self.store.get(ctx, "action_manifest_ref", action_id)); canon = self.store.get(ctx, "action_payloads", "canon:" + action_id)["payload"]; pl = canon["payload"]
        am = self.tr.action_mapping(h.pack_ref, canon["action_type"])
        governed = gov["governance_required"] is True
        if not h.operation_allowed(am["operation"], governed): self.ledger.event(ctx, action_id, "HELD", reason="integration state does not allow this operation"); raise GovernanceHold("integration is not in a state that allows this operation: held")
        ctype, attrs = pl["canonical_type"], pl["attributes"]; classes = self.tr.model.classes(ctype, attrs)
        try: fields, vev = self.tr.translate_outbound(h.pack_ref, ctype, attrs)
        except OutboundValidationError as e:
            return self._refuse(ctx, rec, "outbound validation failed", outbound_validation={"performed": True, "validation_result": "FAILED", "constraints_ref": evidence("outbound-validation", {"violations": len(e.violations)}, "ov-" + action_id), "validated_at": self.clock.iso()})
        bd = self.boundary.enforce(ctx, attrs, classes, {"kind": h.destination_kind, "system": h.target_system_id}, {"purpose": "action", "action_type": canon["action_type"]})
        self.ledger.event(ctx, action_id, "BOUNDARY", decision=bd["decision"], per_attribute=[{k: v for k, v in e.items() if k != "basis"} for e in bd["evidence"]])
        if bd["decision"] == "REJECTED": return self._refuse(ctx, rec, "data boundary: " + bd["reason"])
        if bd["decision"] == "TRANSFORMED":
            try: fields, vev = self.tr.translate_outbound(h.pack_ref, ctype, bd["payload"])
            except OutboundValidationError: return self._refuse(ctx, rec, "outbound validation failed after boundary transformation")
        governed = governed or bd["decision"] == "NEEDS_AUTHORISATION"
        if governed:
            resp = self.gov.request_decision(ctx, {"action_id": action_id, "action_type": canon["action_type"], "target_system_id": h.target_system_id, "environment_id": h.environment_id, "payload_hash": rec["payload_hash"], "classification": top(list(classes.values()))})
            st = resp.get("status")
            if st == "DENIED": return self._refuse(ctx, rec, "governance decision denied")
            if st != "GRANTED": self.ledger.event(ctx, action_id, "HELD", reason="governance decision %s" % st); raise GovernanceHold("governance decision %s: action held" % st)
            if not resp.get("decision_ref") or not resp.get("decision_hash"): raise AuifError("malformed Governor response: a grant must carry a decision reference and hash")
            gov = dict(gov, governance_required=True, governor_decision_ref=resp["decision_ref"], governor_decision_hash=resp["decision_hash"])
        self.store.put(ctx, "action_payloads", "trans:" + action_id, {"entity": fields["entity"], "fields": fields["fields"]}); ext_id = pl["canonical_id"].split(":")[-1]
        rec = self.ledger.transition(ctx, action_id, "SENT", translated_action_ref=evidence("translated-action", fields, "trans-" + action_id), outbound_validation={"performed": True, "validation_result": "PASSED", "constraints_ref": evidence("outbound-validation", vev, "ov-" + action_id), "validated_at": self.clock.iso()},
                                     sent_at=self.clock.iso(), attempt_count=1, governance=gov)        # durable BEFORE the target is contacted
        out = h.runtime.call(ctx, h.integration_id, h.target_system_id, h.environment_id, "write", {"operation": am["operation"], "entity": fields["entity"], "id": ext_id, "fields": fields["fields"]}, idempotency_key=rec["idempotency_key"])
        rec = self.ledger.patch(ctx, action_id, attempt_count=max(1, out.attempts)); self.tel.inc(ctx.tenant_id, h.integration_id, "action_execution")
        if out.result["outcome_kind"] == "DATA_OBTAINED":
            rec = self.ledger.transition(ctx, action_id, "ACKNOWLEDGED", acknowledged_at=self.clock.iso(), external_reference=out.data["external_reference"]); return self.ledger.transition(ctx, action_id, "COMPLETED", completed_at=self.clock.iso(), result={"outcome": "APPLIED"})
        if out.may_have_applied:
            strat = "QUERY_EXTERNAL_BY_IDEMPOTENCY_KEY" if h.runtime.descriptor()["idempotency"]["outcome_reconciliation_supported"] else "OPERATOR_REVIEW"
            return self.ledger.transition(ctx, action_id, "UNKNOWN_OUTCOME", error=out.error, reconciliation={"strategy": strat, "next_check_at": self.clock.iso(self.clock.now + 30), "blind_retry_permitted": False})
        return self.ledger.transition(ctx, action_id, "FAILED", error=out.error)
    def reconcile(self, ctx, action_id):
        rec = self.ledger.get(ctx, action_id)
        h = self.integrations.resolve(ctx, self.store.get(ctx, "action_manifest_ref", action_id))
        if rec["execution_state"] == "UNKNOWN_OUTCOME": rec = self.ledger.transition(ctx, action_id, "RECONCILIATION_REQUIRED"); self.tel.inc(ctx.tenant_id, h.integration_id, "reconciliation")
        if rec["execution_state"] != "RECONCILIATION_REQUIRED": return rec
        if rec["reconciliation"]["strategy"] != "QUERY_EXTERNAL_BY_IDEMPOTENCY_KEY": self.ledger.event(ctx, action_id, "OPERATOR_REVIEW_REQUIRED"); return rec
        found = h.runtime.lookup(ctx, h.integration_id, rec["idempotency_key"])
        if found == "UNSUPPORTED": self.ledger.event(ctx, action_id, "OPERATOR_REVIEW_REQUIRED"); return rec
        if found: return self._complete(ctx, action_id, found)
        return self.ledger.transition(ctx, action_id, "FAILED", error={"code": "TIMEOUT", "retryable": False, "message_redacted": "reconciled: the target holds no record of this idempotency key; the action was not applied"})
    def _complete(self, ctx, action_id, found):
        def fn(old):
            new = {k: v for k, v in old.items() if k != "error"}; new.update(execution_state="COMPLETED", completed_at=self.clock.iso(), result={"outcome": "APPLIED_CONFIRMED_BY_RECONCILIATION"}, external_reference=found["external_reference"])
            if ("RECONCILIATION_REQUIRED", "COMPLETED") not in ACTION_TRANSITIONS or old["execution_state"] != "RECONCILIATION_REQUIRED": raise IllegalTransition("not reconcilable")
            validate("action#ActionExecutionRecord", new); return new
        return self.store.update(ctx, "action_ledger", action_id, fn)
    def operator_resolve(self, ctx, action_id, applied, evidence_ref):
        rec = self.ledger.get(ctx, action_id)
        if rec["execution_state"] != "RECONCILIATION_REQUIRED": raise IllegalTransition("only a record awaiting reconciliation can be resolved by an operator")
        self.ledger.event(ctx, action_id, "OPERATOR_RESOLVED", applied=bool(applied), evidence_id=evidence_ref["evidence_id"])
        return self._complete(ctx, action_id, {"external_reference": "operator:" + evidence_ref["evidence_id"]}) if applied else self.ledger.transition(ctx, action_id, "FAILED", error={"code": "TIMEOUT", "retryable": False, "message_redacted": "operator confirmed the action was not applied"})

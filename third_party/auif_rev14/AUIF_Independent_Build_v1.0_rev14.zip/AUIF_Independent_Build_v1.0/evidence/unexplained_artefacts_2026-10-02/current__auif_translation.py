"""Translation Pack runtime (architecture AR-8): immutable hashed packs, pinning by hash, bidirectional deterministic translation, explicit outcome for every field,
outbound validation against target constraints, and explicit TRANSLATION_INVALID / AMBIGUOUS results (never fabricated data). Packs carry no governance logic."""
import copy, json, re
from decimal import Decimal, ROUND_HALF_UP
from .canonical import top, rank
from .contracts import validate
from .errors import PackError, TranslationFailure, OutboundValidationError
from .util import sha, canon, evidence
def pack_hash(pack): p = dict(pack); p.pop("artifact_hash", None); return sha(p)
def semver(v): return tuple(int(x) for x in re.match(r"^(\d+)\.(\d+)\.(\d+)", v).groups())
class PackRegistry:
    """Content-addressed, append-only registry. A (id, version) can never be re-registered with different content (handoff section 15)."""
    def __init__(self, ai_promotion_verifier=None): self._s, self.ai_verifier = {}, ai_promotion_verifier
    def register(self, pack):
        validate("translation#TranslationPack", pack)
        if pack["artifact_hash"] != pack_hash(pack): raise PackError("artifact_hash does not match the pack content")
        for m in pack["mappings"]:      # an AI-proposed mapping may be VALIDATED/TRUSTED only with evidence issued by the deterministic validator (handoff section 36)
            if m["proposed_by"] == "AI_ASSISTED" and m["mapping_state"] in ("VALIDATED", "TRUSTED") and not (self.ai_verifier and self.ai_verifier(m)): raise PackError("AI-assisted mapping %s promoted without verifiable deterministic validation" % m["mapping_id"])
        k = (pack["pack_id"], pack["pack_version"])
        if k in self._s:
            if json.loads(self._s[k])["artifact_hash"] != pack["artifact_hash"]: raise PackError("immutable: %s@%s already registered with different content" % k)
            return
        self._s[k] = canon(pack)
    def get(self, pack_id, version, expected_hash):
        raw = self._s.get((pack_id, version))
        if raw is None: raise PackError("pack %s@%s is not registered" % (pack_id, version))
        pack = json.loads(raw)
        if pack_hash(pack) != pack["artifact_hash"] or pack["artifact_hash"] != expected_hash: raise PackError("pack hash mismatch for %s@%s: refused" % (pack_id, version))
        return pack
    def versions(self, pack_id): return sorted(v for (p, v) in self._s if p == pack_id)
def compat_problems(pack, canonical_version, auif_contract_version="1.0.0"):
    out = []
    if not (semver(pack["canonical_model_compat"]["min"]) <= semver(canonical_version) <= semver(pack["canonical_model_compat"]["max"])): out.append("canonical model %s outside the pack's range" % canonical_version)
    if not (semver(pack["auif_contract_compat"]["min"]) <= semver(auif_contract_version) <= semver(pack["auif_contract_compat"]["max"])): out.append("AUIF contract %s outside the pack's range" % auif_contract_version)
    return out
FUNCS = {"cents_to_decimal": lambda v: str((Decimal(int(v)) / Decimal(100)).quantize(Decimal("0.01"), ROUND_HALF_UP)), "decimal_to_cents": lambda v: int((Decimal(str(v)) * 100).quantize(Decimal("1"), ROUND_HALF_UP)), "dollars_to_decimal": lambda v: str(Decimal(str(v)).quantize(Decimal("0.01"), ROUND_HALF_UP)), "decimal_to_dollars": lambda v: str(Decimal(str(v)).quantize(Decimal("0.01"), ROUND_HALF_UP))}
def apply_transform(tr, value, direction):
    k, p = tr["kind"], tr.get("parameters", {})
    if k in ("IDENTITY", "RENAME"): return value
    if k == "CONSTANT": return p["value"]
    if k == "ENUM_MAP":
        m = p["map"] if direction == "in" else {v: kk for kk, v in p["map"].items()}
        key = value if value in m else (str(value) if str(value) in m else None)
        if key is None: raise TranslationFailure("unmapped enum value %r" % (value,))
        return m[key]
    if k == "FORMAT": return {"upper": str.upper, "lower": str.lower, "strip": str.strip, "title": str.title}[p["op"]](value)
    if k == "UNIT_CONVERT": f = Decimal(str(p["factor"])); return str((Decimal(str(value)) * f if direction == "in" else Decimal(str(value)) / f).quantize(Decimal(1).scaleb(-p.get("decimals", 2)), ROUND_HALF_UP))
    if k == "DETERMINISTIC_FUNCTION":
        name = p["in"] if direction == "in" else p["out"]
        if name not in FUNCS: raise PackError("unknown deterministic function %s" % name)
        return FUNCS[name](value)
    raise PackError("transform %s is not supported by this runtime" % k)
def get_path(rec, path):
    cur = rec
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur: return False, None
        cur = cur[part]
    return True, cur
def set_path(rec, path, value):
    parts = path.split("."); cur = rec
    for p in parts[:-1]: cur = cur.setdefault(p, {})
    cur[parts[-1]] = value
def leaves(rec, prefix=""):
    for k, v in rec.items():
        p = prefix + k
        if isinstance(v, dict) and v: yield from leaves(v, p + ".")
        else: yield p
RULES = {"email_format": lambda v: isinstance(v, str) and re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", v) is not None}
def check_constraint(c, value):
    k, s = c["kind"], c["spec"]
    if k == "TYPE": return {"string": isinstance(value, str), "integer": isinstance(value, int) and not isinstance(value, bool), "number": isinstance(value, (int, float)) and not isinstance(value, bool), "boolean": isinstance(value, bool)}[s["type"]]
    if k == "ENUM": return value in s["values"]
    if k == "PATTERN": return isinstance(value, str) and re.search(s["regex"], value) is not None
    if k == "RANGE": return isinstance(value, (int, float)) and s.get("min", float("-inf")) <= value <= s.get("max", float("inf"))
    if k == "LENGTH": return hasattr(value, "__len__") and s.get("min", 0) <= len(value) <= s.get("max", 10 ** 9)
    if k == "REQUIRED": return value is not None
    if k == "DETERMINISTIC_RULE": return RULES[s["rule"]](value)
    raise PackError("unknown constraint kind %s" % k)
class Translator:
    def __init__(self, model, registry, ids, clock): self.model, self.reg, self.ids, self.clock = model, registry, ids, clock
    def _entity_mapping(self, pack, entity):
        for m in pack["mappings"]:
            if m["kind"] == "ENTITY" and m["source_ref"] == entity and m["mapping_state"] in ("VALIDATED", "TRUSTED"): return m
        raise TranslationFailure("no validated entity mapping for %s" % entity)
    def translate_inbound(self, ctx, pack_ref, entity, record, *, source_system, observation_id, schema_fingerprint, source_id):
        pack = self.reg.get(pack_ref["id"], pack_ref["version"], pack_ref["hash"]); em = self._entity_mapping(pack, entity); ctype = em["canonical_ref"]
        fmaps = [m for m in pack["mappings"] if m["kind"] == "FIELD" and m["source_ref"].startswith(entity + ".")]; attrs, outcomes, reasons, ambiguous, covered, srcfields = {}, [], [], False, set(), []
        pol = pack["unmapped_field_policy"]; cls_map = {c["source_ref"]: c["classification"] for c in pack["classification_mappings"]}; pack_classes = {}
        for m in fmaps:
            path = m["source_ref"][len(entity) + 1:]; covered.add(path); found, val = get_path(record, path)
            if not found:
                outcomes.append({"source_field": path, "outcome": "OPTIONAL_AND_UNUSED"}); continue
            if m["mapping_state"] == "AMBIGUOUS": outcomes.append({"source_field": path, "outcome": "AMBIGUOUS"}); ambiguous = True; reasons.append("mapping for %s is ambiguous: no authoritative meaning" % path); continue
            if m["mapping_state"] not in ("VALIDATED", "TRUSTED"): outcomes.append({"source_field": path, "outcome": "UNMAPPED"}); covered.discard(path); continue
            try: attr = m["canonical_ref"].split(".", 1)[1]; attrs[attr] = apply_transform(m["inbound"]["transform"], val, "in"); outcomes.append({"source_field": path, "outcome": "MAPPED"}); srcfields.append(m["source_ref"])
            except TranslationFailure as e: outcomes.append({"source_field": path, "outcome": "REJECTED"}); reasons.append("%s: %s" % (path, e))
            if m["source_ref"] in cls_map: pack_classes[attr] = cls_map[m["source_ref"]]
        for p in sorted(set(leaves(record)) - covered):
            rule = next((r for r in pol["ignored_by_rule"] if re.search(r["field_pattern"], p)), None)
            if rule: outcomes.append({"source_field": p, "outcome": "IGNORED_BY_RULE", "rule_ref": rule["rule_id"]}); continue
            if any(re.search(o["field_pattern"], p) for o in pol["optional_and_unused"]): outcomes.append({"source_field": p, "outcome": "OPTIONAL_AND_UNUSED"}); continue
            d = pol["default_outcome"]; outcomes.append({"source_field": p, "outcome": d})
            if d == "REJECTED": reasons.append("unmapped field %s rejected by policy" % p)
            if d == "AMBIGUOUS": ambiguous = True; reasons.append("unmapped field %s is ambiguous" % p)
        if not reasons: reasons += self.model.problems(ctype, attrs) if self.model.has(ctype) else ["unknown canonical type %s" % ctype]
        state = "TRANSLATION_INVALID" if (reasons and not (ambiguous and all("ambiguous" in r for r in reasons))) else ("AMBIGUOUS" if ambiguous else "VALID")
        cid = "%s:%s:%s" % (ctype.lower(), source_system, source_id); cid = cid if re.match(r"^[A-Za-z0-9][A-Za-z0-9._:@-]{0,127}$", cid) else "%s:%s" % (ctype.lower(), sha(cid)[:24])
        chain = [{"step_kind": "SOURCE_SYSTEM", "ref": source_system}, {"step_kind": "SOURCE_OBJECT", "ref": "%s/%s" % (entity, source_id)}] + [{"step_kind": "SOURCE_FIELD", "ref": f} for f in (srcfields or [entity + ".*"])] + \
                [{"step_kind": "TRANSLATION_PACK", "ref": pack["pack_id"], "version": pack["pack_version"], "hash": pack["artifact_hash"]}, {"step_kind": "SCHEMA_FINGERPRINT", "ref": "fp", "hash": schema_fingerprint}, {"step_kind": "OBSERVATION", "ref": observation_id}]
        obj = {"contract_kind": "CanonicalObject", "canonical_type": ctype, "canonical_model_version": self.model.version, "canonical_id": cid, "tenant_id": ctx.tenant_id, "validation_state": state, "provenance_chain": chain, "field_outcomes": outcomes}
        if state == "VALID":
            base = self.model.classes(ctype, attrs); cl = {a: (pack_classes[a] if a in pack_classes and rank(pack_classes[a]) > rank(base[a]) else base[a]) for a in attrs}; obj.update({"attributes": attrs, "attribute_classifications": cl, "classification": top(list(cl.values()))})
        else: obj.update({"classification": "INTERNAL", "diagnostics": {"diagnostics_id": self.ids.next("diag"), "reasons": reasons[:20]}})
        return validate("canonical#CanonicalObject", obj)
    def translate_outbound(self, pack_ref, canonical_type, attrs, operation=None):
        """canonical attributes -> external record, validated against EVERY applicable target constraint BEFORE delivery (handoff section 14)."""
        pack = self.reg.get(pack_ref["id"], pack_ref["version"], pack_ref["hash"]); out, violations, checked, entity = {}, [], 0, None
        for m in pack["mappings"]:
            if m["kind"] != "FIELD" or not m["canonical_ref"].startswith(canonical_type + "."): continue
            attr = m["canonical_ref"].split(".", 1)[1]
            if attr not in attrs: continue
            if m["mapping_state"] not in ("VALIDATED", "TRUSTED"): violations.append("attribute %s has no validated mapping" % attr); continue
            ob = m["outbound"]
            if not ob["supported"]: violations.append("attribute %s cannot be written to the target (%s)" % (attr, ob["reason"])); continue
            entity = m["source_ref"].split(".", 1)[0]
            try: v = apply_transform(ob["transform"], attrs[attr], "out")
            except TranslationFailure as e: violations.append("%s: %s" % (attr, e)); continue
            for c in ob["target_constraints"]:
                checked += 1
                if not check_constraint(c, v): violations.append("target constraint %s violated by %s" % (c["constraint_id"], attr))
            set_path(out, m["source_ref"].split(".", 1)[1], v)
        unmapped = [a for a in attrs if not any(m["kind"] == "FIELD" and m["canonical_ref"] == "%s.%s" % (canonical_type, a) for m in pack["mappings"])]
        violations += ["attribute %s has no outbound mapping" % a for a in unmapped]
        if violations: raise OutboundValidationError(violations)
        return {"entity": entity, "fields": out}, {"constraints_checked": checked, "violations": 0}
    def action_mapping(self, pack_ref, action_type):
        pack = self.reg.get(pack_ref["id"], pack_ref["version"], pack_ref["hash"])
        for m in pack["mappings"]:
            if m["kind"] == "ACTION" and m["canonical_ref"] == action_type and m["mapping_state"] in ("VALIDATED", "TRUSTED") and m["outbound"]["supported"]: return {"operation": m["source_ref"], "entity": m["outbound"]["target_type"]}
        raise TranslationFailure("no validated outbound action mapping for %s" % action_type)

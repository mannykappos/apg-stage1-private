from auif.clock import FakeClock
from auif.tenancy import TenantAuthority, TenantScopedPersistence
from auif.throttle import Throttle
from auif.observability import Telemetry
from auif_ref.persistence import MemoryPersistence
from auif_ref.secrets import InMemorySecretStore
from auif.connector import ConnectorRuntime
class Env:
    def __init__(self):
        self.clock = FakeClock(); self.auth = TenantAuthority(); self.store = TenantScopedPersistence(MemoryPersistence(), self.auth); self.secrets = InMemorySecretStore(); self.th = Throttle(self.clock, default_rate=1000, default_burst=1000); self.tel = Telemetry(self.clock)
        self.A, self.B = self.auth.issue("tenant-a", "svc"), self.auth.issue("tenant-b", "svc")
    def runtime(self, connector): return ConnectorRuntime(connector, secrets=self.secrets, throttle=self.th, telemetry=self.tel, clock=self.clock)

from types import SimpleNamespace
from auif.canonical import CanonicalModel
from auif.classification import BoundaryEnforcer
from auif.discovery import fingerprint
from auif.translation import PackRegistry, Translator
from auif.util import Ids
from auif.action import ActionService
from synthetic.packs import MODEL_DEF, pack_a
from synthetic.systems import SystemA
from synthetic.connectors import SyntheticRestConnector
from synthetic.governor_double import GovernorDouble
from synthetic.policy import SyntheticPolicy
REF = "secretref:synthetic/credential"
class ActionEnv(Env):
    def __init__(self, tenants=("tenant-a",)):
        super().__init__(); self.ids = Ids(); self.sysA = SystemA(); [self.secrets.put(t, REF, "client-secret-A") for t in ("tenant-a", "tenant-b")]; self.rt = self.runtime(SyntheticRestConnector(self.sysA, REF)); fp = fingerprint(self.sysA.metadata())
        self.model = CanonicalModel(MODEL_DEF); self.reg = PackRegistry(); pack = pack_a([fp["value"]]); self.reg.register(pack); self.ref = {"id": pack["pack_id"], "version": pack["pack_version"], "hash": pack["artifact_hash"]}; self.tr = Translator(self.model, self.reg, self.ids, self.clock)
        self.policy, self.gov = SyntheticPolicy(), GovernorDouble(); self.allowed = True
        self.handle = SimpleNamespace(integration_id="i1", target_system_id="synthetic-system-a", environment_id="env-sandbox", pack_ref=self.ref, runtime=self.rt, destination_kind="customer-system", operation_allowed=lambda op, governed: self.allowed, state=lambda: "ACTIVE")
        self.svc = ActionService(self.store, self.clock, self.ids, self.tel, self.tr, BoundaryEnforcer(self.policy), self.gov, SimpleNamespace(resolve=lambda ctx, mref: self.handle))
    def action(self, n, attrs=None, governed=False, key=None, cid="party:synthetic-system-a:3", action_type="synthetic.update_party", ctx=None, decision_ref=None):
        g = {"governance_required": governed, "governance_required_source": "UNKNOWN" if governed == "UNKNOWN" else "MODULE_DECLARED", "governor_decision_ref": decision_ref}
        if decision_ref: g["governor_decision_hash"] = "b" * 64
        return {"contract_kind": "CanonicalAction", "action_id": "act-%04d" % n, "tenant_id": (ctx or self.A).tenant_id, "source_module": "synthetic-module-1", "target_system_id": "synthetic-system-a", "environment_id": "env-sandbox", "manifest_ref": {"id": "manifest-i1", "version": "1.0.0", "hash": "a" * 64},
                "canonical_action": {"action_type": action_type, "payload": {"canonical_type": "Party", "canonical_id": cid, "attributes": attrs or {"lifecycle_state": "INACTIVE"}}}, "idempotency_key": key or "idem-%04d-xyz" % n, "correlation_id": "corr-%04d" % n, "governance": g, "requested_at": self.clock.iso()}

"""SYNTHETIC Anchor modules (test doubles implementing the Module Port). NOT Anchor Real Estate or any real Anchor module (ED-14)."""
from auif.ports import ModulePort
class RecordingModule(ModulePort):
    def __init__(self, module_id, requirements): self.module_id, self._req, self.by_tenant = module_id, requirements, {}
    def _b(self, ctx): return self.by_tenant.setdefault(ctx.tenant_id, {"entities": [], "observations": [], "events": [], "states": [], "errors": []})
    def ingest_canonical_entity(self, ctx, obj): self._b(ctx)["entities"].append(obj)
    def ingest_canonical_observation(self, ctx, observation): self._b(ctx)["observations"].append(observation)
    def ingest_canonical_event(self, ctx, observation): self._b(ctx)["events"].append(observation)
    def semantic_requirements(self): return self._req
    def module_capabilities(self): return {"consumes": [r["concept"] for r in self._req]}
    def receive_integration_state(self, ctx, state): self._b(ctx)["states"].append(state)
    def receive_integration_error(self, ctx, error): self._b(ctx)["errors"].append(error)
def module_one(): return RecordingModule("synthetic-module-1", [{"concept": "Party", "attributes": ["display_name", "lifecycle_state"]}, {"concept": "Property", "attributes": ["street", "city", "status"]}])
def module_two(): return RecordingModule("synthetic-module-2", [{"concept": "Task", "attributes": ["title", "status"]}, {"concept": "Party", "attributes": ["display_name"]}, {"concept": "module.synthetic-module-2.Listing", "attributes": ["headline"]}])

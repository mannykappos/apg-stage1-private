"""AI-assisted mapping boundary (architecture AR-16). AI may PROPOSE; it can never validate, trust, approve, or touch governance, credentials, connectors, the ledger or any action.
Structure, not instruction: the proposer receives a read-only sandbox built from untrusted discovery data; every state it claims is discarded; VALIDATED exists only via the deterministic validator's evidence."""
import copy
from abc import ABC, abstractmethod
from .errors import AuifError
from .security import instruction_like
from .util import sha, evidence
SOURCE_TO_CANON = {"string": {"STRING", "ENUM", "REFERENCE", "TIMESTAMP", "DECIMAL"}, "integer": {"INTEGER", "DECIMAL", "ENUM", "BOOLEAN"}, "number": {"DECIMAL"}, "decimal": {"DECIMAL"}, "boolean": {"BOOLEAN"}}
KNOWN = {"IDENTITY", "RENAME", "ENUM_MAP", "UNIT_CONVERT", "FORMAT", "CONSTANT", "DETERMINISTIC_FUNCTION"}
class UntrustedText(str): """Marks external text as DATA. Nothing in the core interprets it as an instruction."""
class PromotionRefused(AuifError): pass
class ProposerSandbox:
    """The ONLY capability a proposer holds: read-only copies of discovery fields and canonical attribute names. No attribute path leads to a store, secret, connector, ledger, Governor or action."""
    __slots__ = ("_fields", "_canon")
    def __init__(self, fields, canon): object.__setattr__(self, "_fields", fields); object.__setattr__(self, "_canon", canon)
    def __setattr__(self, k, v): raise AttributeError("read-only sandbox")
    def fields(self): return copy.deepcopy(self._fields)
    def canonical_attributes(self): return copy.deepcopy(self._canon)
class MappingProposer(ABC):
    @abstractmethod
    def propose(self, sandbox): ...             # -> [{"source_ref","canonical_ref","transform","alternatives","rationale", ("claimed_state")}]
class MappingValidator:
    def __init__(self, model): self.model = model
    def check(self, source_ref, canonical_ref, transform, alternatives, record):
        problems = []; el = next((e for e in record["elements"] if e["element_kind"] == "FIELD" and e["name"] == source_ref), None)
        if el is None: problems.append("source field %s does not exist in the discovery record" % source_ref)
        try: ctype, attr = canonical_ref.split(".", 1)
        except ValueError: ctype, attr = canonical_ref, ""
        cdef = self.model.attributes(ctype).get(attr) if self.model.has(ctype) else None
        if cdef is None: problems.append("canonical attribute %s does not exist in the model" % canonical_ref)
        if transform.get("kind") not in KNOWN: problems.append("unsupported transform %s" % transform.get("kind"))
        if el is not None and cdef is not None and transform.get("kind") in KNOWN:
            st = el["detail"].get("type", "string")
            if cdef["type"] not in SOURCE_TO_CANON.get(st, set()): problems.append("source type %s is not compatible with canonical %s" % (st, cdef["type"]))
            senum = [str(v) for v in el["detail"].get("enum", [])]; cenum = cdef.get("constraints", {}).get("values")
            if cdef["type"] == "ENUM":
                if transform["kind"] == "ENUM_MAP":
                    m = transform.get("parameters", {}).get("map", {})
                    if senum and not set(senum) <= set(map(str, m)): problems.append("enum map does not cover source values %s" % sorted(set(senum) - set(map(str, m))))
                    if not set(m.values()) <= set(cenum or []): problems.append("enum map targets values outside the canonical enum")
                elif not (senum and set(senum) == set(cenum or [])): problems.append("an enum needs a covering ENUM_MAP")
        return {"passed": not problems, "ambiguous": bool(alternatives), "problems": problems}
class AIMappingService:
    def __init__(self, proposer, model, ids): self.proposer, self.model, self.ids, self.validator, self.reports = proposer, model, ids, MappingValidator(model), {}
    def propose(self, record):
        fields = [{"name": UntrustedText(e["name"]), "detail": {k: (UntrustedText(v) if isinstance(v, str) else v) for k, v in e["detail"].items()}} for e in record["elements"] if e["element_kind"] == "FIELD"]
        flags = [str(f["name"]) for f in fields if any(instruction_like(v) for v in f["detail"].values() if isinstance(v, str))]
        canon = {c: sorted(self.model.attributes(c)) for c in self.model.concepts}; out = {"candidates": [], "rejected": [], "flags": [], "instruction_like_fields": flags}
        try: props = self.proposer.propose(ProposerSandbox(fields, canon))
        except Exception as e: out["flags"].append("proposer failed (%s); no candidates" % type(e).__name__); return out        # a failing or hostile AI must not break the build
        for p in props:
            if p.get("claimed_state") in ("VALIDATED", "TRUSTED"): out["flags"].append("claimed state %s discarded for %s" % (p["claimed_state"], p.get("source_ref")))
            r = self.validator.check(p.get("source_ref", ""), p.get("canonical_ref", ""), p.get("transform", {}), p.get("alternatives", []), record)
            if not r["passed"]: out["rejected"].append({"proposal": p.get("source_ref"), "problems": r["problems"]}); continue
            mid = "ai-%s" % sha([p["source_ref"], p["canonical_ref"]])[:10]
            m = {"mapping_id": mid, "kind": "FIELD", "source_ref": p["source_ref"], "canonical_ref": p["canonical_ref"], "mapping_state": "AMBIGUOUS" if r["ambiguous"] else "CANDIDATE", "proposed_by": "AI_ASSISTED", "inbound": {"source_type": "string", "canonical_type": "STRING", "transform": dict(p["transform"], deterministic=True)}, "outbound": {"supported": False, "reason": "AI-proposed mapping is inbound-only until promoted"}}
            if r["ambiguous"]: m["ambiguity"] = {"candidate_meanings": [p["canonical_ref"]] + [str(a) for a in p["alternatives"]], "resolution_required": True}
            out["candidates"].append(m)
        return out
    def promote(self, mapping, record):
        if mapping["mapping_state"] == "AMBIGUOUS": raise PromotionRefused("an ambiguous mapping cannot be promoted without resolution evidence")
        r = self.validator.check(mapping["source_ref"], mapping["canonical_ref"], mapping["inbound"]["transform"], [], record)
        if not r["passed"]: raise PromotionRefused("; ".join(r["problems"]))
        ev = evidence("mapping-validation", {"mapping": mapping["mapping_id"], "source": mapping["source_ref"], "canonical": mapping["canonical_ref"], "transform": mapping["inbound"]["transform"], "report": r}, "val-" + mapping["mapping_id"]); self.reports[ev["evidence_id"]] = ev["evidence_hash"]
        return dict(mapping, mapping_state="VALIDATED", deterministic_validation_performed=True, validation_ref=ev)
    def resolve_ambiguity(self, mapping, chosen_canonical_ref, resolution_evidence):
        if not resolution_evidence or not resolution_evidence.get("evidence_id") or not resolution_evidence.get("evidence_hash"): raise PromotionRefused("ambiguity resolution requires evidence")
        if chosen_canonical_ref not in mapping["ambiguity"]["candidate_meanings"]: raise PromotionRefused("the chosen meaning is not one of the candidates")
        m = {k: v for k, v in mapping.items() if k != "ambiguity"}; m.update(mapping_state="CANDIDATE", canonical_ref=chosen_canonical_ref); return m
    def verify_promotion(self, mapping): return mapping.get("validation_ref", {}).get("evidence_id") in self.reports and self.reports[mapping["validation_ref"]["evidence_id"]] == mapping["validation_ref"].get("evidence_hash")

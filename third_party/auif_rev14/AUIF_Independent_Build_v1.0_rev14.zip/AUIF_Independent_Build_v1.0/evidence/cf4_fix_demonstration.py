"""CF-4 FIX DEMONSTRATION (rev10). The same crash as evidence/cf4_reproduction.py (between the durable ACKNOWLEDGED and COMPLETED), resolved by the new ActionService.recover_stale_acknowledged.
It shows, with counts: the effect exists once before and after; no write is sent; no lookup is made; no new Governor decision is requested; the record ends COMPLETED/APPLIED with its external reference intact.
Run from the package root: python3 evidence/cf4_fix_demonstration.py   (read-only; uses the core test world)"""
import os, sys
sys.dont_write_bytecode = True; ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
from tests.test_action_flow import ActBase, mk_action
class Crash(Exception): pass
class W(ActBase):
    def runTest(self): pass
for governed in (False, True):
    x = W(); x.setUp(); x.svc.submit(x.ctx, mk_action(1, governed=governed)); led = x.svc.ledger; orig = led.transition; done = []
    def boom(ctx, a, state, **kw):
        if state == "COMPLETED" and not done: done.append(1); raise Crash()
        return orig(ctx, a, state, **kw)
    led.transition = boom
    try: x.svc.dispatch(x.ctx, "act-0001")
    except Crash: pass
    led.transition = orig; calls = []; rt_call = x.rt.call
    def spy(*a, **k): calls.append(a[4] if len(a) > 4 else k.get("method")); return rt_call(*a, **k)
    x.rt.call = spy; decisions = len(x.gov.decisions); before = led.get(x.ctx, "act-0001")
    print("governed=%s after the crash: state=%s effects=%d external_reference=%s decisions=%d" % (governed, before["execution_state"], len(x.sysA.effects), before["external_reference"], decisions))
    x.e.clock.sleep(99999); r = x.svc.recover_stale_acknowledged(x.ctx, 3600); after = led.get(x.ctx, "act-0001")
    print("             after recover_stale_acknowledged: state=%s result=%s effects=%d external_reference=%s decisions=%d target_calls=%s sweep=%s" % (after["execution_state"], after["result"], len(x.sysA.effects), after["external_reference"], len(x.gov.decisions), calls, r))
    assert (after["execution_state"], len(x.sysA.effects), len(x.gov.decisions), calls) == ("COMPLETED", 1, decisions, []) and after["external_reference"] == before["external_reference"]
print("=> the stranded action is COMPLETED with the effect still exactly once, nothing sent, no lookup, and no new Governor decision.")

"""The SYNTHETIC end-to-end proving environment: 2 tenants, 2 modules, 3 external systems per tenant (REST-like, relational, event-driven), 3 connector types, packs, a Governor double and a policy double.
None of this is the Anchor Engine; it exercises the real AUIF core through its ports."""
from auif.canonical import CanonicalModel
from auif.clock import FakeClock
from auif.discovery import fingerprint
from auif.fabric import Fabric
from auif.observability import Telemetry
from auif.tenancy import TenantAuthority, TenantScopedPersistence
from auif.throttle import Throttle
from auif.translation import PackRegistry
from auif.util import Ids
from auif_ref.persistence import MemoryPersistence, SqlitePersistence
from auif_ref.secrets import InMemorySecretStore
from synthetic.connectors import SyntheticRestConnector, SyntheticDatabaseConnector, SyntheticEventConnector
from synthetic.governor_double import GovernorDouble
from synthetic.modules import module_one, module_two
from synthetic.packs import MODEL_DEF, pack_a, pack_b, pack_c
from synthetic.policy import SyntheticPolicy
from synthetic.systems import SystemA, SystemB, SystemC
def ref(p): return {"id": p["pack_id"], "version": p["pack_version"], "hash": p["artifact_hash"]}
class World:
    def __init__(self, persistence="memory", sequencer_policy=None):
        self.clock, self.ids, self.tel, self.auth, self.secrets, self.gov, self.policy = FakeClock(), Ids(), Telemetry(), TenantAuthority(), InMemorySecretStore(), GovernorDouble(), SyntheticPolicy()
        self.store = TenantScopedPersistence(MemoryPersistence() if persistence == "memory" else SqlitePersistence(), self.auth); self.th = Throttle(self.clock, default_rate=1000, default_burst=1000); self.model = CanonicalModel(MODEL_DEF); self.packs = PackRegistry()
        self.fabric = Fabric(store=self.store, authority=self.auth, secrets=self.secrets, governor=self.gov, policy=self.policy, clock=self.clock, telemetry=self.tel, ids=self.ids, model=self.model, pack_registry=self.packs, throttle=self.th, sequencer_policy=sequencer_policy)
        self.m1, self.m2 = module_one(), module_two(); self.fabric.register_module(self.m1); self.fabric.register_module(self.m2); self.ctx = {t: self.auth.issue(t, "svc-" + t) for t in ("tenant-a", "tenant-b")}; self.sys = {}
        fa, fb, fc = (fingerprint(s.metadata())["value"] for s in (SystemA(), SystemB(), SystemC())); self.pA, self.pB, self.pC = pack_a([fa]), pack_b([fb]), pack_c([fc]); self.pA2, self.pAamb = pack_a([fa], "v2"), pack_a([fa], "ambiguous")
        for p in (self.pA, self.pB, self.pC, self.pA2, self.pAamb): self.packs.register(p)
        self.integrations = {}
        for t, suffix in (("tenant-a", "a"), ("tenant-b", "b")):
            ctx = self.ctx[t]; sa, sb, sc = SystemA(secret="rest-secret-" + t), SystemB(secret="db-secret-" + t), SystemC(secret="evt-secret-" + t); self.sys[t] = {"A": sa, "B": sb, "C": sc}
            if t == "tenant-b":
                for i, r in sa.rows["Account"].items(): r["profile"]["name"] = "TenantB Account %s" % i
            for k, v in (("rest", sa.secret), ("db", sb.secret), ("evt", sc.secret)): self.secrets.put(t, "secretref:synthetic/%s" % k, v)
            self.integrations[(t, "rest")] = self.fabric.add_integration(ctx, integration_id="i%s-rest" % suffix, anchor_module="synthetic-module-1", connector=SyntheticRestConnector(sa, "secretref:synthetic/rest"), pack_ref=ref(self.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", governed_operations=["updateAccount"], entities=["Account", "Property"], id_fields={"*": "id"})
            self.integrations[(t, "db")] = self.fabric.add_integration(ctx, integration_id="i%s-db" % suffix, anchor_module="synthetic-module-1", connector=SyntheticDatabaseConnector(sb, "secretref:synthetic/db"), pack_ref=ref(self.pB), target_system_id="synthetic-system-b", environment_id="env-sandbox", entities=["customers"], id_fields={"customers": "cust_id"})
            self.integrations[(t, "evt")] = self.fabric.add_integration(ctx, integration_id="i%s-evt" % suffix, anchor_module="synthetic-module-2", connector=SyntheticEventConnector(sc, "secretref:synthetic/evt"), pack_ref=ref(self.pC), target_system_id="synthetic-system-c", environment_id="env-sandbox", entities=["Ticket"], id_fields={"*": "id"})
    def activate_all(self): return {k: c.activate() for k, c in self.integrations.items()}

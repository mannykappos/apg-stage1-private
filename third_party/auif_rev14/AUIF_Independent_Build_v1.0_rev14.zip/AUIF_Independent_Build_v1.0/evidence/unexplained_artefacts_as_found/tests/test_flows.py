import unittest
from tests.helpers import Env, ActionEnv
from auif.action import ACTION_TRANSITIONS, Ledger
from auif.classification import BoundaryEnforcer
from auif.contracts import validate
from auif.errors import *
from auif.observation import ObservationFactory, Sequencer
from auif.security import scan_for
from auif.util import Ids
from synthetic.policy import SyntheticPolicy
def ev(i, deps=(), seq=None, payload=None, t="ticket.updated"):
    e = {"event_id": i, "type": t, "payload": payload or {"id": i}, "depends_on": list(deps)}
    if seq is not None: e["source_sequence"] = seq
    return e
class TestSequencer(unittest.TestCase):
    def setUp(self): self.e = Env(); self.sq = Sequencer(self.e.store, self.e.clock)
    def states(self, ds): return [(d["event"]["event_id"], d["ordering_state"]) for d in ds]
    def test_in_order_events_apply_with_increasing_adapter_sequence(self):
        a = self.sq.receive(self.e.A, "i", ev("e1")); b = self.sq.receive(self.e.A, "i", ev("e2", ["e1"])); self.assertEqual(self.states(a + b), [("e1", "IN_ORDER"), ("e2", "IN_ORDER")]); self.assertLess(a[0]["adapter_sequence"], b[0]["adapter_sequence"])
    def test_AT_09_duplicate_is_suppressed_without_a_second_application(self):
        self.sq.receive(self.e.A, "i", ev("e1")); d = self.sq.receive(self.e.A, "i", ev("e1")); self.assertEqual(self.states(d), [("e1", "DUPLICATE_SUPPRESSED")]); self.assertEqual(len(self.e.store.list(self.e.A, "seq_applied:i")), 1)
    def test_AT_09_same_id_different_content_is_a_conflict_and_does_not_overwrite(self):
        self.sq.receive(self.e.A, "i", ev("e1", payload={"v": 1})); d = self.sq.receive(self.e.A, "i", ev("e1", payload={"v": 2})); self.assertEqual(d[0]["ordering_state"], "RECONCILIATION_PENDING"); self.assertTrue(d[0]["conflict"]); self.assertEqual(len(self.e.store.list(self.e.A, "seq_conflicts:i")), 1)
    def test_AT_10_out_of_order_event_is_queued_and_released_in_causal_order(self):
        a = self.sq.receive(self.e.A, "i", ev("e2", ["e1"])); self.assertEqual(self.states(a), [("e2", "QUEUED_AWAITING_PREDECESSOR")]); self.assertEqual(a[0]["waiting_on"], ["e1"])
        b = self.sq.receive(self.e.A, "i", ev("e1")); self.assertEqual(self.states(b), [("e1", "IN_ORDER"), ("e2", "IN_ORDER")]); self.assertEqual(self.sq.pending(self.e.A, "i"), [])
    def test_AT_10_causal_chain_resolves_regardless_of_arrival_order(self):
        for e in (ev("e3", ["e2"]), ev("e2", ["e1"])): self.sq.receive(self.e.A, "i", e)
        self.assertEqual(self.states(self.sq.receive(self.e.A, "i", ev("e1"))), [("e1", "IN_ORDER"), ("e2", "IN_ORDER"), ("e3", "IN_ORDER")])
    def test_source_sequence_gap_waits_for_the_missing_number(self):
        self.sq.receive(self.e.A, "i", ev("a", seq=1)); d = self.sq.receive(self.e.A, "i", ev("c", seq=3)); self.assertEqual(d[0]["ordering_state"], "QUEUED_AWAITING_PREDECESSOR"); self.assertEqual(d[0]["waiting_on"], ["seq:2"])
        self.assertEqual(self.states(self.sq.receive(self.e.A, "i", ev("b", seq=2))), [("b", "IN_ORDER"), ("c", "IN_ORDER")])
    def test_AT_10_misleading_timestamps_do_not_decide_order(self):
        late = dict(ev("e2", ["e1"]), observed_at="2020-01-01T00:00:00Z"); early = dict(ev("e1"), observed_at="2030-01-01T00:00:00Z"); self.assertEqual(self.sq.receive(self.e.A, "i", late)[0]["ordering_state"], "QUEUED_AWAITING_PREDECESSOR"); self.assertEqual(self.states(self.sq.receive(self.e.A, "i", early)), [("e1", "IN_ORDER"), ("e2", "IN_ORDER")])
    def test_AT_10_bounded_wait_expires_to_reconciliation_and_never_fabricates_state(self):
        self.sq.receive(self.e.A, "i", ev("e2", ["e1"])); self.assertEqual(self.sq.tick(self.e.A, "i"), []); self.e.clock.sleep(61); d = self.sq.tick(self.e.A, "i"); self.assertEqual(self.states(d), [("e2", "RECONCILIATION_PENDING")])
        self.assertEqual(len(self.e.store.list(self.e.A, "seq_reconcile:i")), 1); self.assertIsNone(self.e.store.get(self.e.A, "seq_applied:i", "e2")); self.assertEqual(self.sq.pending(self.e.A, "i"), [])
    def test_missing_predecessor_policies_reject_defer_reconcile(self):
        for pol, want in (("REJECT", "REJECTED_BY_POLICY"), ("DEFER", "DEFERRED"), ("RECONCILE", "RECONCILIATION_PENDING")):
            e = Env(); sq = Sequencer(e.store, e.clock, {"*": {"on_missing": pol}}); self.assertEqual(sq.receive(e.A, "i", ev("x", ["gone"]))[0]["ordering_state"], want); self.assertIsNone(e.store.get(e.A, "seq_applied:i", "x"))
    def test_deferred_events_never_expire_into_state(self):
        sq = Sequencer(self.e.store, self.e.clock, {"*": {"on_missing": "DEFER"}}); sq.receive(self.e.A, "i", ev("x", ["gone"])); self.e.clock.sleep(10 ** 6); self.assertEqual(sq.tick(self.e.A, "i"), [])
    def test_sequencer_state_is_tenant_scoped(self):
        self.sq.receive(self.e.A, "i", ev("e1")); self.assertEqual(self.sq.receive(self.e.B, "i", ev("e1"))[0]["ordering_state"], "IN_ORDER")
class TestObservationFactory(unittest.TestCase):
    def test_observation_is_contract_valid_and_adapter_sequence_is_per_tenant_and_integration(self):
        e = Env(); f = ObservationFactory(e.store, Ids(), e.clock); kw = dict(anchor_module="m", target_system_id="t", environment_id="env", connector_id="c", source_system="s", source_object={"object_type": "X", "object_id": "1"}, source_version=None, pack_ref={"id": "p", "version": "1.0.0"}, schema_fingerprint="f" * 64, payload={"a": 1}, classification="INTERNAL", confidence={"value": 1.0, "basis": "deterministic"}, provenance=[{"step_kind": "SOURCE_SYSTEM", "ref": "s"}])
        a = f.build(e.A, "i1", **kw); b = f.build(e.A, "i1", **kw); c = f.build(e.B, "i1", **kw); self.assertEqual((a["adapter_sequence"], b["adapter_sequence"], c["adapter_sequence"]), (1, 2, 1)); self.assertEqual(a["source_version"], "NOT_PROVIDED_BY_SOURCE")
class TestBoundary(unittest.TestCase):
    def setUp(self): self.e = Env(); self.b = BoundaryEnforcer(SyntheticPolicy())
    def run_(self, attrs, classes, kind): return self.b.enforce(self.e.A, attrs, classes, {"kind": kind}, {})
    def test_AT_21_outcome_depends_on_classification_and_destination(self):
        a, c = {"name": "Ann", "email": "ann@example.invalid"}, {"name": "INTERNAL", "email": "PII"}
        self.assertEqual(self.run_(a, c, "customer-system")["decision"], "ALLOW"); r = self.run_(a, c, "third-party-analytics"); self.assertEqual(r["decision"], "TRANSFORMED"); self.assertNotEqual(r["payload"]["email"], "ann@example.invalid"); self.assertEqual(r["payload"]["name"], "Ann")
    def test_AT_21_blocked_and_authorisation_required_and_undeterminable(self):
        self.assertEqual(self.run_({"b": "1"}, {"b": "FINANCIAL"}, "third-party-analytics")["decision"], "REJECTED"); self.assertEqual(self.run_({"h": "x"}, {"h": "HEALTH"}, "customer-system")["decision"], "NEEDS_AUTHORISATION")
        r = self.run_({"x": "1"}, {"x": "x-custom-class"}, "customer-system"); self.assertEqual(r["decision"], "REJECTED"); self.assertEqual(r["evidence"][0]["outcome"], "UNDETERMINABLE")
        self.assertEqual(self.run_({"x": "1"}, {"x": "PII"}, "unknown-destination")["decision"], "REJECTED")
    def test_one_rejected_attribute_rejects_the_whole_payload(self): r = self.run_({"n": "a", "b": "1"}, {"n": "INTERNAL", "b": "REGULATED"}, "customer-system"); self.assertEqual(r["decision"], "REJECTED"); self.assertIsNone(r["payload"])
    def test_evidence_contains_no_values_and_transforms_are_deterministic(self):
        a = self.run_({"email": "secret@example.invalid"}, {"email": "PII"}, "third-party-analytics"); b = self.run_({"email": "secret@example.invalid"}, {"email": "PII"}, "third-party-analytics"); self.assertEqual(a, b); self.assertEqual(scan_for(a["evidence"], ["secret@example.invalid"]), [])
    def test_all_transforms(self):
        e = Env()
        for name, want in (("mask", "*" * 8 + "ue"), ("redact", "[REDACTED]")):
            class P(SyntheticPolicy):
                def decide(s, ctx, c, d, x): return {"outcome": "TRANSFORM", "transforms": [name]}
            self.assertEqual(BoundaryEnforcer(P()).enforce(e.A, {"v": "0123456789"[:8] + "ue"}, {"v": "PII"}, {"kind": "k"})["payload"]["v"], want)
        class O(SyntheticPolicy):
            def decide(s, ctx, c, d, x): return {"outcome": "TRANSFORM", "transforms": ["omit"]}
        self.assertEqual(BoundaryEnforcer(O()).enforce(e.A, {"v": "x"}, {"v": "PII"}, {"kind": "k"})["payload"], {})
        class Q(SyntheticPolicy):
            def decide(s, ctx, c, d, x): return {"outcome": "TRANSFORM", "transforms": ["pseudonymise"]}
        p1 = BoundaryEnforcer(Q()).enforce(e.A, {"v": "x"}, {"v": "PII"}, {"kind": "k"})["payload"]["v"]; p2 = BoundaryEnforcer(Q()).enforce(e.B, {"v": "x"}, {"v": "PII"}, {"kind": "k"})["payload"]["v"]; self.assertNotEqual(p1, p2)       # pseudonyms are tenant-scoped
class TestActionLedger(unittest.TestCase):
    def setUp(self): self.x = ActionEnv(); self.A = self.x.A
    def effects(self): return len(self.x.sysA.effects)
    def run_(self, n, **kw): a = self.x.action(n, **kw); self.x.svc.submit(self.A, a); return self.x.svc.dispatch(self.A, a["action_id"])
    def test_non_governed_action_completes_exactly_once_through_the_full_state_path(self):
        seen = []; real = self.x.sysA.update
        def spy(entity, rid, changes, key): seen.append(self.x.svc.ledger.get(self.A, "act-0001")["execution_state"]); return real(entity, rid, changes, key)
        self.x.sysA.update = spy; r = self.run_(1); self.assertEqual(r["execution_state"], "COMPLETED"); self.assertEqual(seen, ["SENT"]); self.assertEqual(self.effects(), 1); self.assertEqual(self.x.sysA.rows["Account"]["3"]["status"], "sus")
        self.assertEqual(r["outbound_validation"]["validation_result"], "PASSED"); self.assertEqual(self.x.gov.decisions, []); validate("action#ActionExecutionRecord", r)
    def test_AT_11_duplicate_submission_returns_the_same_record_and_one_effect(self):
        a = self.x.action(1); r1 = self.x.svc.submit(self.A, a); r2 = self.x.svc.submit(self.A, a); self.assertEqual(r1["action_id"], r2["action_id"]); self.x.svc.dispatch(self.A, "act-0001"); self.x.svc.dispatch(self.A, "act-0001"); self.assertEqual(self.effects(), 1)
        other = self.x.action(2, key="idem-0001-xyz"); other["canonical_action"]["payload"]["attributes"] = {"lifecycle_state": "ARCHIVED"}
        with self.assertRaises(AuifError): self.x.svc.submit(self.A, other)
    def test_AT_11_unknown_outcome_is_never_blindly_retried(self):
        self.x.sysA.faults.push("write", ("timeout_after_apply",)); r = self.run_(1); self.assertEqual(r["execution_state"], "UNKNOWN_OUTCOME"); self.assertFalse(r["reconciliation"]["blind_retry_permitted"]); self.assertEqual(r["reconciliation"]["strategy"], "QUERY_EXTERNAL_BY_IDEMPOTENCY_KEY")
        self.assertEqual(self.x.svc.dispatch(self.A, "act-0001")["execution_state"], "UNKNOWN_OUTCOME"); self.assertEqual(self.effects(), 1)
        with self.assertRaises(IllegalTransition): self.x.svc.ledger.transition(self.A, "act-0001", "SENT")
    def test_AT_11_reconciliation_finds_the_applied_action_without_a_second_effect(self):
        self.x.sysA.faults.push("write", ("timeout_after_apply",)); self.run_(1); r = self.x.svc.reconcile(self.A, "act-0001"); self.assertEqual(r["execution_state"], "COMPLETED"); self.assertEqual(r["result"]["outcome"], "APPLIED_CONFIRMED_BY_RECONCILIATION"); self.assertNotIn("error", r); self.assertEqual(self.effects(), 1)
    def test_AT_11_reconciliation_when_target_never_applied_fails_without_resending(self):
        self.x.sysA.faults.push("write", ("timeout_before",)); r = self.run_(1); self.assertEqual(r["execution_state"], "UNKNOWN_OUTCOME"); r = self.x.svc.reconcile(self.A, "act-0001"); self.assertEqual(r["execution_state"], "FAILED"); self.assertEqual(self.effects(), 0)
        self.assertEqual(self.run_(2, key="idem-0002-new")["execution_state"], "COMPLETED"); self.assertEqual(self.effects(), 1)       # a NEW action with a new key is the only way to try again
    def test_AT_11_operator_review_path_for_connectors_without_lookup(self):
        h = self.x.handle; h.runtime.desc["idempotency"] = dict(h.runtime.desc["idempotency"], outcome_reconciliation_supported=False); self.x.sysA.faults.push("write", ("timeout_after_apply",)); r = self.run_(1); self.assertEqual(r["reconciliation"]["strategy"], "OPERATOR_REVIEW")
        self.assertEqual(self.x.svc.reconcile(self.A, "act-0001")["execution_state"], "RECONCILIATION_REQUIRED")
        with self.assertRaises(IllegalTransition): self.x.svc.operator_resolve(self.A, "act-9999", True, {"evidence_id": "e", "evidence_hash": "0" * 64}) if False else self.x.svc.ledger.transition(self.A, "act-0001", "SENT")
        r = self.x.svc.operator_resolve(self.A, "act-0001", True, {"evidence_id": "ev-ops-1", "evidence_hash": "0" * 64}); self.assertEqual(r["execution_state"], "COMPLETED")
    def test_rate_limit_is_retried_inside_the_runtime_with_one_effect(self):
        self.x.sysA.faults.push("write", ("429", 2.0)); r = self.run_(1); self.assertEqual(r["execution_state"], "COMPLETED"); self.assertEqual(r["attempt_count"], 2); self.assertEqual(self.effects(), 1)
    def test_definitive_target_rejection_is_failed_not_unknown(self):
        self.x.sysA.faults.push("write", ("reject",)); r = self.run_(1); self.assertEqual(r["execution_state"], "FAILED"); self.assertEqual(r["error"]["code"], "TARGET_REJECTED_REQUEST"); self.assertEqual(self.effects(), 0)
    def test_AT_13_unknown_governance_requirement_is_held_and_never_sent(self):
        a = self.x.action(1, governed="UNKNOWN"); self.x.svc.submit(self.A, a)
        with self.assertRaises(GovernanceHold): self.x.svc.dispatch(self.A, "act-0001")
        self.assertEqual(self.x.svc.ledger.get(self.A, "act-0001")["execution_state"], "QUEUED"); self.assertEqual(self.effects(), 0); self.assertEqual(self.x.gov.decisions, [])
        self.x.svc.supply_governance_requirement(self.A, "act-0001", False, "MODULE_DECLARED"); self.assertEqual(self.x.svc.dispatch(self.A, "act-0001")["execution_state"], "COMPLETED")
        with self.assertRaises(AuifError): self.x.svc.supply_governance_requirement(self.A, "act-0001", False, "AUIF_GUESS")
    def test_AT_13_governed_action_carries_governor_decision_ref_and_hash_into_the_ledger(self):
        r = self.run_(1, governed=True); self.assertEqual(r["execution_state"], "COMPLETED"); g = r["governance"]; self.assertEqual(g["governor_decision_ref"], "gov-dec-0001"); self.assertEqual(len(g["governor_decision_hash"]), 64); self.assertEqual(len(self.x.gov.decisions), 1)
    def test_AT_13_governed_action_without_a_grant_is_never_sent(self):
        self.x.gov.deny.add("synthetic.update_party"); r = self.run_(1, governed=True); self.assertEqual(r["execution_state"], "FAILED"); self.assertIn("governance decision denied", r["error"]["message_redacted"]); self.assertEqual(self.effects(), 0)
        for n, (setter, why) in enumerate(((lambda: (self.x.gov.deny.clear(), self.x.gov.pending.add("synthetic.update_party")), "PENDING"), (lambda: (self.x.gov.pending.clear(), setattr(self.x.gov, "unavailable", True)), "UNAVAILABLE")), start=2):
            setter(); a = self.x.action(n); a["governance"]["governance_required"] = True; self.x.svc.submit(self.A, a)
            with self.assertRaises(GovernanceHold): self.x.svc.dispatch(self.A, a["action_id"])
            self.assertEqual(self.x.svc.ledger.get(self.A, a["action_id"])["execution_state"], "QUEUED"); self.assertEqual(self.effects(), 0)
        self.x.gov.unavailable = False; self.x.gov.pending.clear(); self.assertEqual(self.x.svc.dispatch(self.A, "act-0003")["execution_state"], "COMPLETED"); self.assertEqual(self.effects(), 1)
    def test_AT_13_malformed_grant_is_not_accepted(self):
        self.x.gov.request_decision = lambda ctx, req: {"status": "GRANTED"}; a = self.x.action(1, governed=True); self.x.svc.submit(self.A, a)
        with self.assertRaises(AuifError): self.x.svc.dispatch(self.A, "act-0001")
        self.assertEqual(self.effects(), 0)
    def test_AT_13_a_module_cannot_smuggle_in_a_decision_reference(self):
        self.x.gov.deny.add("synthetic.update_party"); a = self.x.action(1, governed=True, decision_ref="forged-decision-1"); rec = self.x.svc.submit(self.A, a); self.assertIsNone(rec["governance"]["governor_decision_ref"])
        self.assertEqual(self.x.svc.dispatch(self.A, "act-0001")["execution_state"], "FAILED"); self.assertEqual(self.effects(), 0); self.assertIn("IGNORED_SUPPLIED_DECISION_REF", [e["kind"] for e in self.x.svc.ledger.events(self.A, "act-0001")])
    def test_AT_13_there_is_no_way_for_auif_to_grant_authorisation(self):
        names = [n for n in dir(self.x.svc) if not n.startswith("_")]; self.assertFalse([n for n in names if any(w in n.lower() for w in ("grant", "authoris", "authoriz", "approve", "issue_decision", "cpt")) and n != "supply_governance_requirement"])
    def test_AT_21_boundary_rejection_blocks_before_send(self):
        self.x.handle.destination_kind = "third-party-analytics"; r = self.run_(1, attrs={"balance": "10.00"}); self.assertEqual(r["execution_state"], "FAILED"); self.assertIn("data boundary", r["error"]["message_redacted"]); self.assertEqual(self.effects(), 0)
    def test_AT_21_policy_requiring_authorisation_routes_to_the_governor_even_if_the_module_said_ungoverned(self):
        class P(SyntheticPolicy):
            def decide(s, ctx, c, d, x): return {"outcome": "NEEDS_AUTHORISATION"} if c == "PII" else {"outcome": "ALLOW"}
        self.x.svc.boundary.policy = P(); r = self.run_(1, attrs={"contact_email": "new@example.invalid"}, governed=False); self.assertEqual(r["execution_state"], "COMPLETED"); self.assertEqual(r["governance"]["governor_decision_ref"], "gov-dec-0001"); self.assertEqual(len(self.x.gov.decisions), 1)
    def test_AT_04_outbound_violation_is_refused_and_recorded_before_any_send(self):
        r = self.run_(1, attrs={"contact_email": "not-an-email"}); self.assertEqual(r["execution_state"], "FAILED"); self.assertEqual(r["outbound_validation"]["validation_result"], "FAILED"); self.assertEqual(self.effects(), 0)
    def test_integration_not_allowing_the_operation_holds_the_action(self):
        self.x.allowed = False; a = self.x.action(1); self.x.svc.submit(self.A, a)
        with self.assertRaises(GovernanceHold): self.x.svc.dispatch(self.A, "act-0001")
        self.assertEqual(self.effects(), 0); self.x.allowed = True; self.assertEqual(self.x.svc.dispatch(self.A, "act-0001")["execution_state"], "COMPLETED")
    def test_ledger_transition_table_rejects_every_unlisted_transition(self):
        states = ["CREATED", "QUEUED", "SENT", "ACKNOWLEDGED", "COMPLETED", "FAILED", "UNKNOWN_OUTCOME", "RECONCILIATION_REQUIRED"]
        self.assertNotIn(("UNKNOWN_OUTCOME", "SENT"), ACTION_TRANSITIONS); self.assertNotIn(("FAILED", "QUEUED"), ACTION_TRANSITIONS); self.assertNotIn(("COMPLETED", "SENT"), ACTION_TRANSITIONS); self.assertNotIn(("SENT", "QUEUED"), ACTION_TRANSITIONS)
        self.assertEqual(sorted(t for t in ACTION_TRANSITIONS if t[0] in ("COMPLETED", "FAILED")), [])                    # terminal states have no exits
        self.assertTrue(all(a in states and b in states for a, b in ACTION_TRANSITIONS))
    def test_terminal_record_is_immutable_and_contract_violation_rolls_back(self):
        self.run_(1)
        with self.assertRaises(IllegalTransition): self.x.svc.ledger.patch(self.A, "act-0001", attempt_count=9)
        self.x.sysA.faults.push("write", ("timeout_after_apply",)); self.run_(2, key="idem-0002-b")
        with self.assertRaises(ContractViolation): self.x.svc.ledger.transition(self.A, "act-0002", "RECONCILIATION_REQUIRED", completed_at="not-a-timestamp")
        self.assertEqual(self.x.svc.ledger.get(self.A, "act-0002")["execution_state"], "UNKNOWN_OUTCOME")
    def test_tenant_isolation_of_actions_and_idempotency_keys(self):
        self.run_(1); B = self.x.B
        with self.assertRaises(NotFound): self.x.svc.ledger.get(B, "act-0001")
        b = self.x.action(1, ctx=B); self.assertEqual(self.x.svc.submit(B, b)["tenant_id"], "tenant-b")      # the same key in another tenant is a different action
    def test_no_payload_or_secret_content_in_telemetry_or_ledger(self):
        self.run_(1, attrs={"contact_email": "pii-sentinel@example.invalid"}); self.assertEqual(scan_for(self.x.tel.events, ["pii-sentinel"]), []); self.assertEqual(scan_for(self.x.svc.ledger.get(self.A, "act-0001"), ["pii-sentinel", "client-secret-A"]), [])

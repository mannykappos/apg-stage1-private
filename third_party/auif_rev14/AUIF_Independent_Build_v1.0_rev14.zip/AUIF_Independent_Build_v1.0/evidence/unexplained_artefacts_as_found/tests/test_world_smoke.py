import unittest
from synthetic.world import World
class Smoke(unittest.TestCase):
    def test_world_activates_and_syncs(self):
        w = World(); states = w.activate_all(); print(states); a = w.ctx["tenant-a"]; r = w.fabric.sync(a, "ia-rest", "Account"); print(r["pages"], [x["state"] for x in r["records"]]); self.assertTrue(all(s == "ACTIVE" for s in states.values()))

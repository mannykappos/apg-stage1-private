# Unexplained workspace artefacts: status record

**Facts.** During the build, files appeared in this tree that the executor of this report did not write, at times between its own tool calls. At 04:46:56 UTC a process list showed `python3 tools/mutation_test.py` and six `unittest discover` processes that the executor had not started; no process was running ~3.5 minutes later and none has been seen since. The owner stated they started only one executor. The origin of the files is **not established**; this record does not guess it. No evidence of remote access was found (no SSH or listening network services in the sandbox).

**Preservation.** A full tree snapshot was taken before any further work: `AUIF_tree_snapshot_045133.tar.gz`, SHA-256 `34d96dd6ab4ad69d37ca50c53f20b934eb7d0f3b118c341d023550222397a2fa` (in the outputs folder, outside the build). Copies of the earliest unexplained files and of the other writer's saved mutation results are in `evidence/unexplained_artefacts_2026-10-02/` with `SHA256SUMS.txt`. Nothing was deleted or overwritten without a copy.

**What was done with them.** Preserve, inspect, test for compatibility, keep what is compatible, record status. Review performed by this executor:

| Check | Result |
|---|---|
| Pattern scan of all project code for network access, `eval`/`exec`/`os.system`, pickle/base64, `ctypes`, remote-access tooling | None found. `__import__` is used only to import `synthetic.connectors` in tests. |
| File deletion and writes | Only in temporary directories created by the code itself (`tempfile.mkdtemp`): the mutation tool and one meta-test that writes a deliberate "evil" file into a temp copy to prove the static checker detects violations. |
| Environment reads | One: `AUIF_BINDINGS_MODULE`, an optional test-world hook that imports a named module so a real persistence binding can be exercised. It is outside the core (`synthetic/world.py`) and is documented. |
| Audited inputs (`evidence/audited_inputs/*`) | Byte-identical to the audited package (`cmp`). |
| Compatibility | The full suite passes against the current core; static checks (import graph, forbidden tokens, authority-API names) are clean; the mutation harness was re-run by this executor, not trusted from the saved file. |
| Manual read of safety-critical edited core code | `auif/action.py` (submit/dispatch) and `auif/integration.py` (`_pack_gate`, mapping/validation phases) were read. Both are sound; `_pack_gate` closes a real gap in the executor's original design (version/pin checks ran only from the mapping phase, so a resumed integration could skip them). |
| **Not done** | Every line of every foreign-origin file was **not** read by hand. Assurance for those files rests on tests, mutation results, static analysis, coverage measurement and the targeted reads above, and on the independent audit that has still to be performed. |

## Status by artefact

| Artefact | Status |
|---|---|
| `tests/helpers.py` (extended with `ActionEnv`), `tests/test_flows.py` (39 tests) | KEPT as supplementary tests; pass; reviewed for hostile behaviour; counted in the totals. |
| `synthetic/modules.py`, `synthetic/ai_stub.py`, `synthetic/world.py` | KEPT; compatible with the core; test doubles outside the core. `world.py` was rewritten after first inspection (current version is the one in this package). |
| `tests/test_world_smoke.py` | Deleted by someone other than this executor before it could be copied. NOT restored; its purpose is covered by `tests/test_acceptance.py` and `tests/test_restart.py`. |
| `auif/action.py` (edited) | KEPT. Adds: discard and log of a module-supplied Governor decision reference (design decision D-1; tested by mutants M32/M33). |
| `auif/integration.py` (edited) | KEPT. Adds `_pack_gate` (guarded by M05, M35-M37). This executor later added `rehydrate()`. |
| `tests/test_acceptance.py`, `tests/acceptance_support.py`, `tests/test_port_contracts.py`, `tests/binding/` | KEPT. All AT-01..AT-30 represented (AT-16 shares a test with AT-02). AT-15 is a guard test asserting it is NOT claimed. |
| `tools/static_checks.py`, `tools/mutation_test.py`, `tools/gen_docs.py`, `tools/amir_items.py` | KEPT. Re-run independently. This executor extended the mutation list from 33 to 42 mutants. |
| `AMIR_ENGINE_DEPENDENCY_TODO.md/.json`, `UNRESOLVED_GOVERNOR_DECISIONS.md`, `docs/*`, `port_contracts/other_contracts.py`, `port_contracts/templates/*` | KEPT after review: 18 items, no empty field, no vague instruction, no asserted Engine fact; every referenced path exists (or is an output Amir creates). Governor decisions GD-01..05 are isolated, none resolved. |
| `evidence/audited_inputs/*` | KEPT; byte-identical to the audited package. |

**Independence caveat.** Because authorship of part of the tree is unestablished, "verified" in this package means *re-run and checked by the executor of this report*. It does not replace the independent audit, which has not yet been performed on this build.

> **Historical record.** This second pass was made during the original build, when the mutation harness defined 42 mutants. The current state (90 mutants, 90 killed) is in `evidence/mutation_results.json` and `BUILD_REPORT.md`.

# Second-pass verification (private copy)

Performed by the executor of this report before packaging, because part of the tree has unestablished authorship (see UNEXPLAINED_ARTEFACTS_STATUS.md). The tree was copied to a private directory outside the shared build folder and checked there; nothing in the shared tree was modified by these checks.

| Check | Result |
|---|---|
| Full suite | 259 run, 259 passed |
| Static checks (import graph, forbidden tokens, authority-API names) | clean; core tree sha256 `089afcbd2579c16e75f53be942f99471399820bbaa0d53b71e028d2fa36a8357` |
| Mutation harness re-run (not the saved file) | 42 mutants, 42 killed, 0 survived, 0 invalid |
| Audited inputs and the 10 contract files vs the audited package | byte-identical (`cmp`) |
| Core imports | standard library and `auif` only |
| Dangerous-pattern scan of the core (network, subprocess, eval/exec, pickle, ctypes, base64) | none |
| Remote-access check of the sandbox | no sshd, no listening ports |

Limits: this is a re-run by an executor, not an independent audit. Every line of every foreign-origin file was not read by hand.

## Correction made during packaging
The saved `evidence/mutation_results.json` recorded 41 mutants; the harness (`tools/mutation_test.py`, identical in both trees) defines 42, so the saved file predated mutant M42 (restart restoration). The file as found is kept as `evidence/mutation_results_as_found_41_stale.json`. `evidence/mutation_results.json` now holds the output of the full re-run (42 mutants, 42 killed, 0 survived) executed on a private copy with identical harness source and an identical core tree hash. ACCEPTANCE_RESULTS and BUILD_REPORT were regenerated from it.

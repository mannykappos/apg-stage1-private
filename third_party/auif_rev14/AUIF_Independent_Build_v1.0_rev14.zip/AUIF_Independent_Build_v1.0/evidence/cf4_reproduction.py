"""CF-4 REPRODUCTION (kept from rev9). On rev9 a crash between ACKNOWLEDGED and COMPLETED strands an action: the target has replied and the effect is confirmed, but the ledger stays ACKNOWLEDGED, and neither dispatch(), reconcile() nor the CF-2 sweep (recover_stale_sent, which handles SENT only) moves it.
In rev10 this script is unchanged and its output is unchanged: that is correct, because it deliberately uses only the rev9 calls. The fix is the NEW call `recover_stale_acknowledged`; see evidence/cf4_fix_demonstration.py for the same crash resolved by it.
Run from the package root: python3 evidence/cf4_reproduction.py   (read-only; uses the core test world)"""
import os, sys
sys.dont_write_bytecode = True; ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
from tests.test_action_flow import ActBase, mk_action
class Crash(Exception): pass
class W(ActBase):
    def runTest(self): pass
x = W(); x.setUp(); x.svc.submit(x.ctx, mk_action(1)); led = x.svc.ledger; orig = led.transition; done = []
def boom(ctx, a, state, **kw):
    if state == "COMPLETED" and not done: done.append(1); raise Crash()
    return orig(ctx, a, state, **kw)
led.transition = boom
try: x.svc.dispatch(x.ctx, "act-0001")
except Crash: pass
led.transition = orig; print("after the crash:         state=%s effects=%d external_reference=%s" % (x.state(1), len(x.sysA.effects), led.get(x.ctx, "act-0001").get("external_reference")))
x.svc.dispatch(x.ctx, "act-0001"); x.svc.reconcile(x.ctx, "act-0001"); x.e.clock.sleep(99999); r = x.svc.recover_stale_sent(x.ctx, 3600)
print("after dispatch, reconcile and the CF-2 sweep: state=%s effects=%d sweep=%s" % (x.state(1), len(x.sysA.effects), r))
print("=> the action is confirmed applied by the target's own reply but stays ACKNOWLEDGED (non-terminal) with no rev9 recovery path. (rev10 adds recover_stale_acknowledged; see evidence/cf4_fix_demonstration.py.)")

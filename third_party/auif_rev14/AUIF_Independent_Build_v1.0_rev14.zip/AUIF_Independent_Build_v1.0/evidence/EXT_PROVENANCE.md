# Provenance of the rev7 extension work (facts only)

This records who wrote what in the rev7 extension work, as far as it can be established. It does not establish authorship where no transcript exists.

## 1. Incident A: unidentified writer on the earlier working tree (2026-10-03, about 02:14-02:27 UTC)

Recorded by the previous session in its handoff package (`AUIF_ext_session_handoff.zip`, sha256 `d7f958f9d63477d86baeb14732027a48b2ec16d0ef03443b47eb66673b9350b8`, file `02_EVIDENCE/INCIDENT.txt`). After a sandbox reboot at 02:14:39, while no executor turn was running, files were written that the previous session had not written: `tools/ext_evidence.py`, `tools/ext_reverse_contamination.py`, `tools/static_checks_ext.py` (02:14:48, byte copies of that session's prepared files), `tools/mutation_ext.py` (02:15:08), `tools/verify_fresh_zip.py` (02:15:56) and `tools/gen_final.py` (02:16:19), and a mutation run was made on a snapshot copy (02:15:08-02:26:51). Its result (120 mutants, 104 killed, 16 survived) was treated as a lead, not a result.

## 2. Incident B: a second executor in the new session's sandbox (2026-10-03, 02:51-03:11 UTC)

When the owner uploaded the rev6.1 and R14 zips, a lock `/home/claude/EXECUTOR_LOCK_auif_ext.txt` with `executor_id=999b18a02b7746faac4a5db31a0db70a` and `utc=2026-10-03T02:51:32Z` appeared 10 seconds after the sandbox booted (02:51:22), with a working directory `/home/claude/ext_run_9b118818` (338 files). It edited tests and tools and completed a mutation run (119 run, 119 killed, E110 documented as equivalent) at 03:11:16. The executor of this package, whose turn began at 03:11:50, did not write it. The executor stopped and reported. At 03:12:05 and again at 03:13:33 no related process was running and the directory's content hash was `075cf9b0e0fd7efbc3703c4e8327b2379ebd5d1e4dc865b8be4c754acb9bde8d` (338 files). The owner stated there was no other executor and instructed this executor to continue.

Handling: the foreign directory was inspected read-only for evidence only (file listing and timestamps, the tail of its mutation log, a content hash); nothing was copied from it and nothing in this package derives from it. Its lock was preserved verbatim and the lock was replaced with this executor's (`executor_id=bfc56bac3efe4ebba706ed3e2da4e13a`, 03:13:43Z, recording the supersession). All work was redone from the verified handoff package in a fresh private directory `/home/claude/ext_run_bfc56bacx`, with content-hash snapshots of that directory taken and compared at each checkpoint.

## 3. Review of the two tool edits from incident A

Both were reviewed line by line by this executor against the diffs preserved in the handoff package.

`tools/verify_fresh_zip.py`. Kept: the extension test, static-check, reverse-contamination and extension-mutation steps (their logic was correct). Corrected: (a) the steps were skipped silently when the extension evidence was missing, so a package with `auif_ext/` but no evidence could PASS (fail-open); now a missing evidence file is a FAIL. (b) the always-on extension step inherited `AUIF_GOVERNOR_R14_ZIP` from the caller, which would make the recorded skip count mismatch; it is now removed for that step. Added: an optional step 5h that re-runs the extension tests against the real R14 Governor when the caller supplies the zip, and checks the zip's hash against the recorded one.

`tools/gen_final.py`. Kept: the README rows and the extension section structure. Corrected: (a) the wording "R14 is a frozen candidate" (R14 is a verified candidate; nothing is to be called frozen); (b) the unverified claim "identical to rev6 and rev6.1" (now compared at generation time with the audited hash recorded in section 1); (c) "rev7 is the audited core and the rev6.1 documentation, UNCHANGED" (documentation was added; it now says exactly what changed); (d) the section was silently omitted when evidence was missing (now refuses); (e) section 10 still said the package differs from rev6 only in documentation (now states rev7's change).

## 4. Deviation from the handoff plan

The handoff proposed E140 as an equivalent mutant. It is not: without the guard, a missing sink still yields `False`, but only after the verifier has been called, which is observable. E140 is therefore run and killed by `test_incomplete_delivery_wiring_consults_nothing`. Only E110 is documented as equivalent.

## 5. rev8 (2026-10-03)

rev8 was built from the rev7 candidate zip (sha256 `62f5441934fea206a4c7f653a4a0608d0d5b5359678c26f233db9902a688d8d2`, verified before extraction) in a fresh private directory under lock `440b81c5f94c47cf9018dc38bcdab9a4` (10:16:31Z; the sandbox had rebooted at 10:16:28Z). The rev7 core, contracts, synthetic world, reference implementations, port contracts and core tests were byte-identical to rev7 at the start and at the end of the build. The rev7 independent audit results (mutation 119/119, real R14 219/219) were relayed to the builder by the owner; the builder did not see the auditor's logs. No unexplained writer was observed during the rev8 build. Changes to tools: `tools/mutation_ext.py` (new mutants, optional nth-occurrence selector, fail-fast suite run) and `tools/gen_final.py` (rev8 wording). `tools/verify_fresh_zip.py` was not changed.

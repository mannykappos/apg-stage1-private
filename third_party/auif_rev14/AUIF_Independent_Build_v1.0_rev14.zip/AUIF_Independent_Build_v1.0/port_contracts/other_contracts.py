"""Conformance suites for the remaining ports. Each is a mixin: subclass with unittest.TestCase and implement the factory. A real Engine binding (UNKNOWN / Amir-dependent) must pass the same cases."""
from auif.errors import SecretError, TenantContextError
from auif.tenancy import TenantAuthority, TenantContext
class SecretPortContract:
    """EP-05. Factory: make_secrets() -> (port, provision) where provision(tenant_id, ref, value) stores a secret out of band."""
    def make_secrets(self): raise NotImplementedError
    def setUp(self): self.port, self.prov = self.make_secrets(); a = TenantAuthority(); self.A, self.B = a.issue("tenant-a", "p"), a.issue("tenant-b", "p"); self.prov("tenant-a", "secretref:t/x", "VALUE-A")
    def test_resolves_for_owning_tenant(self): self.assertEqual(self.port.resolve(self.A, "secretref:t/x"), "VALUE-A")
    def test_other_tenant_cannot_resolve_the_same_reference(self):
        with self.assertRaises(SecretError): self.port.resolve(self.B, "secretref:t/x")
    def test_unknown_reference_raises_secret_error(self):
        with self.assertRaises(SecretError): self.port.resolve(self.A, "secretref:t/none")
class TenantAuthorityContract:
    """EP-01. Factory: make_authority()."""
    def make_authority(self): raise NotImplementedError
    def setUp(self): self.auth = self.make_authority()
    def test_issued_context_verifies(self): self.assertTrue(self.auth.verify(self.auth.issue("t1", "p")))
    def test_forged_context_is_rejected(self): self.assertFalse(self.auth.verify(TenantContext("t1", "p", "0" * 64)))
    def test_a_context_cannot_be_retargeted_to_another_tenant(self): c = self.auth.issue("t1", "p"); self.assertFalse(self.auth.verify(TenantContext("t2", c.principal, c.sig)))
    def test_missing_or_wrong_type_is_rejected(self): self.assertFalse(self.auth.verify(None)); self.assertFalse(self.auth.verify({"tenant_id": "t1"}))
class GovernorPortContract:
    """EP-07. Factory: make_governor(). The port REQUESTS decisions and REPORTS conditions; it never lets AUIF decide."""
    def make_governor(self): raise NotImplementedError
    REQ = {"action_id": "act-0001", "action_type": "synthetic.update_party", "target_system_id": "s", "environment_id": "e", "payload_hash": "a" * 64, "classification": "INTERNAL"}
    def setUp(self): self.g = self.make_governor(); self.ctx = TenantAuthority().issue("tenant-a", "p")
    def test_request_decision_returns_a_known_status_with_ref_and_hash_when_granted(self):
        r = self.g.request_decision(self.ctx, dict(self.REQ)); self.assertIn(r["status"], {"GRANTED", "DENIED", "PENDING", "UNAVAILABLE"})
        if r["status"] == "GRANTED": self.assertTrue(isinstance(r["decision_ref"], str) and r["decision_ref"]); self.assertEqual(len(r["decision_hash"]), 64)
    def test_report_condition_returns_an_acknowledgement_flag(self): r = self.g.report_condition(self.ctx, {"kind": "MANIFEST_DRIFT", "integration_id": "i"}); self.assertIsInstance(r["acknowledged"], bool)
    def test_the_port_exposes_only_request_and_report(self): self.assertEqual({m for m in dir(type(self.g).__mro__[1]) if not m.startswith("_")} & {"request_decision", "report_condition", "grant", "approve", "issue_decision"}, {"request_decision", "report_condition"})
class PolicyPortContract:
    """OD-09 / GD-04. Factory: make_policy(). Undeterminable data MUST yield None (never an implicit ALLOW)."""
    def make_policy(self): raise NotImplementedError
    def setUp(self): self.p = self.make_policy(); self.ctx = TenantAuthority().issue("tenant-a", "p")
    def test_outcomes_are_from_the_closed_set_or_none(self):
        for cls in ("PUBLIC", "INTERNAL", "PII", "FINANCIAL", "HEALTH", "REGULATED"):
            r = self.p.decide(self.ctx, cls, {"kind": "customer-system"}, {}); self.assertTrue(r is None or r["outcome"] in {"ALLOW", "TRANSFORM", "MASK", "REJECT", "NEEDS_AUTHORISATION"})
    def test_an_unknown_destination_for_sensitive_data_is_not_allowed_implicitly(self): r = self.p.decide(self.ctx, "PII", {"kind": "never-heard-of-it"}, {}); self.assertTrue(r is None or r["outcome"] != "ALLOW")
class ModulePortContract:
    """EP-02 / EP-03. Factory: make_module()."""
    def make_module(self): raise NotImplementedError
    OBJ = {"contract_kind": "CanonicalObject", "canonical_type": "Party", "canonical_model_version": "0.1.0", "canonical_id": "party:s:1", "tenant_id": "tenant-a", "validation_state": "VALID", "attributes": {"display_name": "x"}, "attribute_classifications": {"display_name": "INTERNAL"}, "classification": "INTERNAL", "field_outcomes": [{"source_field": "n", "outcome": "MAPPED"}],
           "provenance_chain": [{"step_kind": "SOURCE_SYSTEM", "ref": "s"}, {"step_kind": "SOURCE_OBJECT", "ref": "A/1"}, {"step_kind": "SOURCE_FIELD", "ref": "A.n"}, {"step_kind": "TRANSLATION_PACK", "ref": "p", "version": "1.0.0", "hash": "a" * 64}, {"step_kind": "SCHEMA_FINGERPRINT", "ref": "fp", "hash": "b" * 64}, {"step_kind": "OBSERVATION", "ref": "obs-1"}]}
    def setUp(self): self.m = self.make_module(); self.ctx = TenantAuthority().issue("tenant-a", "p")
    def test_identity_and_descriptors(self): self.assertTrue(isinstance(self.m.module_id, str) and self.m.module_id); self.assertIsInstance(self.m.semantic_requirements(), list); self.assertIsInstance(self.m.module_capabilities(), dict)
    def test_ingest_operations_accept_valid_objects_without_raising(self):
        from auif.contracts import validate
        validate("canonical#CanonicalObject", self.OBJ); self.m.ingest_canonical_entity(self.ctx, dict(self.OBJ)); self.m.receive_integration_state(self.ctx, {"state": "ACTIVE"}); self.m.receive_integration_error(self.ctx, {"kind": "SOURCE_UNAVAILABLE"})

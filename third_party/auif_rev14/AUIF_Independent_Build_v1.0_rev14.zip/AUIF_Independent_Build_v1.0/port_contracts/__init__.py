"""Port conformance suites: any binding of a port (the reference implementations now, the platform's real binding later) must pass these."""

import unittest
from auif.tenancy import TenantAuthority
class PersistenceContract:
    """Mixin. Subclass with unittest.TestCase and define make_store(). A real EP-04 binding (UNKNOWN / Amir-dependent: ED-08) must pass every test here."""
    def make_store(self): raise NotImplementedError
    def setUp(self): self.s = self.make_store(); a = TenantAuthority(); self.A, self.B = a.issue("tenant-a", "p"), a.issue("tenant-b", "p")
    def test_put_get_roundtrip_and_no_aliasing(self):
        v = {"x": [1, 2]}; self.s.put(self.A, "c", "k", v); v["x"].append(3); self.assertEqual(self.s.get(self.A, "c", "k"), {"x": [1, 2]}); g = self.s.get(self.A, "c", "k"); g["x"].append(9); self.assertEqual(self.s.get(self.A, "c", "k"), {"x": [1, 2]})
    def test_missing_is_none(self): self.assertIsNone(self.s.get(self.A, "c", "nope"))
    def test_if_absent_is_a_unique_constraint(self): self.assertTrue(self.s.put(self.A, "c", "k", {"v": 1}, if_absent=True)); self.assertFalse(self.s.put(self.A, "c", "k", {"v": 2}, if_absent=True)); self.assertEqual(self.s.get(self.A, "c", "k"), {"v": 1})
    def test_tenant_isolation_same_key(self):
        self.s.put(self.A, "c", "k", {"t": "a"}); self.s.put(self.B, "c", "k", {"t": "b"}); self.assertEqual(self.s.get(self.A, "c", "k"), {"t": "a"}); self.assertEqual(self.s.get(self.B, "c", "k"), {"t": "b"})
        self.assertEqual([k for k, _ in self.s.list(self.A, "c")], ["k"]); self.s.put(self.A, "only-a", "z", {}); self.assertEqual(self.s.list(self.B, "only-a"), [])
    def test_update_is_atomic_and_rolls_back_on_error(self):
        self.s.put(self.A, "c", "k", {"n": 1}); self.assertEqual(self.s.update(self.A, "c", "k", lambda o: {"n": o["n"] + 1}), {"n": 2})
        def boom(o): raise RuntimeError("fail")
        with self.assertRaises(RuntimeError): self.s.update(self.A, "c", "k", boom)
        self.assertEqual(self.s.get(self.A, "c", "k"), {"n": 2})
    def test_update_missing_raises_keyerror(self):
        with self.assertRaises(KeyError): self.s.update(self.A, "c", "absent", lambda o: o)
    def test_list_prefix_sorted(self):
        for k in ("b2", "a1", "a2"): self.s.put(self.A, "c", k, {"k": k})
        self.assertEqual([k for k, _ in self.s.list(self.A, "c", "a")], ["a1", "a2"]); self.assertEqual([k for k, _ in self.s.list(self.A, "c")], ["a1", "a2", "b2"])
    def test_sequences_strictly_increase_per_tenant_and_name(self):
        self.assertEqual([self.s.next_sequence(self.A, "n") for _ in range(3)], [1, 2, 3]); self.assertEqual(self.s.next_sequence(self.B, "n"), 1); self.assertEqual(self.s.next_sequence(self.A, "other"), 1)

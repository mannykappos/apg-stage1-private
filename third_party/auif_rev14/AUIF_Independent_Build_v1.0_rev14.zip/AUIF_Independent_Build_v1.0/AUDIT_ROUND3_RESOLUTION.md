# AUIF audit round 3: resolution
Final independent audit of rev5. It accepted the rev5 tooling correction and the shipped verifier, confirmed F1-F7, and found one further HIGH finding, F9. Every claim below was reproduced on the unmodified rev5 first. **rev6 is NOT frozen.** rev5 is preserved unchanged (`AUIF_Independent_Build_v1.0_rev5.zip`, sha256 `146cdfb6173c4245006f4050ba13633f831ad2dd366964d848b337696fdaa226`) and is superseded only if rev6 is independently audited.

## 1. Finding
| # | Finding | Class | Severity | Status |
|---|---|---|---|---|
| F9 | A CanonicalAction's `tenant_id` was not bound to the authenticated TenantContext. With `ctx.tenant_id = tenant-a` and `action["tenant_id"] = tenant-b`, `ActionService.submit` accepted the action, created the reservation, the payload and the ledger (stamped `tenant-a`), while the durable intent kept `tenant-b`. A retry of tenant-a's action under tenant-b's context was accepted and processed. The public `Fabric.request_action` already refused a mismatch; the service-level entry point did not. | DEFECT | HIGH | Fixed |

## 2. Fix (production change: `auif/action.py` only)
- `submit` now requires `action["tenant_id"] == ctx.tenant_id` after the read-only contract validation and BEFORE any store write; a mismatch raises `TenantContextError`. The submitted value is checked, never overwritten, and the ledger's later use of `ctx` is not relied on.
- Defence in depth: completing a reservation (`_finish_submission`, used by retries and `recover_pending()`) refuses an intent whose action belongs to a different tenant, as an integrity failure, so a reservation planted or misfiled across tenants can never be completed.
- No contract change: the contract already carries `tenant_id`; binding it to the authenticated context is a runtime rule the schema cannot express.

## 3. Production change
| File | sha256 before (rev5) | sha256 after |
|---|---|---|
| `auif/action.py` | `a8231a3d151e08487cc7d84e5770995da1fde1a8b0371543188a7516a52e0100` | `48d7ccb869c9e5188154a3d47c38a33c7594d4b2c784043b905bb3d158edafac` |

21 core files are byte-identical to rev5. **The core tree hash changed INTENTIONALLY:** `024667e1ccbc1f721fd06578d616fa8343c76a0b9b4b04b617a72f6bedffdcd4` (rev5) to `5f27396249ea4f036fbc51bc9dad69134389d667a46a9962e8948d819bdb84d9` (rev6). `contracts/`, the audited package and Governor: untouched.

## 4. New regression tests: 15 in `tests/test_audit_round3.py` (suite total 363)
- **TestF9_ActionTenantIsBoundToTheAuthenticatedContext** (12): `test_a_matching_tenant_is_accepted_and_flows_end_to_end`, `test_a_mismatched_tenant_is_rejected_with_TenantContextError`, `test_the_rejection_happens_before_ANY_store_write`, `test_no_idempotency_ledger_payload_manifest_or_event_record_exists_in_either_tenant_after_a_mismatch`, `test_the_submitted_tenant_id_is_never_silently_overwritten`, `test_the_durable_intent_never_holds_a_tenant_other_than_the_authenticated_one`, `test_a_rejected_mismatch_cannot_be_recovered_by_the_sweep_in_either_tenant`, `test_a_retry_under_the_wrong_tenant_context_cannot_recover_another_tenants_action`, `test_idempotency_keys_remain_independent_per_tenant`, `test_a_reservation_holding_another_tenants_action_is_never_completed`, `test_a_forged_context_cannot_satisfy_the_check`, `test_the_public_entry_point_still_refuses_a_mismatch_and_a_matching_action_completes`
- **TestRequestActionGuardIsEnforcedAtTheEntryPointItself** (3): `test_the_entry_point_refuses_a_module_that_did_not_author_the_action_before_delegating`, `test_the_entry_point_refuses_a_tenant_mismatch_itself_before_delegating_to_the_service`, `test_a_request_whose_module_and_tenant_both_match_is_delegated_exactly_once`

## 5. Mutation testing, and a gap the fix exposed
90 mutants defined, **90 killed, 0 survived, 0 invalid**. M87 and M88 target the two new guards and were killed immediately.
The first full run nevertheless refused to write its evidence: **M31 survived**. M31 disables the whole `Fabric.request_action` guard (module AND tenant). It had been killed before only because one test of that guard checked a tenant mismatch; with F9 fixed that case is also refused downstream by `submit`, so the outcome (`TenantContextError`) no longer distinguished the layers. This exposed that **the module clause (`source_module != module_id`) had never had a test of its own**. It was not dismissed as equivalent: three tests now check each clause and that the entry point refuses BEFORE delegating to the service (a spy fails if `submit` is reached), and M31 was split into per-clause mutants M89 (tenant clause) and M90 (module clause). All three are killed.
The evidence was assembled from chunked runs (22 `action.py` mutants, 65 others, and the 3 new results); `--merge` accepts a set only if it covers every defined mutant exactly once. The shipped verifier re-runs all 90 inside the fresh extraction.

## 6. Replay of the auditor's scenario
`python3 tools/audit_round3_replay.py` writes nothing and exits 0 only if every scenario passes. **rev6: 17/17. rev5: 3/17** (the matching case and two controls); the failures include `ACCEPTED (QUEUED)` for a mismatch, `reservation exists, its intent carries tenant_id=tenant-b`, and `completed ['act-0001']; ledger CREATED under tenant-a` for a planted cross-tenant reservation. `tools/verify_fresh_zip.py` runs it as step 5d.

## 7. Analogous cases (reported, not changed)
Of the ten contracts carrying a `tenant_id`, `CanonicalAction` is the only one a caller supplies. `ActionExecutionRecord`, `Observation`, `CanonicalObject`, `ConnectorResult`, `SystemDiscoveryRecord`, `IntegrationManifest`, `IntegrationState` and `StateTransition` are all built by AUIF from `ctx.tenant_id`; `rehydrate()` already compares a restored discovery record's tenant to the context. The only object-tenant comparison in the core was `Fabric.request_action`. One observation is recorded as limitation 27: persisted ledger, reservation and manifest-reference records are read through the tenant-scoped store and not re-checked against the context on read; no defect was reproduced there.

## 8. Not changed
Architecture, contracts, Governor, and every other production file. Open: limitations 18, 23, 24, 25, 26 (rev5 verifier), 27 (new); decisions D-1..D-19 (D-19 new) await ratification; findings F-1..F-4 unchanged.

from auif.errors import SecretError
from auif.ports import SecretPort
class InMemorySecretStore(SecretPort):
    """REFERENCE secret store. Tracks accesses by reference only (never values). The real boundary (EP-05, ED-09, ID-01) is UNKNOWN / Amir-dependent."""
    def __init__(self): self._v, self.access_log = {}, []
    def put(self, tenant_id, ref, value): self._v[(tenant_id, ref)] = value
    def resolve(self, ctx, ref):
        self.access_log.append((ctx.tenant_id, ref))
        if (ctx.tenant_id, ref) not in self._v: raise SecretError("secret reference not resolvable for this tenant")
        return self._v[(ctx.tenant_id, ref)]

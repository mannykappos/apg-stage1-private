"""REFERENCE implementations of the AUIF ports for local development and tests. They are NOT the Anchor Engine and are never to be represented as it."""

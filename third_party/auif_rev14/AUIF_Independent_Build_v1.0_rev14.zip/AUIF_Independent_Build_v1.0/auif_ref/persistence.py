import copy, json, sqlite3
from auif.ports import PersistencePort
class MemoryPersistence(PersistencePort):
    """REFERENCE persistence (in memory). Not the platform's storage (UNKNOWN / Amir-dependent: ED-08)."""
    def __init__(self): self.d, self.seq = {}, {}
    def _c(self, ctx, coll): return self.d.setdefault(ctx.tenant_id, {}).setdefault(coll, {})
    def put(self, ctx, coll, key, value, if_absent=False):
        c = self._c(ctx, coll)
        if if_absent and key in c: return False
        c[key] = json.loads(json.dumps(value)); return True
    def get(self, ctx, coll, key): v = self._c(ctx, coll).get(key); return None if v is None else json.loads(json.dumps(v))
    def update(self, ctx, coll, key, fn):
        c = self._c(ctx, coll)
        if key not in c: raise KeyError(key)
        new = fn(json.loads(json.dumps(c[key]))); c[key] = json.loads(json.dumps(new)); return json.loads(json.dumps(new))
    def list(self, ctx, coll, prefix=""): return [(k, json.loads(json.dumps(v))) for k, v in sorted(self._c(ctx, coll).items()) if k.startswith(prefix)]
    def next_sequence(self, ctx, name): s = self.seq.setdefault(ctx.tenant_id, {}); s[name] = s.get(name, 0) + 1; return s[name]
class SqlitePersistence(PersistencePort):
    """REFERENCE persistence over SQLite (second implementation, proving the port is not tied to one store). Not the platform's database."""
    def __init__(self, path=":memory:"):
        self.db = sqlite3.connect(path, isolation_level=None); self.db.execute("CREATE TABLE IF NOT EXISTS kv(tenant TEXT, coll TEXT, k TEXT, v TEXT, PRIMARY KEY(tenant, coll, k))"); self.db.execute("CREATE TABLE IF NOT EXISTS seq(tenant TEXT, name TEXT, n INTEGER, PRIMARY KEY(tenant, name))")
    def put(self, ctx, coll, key, value, if_absent=False):
        v = json.dumps(value, sort_keys=True)
        if if_absent:
            try: self.db.execute("INSERT INTO kv VALUES(?,?,?,?)", (ctx.tenant_id, coll, key, v)); return True
            except sqlite3.IntegrityError: return False
        self.db.execute("INSERT OR REPLACE INTO kv VALUES(?,?,?,?)", (ctx.tenant_id, coll, key, v)); return True
    def get(self, ctx, coll, key):
        r = self.db.execute("SELECT v FROM kv WHERE tenant=? AND coll=? AND k=?", (ctx.tenant_id, coll, key)).fetchone(); return None if r is None else json.loads(r[0])
    def update(self, ctx, coll, key, fn):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            r = self.db.execute("SELECT v FROM kv WHERE tenant=? AND coll=? AND k=?", (ctx.tenant_id, coll, key)).fetchone()
            if r is None: raise KeyError(key)
            new = fn(json.loads(r[0])); self.db.execute("UPDATE kv SET v=? WHERE tenant=? AND coll=? AND k=?", (json.dumps(new, sort_keys=True), ctx.tenant_id, coll, key)); self.db.execute("COMMIT"); return json.loads(json.dumps(new))
        except BaseException: self.db.execute("ROLLBACK"); raise
    def list(self, ctx, coll, prefix=""): return [(k, json.loads(v)) for k, v in self.db.execute("SELECT k, v FROM kv WHERE tenant=? AND coll=? ORDER BY k", (ctx.tenant_id, coll)) if k.startswith(prefix)]
    def next_sequence(self, ctx, name):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            r = self.db.execute("SELECT n FROM seq WHERE tenant=? AND name=?", (ctx.tenant_id, name)).fetchone(); n = (r[0] if r else 0) + 1
            self.db.execute("INSERT OR REPLACE INTO seq VALUES(?,?,?)", (ctx.tenant_id, name, n)); self.db.execute("COMMIT"); return n
        except BaseException: self.db.execute("ROLLBACK"); raise

# BUILD_REPORT sections 13 to 16, as generated for rev13

These sections are copied byte for byte from rev13's `BUILD_REPORT.md` (lines 122 to 186) and are not regenerated: their figures describe rev10 to rev13 when those revisions were built (core tree `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d`). rev14 revised the core; its figures are in section 17 of the current `BUILD_REPORT.md`.

---

## 13. rev10: core revision (CF-4)

rev10 revises the audited rev9 core in exactly one file, `auif/action.py` (CF-4: `ActionService.recover_stale_acknowledged`), and adds one regression test file (`tests/test_cf4_stale_acknowledged_recovery.py`). `auif_ext/` is byte-identical to rev9's apart from one pinned core-hash literal in `auif_ext/tests/test_extension_boundary.py`. Details, what was NOT changed and how to read the evidence: `CHANGES_rev10.md`.

| Evidence | Result |
|---|---|
| rev10 core tree hash | `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d` (rev9's was `a18fd7aa98fdbb4a7ca28fa25b4b98275e2d2c3f3b100629a6300c46128e7146`) |
| Core tests (all of `tests/`, including the CF-4 regression tests) | **410 run, all passing** (rev9: 389) |
| Core mutation (`tools/mutation_test.py`) | **133 mutants: 133 killed, 0 survived, 0 invalid** (rev9: 114; 19 new mutants guard the CF-4 code) |

Not claimed: this is a core revision for independent audit, not a closure. Production readiness, Engine integration, Governor integration, Layer 2 and any real-system behaviour are all unclaimed. `KNOWN_LIMITATIONS.md` limitation 31 records the scope and its caveats.


## 14. rev11: the onboarding accelerator (`auif_onboard`)

rev11 adds a **drafting and review accelerator, not an onboarding authority**: Discover, Draft, Propose, Validate (synthetic only), Present for human approval. It generates a draft connector configuration from an OpenAPI/Swagger JSON document, a candidate translation pack through the existing mapping boundary, and a synthetic validation report; every mapping is a candidate until a named human approves it, and the generator cannot promote anything. Design, the approval model and the limitations are in `AUIF_ONBOARDING.md`; what changed is in `CHANGES_rev11.md`.

| Evidence | Result |
|---|---|
| Core tree hash | `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d` (equal to the pinned rev10 hash: True) |
| Frozen layers (`auif`, `auif_ext`, `auif_ref`, `synthetic`, `contracts`, `tests`, `port_contracts`) against the untouched rev10 extraction | 116 files identical; 1 changed, 1 added, 0 removed |
| Core tests | 410 run, all passing (unchanged) |
| Extension tests | 343 run, 20 skipped, all passing (unchanged) |
| Accelerator tests (`auif_onboard/tests`) | **418 run, all passing** |
| Accelerator mutation (`tools/mutation_onboard.py`) | **435 mutants run: 435 killed, 0 survived, 0 invalid**; 7 further mutants are documented as equivalent and are not run (each with its reason, in `evidence/mutation_onboard_results.json`) |
| Reverse contamination | with `auif_onboard` removed, 410 core and 343 extension tests still pass, static checks are clean and the core hash is unchanged: True |

Three materially different synthetic specifications, each drafted, validated against its own synthetic loopback vendor, and taken through a test-reviewer approval flow:

| Spec | Auth | Entities | Synthetic validation | Mappings approved (test reviewer) | Items left pending |
|---|---|---|---|---|---|
| crm_cursor_apikey | API_KEY | 2 | 14 PASS, 1 ATTENTION, 0 FAIL | 9 | 5 |
| helpdesk_link_swagger2 | API_KEY | 1 | 8 PASS, 1 ATTENTION, 0 FAIL | 3 | 5 |
| ledger_offset_oauth2 | OAUTH2_CLIENT_CREDENTIALS | 1 | 9 PASS, 2 ATTENTION, 0 FAIL | 5 | 3 |

A canary secret planted in every untrusted text field of the specifications appears in no artefact, ledger or report. The approvals in this evidence were made by a test reviewer inside the test suite: they demonstrate the mechanism, they are not approvals of anything. Not claimed: validation against any real system (a separate, gated phase that has not started and needs a named sandbox target), authentication of the human behind an approval, production readiness, Engine, Governor or Layer 2 integration. `KNOWN_LIMITATIONS.md` items O-1 onwards record the limitations.


## 15. rev12: fixes from the first real-API draft (tenant header, wrapped lists, entity exclusion)

rev12 closes the gaps that the first draft of a real vendor's published API description exposed (offline: no credential, no real system contacted). It changes **one optional setting of the REST connector** (`tenant_header` / `tenant_id`, extension layer) and the accelerator. The core, Governor, GD-05 and Layer 2 are untouched; rev11 is pinned. Findings, the approval recipe and the hypotheses the live phase must test are in `CHANGES_rev12.md`.

| Evidence | Result |
|---|---|
| Core tree hash | `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d` (equal to the pinned rev10 hash: True) |
| Layers against the untouched rev10 extraction | 116 files identical; changed: `auif_ext/connectors/rest.py`; added: `auif_ext/tests/test_rest_tenant.py`; removed: 0; any difference outside `auif_ext/`: 0 |
| Core tests | 410 run, all passing (unchanged) |
| Extension tests | 343 run, 20 skipped, all passing |
| Accelerator tests | **418 run, all passing** |
| Extension mutation | **187 mutants run: 187 killed, 0 survived, 0 invalid** (188 defined) |
| Accelerator mutation | **435 mutants run: 435 killed, 0 survived, 0 invalid**; 7 further mutants documented as equivalent and not run |
| Reverse contamination | with `auif_onboard` removed, 410 core and 343 extension tests still pass, core hash unchanged: True |

Not claimed: validation against any real system (the live phase is a separate, gated step), authentication of the human behind an approval, production readiness, Engine, Governor or Layer 2 integration. `KNOWN_LIMITATIONS.md` items E-20 and O-15 to O-23 record the limits.


## 16. rev13: one approval-consistency fix in the accelerator (audit finding REV12-AUD-01)

The independent audit of rev12 found that a reviewer could approve an outbound mapping and then approve a configuration that removes that entity's write endpoint, leaving an approved configuration (not writable) and an assembled pack (outbound enabled) that disagree. rev13 refuses such a configuration approval, for approved ENTITY, FIELD and ACTION outbound mappings, so the outcome no longer depends on the order of human decisions. The change is one guard in `auif_onboard/review.py`; the extension layer, the core, Governor, GD-05, Layer 2 and the frozen rev12 package are untouched. Details: `CHANGES_rev13.md`.

| Evidence | Result |
|---|---|
| Core tree hash | `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d` (equal to the pinned rev10 hash: True) |
| Accelerator tests | **418 run, all passing** (11 new, in `test_write_consistency.py`) |
| Accelerator mutation | **435 mutants run: 435 killed, 0 survived, 0 invalid**; 7 documented equivalents not run (8 new mutants for the guard) |

# Action submission: resumable write-ahead intent (audit round 2, F7)

## Why this design
`PersistencePort` (EP-04) guarantees only **single-record** atomicity: `put` with `if_absent`, and an atomic read-modify-write `update`. There is no multi-record transaction, and none is assumed of the real Engine (this is the same pair of guarantees AMIR-TODO-04 already asks for). Submission touches several records (idempotency, payload, ledger, manifest reference, queue state). So it cannot be made atomic; it is made **resumable** instead.

Reordering the writes only moves the failure window (an action record without its idempotency key would allow a duplicate). The design below removes the window: the first write is one atomic record that already contains everything needed to finish, and every later step is idempotent.

## The reservation record (`action_idem`, key = idempotency key)
| Field | Meaning |
|---|---|
| `action_id` | the action this key reserves |
| `content_hash` | hash of the canonical action; a reused key with a different hash is refused |
| `state` | `RESERVED` or `COMMITTED` |
| `reserved_at` | time of the reservation; becomes the action's `created_at`, so recovery never rewrites history |
| `intent` | present only while `RESERVED`: the full submitted action, so anyone can complete the submission from this record alone |

## State machine (forward only)
```
(absent) --put if_absent--> RESERVED --all steps done--> COMMITTED
```
`RESERVED` means "the intent is durable; the action may not be fully materialised yet". `COMMITTED` means "the action record exists and has left `CREATED`". `RESERVED` cannot strand an action, because the intent needed to complete it is inside it.

## Completion steps (every one idempotent, in this order)
1. put payload `canon:<action_id>` (same bytes every time)
2. create the ledger record (`if_absent`: an existing record is never overwritten)
3. put the manifest reference (same value every time)
4. record the supplied-decision-ref event, if any (fixed slot `0000`, `if_absent`: exactly once)
5. `CREATED -> QUEUED` only if the record is still `CREATED` (a record already beyond it is left untouched, so a late recovery can never regress a dispatched action)
6. record `SUBMISSION_RECOVERED` if this completion was a recovery (fixed slot `0000r`, `if_absent`: at most once)
7. mark the reservation `COMMITTED` and drop the intent

A clean submission therefore performs six store writes: `put:action_idem`, `put:action_payloads`, `put:action_ledger`, `put:action_manifest_ref`, `update:action_ledger`, `update:action_idem` (plus one event write when a decision ref was supplied).

## Who completes a `RESERVED` submission
- **a retry** of the same key (same content): it completes the *original* reserved action, even if the retry carries a new `action_id`; no second action is ever created;
- **a concurrent duplicate**: it sees `RESERVED` and runs the same idempotent steps; both converge on one action;
- **`ActionService.recover_pending(ctx)`**: sweeps every `RESERVED` submission for the tenant and completes it with no caller involved. Safe at any time, including concurrently with live submissions.

## Failure matrix (each row is a tested case: a failure injected at that write)
| Failed write | State left behind | Recovered by retry or sweep |
|---|---|---|
| 1 `put action_idem` | nothing | a normal submission |
| 2 `put action_payloads` | `RESERVED` + intent | yes |
| 3 `put action_ledger` | `RESERVED` + intent + payload | yes |
| 4 `put action_manifest_ref` | `RESERVED` + intent + ledger `CREATED` | yes |
| 5 `update action_ledger` (queue) | `RESERVED` + ledger `CREATED` + manifest | yes |
| 6 `update action_idem` (commit) | ledger `QUEUED`, still `RESERVED` | yes; if already dispatched the action is not regressed |

Rev3 stranded the action permanently for failures 2 and 3 (`NotFound`), and silently left it in `CREATED`, never dispatched, for failures 4 and 5.

## Evidence semantics
- A recovered submission carries a `SUBMISSION_RECOVERED` event (once). A normal one does not.
- A `COMMITTED` reservation whose action record is missing, a `RESERVED` reservation with no usable intent, an intent whose hash or action id does not match, are all **integrity failures**: loud `AuifError`, never `NotFound`, never silently re-created, never executed. The sweep reports them as `unrecoverable` and still completes the others.
- The intent stores the submitted payload for as long as the reservation is `RESERVED`; it is dropped at `COMMIT`. It is held in the same tenant-scoped store and under the same sensitivity as `action_payloads`.

## Not assumed, and left to the host
- Nothing schedules `recover_pending`. The host must call it at start-up and periodically (known limitation 24). A retry also recovers, so a sweep is a safety net, not the only path.
- Real concurrency is not proven (known limitation 8). Interleaving is proven deterministically, by injecting a duplicate submission immediately before each write.

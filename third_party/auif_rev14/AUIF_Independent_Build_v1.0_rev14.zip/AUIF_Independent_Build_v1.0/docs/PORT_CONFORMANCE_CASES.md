# Port conformance cases (language-neutral)

A binding of a port passes when every case below holds. In Python, subclass the mixin (see port_contracts/templates). In another language, implement these cases in your framework.

## PersistenceContract

Mixin. Subclass with unittest.TestCase and define make_store(). A real EP-04 binding (UNKNOWN / Amir-dependent: ED-08) must pass every test here.

- `if absent is a unique constraint`
- `list prefix sorted`
- `missing is none`
- `put get roundtrip and no aliasing`
- `sequences strictly increase per tenant and name`
- `tenant isolation same key`
- `update is atomic and rolls back on error`
- `update missing raises keyerror`

## SecretPortContract

EP-05. Factory: make_secrets() -> (port, provision) where provision(tenant_id, ref, value) stores a secret out of band.

- `other tenant cannot resolve the same reference`
- `resolves for owning tenant`
- `unknown reference raises secret error`

## TenantAuthorityContract

EP-01. Factory: make_authority().

- `a context cannot be retargeted to another tenant`
- `forged context is rejected`
- `issued context verifies`
- `missing or wrong type is rejected`

## GovernorPortContract

EP-07. Factory: make_governor(). The port REQUESTS decisions and REPORTS conditions; it never lets AUIF decide.

- `report condition returns an acknowledgement flag`
- `request decision returns a known status with ref and hash when granted`
- `the port exposes only request and report`

## PolicyPortContract

OD-09 / GD-04. Factory: make_policy(). Undeterminable data MUST yield None (never an implicit ALLOW).

- `an unknown destination for sensitive data is not allowed implicitly`
- `outcomes are from the closed set or none`

## ModulePortContract

EP-02 / EP-03. Factory: make_module().

- `identity and descriptors`
- `ingest operations accept valid objects without raising`

# AUIF extensions (rev8 candidate, building on the rev7 extension candidate)

**Status: candidate for independent audit. Not frozen.** This package adds a separate `auif_ext/` package next to the audited core. It **does not change the audited core**: `auif/`, `contracts/`, the audited architecture package and Governor are immutable dependencies, and the core tree hash is unchanged (`5f27396249ea4f036fbc51bc9dad69134389d667a46a9962e8948d819bdb84d9`).

**rev10 note.** rev10 is a revision of the CORE (CF-4, on top of rev9's CF-1 and CF-2; see `CHANGES_rev10.md` and `CHANGES_rev9.md`). This extension package is carried unchanged from rev8, except that one pinned core-hash literal in `auif_ext/tests/test_extension_boundary.py` was updated. Where this document says the extensions do not change the audited core, that is a statement about the extensions, not about this revision.

## rev8 additions (extension code only; the core is untouched)

rev8 builds on the **rev7 extension candidate** (zip sha256 `62f5441934fea206a4c7f653a4a0608d0d5b5359678c26f233db9902a688d8d2`), whose independent audit results (extension mutation 119/119 with mutant-by-mutant agreement; real R14 conformance 219 run, 0 skipped) were relayed to the builder by the owner. **rev8 is itself a new candidate and has not been audited.** All 219 rev7 extension tests pass unchanged; rev8 only adds tests (plus one import in `test_oauth2.py`). Nothing here is frozen, production-ready, Engine-integrated or Governor-integrated.

Each item below started as a test that failed against rev7 behaviour, or as a gap found by reading rev7 (limitations E-3, E-11 and E-13).

| # | Change | Why (found in rev7) |
|---|---|---|
| 1 | `HttpTransport(total_deadline=60.0)` and `RestConfig.total_deadline`: a hard bound on the WHOLE exchange | rev7 bounded each socket operation only, so a server dripping one byte at a time held a call open indefinitely (a 400-byte body at 0.15 s per byte took 60 s against a 5 s read timeout). The deadline cuts the socket from a timer; a read cut short is never accepted as complete; a write cut off after sending is MAYBE applied |
| 2 | Default TLS context sets `minimum_version = TLS 1.2` explicitly | On the test platform the interpreter's default context reported no minimum at all, so rev7 inherited whatever the platform allowed |
| 3 | `OAuth2ClientCredentials`: thread-safe, single-flight token fetch | 16 concurrent callers made 7 token requests where 1 would do. Followers share the leader's token or its failure; a different credential never joins a flight; an `invalidate()` during a fetch is not undone by it |
| 4 | `WebhookReceiver` serialises its own calls into the core | The core has no internal synchronisation (core limitation 8). A racing stub accepted one event several times without it. Signature verification stays parallel |
| 5 | REST pagination styles: `offset`, `page`, `link` (RFC 8288 `rel="next"`), besides the rev7 `cursor` | rev7 supported one style. `link` accepts only a same-origin, same-endpoint next link and replays its canonical query as the cursor; a header that names a next page but cannot be read FAILS instead of ending the walk (silent truncation); an empty page, not a short page, ends offset and page paging, because a server may clamp the page size |
| 6 | Real TLS tests (`test_tls_e2e.py`, throwaway certificates in `auif_ext/tests/fixtures/tls/`) | rev7 asserted only that a TLS context was honoured. rev8 performs handshakes: verified success, untrusted, wrong-host and expired certificates are refused, a WRITE that fails the handshake is NOT_APPLIED, and errors reveal nothing |
| 7 | Connector conformance kit (`auif_ext/conformance/`, `auif_ext/CONNECTOR_ONBOARDING.md`) | The gate a new connector must pass. It runs inside the real `ConnectorRuntime`, is proven on four REST configurations, and its self-test shows eight deliberately broken connectors are all caught |

**Behaviour changes versus the audited rev7 extensions.** (a) Every HTTP call is now bounded to 60 seconds in total unless `total_deadline` is raised (a legitimately long export needs a larger value). (b) The default TLS floor is 1.2. (c) Webhook ingest through one receiver is serialised. (d) `Endpoint` gained optional fields; the defaults reproduce rev7 behaviour exactly.

## What the extensions are, and are not

The core already has the architectural interfaces for connectors, modules and Governor (the connector contract, `ModulePort`, `GovernorPort`). The extensions are **concrete, reusable implementations that operationalise those existing contracts**. They are not evidence that the core was incomplete.

The REST / OAuth2 connector, the webhook receiver and the CSV / JSON file importer are **the first extension implementations**. They are **not locked architecture requirements**: nothing in the audited architecture mandates them, and a different connector kit could replace them without touching the core.

| Component | Status |
|---|---|
| AUIF core architecture and runtime | Built and independently audited (rev6) |
| Connector contract and boundary | Built in the core |
| Concrete reusable connector kit | **Extension (this package)** |
| `ModulePort` | Built in the core as a contract; a real module binding remains (register item 12) |
| Practical module client and examples | **Extension (this package)** |
| `GovernorPort` | Built in the core as a contract |
| AUIF-side Governor adapter | **Extension (this package)** |
| Real external-system connectors | Not built: no real external system is integrated |
| Translation packs for real systems | Not built |
| Anchor Engine binding | Amir-dependent |

## Layout

| Path | What it is |
|---|---|
| `auif_ext/common.py` | `Secret` (a credential wrapper that cannot leak), header hygiene, `Retry-After` parsing |
| `auif_ext/connectors/http_client.py` | The only place that opens a socket: https only, host allow-list, no redirects, bounded responses, a total deadline, TLS verification on with a TLS 1.2 floor |
| `auif_ext/connectors/oauth2.py` | OAuth2 client-credentials (thread-safe, single-flight) |
| `auif_ext/connectors/rest.py` | One declarative REST connector, configured by data |
| `auif_ext/connectors/webhook.py` | Webhook receiver: authenticate before parsing, replay and duplicate protection |
| `auif_ext/connectors/file_import.py` | Read-only CSV / JSON import |
| `auif_ext/connectors/descriptor.py` | Builds a schema-valid `ConnectorDescriptor` |
| `auif_ext/module_client/` | `BaseModule` (a ready `ModulePort`), `ModuleClient`, two worked examples |
| `auif_ext/governor_adapter/` | AUIF implementing Governor's Universal Adapter Contract (v1.2 section 2) |
| `auif_ext/conformance/` | The connector conformance kit (rev8): the gate a new connector must pass. See `auif_ext/CONNECTOR_ONBOARDING.md` |
| `auif_ext/tests/` | 328 tests: 308 run in every run; 20 more run only against the real R14 Governor when its zip is supplied (with it: 328 run, 0 skipped). `fixtures/tls/` holds throwaway TLS test certificates (TEST-ONLY) |
| `tools/static_checks_ext.py`, `tools/mutation_ext.py`, `tools/ext_reverse_contamination.py`, `tools/ext_evidence.py` | Static checks, mutation testing, reverse contamination and evidence for the extensions |

## 1. Connector kit

**REST connector.** One class, `RestConnector`, configured by a `RestConfig` (base URL, host allow-list, auth mode, entities and their endpoints). Target-specific behaviour is configuration plus a translation pack, never a subclass. It implements the audited `Connector` contract and normalises every failure to the core's `TransportError` with an honest `applied` flag:

| Status | Normalised code | Applied (read) | Applied (write) |
|---|---|---|---|
| 401 | `AUTHENTICATION_FAILED` | NOT_APPLIED | NOT_APPLIED |
| 403 | `AUTHORIZATION_DENIED_BY_TARGET` | NOT_APPLIED | NOT_APPLIED |
| 429 | `RATE_LIMITED` (with `Retry-After`, seconds or HTTP-date, clamped) | NOT_APPLIED | NOT_APPLIED |
| 408 | `TIMEOUT` | NOT_APPLIED | MAYBE |
| 5xx | `UNAVAILABLE` | NOT_APPLIED | MAYBE |
| other 3xx / 4xx | `TARGET_REJECTED_REQUEST` | NOT_APPLIED | NOT_APPLIED |

A write that times out or loses its connection after the request was sent is MAYBE applied, so the core never retries it blindly and reconciles by idempotency key (`lookup_by_idempotency_key`). The idempotency key is sent in a configurable header. Credentials are held in a `Secret`, are sent only in a header, and never appear in a URL, a body, an error or a `repr`.

Authentication: none, API key / bearer, or OAuth2 client-credentials (`OAuth2ClientCredentials`). The credential resolved from the secret boundary is one string, `client_id:client_secret`. Authorization-code and rotating refresh-token flows are **not** supported (see `KNOWN_LIMITATIONS.md`, Extension limitations).

**Webhook receiver.** `WebhookReceiver.handle(ctx, integration_id, headers, body)` authenticates a delivery **before** parsing or storing anything: an HMAC over the exact bytes (and an optional timestamp), compared in constant time against every currently valid secret (so a secret can be rotated without dropping deliveries). A timestamp outside the tolerance is refused; a repeated event id is suppressed by the core's own sequencer; an id reused with a different payload is reported as a conflict. Nothing about a rejected delivery is echoed back, and if no secret can be resolved the receiver **fails closed** (503) and accepts nothing. The signature scheme (header names, encoding, prefix, signed template) is configuration; no provider is named. The receiver does not open a socket: the host supplies the HTTPS endpoint and wires `secrets` to the SecretPort and `ingest` to `Fabric.ingest_events`.

**File import.** `FileImportConnector` reads CSV or JSON from one confined directory, read-only. Symlinks and non-regular files are refused; size and row counts are bounded; encodings are strict. Nothing is type-guessed: a column is a string unless the configuration declares a type, and a value that does not fit invalidates the page.

## 2. Module client

`BaseModule` is a ready-made `ModulePort`: a module declares what it needs and registers handlers for entities, observations, events, state and errors. `ModuleClient` is a thin convenience over the Fabric's public entry points (`activate`, `sync`, `request_action`). It adds no authority: it **never sets a Governor decision reference**, binds every action to the authenticated tenant context, derives a deterministic idempotency key so a retry deduplicates, and isolates handler failures (the message of a failing handler, which may hold data, is not kept). Two worked examples (`ExampleDirectoryModule`, a read-side mirror; `ExampleUpdaterModule`, a write-side rename) run against the real Fabric in the tests.

## 3. Governor adapter

`build_adapter_class(binding)` returns a class that implements Governor's `TargetSystemAdapter` (v1.2 section 2) on top of AUIF. Governor's classes are **injected**: AUIF never imports Governor, so the audited core stays free of it. The adapter is exactly the nine contract methods; Governor's authority operations (`evaluate_policy`, `issue_promotion_token`, `mutate_governor_state`, `assert_compliant`, `determine_materiality`, `resolve_conflict`) are absent by construction. It observes and translates; it is never an authority. It forwards **metadata only** (identifiers, provenance, hashes), never business payloads.

`deliver_decision` **fails closed**: a decision is delivered only if an injected verifier authenticates it and returns exactly `True`. How AUIF authenticates to Governor is an open decision (**GD-05** / ED-11), so no real authentication is implemented and, where the decision is undecided, the adapter must fail closed rather than guess; the verifier is supplied by the host, and the tests use a test double. `declared_capabilities` is an honest self-declaration: a capability is `False` unless it is actually wired.

**Conformance (AUIF-AT-27).** The per-method boundary checks run against a Governor contract test double in every run. When `AUIF_GOVERNOR_R14_ZIP` points at the R14 Governor zip, the same checks run against the **real** Governor code, plus its full pipeline (declare, observe, reconcile, authorize, token, delivery) and a hash check that the extracted Governor artefacts are byte-identical before and after. R14 is a verified candidate and Governor is not closed: this is conformance evidence against the R14 reference code, not a Governor integration.

## How a real system is added later

One connector configuration (usually a `RestConfig`) plus one translation pack plus one integration manifest, with no change to the core. Until someone runs it against a sandbox account it stays **unverified against that system**: the extensions were tested only against local loopback servers, and there is **no real external system** in this package.

## Verification

```sh
python3 -W ignore -m unittest discover -s auif_ext/tests -t .          # extension tests
AUIF_GOVERNOR_R14_ZIP=/path/to/governor_v1.2_reference_implementation_R14_verified_candidate.zip \
  python3 -W ignore -m unittest discover -s auif_ext/tests -t .        # also against the real Governor
python3 tools/static_checks_ext.py                                     # imports, names, constructs, sockets, core hash
python3 tools/ext_reverse_contamination.py                             # the core passes with auif_ext removed
python3 tools/mutation_ext.py                                          # mutation testing of the extension guards
python3 tools/verify_fresh_zip.py <package.zip>                        # everything above, from a fresh extraction
```

**Recorded results for this candidate** (`evidence/ext_verification.json`, `evidence/mutation_ext_results.json`): extension tests 328 run, 20 skipped, OK without the Governor zip; 328 run, 0 skipped, OK against the real R14 Governor; extension static checks clean; reverse contamination PASS (the 363 core tests pass with `auif_ext` removed, core hash unchanged); extension mutation 158 mutants run, 158 killed, 0 survived, 0 invalid. 159 mutants are defined; **E110** is documented as equivalent and not run (`EQUIVALENT` in `tools/mutation_ext.py`, with its reason). These are the builder's measurements for audit, not a closure.
## The onboarding accelerator sits above the extensions (rev11)
`auif_onboard/` (see `AUIF_ONBOARDING.md`) drafts a connector configuration for the generic REST connector in this package and a candidate translation pack for the core. It imports `auif` and `auif_ext`; neither imports it, and `tools/onboard_reverse_contamination.py` proves that the core tests and these extension tests pass, with the same counts and the same core hash, when it is removed. `auif_ext/` is byte-identical to rev10's. The accelerator only builds `RestConfig` objects and runs the existing conformance kit against synthetic loopback vendors; it adds no connector behaviour.

## rev12: tenant-scoped connections (`connectors/rest.py`)
`RestConfig` gained two optional fields, `tenant_header` and `tenant_id`, given together or not at all. The header is sent on every API call (discover, health, read, write, lookup), never to the OAuth2 token endpoint, never replaces a credential header, and is never part of the credential. A header name the connector owns (authorization, host, content-type, content-length, accept, cookie, connection, transfer-encoding, upgrade, expect, te, trailer) or one that collides with the API-key or idempotency header is refused; the value is limited to `[A-Za-z0-9._:-]`, 1 to 100 characters. Tests: `auif_ext/tests/test_rest_tenant.py`. This is the only rev12 change to any layer below the accelerator.

## rev14: `BaseModule` reports a handler failure (finding M8-F4)
`BaseModule` still delivers to every handler and still keeps only the exception's type name, but each delivery method now returns `{"handler_failures": n}` when n of its handlers raised (and `None` otherwise). The fabric reads that marker, counts the delivery as failed (`module_failures`), records it and tells the module (`MODULE_DELIVERY_FAILED`); before rev14 the failure was swallowed and the delivery counted as made. Nothing else in `auif_ext/` changed apart from the pinned core hash in `auif_ext/tests/test_extension_boundary.py` and one declared identity in the same file's three-connector test (see `CHANGES_rev14.md`). New tests: `auif_ext/tests/test_rev14_module_client.py`; new mutants E177 to E183.

# CHANGES rev13: one approval-consistency fix in the onboarding accelerator

rev13 is built on the frozen rev12 package (rev12 is preserved unchanged; its zip sha256 is `24bad9e600bfa46dfc7ce3d11aff46eb006008484eb79bd4e486b9af0550ee93`). It answers one finding of the independent audit of rev12.

## Finding REV12-AUD-01 (HIGH, as classified by the auditor)
Approving an outbound mapping and then approving a configuration with `entities.Account.write = null` succeeded, and `assemble_pack()` then produced a pack with `Account.outbound.supported = true` next to a configuration in which Account is not writable. The reverse order (remove the write endpoint, then approve an outbound mapping) was already refused. The outcome depended on the order of human decisions. rev12 had closed the same class of problem for entity exclusion but not for write-endpoint removal. Reproduced on the shipped rev12 zip before the fix; the reproduction now ends in a refusal.

## Fix
`auif_onboard/review.py`, `ReviewSession.approve_config`: after the existing check for excluded entities, the configuration approval is refused if any approved mapping with `outbound.supported == true` (kind ENTITY, FIELD or ACTION, attributed to its entity by `_entity_of`) belongs to an entity that has no write endpoint in the configuration being approved. The refusal names the entities, changes nothing (no mapping is stripped, no ledger entry), and the reviewer resolves the conflict explicitly.

## Tests and mutants
* New `auif_onboard/tests/test_write_consistency.py` (11 tests): each of the three mapping kinds alone blocks the removal (so each branch is independently exercised); the refusal leaves state unchanged and approval with the endpoint kept still works; the reverse order is refused for ENTITY, ACTION and FIELD; inbound-only approvals, rejected decisions, other entities and an empty review are not blocked; both orders end with a configuration and a pack that agree.
* 8 new mutants (V111 to V118: guard bypassed, inbound-only blocked, polarity inverted, entity-only, action-ignored, field-ignored, draft config consulted, entity not named); all killed. The auditor asked for a mutant that bypasses the guard (V111) and a test that kills it.
* No existing test or mutant was changed.

## Unchanged
Core, Governor, GD-05, Layer 2, `auif_ext/` (including rev12's tenant-header setting), rev11 and rev12 packages, the offline real-vendor draft (draft hashes identical to rev12's: the fix concerns review, not drafting). No live call, no credential.

## Still gated
The real-system sandbox pass (the vendor's free demo organisation) has not started. It still needs: independent acceptance of this revision, a named real human reviewer, and a `secretref:` credential reference (never the secret).

## Measured on this package (builder evidence; none of it is an audit)
Core 410 tests (unchanged); extension 343 (also 343 against the real R14 Governor, 0 skipped); accelerator 418 (407 carried plus 11 new); accelerator mutation 435 run, 435 killed, 0 survived, 0 invalid, 7 documented equivalents not run (442 defined); extension mutation evidence carried from rev12 (the extension layer is byte-identical to rev12's) and re-run by the verifier. Core tree hash `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d`, equal to rev10's. Against the untouched rev10 extraction, the only changed pre-existing file below the audited layers is `auif_ext/connectors/rest.py` and the only added one `auif_ext/tests/test_rest_tenant.py`, as in rev12.

# AMIR_ENGINE_DEPENDENCY_TODO

Blocked items only. 18 open items. Every item states: component, why blocked, exact Engine information, exact question, exact evidence, exact implementation step, whether Engine code changes, whether DB access is needed, whether staging suffices, exact validation command, expected result, evidence to return, what it unblocks, dependencies, status.

Rule: nothing here states a fact about the Anchor Engine. Order of work: AMIR-TODO-01 first; the dependency column gives the rest.

Run any suite from the build directory. Reference run: `python3 -W ignore -m unittest discover -s tests -t .`

## AMIR-TODO-01: Engine reconnaissance gate (architecture AR-22/AR-23; lock prerequisite)

- **Register references:** ED-01..ED-14, A-01..A-20, R-01..R-44
- **Why it cannot be completed:** No source, database, deployment or integration of the Anchor Engine is available to this build. Every ED item is UNKNOWN / Amir-dependent.
- **Engine information required:** Repository location and a stated commit; languages, frameworks and versions; directory layout; build, test and run commands; the list of environments.
- **Question for Amir:** Please give the AUIF executor read access to the Anchor Engine repository at a stated commit and answer requests A-01 to A-20 in 05_Amir_Request_Pack.md (architecture package), citing a file path per answer.
- **Source / file / config / DB evidence required:** Commit hash; tracked-file count; top-level directory listing; dependency manifest files; answers A-01..A-20, each citing file path and line range or command output.
- **Implementation step Amir performs:** Grant read access. For each request A-01..A-20 write the answer with a file path and line range or the output of a command. Do not answer from memory.
- **Amir must modify Engine code?:** NO
- **DB access required?:** NO
- **Staging / non-production sufficient?:** Not applicable (read-only source access)
- **Validation command / procedure:** In the Engine repository run: git rev-parse HEAD && git ls-files | wc -l   and return the output. The AUIF executor then checks every cited path exists at that commit with: test -f <path>
- **Expected result:** A 40-hex-character commit id; a non-zero file count; every cited path exists at that commit.
- **Evidence to return:** The command output; the completed A-01..A-20 answers.
- **Unblocks:** Reconnaissance review and therefore the Architecture lock decision; every other AMIR-TODO item; real port bindings.
- **Dependencies / blockers:** None. First item.
- **Status:** OPEN

## AMIR-TODO-02: Module Port binding (EP-02, EP-03)

- **Register references:** ED-01, ED-05, ED-06, OD-22
- **Why it cannot be completed:** How Anchor modules are defined, registered, invoked, how they receive data and emit requests is unknown. A binding cannot be written without inventing the interface.
- **Engine information required:** The exact interface a module exposes to receive an entity, an observation and an event; how a module submits an action request; how a module declares its semantic requirements; API and event conventions.
- **Question for Amir:** Which exact class, function or endpoint must AUIF call to deliver (a) a canonical entity, (b) an observation, (c) an event to a module, and by which exact mechanism does a module submit an action request?
- **Source / file / config / DB evidence required:** File paths and signatures of the module base class or registration; one existing module's entry points; the event bus or API convention used.
- **Implementation step Amir performs:** Implement a binding exposing the ModulePort interface (auif/ports.py::ModulePort: its 7 abstract methods and the module_id attribute) that calls the interfaces identified above. Copy port_contracts/templates/test_module_binding.py.template to tests/binding/test_module_binding.py and point the factory at the new binding. Run the suite. Add a minimal entry point to the Engine ONLY if none exists able to receive canonical objects, and return that diff.
- **Amir must modify Engine code?:** CONDITIONAL: only if the Engine has no suitable entry point. Return the diff.
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES: non-production is sufficient
- **Validation command / procedure:** python3 -W ignore -m unittest tests.binding.test_module_binding -v   (If the Engine is not Python, implement the language-neutral cases listed for this port in docs/PORT_CONFORMANCE_CASES.md in the Engine's own test framework and return their output instead.)
- **Expected result:** All ModulePortContract cases pass: OK with zero failures.
- **Evidence to return:** The unittest output; the binding source; the diff of any Engine change.
- **Unblocks:** AUIF-AT-01 against a real module; delivery to Anchor Real Estate; closing OD-22 (module descriptor format).
- **Dependencies / blockers:** AMIR-TODO-01
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-01` {"title": "Module architecture and attachment mechanism", "requirement": "A way for an Anchor module to attach to AUIF through the Module Port (ingest canonical objects, observations, events; request actions; receive state and errors).", "closure_evidence": "Cited description of how modules are structured, packaged, registered and called, with file and line evidence."}
- `ED-05` {"title": "Event systems", "requirement": "A way to carry canonical observations and events to modules and to receive internal events, with known ordering and delivery guarantees.", "closure_evidence": "Cited description of event mechanisms, schemas and ordering/delivery guarantees."}
- `ED-06` {"title": "API conventions", "requirement": "Conventions for internal APIs (style, versioning, error format) so AUIF interfaces fit the platform.", "closure_evidence": "Cited description of API style, versioning and error conventions and how a new service is exposed."}

## AMIR-TODO-03: Tenant and caller context binding (EP-01)

- **Register references:** ED-03, ID-02
- **Why it cannot be completed:** How the Engine authenticates callers, identifies the tenant and propagates context is unknown. The reference HMAC-signed context only proves the core rejects forged or missing context.
- **Engine information required:** Authentication mechanism; how tenant identity is established and propagated per request or job; how background jobs obtain tenant context; how context forgery is prevented.
- **Question for Amir:** Where in the Engine is the tenant identity resolved and how is it carried into background/worker execution? Show the code that prevents a caller from selecting another tenant.
- **Source / file / config / DB evidence required:** File paths for the auth middleware, tenant resolution and job-context propagation; one test in the Engine that proves cross-tenant selection is rejected.
- **Implementation step Amir performs:** Implement TenantAuthorityPort (auif/ports.py) on the Engine's tenant context so verify() is true only for contexts the Engine issued. Copy port_contracts/templates/test_tenant_binding.py.template to tests/binding/test_tenant_binding.py and point the factory at the new binding. Run the suite.
- **Amir must modify Engine code?:** NO (binding only), unless context cannot be verified server-side; then report
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** python3 -W ignore -m unittest tests.binding.test_tenant_binding -v   (If the Engine is not Python, implement the language-neutral cases listed for this port in docs/PORT_CONFORMANCE_CASES.md in the Engine's own test framework and return their output instead.)
- **Expected result:** All TenantAuthorityContract cases pass, including forged, retargeted and missing contexts being rejected.
- **Evidence to return:** unittest output; binding source.
- **Unblocks:** Trusted tenant context for every AUIF service; real AUIF-AT-12.
- **Dependencies / blockers:** AMIR-TODO-01
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-03` {"title": "Authentication, identity and tenant context", "requirement": "A trustworthy source of tenant and caller identity for every AUIF operation.", "closure_evidence": "Cited description of the authentication mechanism, tenant concept and how tenant context is propagated and enforced."}
- `ID-02` {"title": "Physical and network isolation", "detail": "Isolation of tenants, connectors and workers at the network and host level."}

## AMIR-TODO-04: Persistence binding (EP-04) and DB-dependent closure items

- **Register references:** ED-08, DB-01..DB-09, ID-04
- **Why it cannot be completed:** Storage technology, tenant isolation mechanism, transactional guarantees and migration tooling are unknown. AUIF persists only through PersistencePort; the reference stores prove the port, not the platform's database.
- **Engine information required:** Data stores and versions; tenant isolation mechanism at the data layer; transaction semantics for read-modify-write; unique-constraint support; migration tooling; backup/retention.
- **Question for Amir:** Which store will hold AUIF's collections (see docs/PERSISTENCE_COLLECTIONS.md), how is tenant isolation enforced at the data layer, and can a per-(tenant, collection, key) unique constraint and an atomic read-modify-write be provided?
- **Source / file / config / DB evidence required:** Per DB-01..DB-09 in 03_AUIF_Open_Decisions_and_Dependency_Register.json: the exact_amir_instruction of each is reproduced in the generated section below.
- **Implementation step Amir performs:** Implement PersistencePort (put, get, update, list, next_sequence) over the Engine's store with a unique key on (tenant, collection, key) and an atomic update. Create the collections listed in docs/PERSISTENCE_COLLECTIONS.md via the Engine's migration tooling. Copy port_contracts/templates/test_persistence_binding.py.template to tests/binding/test_persistence_binding.py and point the factory at the new binding. Run the suite, then the acceptance suite on the binding (command below).
- **Amir must modify Engine code?:** YES: adds storage objects and migrations to the Engine (non-production first)
- **DB access required?:** YES: a non-production database is sufficient; no production data
- **Staging / non-production sufficient?:** YES: a non-production environment and database are sufficient; production data must not be used
- **Validation command / procedure:** python3 -W ignore -m unittest tests.binding.test_persistence_binding -v   then   AUIF_BINDINGS_MODULE=<your_module> python3 -W ignore -m unittest discover -s tests -t .   (your_module must expose make_persistence() returning the binding)
- **Expected result:** PersistenceContract: all cases OK. Full suite: the same pass count as the reference run recorded in ACCEPTANCE_RESULTS.json, with zero failures.
- **Evidence to return:** Both unittest outputs; migration scripts; the DB-01..DB-09 evidence listed in the register.
- **Unblocks:** Durable Action Execution Ledger, observations, manifests, discovery records; AUIF-AT-12 and AUIF-AT-11 on real storage; DB-dependent closure items.
- **Dependencies / blockers:** AMIR-TODO-01, AMIR-TODO-03
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-08` {"title": "Persistence and storage", "requirement": "Durable, tenant-isolated storage with defined transactional guarantees for discovery records, manifests, observations, the Action Execution Ledger and pack metadata.", "closure_evidence": "Cited description of storage technologies, tenant isolation, transactions, migrations, durability and retention; plus DB-dependent closure evidence (section DB)."}
- `DB-01` {"title": "Identify storage technologies and which holds tenant-scoped platform data", "exact_amir_instruction": "Send the list of data stores in use (engine, version, purpose) and which hold tenant-scoped data. Names and versions only; no data.", "required_database_environment": "Read access to deployment and config documentation; no production data", "validation_procedure": "Compare the list against the architecture's persistence requirements EP-04", "required_closure_evidence": "Cited list of stores with versions and purposes"}
- `DB-02` {"title": "Tenant isolation mechanism at the data layer", "exact_amir_instruction": "Describe how tenant data is separated (row-level, schema or database per tenant, other) and where it is enforced. In a NON-production database, run the same query once with and once without tenant context and report both results.", "required_database_environment": "A non-production database with two synthetic tenants", "validation_procedure": "Query without tenant context fails or returns nothing; query with tenant A never returns tenant B rows", "required_closure_evidence": "The two query results and the enforcement point cited from source"}
- `DB-03` {"title": "Transactional guarantees for ledger write and state update", "exact_amir_instruction": "State the default isolation level and whether an atomic insert plus update (and an outbox-style pattern) is supported. In a NON-production database, demonstrate that two concurrent updates to one row serialise.", "required_database_environment": "Non-production database of the same engine and version as production", "validation_procedure": "Concurrent update test result; isolation level statement", "required_closure_evidence": "Test script, output and the version of the engine"}
- `DB-04` {"title": "Migration tooling and process", "exact_amir_instruction": "Describe the migration tool, naming convention and review process. Do NOT run any migration for AUIF.", "required_database_environment": "Read access to the migration directory and process documentation", "validation_procedure": "Process described with cited examples", "required_closure_evidence": "Cited description and an example migration file path"}
- `DB-05` {"title": "Durability, backup and retention settings", "exact_amir_instruction": "Report backup frequency, point-in-time recovery capability and any retention or deletion jobs affecting platform data.", "required_database_environment": "Operations documentation or configuration", "validation_procedure": "Statement checked against the retention decision once made", "required_closure_evidence": "Cited configuration or operations document"}
- `DB-06` {"title": "Write-rate and capacity baseline", "exact_amir_instruction": "In a NON-production database, run the supplied or agreed insert benchmark and report the sustained inserts per second at the production engine version and instance class. Do not use production data.", "required_database_environment": "Non-production database with a production-comparable instance class", "validation_procedure": "Benchmark output with parameters", "required_closure_evidence": "Benchmark script, parameters, raw output and environment description"}
- `DB-07` {"title": "Per-tenant unique constraints for idempotency and dedupe keys", "exact_amir_instruction": "In a NON-production database, create a throwaway table with a (tenant, key) unique constraint and attempt a duplicate insert; report the error raised.", "required_database_environment": "Non-production database", "validation_procedure": "Duplicate insert is rejected deterministically", "required_closure_evidence": "The statement run and the error returned"}
- `DB-08` {"title": "Existing audit or evidence tables", "exact_amir_instruction": "List existing audit, evidence or provenance tables (names and purposes only).", "required_database_environment": "Read access to schema documentation", "validation_procedure": "List compared against AUIF provenance and ledger needs", "required_closure_evidence": "Cited table list"}
- `DB-09` {"title": "CI test database", "exact_amir_instruction": "Describe how CI provisions databases, and confirm a throwaway database of the production engine and version can be created per test run.", "required_database_environment": "CI configuration", "validation_procedure": "A CI job creates and destroys a matching database", "required_closure_evidence": "Cited CI configuration and a successful run log"}
- `ID-04` {"title": "Database isolation and durability", "detail": "Database-level tenant isolation, durability, backup and retention."}

## AMIR-TODO-05: Secret store binding (EP-05)

- **Register references:** ED-09, ID-01
- **Why it cannot be completed:** How the Engine stores and resolves credentials (vault/KMS/env) is unknown. The reference store only proves the core handles secrets by reference and never logs them.
- **Engine information required:** Secret store technology; reference format; tenant scoping; rotation; access audit.
- **Question for Amir:** Which secret manager holds tenant integration credentials, how is a reference like secretref:<path> resolved per tenant, and how is access audited?
- **Source / file / config / DB evidence required:** File paths/config for secret resolution; the policy or ACL that scopes a secret to a tenant.
- **Implementation step Amir performs:** Implement SecretPort.resolve(ctx, ref) over the Engine's secret store, tenant-scoped, raising SecretError when unresolvable. Copy port_contracts/templates/test_secret_binding.py.template to tests/binding/test_secret_binding.py and point the factory at the new binding. Run the suite.
- **Amir must modify Engine code?:** NO (binding only)
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** python3 -W ignore -m unittest tests.binding.test_secret_binding -v   (If the Engine is not Python, implement the language-neutral cases listed for this port in docs/PORT_CONFORMANCE_CASES.md in the Engine's own test framework and return their output instead.)
- **Expected result:** All SecretPortContract cases pass: another tenant cannot resolve the reference; unknown reference raises SecretError.
- **Evidence to return:** unittest output; binding source.
- **Unblocks:** Connectors authenticating with real credentials; real AUIF-AT-20.
- **Dependencies / blockers:** AMIR-TODO-01, AMIR-TODO-03
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-09` {"title": "Secrets management", "requirement": "Access to a secret-management boundary through references, with no secret in ordinary state.", "closure_evidence": "Cited description of secret storage and access; location-only report of any secret found in source."}
- `ID-01` {"title": "Secret store, HSM or KMS", "detail": "Production-grade secret storage, rotation and access control. The reference implementation can show reference-only handling; it cannot assure production secrecy."}

## AMIR-TODO-06: Queue / worker / scheduler binding (EP-06)

- **Register references:** ED-12, ID-03
- **Why it cannot be completed:** The Engine's queue and worker infrastructure is unknown. The core's FairScheduler and Throttle are in-process references of the required behaviour (bounded per-(tenant, integration) queues, tenant-fair service, Retry-After isolation).
- **Engine information required:** Queue technology; worker model; retry/backoff facilities; per-tenant fairness controls; concurrency limits.
- **Question for Amir:** Which queue and workers will run Fabric.sync / ingest_events / actions.dispatch, and can work be partitioned and rate-limited per (tenant, integration)?
- **Source / file / config / DB evidence required:** File paths/config for queues and workers; concurrency and retry settings.
- **Implementation step Amir performs:** Run AUIF tasks on the Engine's workers, keeping one bounded queue per (tenant, integration) and tenant-fair service; use Throttle for Retry-After and circuit state. Reproduce the fairness case below on the real workers.
- **Amir must modify Engine code?:** YES: worker registration/config
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** Enqueue 20 tasks for tenant A against a stub target returning 429 with Retry-After 300, and 20 tasks each for tenants B and C against a healthy stub. Record completion times. Reference behaviour: tests/test_foundation.py::TestFairScheduler::test_AT_30_throttled_tenant_does_not_stall_others
- **Expected result:** All B and C tasks complete without waiting for A; A's 20 tasks stay queued until Retry-After elapses; no queue grows beyond its bound.
- **Evidence to return:** Timeline log of task completions per tenant; queue-depth samples; worker config.
- **Unblocks:** AUIF-AT-30 and AUIF-AT-08 on real infrastructure.
- **Dependencies / blockers:** AMIR-TODO-01, AMIR-TODO-03
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-12` {"title": "Queue and worker infrastructure", "requirement": "Per-tenant queues and workers with fairness and isolation.", "closure_evidence": "Cited description of job, queue and worker mechanisms and tenant isolation or fairness provisions."}
- `ID-03` {"title": "Queue and worker infrastructure at scale", "detail": "Production queue infrastructure and worker isolation."}

## AMIR-TODO-07: Governor port wiring (EP-07)

- **Register references:** ED-11, GD-03, GD-05
- **Why it cannot be completed:** The Governor integration surface on the Engine side is unknown, and the Governor-side decisions GD-03 (who determines governance is required and decision validity) and GD-05 (AUIF-to-Governor security) are open and are NOT Amir's to close. AUIF isolates the interface and holds undetermined actions.
- **Engine information required:** How Engine components currently call the Governor; the transport and authentication; the existing adapter instance, if any.
- **Question for Amir:** What is the exact call by which Engine code requests a Governor decision and reports a condition, and how is that call authenticated?
- **Source / file / config / DB evidence required:** File paths of the Governor client/adapter; one existing call site; the authentication used. Governor-side decisions are recorded in UNRESOLVED_GOVERNOR_DECISIONS.md and need Emmanuel/Governor-side owners.
- **Implementation step Amir performs:** Implement GovernorPort.request_decision and report_condition over the existing Governor surface WITHOUT changing the locked adapter terms and WITHOUT letting AUIF decide. Copy port_contracts/templates/test_governor_binding.py.template to tests/binding/test_governor_binding.py and point the factory at the new binding. Run the suite.
- **Amir must modify Engine code?:** NO to the Governor; binding only
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES: a non-production Governor
- **Validation command / procedure:** python3 -W ignore -m unittest tests.binding.test_governor_binding -v   then confirm against the staging Governor: a granted request returns a reference and 64-hex hash; a denied request yields a FAILED ledger record; an unavailable Governor leaves the action QUEUED and unsent.
- **Expected result:** GovernorPortContract OK; the three staging outcomes observed exactly as stated.
- **Evidence to return:** unittest output; staging transcripts of the three outcomes with ids/hashes.
- **Unblocks:** Governed actions against the real Governor; real AUIF-AT-13; draft positions on GD-03/GD-05 can be reviewed against reality.
- **Dependencies / blockers:** AMIR-TODO-01; owner decisions GD-03 and GD-05
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-11` {"title": "Governor integration surface", "requirement": "A path to request governance decisions and report conditions to Governor, and knowledge of how Governor is deployed and wired alongside the platform today.", "closure_evidence": "Cited description of Governor deployment and any existing adapter wiring, decision and token flow."}
- `GD-03` {"title": "Who determines that governance is required, and decision-reference validity", "detail": "Neither document says who determines whether an action requires governance, what AUIF does when that is undetermined, or how long a Governor decision reference remains valid and who verifies it at the target."}
- `GD-05` {"title": "Security of the AUIF to Governor interaction", "detail": "How AUIF authenticates to Governor and how the locked adapter authentication relates to AUIF's own operations is not defined."}

## AMIR-TODO-08: Observability sink binding (EP-08)

- **Register references:** ED-13
- **Why it cannot be completed:** The Engine's metrics/logging/tracing stack is unknown. AUIF's Telemetry emits the 15 required signals with payload redaction, but is not connected to any real sink.
- **Engine information required:** Metrics, log and trace systems; label/cardinality rules; PII handling in logs.
- **Question for Amir:** Where should AUIF's gauges, counters and redacted events be sent, and what label cardinality limits apply per tenant and integration?
- **Source / file / config / DB evidence required:** File paths/config of the metrics and logging setup.
- **Implementation step Amir performs:** Forward Telemetry.set / inc / log to the Engine's sinks, keeping the redaction in auif/observability.py (never forward payload or secret values). Add a test that sends a sentinel payload through an AUIF flow and scans the sink output.
- **Amir must modify Engine code?:** NO (binding only)
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** Run tests.test_acceptance.TestAT24_Observability against a Telemetry wired to the real sink, then search the sink for the sentinel strings SENTINEL-NAME-777 and SENTINEL-TITLE-888.
- **Expected result:** All 15 REQUIRED_SIGNALS appear in the sink; zero occurrences of either sentinel.
- **Evidence to return:** The sink query output for the 15 signals; the zero-hit search output.
- **Unblocks:** Real AUIF-AT-24; operational dashboards.
- **Dependencies / blockers:** AMIR-TODO-01
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-13` {"title": "Observability stack", "requirement": "A sink for metrics, logs and traces with redaction of sensitive payloads.", "closure_evidence": "Cited description of logging, metrics and tracing and existing redaction practice."}

## AMIR-TODO-09: Deployment topology and egress controls (EP-06, EP-09)

- **Register references:** ED-07, ID-02
- **Why it cannot be completed:** Deployment model, environments and network egress policy are unknown. Connectors make outbound calls, so egress control is a security requirement the reference cannot prove.
- **Engine information required:** Environments; where AUIF would run; outbound network policy; secrets/network separation per tenant.
- **Question for Amir:** From which hosts will connectors run, which outbound destinations are allow-listed, and is the cloud metadata endpoint blocked?
- **Source / file / config / DB evidence required:** Network policy/egress configuration; environment list.
- **Implementation step Amir performs:** Configure the runtime so connectors can reach only registered target endpoints, then run the egress checks below from the runtime host.
- **Amir must modify Engine code?:** YES: egress configuration
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** From the runtime host: curl -sS -m 5 -o /dev/null -w '%{http_code}\n' https://<allow-listed-sandbox-host>/ ; curl -sS -m 5 http://169.254.169.254/ ; curl -sS -m 5 https://example.org/
- **Expected result:** The first returns an HTTP status (200/401/403); the second and third fail to connect (blocked).
- **Evidence to return:** The three command outputs and the egress policy.
- **Unblocks:** Safe execution of real connectors; production-isolation work (AMIR-TODO-16).
- **Dependencies / blockers:** AMIR-TODO-01
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-07` {"title": "Deployment model and environments", "requirement": "Knowledge of runtime, environments, scaling and network egress controls where connectors and workers will run.", "closure_evidence": "Cited description of deployment topology, environments, egress controls and scaling."}
- `ID-02` {"title": "Physical and network isolation", "detail": "Isolation of tenants, connectors and workers at the network and host level."}

## AMIR-TODO-10: CI and test conventions (EP-10)

- **Register references:** ED-10, DB-09
- **Why it cannot be completed:** How the Engine's CI runs tests, its Python/runtime versions and CI database are unknown.
- **Engine information required:** CI system, runtime versions, test runner conventions, CI database.
- **Question for Amir:** How can the AUIF suites (python3 -m unittest, standard library only) be run in the Engine's CI, and is a CI database available?
- **Source / file / config / DB evidence required:** CI configuration file path; runtime version.
- **Implementation step Amir performs:** Add a CI job that runs: python3 -W ignore -m unittest discover -s tests -t . from the AUIF build directory and archives ACCEPTANCE_RESULTS.json.
- **Amir must modify Engine code?:** YES: CI configuration
- **DB access required?:** OPTIONAL (needed only for the persistence binding job)
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** python3 -W ignore -m unittest discover -s tests -t .
- **Expected result:** Zero failures; the test count equals the count in ACCEPTANCE_RESULTS.json.
- **Evidence to return:** CI run URL or log and the archived results file.
- **Unblocks:** Continuous verification of the build against the Engine's CI.
- **Dependencies / blockers:** AMIR-TODO-01
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-10` {"title": "Testing framework and CI conventions", "requirement": "Test and CI conventions so AUIF tests run where the platform's tests run.", "closure_evidence": "Cited description of test frameworks, fixtures and CI."}
- `DB-09` {"title": "CI test database", "exact_amir_instruction": "Describe how CI provisions databases, and confirm a throwaway database of the production engine and version can be created per test run.", "required_database_environment": "CI configuration", "validation_procedure": "A CI job creates and destroys a matching database", "required_closure_evidence": "Cited CI configuration and a successful run log"}

## AMIR-TODO-11: Real Canonical Anchor Model (replaces the synthetic model)

- **Register references:** ED-04, OD-08, GD-01
- **Why it cannot be completed:** The Anchor canonical attribute sets are an open decision (OD-08) and depend on the Engine's existing data models (ED-04). The model in this build is SYNTHETIC (status DRAFT_EXAMPLE_ONLY).
- **Engine information required:** Existing Engine data models for parties, properties, agreements, tasks, events; naming and classification conventions.
- **Question for Amir:** Which existing Engine entities and attributes should the canonical concepts (Party, Property, Agreement, Task, Event, ...) align to, and what is each attribute's classification?
- **Source / file / config / DB evidence required:** Model definitions (file paths) and the classification of each attribute. Governor-side GD-01 (Canonical Model vs Governor Neutral Model) remains an owner decision.
- **Implementation step Amir performs:** With the owner, author a real CanonicalModelDefinition JSON (schema: contracts/canonical.schema.json#/$defs/CanonicalModelDefinition) and place it outside the core.
- **Amir must modify Engine code?:** NO
- **DB access required?:** NO
- **Staging / non-production sufficient?:** Not applicable
- **Validation command / procedure:** python3 -c "import json; from auif.contracts import validate; validate('canonical#CanonicalModelDefinition', json.load(open('<real_model.json>'))); print('VALID')"
- **Expected result:** Prints VALID with no exception.
- **Evidence to return:** The model file and the validation output.
- **Unblocks:** Real Translation Packs; module requirements; real AUIF-AT-01..AT-04.
- **Dependencies / blockers:** AMIR-TODO-01; owner decision OD-08; GD-01
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-04` {"title": "Existing data models", "requirement": "Knowledge of existing entity models so the Canonical Anchor Model aligns with them without copying any external system and without duplicating existing concepts.", "closure_evidence": "Inventory of existing entities relevant to the core canonical concepts, with existing classification and provenance fields."}
- `GD-01` {"title": "Canonical Anchor Model versus Governor Neutral Model", "detail": "The handoff's Canonical Anchor Model and the locked Governor Neutral Model (the target of Normalize()) are separate models that share the names Observation, Resource, Change and Environment. Neither document defines their relationship."}

## AMIR-TODO-12: Anchor Real Estate module specifics

- **Register references:** ED-14
- **Why it cannot be completed:** The real first module's semantic requirements and entry points are unknown; the two synthetic modules are not Anchor Real Estate.
- **Engine information required:** The module's concepts, attributes, actions it requests, events it consumes.
- **Question for Amir:** What canonical concepts and attributes does Anchor Real Estate require, and which actions will it request from external systems?
- **Source / file / config / DB evidence required:** File paths of the module's data model and its integration points.
- **Implementation step Amir performs:** Write the module descriptor (OD-22 format as decided) and a ModulePort binding (AMIR-TODO-02) for it; add an acceptance run with this module registered.
- **Amir must modify Engine code?:** CONDITIONAL: as in AMIR-TODO-02
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** Register the real module in a World-equivalent and run: python3 -W ignore -m unittest tests.test_acceptance.TestAT01_02_16_Universality -v
- **Expected result:** AT-01 passes with the real module and core tree hash unchanged (tools/static_checks.py prints the same core_tree_sha256).
- **Evidence to return:** unittest output and the two core_tree_sha256 values.
- **Unblocks:** The first real proving ground leg (Anchor Real Estate side).
- **Dependencies / blockers:** AMIR-TODO-01, AMIR-TODO-02, AMIR-TODO-11
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-14` {"title": "Anchor Real Estate module specifics", "requirement": "The module's actual semantic requirements, data and workflows, and any existing integration paths to customer systems.", "closure_evidence": "Cited description of the module's integration needs and existing paths, with the module owner's confirmation."}

## AMIR-TODO-13: McGrath proof (AUIF-AT-15) and external-system access

- **Register references:** XD-01, XD-02, AUIF-AT-15
- **Why it cannot be completed:** No representative McGrath/customer system, documentation, sandbox or test credentials is available. The McGrath proof cannot be performed or simulated honestly.
- **Engine information required:** Access to a representative system or sandbox, its API/schema documentation, test credentials, rate limits, supported auth.
- **Question for Amir:** Can a McGrath sandbox (or an equivalent representative system) with documentation and test credentials be provided for the AT-15 procedure?
- **Source / file / config / DB evidence required:** Sandbox endpoint, documentation, credential reference stored in the Engine's secret store, rate limits.
- **Implementation step Amir performs:** 1. Provision test credentials into the secret store (AMIR-TODO-05). 2. Implement or select the connector for the system's protocol. 3. Author a Translation Pack for it with the owner. 4. Execute the AT-15 steps from 07_AUIF_Acceptance_Test_Specification.json (reproduced in the generated section below). 5. Run tools/static_checks.py to show no McGrath-specific code entered the core.
- **Amir must modify Engine code?:** NO to the Engine
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES: the sandbox is the proof environment
- **Validation command / procedure:** Execute the AUIF-AT-15 steps (generated below), then: python3 tools/static_checks.py
- **Expected result:** AT-15 expected results hold; static_checks.py exit code 0 and an unchanged core_tree_sha256.
- **Evidence to return:** Per-step evidence defined by AT-15; static_checks output; connector and pack files.
- **Unblocks:** AUIF-AT-15; the commercial proving claim.
- **Dependencies / blockers:** AMIR-TODO-05, AMIR-TODO-09, AMIR-TODO-11, AMIR-TODO-12
- **Status:** OPEN

Verbatim extracts from the audited register:

- `XD-01` {"title": "Representative McGrath/customer system access and documentation", "detail": "This draft has no knowledge of any real McGrath schema, interface or behaviour. Integration tests against representative systems (handoff sections 45, 59) and the McGrath Translation Pack need access to a representative system and its documentation."}
- `XD-02` {"title": "Test credentials and sandbox provisioning for external systems", "detail": "Real connector tests need credentials and a sandbox. Credentials are provided only through the secret boundary, never in code, packs, logs or documents."}
- `AUIF-AT-15` {"title": "McGrath Proof", "steps": ["With a McGrath pack and connector configuration and a representative McGrath system, run the inbound and outbound flows.", "Statically check the Core for McGrath-specific imports or identifiers."], "expected": "McGrath to AUIF to Anchor Real Estate demonstrated without McGrath-specific logic in the Core.", "evidence": "Flow logs; static check output."}

## AMIR-TODO-14: Performance measurement (AUIF-AT-29)

- **Register references:** AT-29, DB-06
- **Why it cannot be completed:** Performance thresholds and a production-like environment are not available. The reference measurement (evidence/performance_measurement.json) is explicitly non-representative.
- **Engine information required:** Target throughput/latency thresholds (owner decision) and a production-like environment with representative data volumes.
- **Question for Amir:** What throughput and latency are required per tenant and per integration, and in which environment may AUIF be measured?
- **Source / file / config / DB evidence required:** Threshold document; environment description; DB write-rate baseline (DB-06).
- **Implementation step Amir performs:** Run the measurement on the real persistence binding in the production-like environment and compare with thresholds.
- **Amir must modify Engine code?:** NO
- **DB access required?:** YES: production-like non-production
- **Staging / non-production sufficient?:** YES: production-like staging
- **Validation command / procedure:** AUIF_BINDINGS_MODULE=<your_module> AUIF_PERF_OUT=./amir_performance.json python3 -W ignore -m unittest tests.test_acceptance.TestAT29_Performance -v   then read ./amir_performance.json (the tracked evidence file is not touched)
- **Expected result:** Measured values meet the owner's thresholds (to be supplied).
- **Evidence to return:** The JSON file, environment description, thresholds.
- **Unblocks:** AUIF-AT-29.
- **Dependencies / blockers:** AMIR-TODO-04, AMIR-TODO-06; owner thresholds
- **Status:** OPEN

Verbatim extracts from the audited register:

- `DB-06` {"title": "Write-rate and capacity baseline", "exact_amir_instruction": "In a NON-production database, run the supplied or agreed insert benchmark and report the sustained inserts per second at the production engine version and instance class. Do not use production data.", "required_database_environment": "Non-production database with a production-comparable instance class", "validation_procedure": "Benchmark output with parameters", "required_closure_evidence": "Benchmark script, parameters, raw output and environment description"}

## AMIR-TODO-15: Existing integration code reuse assessment

- **Register references:** ED-02
- **Why it cannot be completed:** Whether the Engine already has integration code or abstractions AUIF should reuse or replace is unknown.
- **Engine information required:** Inventory of existing integration code, abstractions and their consumers.
- **Question for Amir:** List existing integration code (paths) and state for each whether modules depend on it.
- **Source / file / config / DB evidence required:** File paths and consumers.
- **Implementation step Amir performs:** Provide the inventory; the executor writes a reuse/replace assessment against AR-4.
- **Amir must modify Engine code?:** NO
- **DB access required?:** NO
- **Staging / non-production sufficient?:** Not applicable
- **Validation command / procedure:** For each listed path run: git log -1 --format=%H -- <path>   and return the output.
- **Expected result:** A commit id per path (proves each path exists and is tracked).
- **Evidence to return:** Inventory with command output.
- **Unblocks:** Decision on reuse versus replacement; avoids duplicate abstractions.
- **Dependencies / blockers:** AMIR-TODO-01
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ED-02` {"title": "Existing integration code and abstractions", "requirement": "Knowledge of what integration code already exists, to reuse it where sound. Not assumed correct merely because it exists (handoff section 52).", "closure_evidence": "Inventory of external-system-facing code, each item classified for reuse, conflict or irrelevance against the AUIF principles."}

## AMIR-TODO-16: Production isolation verification (cross-tenant, real infrastructure)

- **Register references:** ID-02, ID-03, ID-04, DB-02, AUIF-AT-12
- **Why it cannot be completed:** Cross-tenant isolation in the real data layer and runtime cannot be proven by the reference. Only the core's own guards are proven.
- **Engine information required:** Data-layer isolation mechanism and a staging environment with two test tenants.
- **Question for Amir:** Can two non-production test tenants be provisioned so isolation tests can be run against the real data layer?
- **Source / file / config / DB evidence required:** DB-02 evidence plus the test output below.
- **Implementation step Amir performs:** Provision tenants 'tenant-a' and 'tenant-b' in staging; run the isolation acceptance tests on the persistence binding; run the data-layer query below.
- **Amir must modify Engine code?:** NO
- **DB access required?:** YES: non-production
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** AUIF_BINDINGS_MODULE=<your_module> python3 -W ignore -m unittest tests.test_acceptance.TestAT12_Isolation -v   then in the database count rows visible to tenant-b whose tenant column is tenant-a
- **Expected result:** All AT-12 tests pass; the cross-tenant row count is 0.
- **Evidence to return:** unittest output; the query and its result.
- **Unblocks:** Real AUIF-AT-12; production readiness assessment (not claimed here).
- **Dependencies / blockers:** AMIR-TODO-03, AMIR-TODO-04, AMIR-TODO-09
- **Status:** OPEN

Verbatim extracts from the audited register:

- `ID-02` {"title": "Physical and network isolation", "detail": "Isolation of tenants, connectors and workers at the network and host level."}
- `ID-03` {"title": "Queue and worker infrastructure at scale", "detail": "Production queue infrastructure and worker isolation."}
- `ID-04` {"title": "Database isolation and durability", "detail": "Database-level tenant isolation, durability, backup and retention."}
- `DB-02` {"title": "Tenant isolation mechanism at the data layer", "exact_amir_instruction": "Describe how tenant data is separated (row-level, schema or database per tenant, other) and where it is enforced. In a NON-production database, run the same query once with and once without tenant context and report both results.", "required_database_environment": "A non-production database with two synthetic tenants", "validation_procedure": "Query without tenant context fails or returns nothing; query with tenant A never returns tenant B rows", "required_closure_evidence": "The two query results and the enforcement point cited from source"}

## AMIR-TODO-17: Real AI service binding for mapping proposals

- **Register references:** OD-12, AR-9
- **Why it cannot be completed:** Which AI service (if any) may be used, and its data-handling constraints, are undecided. The boundary and its deterministic validation are built and tested with scripted and adversarial doubles only.
- **Engine information required:** Approved provider/model, data residency, what discovery content may be sent.
- **Question for Amir:** Which provider is approved and what discovery content may be sent to it?
- **Source / file / config / DB evidence required:** Approval and constraints from the owner.
- **Implementation step Amir performs:** Implement MappingProposer (auif/ai_boundary.py) over the approved service. It receives only the read-only ProposerSandbox. Run the adversarial acceptance tests with the real proposer.
- **Amir must modify Engine code?:** NO
- **DB access required?:** NO
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** python3 -W ignore -m unittest tests.test_acceptance.TestAT25_AI -v   with the real proposer substituted for AdversarialProposer in a copy of the test
- **Expected result:** No candidate is ever VALIDATED by the proposer; claimed states are discarded and flagged; promotion happens only through AIMappingService.promote.
- **Evidence to return:** unittest output; proposer source; the approval.
- **Unblocks:** AI-assisted pack authoring.
- **Dependencies / blockers:** Owner decision OD-12
- **Status:** OPEN

## AMIR-TODO-18: Existing data classification metadata and policy source

- **Register references:** DB-10, OD-09, GD-04
- **Why it cannot be completed:** Where classification metadata and the data-boundary policy live (and who owns them) is unknown; GD-04 is a Governor-side decision. The reference policy is a synthetic table.
- **Engine information required:** Existing classification metadata; policy source of truth.
- **Question for Amir:** Where is data classification currently recorded, and which system owns the data-boundary policy?
- **Source / file / config / DB evidence required:** DB-10 evidence; policy source location; GD-04 decision by the owner.
- **Implementation step Amir performs:** Implement PolicyPort.decide over the real policy source: return None when a classification/destination pair is not covered. Copy port_contracts/templates/test_policy_binding.py.template to tests/binding/test_policy_binding.py and point the factory at the new binding. Run the suite.
- **Amir must modify Engine code?:** NO (binding only)
- **DB access required?:** CONDITIONAL: read access to classification metadata (non-production)
- **Staging / non-production sufficient?:** YES
- **Validation command / procedure:** python3 -W ignore -m unittest tests.binding.test_policy_binding -v   (If the Engine is not Python, implement the language-neutral cases listed for this port in docs/PORT_CONFORMANCE_CASES.md in the Engine's own test framework and return their output instead.)
- **Expected result:** All PolicyPortContract cases pass: undeterminable pairs return None; unknown destinations are never implicitly allowed.
- **Evidence to return:** unittest output; binding source.
- **Unblocks:** Real AUIF-AT-21; removes the synthetic policy dependency.
- **Dependencies / blockers:** AMIR-TODO-01; owner decision GD-04
- **Status:** OPEN

Verbatim extracts from the audited register:

- `DB-10` {"title": "Existing data classification metadata", "exact_amir_instruction": "Report whether any column, table or field already carries sensitivity classification (for example PII or health tagging) and where it is defined.", "required_database_environment": "Read access to schema and model definitions", "validation_procedure": "Tags located or confirmed absent", "required_closure_evidence": "Cited locations or an explicit statement of absence with the search performed"}
- `GD-04` {"title": "Policy and authorisation source for data boundary enforcement", "detail": "Handoff section 24 requires policy and authorisation before data leaves the boundary but not where policy lives or how authorisation is requested."}

# DOCUMENTATION_CORRECTIONS_rev6.1

This package is a **documentation-only correction** of the independently audited rev6 (zip sha256 `b7956f0094150cd49cf177a970f24a37bbe56e51b30bea425c7591e5111b5332`). It exists because rev6 contained statements that had become stale during the audit rounds; they were corrected before handoff. Changing any file changes the zip hash, so the corrected package is a new artifact with a new hash. The audited rev6 zip is preserved unchanged.

## What did not change

- **No file under `auif/`, `contracts/`, `synthetic/`, `auif_ref/`, `port_contracts/` or `tests/` changed.** Byte-compared against rev6.
- **The core tree hash is identical:** `5f27396249ea4f036fbc51bc9dad69134389d667a46a9962e8948d819bdb84d9`.
- No mutant, mutation result, test or acceptance result changed: 363 tests, 90 mutants, 90 killed.
- Architecture, contracts, Governor and the audited architecture package are untouched. No open limitation, decision or finding was resolved or reworded beyond the statements below.

## What changed

| Where | Was | Now |
| --- | --- | --- |
| `README.md` | mutation testing takes "about 2.5 minutes" | roughly 16 to 18 minutes on the reference machine; the shipped verifier waits for it |
| `RTM_ARCH_TO_IMPL.md` and `.json`; `COMPONENT_STATUS.md` and `.json` (row AR-19) | "mutation (33/33)" | a pointer to `evidence/mutation_results.json` (90 mutants, 90 killed), so it cannot go stale again |
| `KNOWN_LIMITATIONS.md` item 5 | 42 mutants | 90 |
| `KNOWN_LIMITATIONS.md` item 6 | "No independent audit has been performed" | independently audited in three rounds; the authorship caveat is kept and the line-by-line review of the foreign-origin files is stated as not done |
| `KNOWN_LIMITATIONS.md` item 10 | restart restores state, manifest binding and fingerprint | also the persisted discovery record since rev3 (see item 21) |
| `docs/PERSISTENCE_COLLECTIONS.md` | 21 collections | 22: adds `discovery_latest` (regenerated from the code) |
| `AMIR_ENGINE_DEPENDENCY_TODO.md` and `.json` (item 02); `AMIR_HANDOFF.md` | "8 ModulePort operations" | the ModulePort interface: 7 abstract methods and the `module_id` attribute |
| `AMIR_HANDOFF.md` banner | "ON HOLD. Not released to Amir" | "RELEASED FOR HANDOFF", pointing to the accompanying overview document |
| `BUILD_REPORT.md` section 1 | "42 chosen" guards | refers to the 90 in `evidence/mutation_results.json` |
| `BUILD_REPORT.md` section 5 | results "not independently audited"; "An independent audit of this build has not been performed" | independently audited in three rounds; authorship of the foreign-origin part is still unestablished and fully reviewing it line by line has not been done |
| `BUILD_REPORT.md` sections 6 to 8 | "resolved, awaiting re-audit / awaiting audit" | confirmed by the following audit; rev6 independently accepted (not frozen) |
| `BUILD_REPORT.md` sections 9 and 10 | rev6 "NOT frozen until audited"; "Do not send anything to Amir yet"; next action "independent audit of rev6" | rev6 audited and accepted; rev6.1 described; released for handoff; the audit action recorded as done |
| `evidence/SECOND_PASS_VERIFICATION.md` | (historical, 42 mutants) | a note prepended saying it is a historical record |
| `tools/amir_items.py`, `tools/gen_reports.py`, `tools/gen_final.py` | the same stale text in the generators | corrected, so regenerating the documents cannot restore it |

## Files changed from rev6

- `AMIR_ENGINE_DEPENDENCY_TODO.json`
- `AMIR_ENGINE_DEPENDENCY_TODO.md`
- `AMIR_HANDOFF.md`
- `BUILD_REPORT.md`
- `COMPONENT_STATUS.json`
- `COMPONENT_STATUS.md`
- `FILE_MANIFEST.json`
- `KNOWN_LIMITATIONS.md`
- `README.md`
- `RTM_ARCH_TO_IMPL.json`
- `RTM_ARCH_TO_IMPL.md`
- `docs/PERSISTENCE_COLLECTIONS.md`
- `evidence/SECOND_PASS_VERIFICATION.md`
- `tools/amir_items.py`
- `tools/gen_final.py`
- `tools/gen_reports.py`

## Files added


- `DOCUMENTATION_CORRECTIONS_rev6.1.md` (this note)

## How to confirm it yourself

Extract the audited rev6 zip and this package, then compare `auif/`, `contracts/`, `synthetic/`, `auif_ref/`, `port_contracts/` and `tests/` byte for byte (they are identical), and run `python3 tools/static_checks.py` here: `core_tree_sha256` must print `5f27396249ea4f036fbc51bc9dad69134389d667a46a9962e8948d819bdb84d9`. `python3 tools/verify_fresh_zip.py` still passes end to end.

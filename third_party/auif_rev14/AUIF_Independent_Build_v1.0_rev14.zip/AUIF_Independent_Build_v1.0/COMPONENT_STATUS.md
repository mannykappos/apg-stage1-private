# COMPONENT_STATUS

Per architecture section (AR-n), derived from `RTM_ARCH_TO_IMPL.json`. Three categories, as required by the build authorization. All evidence is on the SYNTHETIC world; nothing here is an Engine result.

- **BUILT AND VERIFIED**: implemented and tested here. Sections with a non-empty verified scope: 24 of 24.
- **BUILT BUT ENVIRONMENT-DEPENDENT**: implemented here; final validation needs Amir / live infrastructure. Sections: 13.
- **BLOCKED - AMIR REQUIRED**: cannot be implemented without Engine facts. Sections with a blocked part: 5.

| AR | Title | Verified scope | Environment-dependent scope | Blocked scope | Amir items | AT |
|---|---|---|---|---|---|---|
| AR-0 | Reading rules and tagging | Audited inputs copied byte-identically (verified) | - | - | - | AT-27, AT-28 |
| AR-1 | Purpose and commercial shape | Document only | - | - | - | AT-01, AT-02, AT-16 |
| AR-2 | Separation of concerns | Core depends only on stdlib and itself; ports are the only boundary (static check, AT-17/28) | - | - | - | AT-02, AT-03, AT-16 |
| AR-3 | Governor boundary | AUIF requests and reports only; no authority API exists (static scan); governed action never sent without a decision (AT-13, M11/M25/M28) | Real Governor wiring (EP-07); GD-03/GD-05 open | - | AMIR-TODO-07 | AT-13, AT-26, AT-27 |
| AR-4 | Component model and isolation | Core/synthetic separation; core tree hash unchanged when a 4th system is added (AT-01/02/16) | - | - | - | AT-01, AT-02, AT-03, AT-16, AT-17 |
| AR-5 | Connection Layer / Connector contract | Contract enforcement, retry/Retry-After, idempotency-gated writes, failure principle, cancellation, credential boundary (AT-08/11/14/18/20) | Real transports and credentials | - | AMIR-TODO-05, AMIR-TODO-09 | AT-02, AT-03, AT-08, AT-17, AT-18, AT-30 |
| AR-6 | Discovery, fingerprint, drift | Records, deterministic fingerprints, scoped drift (AT-05) | Materiality policy (OD-05) is a draft position | - | - | AT-02, AT-05, AT-07, AT-18 |
| AR-7 | Canonical Anchor Model boundary | Framework, typed validation, classification, provenance chain (AT-19/22) | - | The REAL Anchor canonical attribute sets (OD-08) | AMIR-TODO-11 | AT-04, AT-16, AT-19, AT-21 |
| AR-8 | Translation Packs | Immutable hashed registry, pinning, bidirectional translation, explicit outcomes, outbound validation (AT-03/04/06/19/23); ONE shared transform validator for the registry, runtime and AI validator, and hostile data values are explicit per-field failures (audit round 1: F1, F5) | - | Real target packs (McGrath) | AMIR-TODO-13 | AT-03, AT-04, AT-06, AT-15, AT-17, AT-19, AT-23 |
| AR-9 | Ambiguity and AI boundary | AI proposes only; deterministic promotion with full transform validation; sandbox; proposer OUTPUT treated as untrusted input; ambiguity-resolution evidence hash-bound into the validation record; untrusted text (AT-07/25; audit round 1: F1, F2, F3); promotion evidence binds the complete mapping and the registry recognises AI promotion by its evidence (audit round 2: F6) | Real AI service binding | - | AMIR-TODO-17 | AT-07, AT-14, AT-25 |
| AR-10 | Observations, provenance, ordering | Envelopes, causal ordering, bounded wait then reconcile, dedupe (AT-09/10/22) | - | - | - | AT-09, AT-10, AT-22 |
| AR-11 | Backpressure and throttling | Token bucket, Retry-After, circuit breaker, bounded queues, tenant-fair scheduling (AT-08/30) | Fairness on the platform's real workers | - | AMIR-TODO-06 | AT-08, AT-29, AT-30 |
| AR-12 | Classification and boundary enforcement | Policy-driven allow/transform/reject; undeterminable means reject (AT-21) | The real policy source (GD-04/OD-09) | - | AMIR-TODO-18 | AT-21 |
| AR-13 | Actions, ledger, idempotency | Ledger transition table, durable before send, idempotency, no blind retry, reconciliation (AT-11/13); submission is a resumable write-ahead intent: a failure at any single write cannot strand an action or a key (audit round 2: F7); an action's tenant must equal the authenticated context before any record is written (audit round 3: F9) | Durable ledger on real storage | - | AMIR-TODO-04 | AT-11, AT-13, AT-21, AT-27 |
| AR-14 | Integration state machine and manifest | ACTIVE only via validation; failure distinctions; manifests carry no authority; discovery record persisted, restored on restart and re-taken on resume, and the pack gate fails closed without one (AT-05/06; audit round 1: F4) | - | - | - | AT-05, AT-06, AT-18 |
| AR-15 | Tenant isolation, credentials, security | Forged/missing context refused; hostile input; no secret in outputs (AT-12/14/20/24); a caller-supplied action tenant is verified against the authenticated context (audit round 3: F9) | Isolation on real data layer, secrets and infrastructure | - | AMIR-TODO-03, AMIR-TODO-05, AMIR-TODO-16 | AT-12, AT-14, AT-20, AT-23, AT-24 |
| AR-16 | Versioning | Pack/model/contract compatibility checks; manifest versions | - | - | - | AT-06, AT-23 |
| AR-17 | Observability and performance | 15 required signals, redaction (AT-24); synthetic performance measured (AT-29) | Real sink and real performance | - | AMIR-TODO-08, AMIR-TODO-14 | AT-24, AT-29 |
| AR-18 | Anchor module contract | Module Port against reference modules; module isolation | Real module binding; descriptor format OD-22 is reference-only | Anchor Real Estate specifics | AMIR-TODO-02, AMIR-TODO-12 | AT-01 |
| AR-19 | Proving ground and testing strategy | Synthetic world, acceptance, mutation testing (see evidence/mutation_results.json), static checks | - | McGrath proof (AT-15) | AMIR-TODO-13 | AT-01, AT-02, AT-03, AT-04, AT-05, AT-06, AT-07, AT-08, AT-09, AT-10, AT-11, AT-12, AT-13, AT-14, AT-15, AT-16, AT-17, AT-26 |
| AR-20 | Engine boundary (ED-01..14) | Ports and conformance suites exist; every Engine fact recorded as UNKNOWN | All bindings | Reconnaissance | AMIR-TODO-01, AMIR-TODO-02, AMIR-TODO-03, AMIR-TODO-04, AMIR-TODO-05, AMIR-TODO-06, AMIR-TODO-07, AMIR-TODO-08, AMIR-TODO-09, AMIR-TODO-10, AMIR-TODO-15 | AT-28 |
| AR-21 | Reference vs production; DB-dependent closure | Two reference stores pass the persistence conformance suite | DB-dependent closure items (DB-01..DB-10) | - | AMIR-TODO-04, AMIR-TODO-18 | AT-28 |
| AR-22 | Order, gates, evidence, change control | Evidence, manifest and hashes | Architecture LOCK remains gated on reconnaissance review | - | AMIR-TODO-01 | AT-27, AT-28 |
| AR-23 | What remains open | Open items recorded; none resolved here | - | - | - | - |

## Acceptance tests by category

- **BUILT BUT ENVIRONMENT-DEPENDENT** (10): 01, 05, 12, 13, 20, 21, 24, 27, 29, 30
- **BUILT AND VERIFIED** (19): 02, 03, 04, 06, 07, 08, 09, 10, 11, 14, 16, 17, 18, 19, 22, 23, 25, 26, 28
- **BLOCKED - AMIR REQUIRED** (1): 15

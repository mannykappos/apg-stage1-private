"""Data classification and boundary enforcement (architecture AR-12). The outcome depends on classification, destination and POLICY INPUT; AUIF performs deterministic transformations
and never authors policy or grants authorisation (GD-04 / OD-09 open). If the policy cannot be determined for a datum, nothing is sent."""
from .util import sha
def _mask(v): s = str(v); return "*" * max(0, len(s) - 2) + s[-2:]
def _minimise(v): s = str(v); return "@" + s.split("@", 1)[1] if "@" in s else s[:1] + "***"
TRANSFORMS = {"mask": _mask, "redact": lambda v: "[REDACTED]", "minimise": _minimise, "omit": None}
class BoundaryEnforcer:
    def __init__(self, policy, telemetry=None): self.policy, self.tel = policy, telemetry
    def enforce(self, ctx, attrs, classes, destination, context=None):
        per, out, needs, reject = [], {}, [], None
        for a, v in attrs.items():
            cls = classes.get(a, "INTERNAL"); d = self.policy.decide(ctx, cls, destination, context or {})
            if d is None: reject = reject or "policy undeterminable for %s data to %s" % (cls, destination.get("kind")); per.append({"attribute": a, "classification": cls, "outcome": "UNDETERMINABLE"}); continue
            o = d["outcome"]; per.append({"attribute": a, "classification": cls, "outcome": o, "basis": d.get("basis", "")})
            if o == "REJECT": reject = reject or "policy rejects %s data to %s" % (cls, destination.get("kind"))
            elif o == "NEEDS_AUTHORISATION": needs.append(a); out[a] = v
            elif o in ("TRANSFORM", "MASK"):
                for t in d.get("transforms", ["mask"]):
                    if t == "omit": v = None; break
                    if t == "pseudonymise": v = "pseud:" + sha([ctx.tenant_id, str(v)])[:16]
                    else: v = TRANSFORMS[t](v)
                if v is not None: out[a] = v
            else: out[a] = v
        if reject: return {"decision": "REJECTED", "reason": reject, "payload": None, "evidence": per, "needs_authorisation": []}
        if needs: return {"decision": "NEEDS_AUTHORISATION", "reason": "policy requires an authorisation decision", "payload": out, "evidence": per, "needs_authorisation": needs}
        return {"decision": "TRANSFORMED" if out != attrs else "ALLOW", "reason": "", "payload": out, "evidence": per, "needs_authorisation": []}

"""Observation envelopes and event sequencing (architecture AR-10). Timestamps never establish causal order; a missing predecessor never produces fabricated state."""
from .contracts import validate
from .util import sha
class ObservationFactory:
    def __init__(self, store, ids, clock): self.store, self.ids, self.clock = store, ids, clock
    def build(self, ctx, integration_id, *, observation_id=None, anchor_module, target_system_id, environment_id, connector_id, source_system, source_object, source_version, pack_ref, schema_fingerprint, payload, classification, confidence, provenance, causal=None, source_sequence=None, ordering_state="IN_ORDER", manifest_version=None, observed_at=None):
        o = {"contract_kind": "Observation", "observation_id": observation_id or self.ids.next("obs"), "tenant_id": ctx.tenant_id, "anchor_module": anchor_module, "target_system_id": target_system_id, "environment_id": environment_id, "connector_id": connector_id, "source_system": source_system, "source_object": source_object,
             "source_version": source_version or "NOT_PROVIDED_BY_SOURCE", "translation_pack_id": pack_ref["id"], "translation_pack_version": pack_ref["version"], "schema_fingerprint": schema_fingerprint, "observed_at": observed_at or self.clock.iso(), "received_at": self.clock.iso(),
             "adapter_sequence": self.store.next_sequence(ctx, "adapter-seq:" + integration_id), "payload_hash": sha(payload), "classification": classification, "confidence": confidence, "provenance": provenance, "ordering_state": ordering_state}
        if source_sequence is not None: o["source_sequence"] = source_sequence
        if causal: o["causal"] = causal
        if manifest_version: o["manifest_version"] = manifest_version
        return validate("canonical#Observation", o)
class Sequencer:
    """Applies events in CAUSAL order. Outcomes for a missing predecessor are deterministic and evidenced: QUEUE (bounded wait, then RECONCILE), DEFER, RECONCILE or REJECT (OD-06 draft position: QUEUE then RECONCILE)."""
    def __init__(self, store, clock, policy=None): self.store, self.clock, self.policy = store, clock, policy or {}
    def _pol(self, etype): p = self.policy.get(etype) or self.policy.get("*") or {}; return p.get("on_missing", "QUEUE"), float(p.get("wait_seconds", 60.0))
    def _missing(self, ctx, integ, ev):
        miss = [d for d in ev.get("depends_on", []) if self.store.get(ctx, "seq_applied:" + integ, d) is None]
        n = ev.get("source_sequence")
        if n is not None and n > 1 and self.store.get(ctx, "seq_applied_n:" + integ, str(n - 1)) is None: miss.append("seq:%d" % (n - 1))
        return miss
    def _apply(self, ctx, integ, ev, aseq):
        self.store.put(ctx, "seq_applied:" + integ, ev["event_id"], {"payload_hash": sha([ev["type"], ev.get("payload")]), "adapter_sequence": aseq, "applied_at": self.clock.iso()})
        if ev.get("source_sequence") is not None: self.store.put(ctx, "seq_applied_n:" + integ, str(ev["source_sequence"]), {"event_id": ev["event_id"]})
    def _decision(self, ev, state, aseq, missing=None, extra=None):
        d = {"event": ev, "ordering_state": state, "adapter_sequence": aseq}
        if missing: d["waiting_on"] = list(missing)
        if extra: d.update(extra)
        return d
    def receive(self, ctx, integ, ev):
        aseq = self.store.next_sequence(ctx, "adapter-seq-events:" + integ); h = sha([ev["type"], ev.get("payload")]); eid = ev["event_id"]
        prev = self.store.get(ctx, "seq_applied:" + integ, eid) or (self.store.get(ctx, "seq_pending:" + integ, eid) or {}).get("receipt")
        if prev is not None:
            if prev["payload_hash"] == h: return [self._decision(ev, "DUPLICATE_SUPPRESSED", aseq)]
            self.store.put(ctx, "seq_conflicts:" + integ, "%s:%06d" % (eid, aseq), {"event_id": eid, "first_hash": prev["payload_hash"], "second_hash": h}); return [self._decision(ev, "RECONCILIATION_PENDING", aseq, extra={"conflict": True})]
        miss = self._missing(ctx, integ, ev)
        if not miss: self._apply(ctx, integ, ev, aseq); return [self._decision(ev, "IN_ORDER", aseq)] + self._release(ctx, integ)
        action, wait = self._pol(ev["type"])
        if action == "REJECT": return [self._decision(ev, "REJECTED_BY_POLICY", aseq, miss)]
        if action == "RECONCILE": self._reconcile(ctx, integ, ev, aseq, miss); return [self._decision(ev, "RECONCILIATION_PENDING", aseq, miss)]
        self.store.put(ctx, "seq_pending:" + integ, eid, {"event": ev, "aseq": aseq, "deadline": None if action == "DEFER" else self.clock.now + wait, "receipt": {"payload_hash": h}})
        return [self._decision(ev, "DEFERRED" if action == "DEFER" else "QUEUED_AWAITING_PREDECESSOR", aseq, miss)]
    def _reconcile(self, ctx, integ, ev, aseq, miss): self.store.put(ctx, "seq_reconcile:" + integ, ev["event_id"], {"event_id": ev["event_id"], "waiting_on": miss, "requested_at": self.clock.iso(), "adapter_sequence": aseq})
    def _release(self, ctx, integ):
        out, progress = [], True
        while progress:
            progress = False
            for eid, p in self.store.list(ctx, "seq_pending:" + integ):
                if p.get("done") or p.get("released"): continue
                ev = p["event"]
                if not self._missing(ctx, integ, ev):
                    self._apply(ctx, integ, ev, p["aseq"]); self.store.put(ctx, "seq_pending:" + integ, eid, dict(p, released=True)); self._drop(ctx, integ, eid); out.append(self._decision(ev, "IN_ORDER", p["aseq"], extra={"released_from_queue": True})); progress = True; break
        return out
    def _drop(self, ctx, integ, eid): self.store.update(ctx, "seq_pending:" + integ, eid, lambda o: dict(o, done=True))
    def tick(self, ctx, integ):
        """Bounded wait expired and the predecessor still has not arrived: RECONCILE. Never invents state."""
        out = []
        for eid, p in self.store.list(ctx, "seq_pending:" + integ):
            if p.get("done") or p.get("released") or p["deadline"] is None or self.clock.now < p["deadline"]: continue
            miss = self._missing(ctx, integ, p["event"])
            if miss: self._reconcile(ctx, integ, p["event"], p["aseq"], miss); self._drop(ctx, integ, eid); out.append(self._decision(p["event"], "RECONCILIATION_PENDING", p["aseq"], miss))
        return out
    def pending(self, ctx, integ): return [e for e, p in self.store.list(ctx, "seq_pending:" + integ) if not p.get("done")]

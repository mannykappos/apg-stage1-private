"""The AUIF runtime: wires connectors, discovery, translation, observations, sequencing, boundary enforcement, actions, the state machine and the module/Governor ports into end-to-end flows."""
from types import SimpleNamespace
from .action import ActionService
from .classification import BoundaryEnforcer
from .connector import ConnectorRuntime
from .contracts import validate
from .discovery import DiscoveryEngine
from .errors import *
from .integration import IntegrationController, IntegrationRegistry
from .modules import ModuleRegistry
from .observation import ObservationFactory, Sequencer
from .security import InputGuard
from .translation import Translator
from .util import sha
IDENTITY_CONTENT_HASH = "CONTENT_HASH"            # rev14 (M8-F2): the ONLY way to ask for a content-hash identity; it is never a silent fallback
NOT_APPLIED = ("QUEUED_AWAITING_PREDECESSOR", "DEFERRED", "RECONCILIATION_PENDING", "REJECTED_BY_POLICY")
def source_identity(spec, record):
    """rev14 (M8-F2, M8-F6). spec: one field name, a list of field names (a composite identity), or IDENTITY_CONTENT_HASH.  -> (source id, None) or (None, why).
    A field that is absent, null, blank, or not a scalar makes the record's identity missing: it is refused as one record, never replaced by a hash."""
    if spec == IDENTITY_CONTENT_HASH: return sha(record)[:12], None
    fields = list(spec) if isinstance(spec, (list, tuple)) else [spec]
    if not fields or not all(isinstance(f, str) and f for f in fields): return None, "the identity declaration is not a field name or a list of field names"
    vals = []
    for f in fields:
        v = record.get(f) if isinstance(record, dict) else None
        if v is None or isinstance(v, (dict, list, bool)) or (isinstance(v, str) and not v.strip()): return None, "identity field %s is missing or blank" % f
        vals.append(str(v))
    return (vals[0] if len(vals) == 1 else "|".join(x.replace("\\", "\\\\").replace("|", "\\|") for x in vals)), None
class Fabric:
    def __init__(self, *, store, authority, secrets, governor, policy, clock, telemetry, ids, model, packs, throttle, guard=None, sequencer_policy=None):
        self.store, self.auth, self.secrets, self.gov, self.clock, self.tel, self.ids, self.model, self.packs, self.th, self.guard = store, authority, secrets, governor, clock, telemetry, ids, model, packs, throttle, guard or InputGuard()
        self.discovery, self.translator, self.modules, self.registry = DiscoveryEngine(clock, ids), Translator(model, packs, ids, clock), ModuleRegistry(), IntegrationRegistry(); self.sequencer, self.obs, self.sot, self.cfg = Sequencer(store, clock, sequencer_policy or {"*": {"on_missing": "QUEUE", "wait_seconds": 30}}), ObservationFactory(store, ids, clock), {}, {}
        self.deps = SimpleNamespace(store=store, clock=clock, ids=ids, tel=telemetry, discovery=self.discovery, packs=packs, model=model, governor=governor, notify=self._notify); self.actions = ActionService(store, clock, ids, telemetry, self.translator, BoundaryEnforcer(policy), governor, self.registry, self.guard)
    def register_module(self, module): self.modules.register(module)
    def _notify(self, ctx, module_id, state):
        try: failed = self._failed(self.modules.get(module_id).receive_integration_state(ctx, state))
        except NotFound: failed = False
        except Exception: failed = True
        if failed: self._module_failed(ctx, state.get("integration_id", "-"), "state")             # rev14 (M8-F4): counted and recorded, never silent, never fatal to the transition
    def add_integration(self, ctx, integration_id, *, anchor_module, connector, pack_ref, target_system_id, environment_id, governed_operations=(), entities=(), destination_kind="customer-system", event_entities=None, identity_fields=None):
        self.auth.require(ctx); rt = ConnectorRuntime(connector, secrets=self.secrets, throttle=self.th, telemetry=self.tel, clock=self.clock, guard=self.guard)
        c = IntegrationController(self.deps, ctx, integration_id, anchor_module, target_system_id, environment_id, rt, pack_ref, governed_operations=governed_operations, entities=entities, destination_kind=destination_kind); c.rehydrate(); self.registry.add(c); self.cfg[(ctx.tenant_id, integration_id)] = {"event_entities": event_entities or {}, "identity": identity_fields or {}}; return c
    def integration(self, ctx, integration_id): self.auth.require(ctx); return self.registry.get(ctx, integration_id)
    def _error(self, ctx, module_id, kind, **d):
        self.tel.inc(ctx.tenant_id, d.get("integration", "-"), "failures"); self._tell(ctx, module_id, kind, **d)
    def _tell(self, ctx, module_id, kind, **d):
        try: failed = self._failed(self.modules.get(module_id).receive_integration_error(ctx, dict({"kind": kind}, **d)))
        except NotFound: failed = False
        except Exception: failed = True
        if failed: self._module_failed(ctx, d.get("integration", "-"), "error")
    def _module_failed(self, ctx, integration_id, what):
        """rev14 (M8-F4): a module that raised, or reported a handler failure, while AUIF delivered something to it. Counted and recorded by type of delivery only (never the message)."""
        self.tel.inc(ctx.tenant_id, integration_id, "module_failures")
        self.store.put(ctx, "module_delivery_failures", "%s:%06d" % (integration_id, self.store.next_sequence(ctx, "module-failures:" + integration_id)), {"integration_id": integration_id, "delivery": what, "at": self.clock.iso()})
    @staticmethod
    def _failed(result): return isinstance(result, dict) and bool(result.get("handler_failures"))
    def _canonical_apply(self, ctx, obj, source_system):
        """Single owning source per canonical id unless a source of truth is explicitly declared. Observations never write governance state: this store holds canonical DATA only (AT-26)."""
        key = obj["canonical_id"]; cur = self.store.get(ctx, "canonical_objects", key)
        if cur and cur["source_system"] != source_system and self.sot.get(obj["canonical_type"]) != source_system:
            self.store.put(ctx, "canonical_conflicts", "%s:%06d" % (key, self.store.next_sequence(ctx, "canonical-conflicts")), {"canonical_id": key, "owner": cur["source_system"], "claimant": source_system}); return False
        self.store.put(ctx, "canonical_objects", key, {"object": obj, "source_system": source_system}); return True
    def _ingest_record(self, ctx, c, entity, record, *, event=False, ordering_state="IN_ORDER", source_sequence=None, causal=None):
        """-> (canonical object or None, status): delivered | invalid | ambiguous | refused | conflict | module_failed (rev14: the status says what really happened)."""
        cfg = self.cfg[(ctx.tenant_id, c.integration_id)]; mod = self.modules.get(c.anchor_module)
        sid, why = source_identity(cfg["identity"].get(entity, "id"), record)
        if sid is None: self._error(ctx, c.anchor_module, "IDENTITY_MISSING", integration=c.integration_id, entity=entity, reason=why); return None, "refused"      # rev14 (M8-F2/F6): one record refused, the read goes on
        oid = self.ids.next("obs")
        try: obj = self.translator.translate_inbound(ctx, c.pack_ref, entity, record, source_system=c.target_system_id, observation_id=oid, schema_fingerprint=c.fp["value"], source_id=sid)
        except TranslationFailure as e: self._error(ctx, c.anchor_module, "TRANSLATION_FAILURE", integration=c.integration_id, entity=entity, reason=str(e)); return None, "refused"
        except PackError as e: self._error(ctx, c.anchor_module, "PACK_INTEGRITY_FAILURE", integration=c.integration_id, entity=entity, reason=str(e)[:200]); return None, "refused"
        ok = obj["validation_state"] == "VALID"
        try: ob = self.obs.build(ctx, c.integration_id, observation_id=oid, anchor_module=c.anchor_module, target_system_id=c.target_system_id, environment_id=c.environment_id, connector_id=c.runtime.desc["connector_id"], source_system=c.target_system_id, source_object={"object_type": entity, "object_id": sid}, source_version=None, pack_ref=c.pack_ref,
                            schema_fingerprint=c.fp["value"], payload=record, classification=obj["classification"], confidence={"value": 1.0 if ok else 0.0, "basis": "deterministic pack translation" if ok else "translation did not produce a valid object"}, provenance=obj["provenance_chain"], causal=causal, source_sequence=source_sequence, ordering_state=ordering_state, manifest_version=c.manifest_ref())
        except ContractViolation as e: self._error(ctx, c.anchor_module, "RECORD_REFUSED", integration=c.integration_id, entity=entity, reason=str(e)[:200]); return None, "refused"      # rev14 (M8-F6): reported, not raised
        self.store.put(ctx, "observations", oid, ob)
        if not ok: self._error(ctx, c.anchor_module, obj["validation_state"], integration=c.integration_id, canonical_id=obj["canonical_id"], diagnostics=obj["diagnostics"]); return obj, ("ambiguous" if obj["validation_state"] == "AMBIGUOUS" else "invalid")
        if not self._canonical_apply(ctx, obj, c.target_system_id): self._error(ctx, c.anchor_module, "CANONICAL_CONFLICT", integration=c.integration_id, canonical_id=obj["canonical_id"]); return obj, "conflict"
        try:
            r1 = mod.ingest_canonical_entity(ctx, obj); r2 = (mod.ingest_canonical_event if event else mod.ingest_canonical_observation)(ctx, ob)
            failed = self._failed(r1) or self._failed(r2)
        except Exception: failed = True
        if failed: self._module_failed(ctx, c.integration_id, "event" if event else "entity"); self._tell(ctx, c.anchor_module, "MODULE_DELIVERY_FAILED", integration=c.integration_id, canonical_id=obj["canonical_id"]); return obj, "module_failed"
        return obj, "delivered"
    def sync(self, ctx, integration_id, entity, max_pages=10, page_size=3):
        """rev14 (M8-F5): the report also says whether the read reached the end ('complete'), whether it stopped at max_pages ('stopped_at_page_limit'), and counts records that were
        refused before translation, objects AUIF did not deliver because of a canonical conflict, and deliveries the module failed to take.  'delivered' counts only what the module took."""
        c = self.integration(ctx, integration_id); rep = {"pages": 0, "delivered": 0, "invalid": 0, "ambiguous": 0, "refused": 0, "conflict": 0, "module_failed": 0, "empty": False, "failed": None, "not_allowed": False,
                                                          "complete": False, "stopped_at_page_limit": False}
        if not c.entity_readable(entity): rep["not_allowed"] = True; return rep
        cursor = None
        for _ in range(max_pages):
            out = c.runtime.call(ctx, integration_id, c.target_system_id, c.environment_id, "read", {"entity": entity, "cursor": cursor, "page_size": page_size}); k = out.result["outcome_kind"]
            if k == "NO_DATA": rep["empty"] = True; rep["complete"] = True; break
            if k != "DATA_OBTAINED": rep["failed"] = out.error["code"]; self._error(ctx, c.anchor_module, "SOURCE_UNAVAILABLE" if k == "COULD_NOT_OBTAIN" else "SOURCE_DATA_INVALID", integration=integration_id, error=out.error); break
            rep["pages"] += 1
            for item in out.data["items"]:
                _, status = self._ingest_record(ctx, c, entity, item); rep[status] += 1
            cursor = out.data["next_cursor"]
            if cursor is None: rep["complete"] = True; break
        else: rep["stopped_at_page_limit"] = True
        return rep
    def ingest_events(self, ctx, integration_id, events):
        c = self.integration(ctx, integration_id); cfg = self.cfg[(ctx.tenant_id, integration_id)]; results = []
        for ev in events:
            try: self.guard.check(ev)
            except UntrustedInput as e: self._error(ctx, c.anchor_module, "EVENT_REJECTED", integration=integration_id, reasons=e.reasons[:3]); results.append({"event_id": str(ev.get("event_id"))[:40], "ordering_state": "REJECTED_BY_POLICY"}); continue
            for d in self.sequencer.receive(ctx, integration_id, ev): results.append(self._record_decision(ctx, c, cfg, d))
        for d in self.sequencer.tick(ctx, integration_id): results.append(self._record_decision(ctx, c, cfg, d))
        return results
    def tick(self, ctx, integration_id):
        c = self.integration(ctx, integration_id); cfg = self.cfg[(ctx.tenant_id, integration_id)]; return [self._record_decision(ctx, c, cfg, d) for d in self.sequencer.tick(ctx, integration_id)]
    def _record_decision(self, ctx, c, cfg, d):
        ev, st = d["event"], d["ordering_state"]; entity = cfg["event_entities"].get(ev["type"]); causal = {"event_id": ev["event_id"]}
        if ev.get("depends_on"): causal["parent_id"] = ev["depends_on"][0]
        if st == "QUEUED_AWAITING_PREDECESSOR": causal["expected_predecessor"] = d["waiting_on"][0]
        if st == "IN_ORDER" and entity:
            _, status = self._ingest_record(ctx, c, entity, ev["payload"], event=True, ordering_state=st, source_sequence=ev.get("source_sequence"), causal=causal); return {"event_id": ev["event_id"], "ordering_state": st, "delivered": status == "delivered"}
        ob = self.obs.build(ctx, c.integration_id, anchor_module=c.anchor_module, target_system_id=c.target_system_id, environment_id=c.environment_id, connector_id=c.runtime.desc["connector_id"], source_system=c.target_system_id, source_object={"object_type": entity or "Event", "object_id": ev["event_id"]}, source_version=None, pack_ref=c.pack_ref, schema_fingerprint=c.fp["value"],
                            payload=ev.get("payload"), classification="INTERNAL", confidence={"value": 0.0, "basis": "event not applied: %s" % st}, provenance=[{"step_kind": "SOURCE_SYSTEM", "ref": c.target_system_id}, {"step_kind": "SOURCE_OBJECT", "ref": ev["event_id"]}, {"step_kind": "SOURCE_FIELD", "ref": "event.payload"}, {"step_kind": "TRANSLATION_PACK", "ref": c.pack_ref["id"], "version": c.pack_ref["version"], "hash": c.pack_ref["hash"]}, {"step_kind": "SCHEMA_FINGERPRINT", "ref": "fp", "hash": c.fp["value"]}, {"step_kind": "OBSERVATION", "ref": "pending"}],
                            causal=causal, ordering_state=st)
        self.store.put(ctx, "observations", ob["observation_id"], ob); self.tel.set(ctx.tenant_id, c.integration_id, "queue_depth", len(self.sequencer.pending(ctx, c.integration_id)))
        if st in NOT_APPLIED or st == "IN_ORDER":                                 # rev14 (M8-F3): the module is told about every event that was NOT delivered to it (not a failure count)
            self._tell(ctx, c.anchor_module, "EVENT_NOT_APPLIED", integration=c.integration_id, event_id=ev["event_id"], ordering_state=st, waiting_on=list(d.get("waiting_on", [])),
                       reason="no entity mapping for event type %s" % str(ev.get("type"))[:60] if st == "IN_ORDER" else st)
        return {"event_id": ev["event_id"], "ordering_state": st, "delivered": False}
    def poll_events(self, ctx, integration_id):
        c = self.integration(ctx, integration_id); out = c.runtime.call(ctx, integration_id, c.target_system_id, c.environment_id, "read", {})
        if out.result["outcome_kind"] == "NO_DATA": return []
        if out.result["outcome_kind"] != "DATA_OBTAINED": self._error(ctx, c.anchor_module, "SOURCE_UNAVAILABLE" if out.result["outcome_kind"] == "COULD_NOT_OBTAIN" else "SOURCE_DATA_INVALID", integration=integration_id, error=out.error); return []
        return self.ingest_events(ctx, integration_id, out.data["items"])
    def request_action(self, ctx, module_id, action, dispatch=True):
        self.auth.require(ctx)
        if action["source_module"] != module_id or action["tenant_id"] != ctx.tenant_id: raise TenantContextError("action does not belong to the requesting module or tenant")
        rec = self.actions.submit(ctx, action)
        if dispatch and rec["execution_state"] == "QUEUED":
            try: rec = self.actions.dispatch(ctx, rec["action_id"])
            except GovernanceHold: rec = self.actions.ledger.get(ctx, rec["action_id"])
        return rec

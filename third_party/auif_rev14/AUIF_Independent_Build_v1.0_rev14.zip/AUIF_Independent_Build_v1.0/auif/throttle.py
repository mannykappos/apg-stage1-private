"""Backpressure / Throttling Controller and tenant-fair scheduler (handoff sections 21, 22; architecture AR-11). State is per (tenant, integration)."""
from collections import deque
from .errors import Throttled, CircuitOpen
class Throttle:
    def __init__(self, clock, default_rate=50.0, default_burst=50, breaker_threshold=5, breaker_open_s=30.0):
        self.clock, self.dr, self.db, self.thr, self.open_s, self.cfg, self.st = clock, default_rate, default_burst, breaker_threshold, breaker_open_s, {}, {}
    def configure(self, key, rate, burst): self.cfg[key] = (rate, burst); self.st.pop(key, None)
    def _s(self, key):
        if key not in self.st:
            rate, burst = self.cfg.get(key, (self.dr, self.db)); self.st[key] = {"tokens": float(burst), "t": self.clock.now, "blocked_until": 0.0, "fails": 0, "open_until": 0.0, "half": False, "rate": rate, "burst": burst}
        return self.st[key]
    def peek(self, key):
        s = self._s(key); now = self.clock.now; return max(s["blocked_until"] - now, s["open_until"] - now if s["open_until"] > now else 0.0, 0.0)
    def acquire(self, key):
        s = self._s(key); now = self.clock.now
        if now < s["blocked_until"]: raise Throttled(s["blocked_until"] - now, "RETRY_AFTER")
        if s["open_until"] > now: raise CircuitOpen(s["open_until"] - now)
        if s["open_until"] and s["open_until"] <= now: s["half"] = True; s["open_until"] = 0.0     # half-open: one probe is allowed
        s["tokens"] = min(s["burst"], s["tokens"] + (now - s["t"]) * s["rate"]); s["t"] = now
        if s["tokens"] < 1.0: raise Throttled((1.0 - s["tokens"]) / s["rate"], "RATE")
        s["tokens"] -= 1.0
    def success(self, key): s = self._s(key); s["fails"] = 0; s["half"] = False; s["open_until"] = 0.0
    def failure(self, key, retryable=True, retry_after=None):
        s = self._s(key); now = self.clock.now
        if retry_after is not None: s["blocked_until"] = max(s["blocked_until"], now + float(retry_after))
        if retryable: s["fails"] += 1
        if s["half"] or s["fails"] >= self.thr: s["open_until"] = now + self.open_s; s["half"] = False; s["fails"] = 0
    def circuit(self, key):
        s = self._s(key); now = self.clock.now
        return "OPEN" if s["open_until"] > now else ("HALF_OPEN" if s["half"] else "CLOSED")
class FairScheduler:
    """Per-(tenant, integration) bounded queues served round-robin across tenants: one tenant's throttled target cannot stall another's tasks."""
    def __init__(self, clock, throttle, max_queue=1000): self.clock, self.th, self.mq, self.q, self.order, self.done, self.rr = clock, throttle, max_queue, {}, [], {}, 0
    def submit(self, key, task):
        q = self.q.setdefault(key, deque())
        if len(q) >= self.mq: return False                      # bounded: backpressure signal to the caller, never unbounded growth
        q.append(task)
        if key[0] not in self.order: self.order.append(key[0])
        return True
    def depth(self, key=None): return sum(len(q) for q in self.q.values()) if key is None else len(self.q.get(key, ()))
    def run(self, passes=100, tick=0.1):
        for _ in range(passes):
            progressed = False
            if not self.order: break
            for i in range(len(self.order)):
                tenant = self.order[(self.rr + i) % len(self.order)]
                for key in [k for k in self.q if k[0] == tenant and self.q[k]]:
                    if self.th.peek(key) > 0: continue
                    task = self.q[key].popleft()
                    try: task(); self.done[key] = self.done.get(key, 0) + 1; progressed = True
                    except Throttled: self.q[key].append(task)
                    break
            self.rr = (self.rr + 1) % max(1, len(self.order)); self.clock.sleep(tick)
            if not progressed and all(not q for q in self.q.values()): break
        return dict(self.done)

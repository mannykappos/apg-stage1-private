#!/usr/bin/env python3
"""AUIF schema validator (stdlib-only, Python). Implements a DEFINED SUBSET of JSON Schema 2020-12 and FAILS CLOSED: any keyword outside the subset raises SchemaError,
so a constraint can never be silently ignored. Registry: absolute $id URI -> schema document. NOT a replacement for a mature validator (ajv / jsonschema): re-run the schemas through one in your environment."""
import json, re
ANNOTATIONS = {"$schema", "$id", "$defs", "$comment", "title", "description", "examples", "default", "format"}
KEYWORDS = ANNOTATIONS | {"$ref", "type", "enum", "const", "pattern", "minLength", "maxLength", "minimum", "maximum", "exclusiveMinimum", "exclusiveMaximum", "multipleOf", "minItems", "maxItems", "uniqueItems", "items",
    "required", "properties", "additionalProperties", "patternProperties", "propertyNames", "minProperties", "maxProperties", "oneOf", "anyOf", "allOf", "not", "if", "then", "else"}
class SchemaError(Exception): pass
def is_bool(x): return isinstance(x, bool)
def is_num(x): return isinstance(x, (int, float)) and not is_bool(x)
def is_int(x): return (isinstance(x, int) and not is_bool(x)) or (isinstance(x, float) and x.is_integer())
def jtype(x, t):
    return {"string": isinstance(x, str), "number": is_num(x), "integer": is_int(x), "boolean": is_bool(x), "array": isinstance(x, list), "object": isinstance(x, dict), "null": x is None}[t]
def jeq(a, b):
    if is_bool(a) or is_bool(b): return is_bool(a) and is_bool(b) and a == b
    if is_num(a) and is_num(b): return a == b
    if isinstance(a, list) and isinstance(b, list): return len(a) == len(b) and all(jeq(x, y) for x, y in zip(a, b))
    if isinstance(a, dict) and isinstance(b, dict): return a.keys() == b.keys() and all(jeq(a[k], b[k]) for k in a)
    return type(a) == type(b) and a == b
def pointer(doc, frag):
    node = doc
    for part in [p for p in frag.split("/") if p != ""] if frag else []:
        part = part.replace("~1", "/").replace("~0", "~")
        if isinstance(node, list): node = node[int(part)]
        elif isinstance(node, dict) and part in node: node = node[part]
        else: raise SchemaError("unresolvable pointer: #%s" % frag)
    return node
class Validator:
    def __init__(self, registry): self.reg = registry
    def check_schema(self, s, path="#"):
        if isinstance(s, bool): return
        if not isinstance(s, dict): raise SchemaError("%s: schema must be an object or boolean" % path)
        for k, v in s.items():
            if k not in KEYWORDS: raise SchemaError("%s: unsupported keyword %r (validator fails closed)" % (path, k))
            if k == "$defs" or k == "properties" or k == "patternProperties":
                for n, sub in v.items(): self.check_schema(sub, "%s/%s/%s" % (path, k, n))
            elif k in ("items", "additionalProperties", "not", "if", "then", "else", "propertyNames"): self.check_schema(v, path + "/" + k)
            elif k in ("oneOf", "anyOf", "allOf"):
                for i, sub in enumerate(v): self.check_schema(sub, "%s/%s/%d" % (path, k, i))
    def validate(self, instance, schema, base=""):
        saved = self.reg; self.reg = dict(saved); self.reg.setdefault(base, schema)      # the root schema is its own base for local '#/...' references
        try:
            errs = []; self._v(instance, schema, base, "", errs); return errs
        finally: self.reg = saved
    def _ref(self, ref, base):
        uri, _, frag = ref.partition("#")
        uri = uri or base
        if uri not in self.reg: raise SchemaError("unknown schema URI %r" % uri)
        return pointer(self.reg[uri], frag), uri
    def _v(self, x, s, base, path, errs):
        if s is True: return
        if s is False: errs.append((path or "/", "false", "schema is false")); return
        if "$id" in s and s["$id"] in self.reg: base = s["$id"]
        for k in s:
            if k not in KEYWORDS: raise SchemaError("unsupported keyword %r (validator fails closed)" % k)
        P = path or "/"
        if "$ref" in s:
            tgt, nb = self._ref(s["$ref"], base); self._v(x, tgt, nb, path, errs)
        if "type" in s:
            ts = s["type"] if isinstance(s["type"], list) else [s["type"]]
            if not any(jtype(x, t) for t in ts): errs.append((P, "type", "expected %s" % ts)); return
        if "enum" in s and not any(jeq(x, e) for e in s["enum"]): errs.append((P, "enum", "not one of the allowed values"))
        if "const" in s and not jeq(x, s["const"]): errs.append((P, "const", "must equal %r" % (s["const"],)))
        if isinstance(x, str):
            n = len(x)
            if "minLength" in s and n < s["minLength"]: errs.append((P, "minLength", "too short"))
            if "maxLength" in s and n > s["maxLength"]: errs.append((P, "maxLength", "too long"))
            if "pattern" in s and not re.search(s["pattern"], x): errs.append((P, "pattern", "does not match %s" % s["pattern"]))
        if is_num(x):
            if "minimum" in s and x < s["minimum"]: errs.append((P, "minimum", "below minimum"))
            if "maximum" in s and x > s["maximum"]: errs.append((P, "maximum", "above maximum"))
            if "exclusiveMinimum" in s and x <= s["exclusiveMinimum"]: errs.append((P, "exclusiveMinimum", "not above exclusive minimum"))
            if "exclusiveMaximum" in s and x >= s["exclusiveMaximum"]: errs.append((P, "exclusiveMaximum", "not below exclusive maximum"))
            if "multipleOf" in s and abs(round(x / s["multipleOf"]) * s["multipleOf"] - x) > 1e-9: errs.append((P, "multipleOf", "not a multiple"))
        if isinstance(x, list):
            if "minItems" in s and len(x) < s["minItems"]: errs.append((P, "minItems", "too few items"))
            if "maxItems" in s and len(x) > s["maxItems"]: errs.append((P, "maxItems", "too many items"))
            if s.get("uniqueItems") and any(jeq(x[i], x[j]) for i in range(len(x)) for j in range(i + 1, len(x))): errs.append((P, "uniqueItems", "items not unique"))
            if "items" in s:
                for i, it in enumerate(x): self._v(it, s["items"], base, "%s/%d" % (path, i), errs)
        if isinstance(x, dict):
            if "required" in s:
                for r in s["required"]:
                    if r not in x: errs.append(((path + "/" + r) if path else "/" + r, "required", "missing required property %r" % r))
            if "minProperties" in s and len(x) < s["minProperties"]: errs.append((P, "minProperties", "too few properties"))
            if "maxProperties" in s and len(x) > s["maxProperties"]: errs.append((P, "maxProperties", "too many properties"))
            props = s.get("properties", {}); pats = s.get("patternProperties", {})
            for k, v in x.items():
                matched = False
                if k in props: self._v(v, props[k], base, path + "/" + k, errs); matched = True
                for pat, sub in pats.items():
                    if re.search(pat, k): self._v(v, sub, base, path + "/" + k, errs); matched = True
                if not matched and "additionalProperties" in s:
                    ap = s["additionalProperties"]
                    if ap is False: errs.append((path + "/" + k, "additionalProperties", "property %r is not allowed" % k))
                    elif ap is not True: self._v(v, ap, base, path + "/" + k, errs)
            if "propertyNames" in s:
                for k in x:
                    e2 = []; self._v(k, s["propertyNames"], base, path + "/" + k, e2)
                    errs.extend((p, "propertyNames", m) for p, _, m in e2)
        if "allOf" in s:
            for sub in s["allOf"]: self._v(x, sub, base, path, errs)
        if "anyOf" in s:
            if not any(not self._try(x, sub, base) for sub in s["anyOf"]): errs.append((P, "anyOf", "matches none of the alternatives"))
        if "oneOf" in s:
            n = sum(1 for sub in s["oneOf"] if not self._try(x, sub, base))
            if n != 1: errs.append((P, "oneOf", "matches %d alternatives, exactly 1 required" % n))
        if "not" in s and not self._try(x, s["not"], base): errs.append((P, "not", "must not match the subschema"))
        if "if" in s:
            if not self._try(x, s["if"], base):
                if "then" in s: self._v(x, s["then"], base, path, errs)
            elif "else" in s: self._v(x, s["else"], base, path, errs)
    def _try(self, x, sub, base):
        e = []; self._v(x, sub, base, "", e); return e
def load_registry(files):
    reg = {}
    for f in files:
        d = json.load(open(f, encoding="utf-8"))
        if "$id" not in d: raise SchemaError("%s has no $id" % f)
        reg[d["$id"]] = d
    return reg

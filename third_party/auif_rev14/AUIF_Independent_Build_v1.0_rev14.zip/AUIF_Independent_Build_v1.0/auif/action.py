"""Action delivery, Action Execution Ledger, idempotency and reconciliation (architecture AR-13). AUIF carries a Governor decision reference and hash; it never issues, verifies or substitutes for a decision.
FINDING F-1 (contract gap): ActionExecutionRecord.error uses the EXTERNAL error code set, which has no code for an AUIF-side refusal (governance denial, boundary rejection, outbound-validation failure).
This build uses CANCELLED with an explicit message_redacted ('refused before transmission: <reason>'). Reported to the auditor; the audited contract is not changed here."""
from .canonical import top
from .contracts import validate
from .errors import *
from .security import InputGuard
from .util import sha, evidence
ACTION_TRANSITIONS = {("CREATED", "QUEUED"), ("CREATED", "FAILED"), ("QUEUED", "SENT"), ("QUEUED", "FAILED"), ("SENT", "ACKNOWLEDGED"), ("SENT", "COMPLETED"), ("SENT", "FAILED"), ("SENT", "UNKNOWN_OUTCOME"), ("ACKNOWLEDGED", "COMPLETED"), ("ACKNOWLEDGED", "FAILED"),
                      ("UNKNOWN_OUTCOME", "RECONCILIATION_REQUIRED"), ("RECONCILIATION_REQUIRED", "COMPLETED"), ("RECONCILIATION_REQUIRED", "FAILED")}
TERMINAL = {"COMPLETED", "FAILED"}
class Ledger:
    def __init__(self, store, clock): self.store, self.clock = store, clock
    def get(self, ctx, action_id):
        r = self.store.get(ctx, "action_ledger", action_id)
        if r is None: raise NotFound("action %s" % action_id)
        return r
    def create(self, ctx, rec): validate("action#ActionExecutionRecord", rec); self.store.put(ctx, "action_ledger", rec["action_id"], rec, if_absent=True); return rec
    def transition(self, ctx, action_id, to, **fields):
        def fn(old):
            if (old["execution_state"], to) not in ACTION_TRANSITIONS: raise IllegalTransition("%s -> %s" % (old["execution_state"], to))
            new = dict(old); new.update(fields); new["execution_state"] = to; validate("action#ActionExecutionRecord", new); return new      # a contract violation rolls the update back
        return self.store.update(ctx, "action_ledger", action_id, fn)
    def queue_if_created(self, ctx, action_id):
        """CREATED -> QUEUED, idempotently: a record already beyond CREATED is left exactly as it is (so completing a submission twice, or concurrently, is harmless)."""
        def fn(old):
            if old["execution_state"] != "CREATED": return old
            new = dict(old); new["execution_state"] = "QUEUED"; validate("action#ActionExecutionRecord", new); return new
        return self.store.update(ctx, "action_ledger", action_id, fn)
    def patch(self, ctx, action_id, **fields):
        def fn(old):
            if old["execution_state"] in TERMINAL: raise IllegalTransition("terminal record is immutable")
            new = dict(old); new.update(fields); validate("action#ActionExecutionRecord", new); return new
        return self.store.update(ctx, "action_ledger", action_id, fn)
    def event(self, ctx, action_id, kind, **detail):
        n = self.store.next_sequence(ctx, "action-events:" + action_id); self.store.put(ctx, "action_events", "%s:%04d" % (action_id, n), dict({"kind": kind, "at": self.clock.iso()}, **detail))
    def event_once(self, ctx, action_id, slot, kind, **detail):
        """An informational event recorded AT MOST ONCE, atomically: put-if-absent on a fixed slot that sorts before the sequenced events (check-then-write would race)."""
        self.store.put(ctx, "action_events", "%s:%s" % (action_id, slot), dict({"kind": kind, "at": self.clock.iso()}, **detail), if_absent=True)
    def events(self, ctx, action_id): return [v for _, v in self.store.list(ctx, "action_events", action_id + ":")]
class ActionService:
    def __init__(self, store, clock, ids, telemetry, translator, boundary, governor, integrations, guard=None):
        self.store, self.clock, self.ids, self.tel, self.tr, self.boundary, self.gov, self.integrations, self.guard = store, clock, ids, telemetry, translator, boundary, governor, integrations, guard or InputGuard(); self.ledger = Ledger(store, clock)
    def _refuse(self, ctx, rec, reason, **extra):
        err = {"code": "CANCELLED", "retryable": False, "message_redacted": "refused before transmission: %s" % reason}; self.ledger.event(ctx, rec["action_id"], "REFUSED", reason=reason); return self.ledger.transition(ctx, rec["action_id"], "FAILED", error=err, **extra)
    def submit(self, ctx, action):
        """Idempotent and RESUMABLE submission (audit round 2, F7). The PersistencePort gives single-record atomicity only, so submission is a write-ahead INTENT: ONE atomic record (action_idem) holds the reservation AND everything needed
        to finish it (the full action), in state RESERVED. Every later step is idempotent, so a retry, a concurrent duplicate or recover_pending() can complete it from that record alone; the last step marks it COMMITTED and drops the intent.
        action_idem states: (absent) -> RESERVED -> COMMITTED, forward only. A RESERVED record cannot strand an action: the intent needed to complete it is inside it. No multi-record transaction is assumed."""
        validate("action#CanonicalAction", action)
        if action["tenant_id"] != ctx.tenant_id: raise TenantContextError("the action's tenant does not match the authenticated tenant context: refused before any record is written")        # the caller-supplied identity is CHECKED, never overwritten, and never left for the ledger's later use of ctx to paper over (audit round 3, F9)
        self.guard.check(action["canonical_action"]["payload"]); key, h = action["idempotency_key"], sha(action["canonical_action"])
        resv = {"action_id": action["action_id"], "content_hash": h, "state": "RESERVED", "reserved_at": self.clock.iso(), "intent": {"action": action}}; won = self.store.put(ctx, "action_idem", key, resv, if_absent=True)
        if not won:
            resv = self.store.get(ctx, "action_idem", key)
            if resv is None: raise AuifError("integrity failure: idempotency record %s disappeared during submission" % key)
            if resv["content_hash"] != h: raise AuifError("idempotency key reused with different content")
            if resv.get("state") == "COMMITTED": return self._committed(ctx, resv)                  # duplicate submission (including of a terminal action): the existing record, no second action
        return self._finish_submission(ctx, key, resv, recovered=not won)                                   # new, or a RESERVED one a previous attempt did not finish: finish it from its own intent
    def _committed(self, ctx, resv):
        rec = self.store.get(ctx, "action_ledger", resv["action_id"])
        if rec is None: raise AuifError("integrity failure: the idempotency record for action %s is COMMITTED but its action record is missing" % resv["action_id"])      # never silently re-created
        return rec
    def _finish_submission(self, ctx, key, resv, recovered):
        """Finish a submission from its durable intent. Every step is idempotent; completing twice or concurrently yields exactly one action."""
        a = (resv.get("intent") or {}).get("action")
        if not isinstance(a, dict) or a.get("action_id") != resv.get("action_id") or sha(a.get("canonical_action")) != resv.get("content_hash"): raise AuifError("integrity failure: the reservation for key %s has no usable intent" % key)
        if a.get("tenant_id") != ctx.tenant_id: raise AuifError("integrity failure: the reservation for key %s carries an action for a different tenant" % key)        # defence in depth: such a reservation is never completed
        aid, h, supplied = a["action_id"], resv["content_hash"], a["governance"].get("governor_decision_ref")
        self.store.put(ctx, "action_payloads", "canon:" + aid, {"payload": a["canonical_action"]})
        rec = {"contract_kind": "ActionExecutionRecord", "action_id": aid, "tenant_id": ctx.tenant_id, "source_module": a["source_module"], "target_system_id": a["target_system_id"], "environment_id": a["environment_id"],
               "canonical_action_ref": evidence("canonical-action", a["canonical_action"], "canon-" + aid), "payload_hash": h, "idempotency_key": key, "correlation_id": a["correlation_id"], "attempt_count": 0, "created_at": resv["reserved_at"], "execution_state": "CREATED", "governance": {k: v for k, v in a["governance"].items() if k not in ("governor_decision_ref", "governor_decision_hash")} | {"governor_decision_ref": None}}
        self.ledger.create(ctx, rec); self.store.put(ctx, "action_manifest_ref", aid, a["manifest_ref"])             # create is if_absent: an existing record is never overwritten
        if supplied: self.ledger.event_once(ctx, aid, "0000", "IGNORED_SUPPLIED_DECISION_REF", note="AUIF does not trust or verify a decision reference supplied by a module; it obtains the decision from the Governor port itself (OD-04 / GD-03 / GD-05 open)")
        self.ledger.queue_if_created(ctx, aid)
        if recovered: self.ledger.event_once(ctx, aid, "0000r", "SUBMISSION_RECOVERED", note="the original submission did not finish; it was completed from its durable intent")
        self.store.update(ctx, "action_idem", key, lambda old: dict({k: v for k, v in old.items() if k != "intent"}, state="COMMITTED"))
        return self.ledger.get(ctx, aid)
    def recover_pending(self, ctx):
        """Complete every submission left RESERVED by a crash or a failed write. Safe at any time, including concurrently with live submissions (every step is idempotent). Returns what was completed and anything unrecoverable."""
        done, bad = [], []
        for key, resv in self.store.list(ctx, "action_idem"):
            if resv.get("state") != "RESERVED": continue
            try: self._finish_submission(ctx, key, resv, recovered=True); done.append(resv["action_id"])
            except Exception as e: bad.append({"idempotency_key": key, "action_id": resv.get("action_id"), "problem": "%s: %s" % (type(e).__name__, str(e)[:160])})
        return {"completed": done, "unrecoverable": bad}
    def recover_stale_sent(self, ctx, stale_after_seconds):
        """CF-2 (rev9). A crash after the durable SENT (before the send, or after the target applied the write but before the outcome was recorded) leaves a record in SENT forever. This sweep resolves it SAFELY, and only by the rules that already govern an unknown outcome:
        a SENT record whose `sent_at` is at least `stale_after_seconds` old becomes UNKNOWN_OUTCOME (the target may or may not hold the write) and is then reconciled by the existing path: found by idempotency key -> COMPLETED; not found -> FAILED; no lookup possible -> operator review.
        NOTHING is ever re-sent, and no Governor decision is requested or reused (G5: an unknown outcome is never re-sent). `stale_after_seconds` MUST exceed the longest a live dispatch can take (the runtime's retry and deadline budget), because a live record is SENT while its call is in flight; the host chooses it and
        calls this serially with dispatch (the core has no internal synchronisation). Safe to repeat. Returns what it moved, how each ended, what was too recent, what had moved on, and any problem."""
        if isinstance(stale_after_seconds, bool) or not isinstance(stale_after_seconds, (int, float)) or not 0 < stale_after_seconds < float("inf"): raise AuifError("stale_after_seconds must be a positive, finite number of seconds")
        cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"recovered": [], "reconciled": {}, "not_stale": 0, "skipped": [], "problems": []}
        for aid, rec in self.store.list(ctx, "action_ledger"):
            if rec.get("execution_state") != "SENT": continue
            if rec.get("sent_at", "") > cutoff: out["not_stale"] += 1; continue
            try:
                h = self.integrations.resolve(ctx, self.store.get(ctx, "action_manifest_ref", aid))
                strat = "QUERY_EXTERNAL_BY_IDEMPOTENCY_KEY" if h.runtime.descriptor()["idempotency"]["outcome_reconciliation_supported"] else "OPERATOR_REVIEW"
                self.ledger.transition(ctx, aid, "UNKNOWN_OUTCOME", error={"code": "UNKNOWN_EXTERNAL_ERROR", "retryable": False, "message_redacted": "recovered: the record was left in SENT, so the outcome is unknown; it is reconciled and is never re-sent"},
                                       reconciliation={"strategy": strat, "next_check_at": self.clock.iso(self.clock.now), "blind_retry_permitted": False})
                self.ledger.event(ctx, aid, "STALE_SENT_RECOVERED", sent_at=rec["sent_at"], stale_after_seconds=stale_after_seconds); self.tel.inc(ctx.tenant_id, h.integration_id, "stale_sent_recovery"); out["recovered"].append(aid)
                out["reconciled"][aid] = self.reconcile(ctx, aid)["execution_state"]
            except IllegalTransition: out["skipped"].append(aid)                  # the record moved on (a live dispatch finished): there is nothing to recover
            except Exception as e: out["problems"].append({"action_id": aid, "problem": "%s: %s" % (type(e).__name__, str(e)[:160])})
        return out
    def recover_stale_acknowledged(self, ctx, stale_after_seconds):
        """CF-4 (rev10). A crash between the durable ACKNOWLEDGED and COMPLETED leaves a record in ACKNOWLEDGED forever, although the target has already replied and the effect is confirmed: ACKNOWLEDGED is only written after the target's reply carried the external reference.
        The authoritative transition is ACKNOWLEDGED -> COMPLETED (already in the transition table; no contract or schema change), the very step dispatch() would have taken. An ACKNOWLEDGED record whose `acknowledged_at` is at least `stale_after_seconds` old, and which carries the target's external reference, is completed as APPLIED.
        NOTHING is sent, nothing is looked up at the target, and no Governor decision is requested or reused: the confirmation is already on the record, so there is nothing to re-send and nothing to ask. A record without that reference or timestamp cannot be established as confirmed and is left for an operator. `stale_after_seconds` MUST exceed the longest a live dispatch can spend between its two writes;
        the host chooses it and calls this serially with dispatch (the core has no internal synchronisation). Safe to repeat. Returns what it completed, what was too recent, what had moved on, and any problem."""
        if isinstance(stale_after_seconds, bool) or not isinstance(stale_after_seconds, (int, float)) or not 0 < stale_after_seconds < float("inf"): raise AuifError("stale_after_seconds must be a positive, finite number of seconds")
        cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"completed": [], "not_stale": 0, "skipped": [], "problems": []}
        for aid, rec in self.store.list(ctx, "action_ledger"):
            if rec.get("execution_state") != "ACKNOWLEDGED": continue
            ref, at = rec.get("external_reference"), rec.get("acknowledged_at")
            if not (isinstance(ref, str) and ref and isinstance(at, str) and at): out["problems"].append({"action_id": aid, "problem": "ACKNOWLEDGED without the target's external reference or timestamp: the confirmation cannot be established, so it is left for an operator"}); continue
            if at > cutoff: out["not_stale"] += 1; continue
            try:
                self.ledger.transition(ctx, aid, "COMPLETED", completed_at=self.clock.iso(), result={"outcome": "APPLIED"})
                self.ledger.event(ctx, aid, "STRANDED_ACKNOWLEDGED_COMPLETED", acknowledged_at=at, stale_after_seconds=stale_after_seconds); out["completed"].append(aid)
                try: self.tel.inc(ctx.tenant_id, self.integrations.resolve(ctx, self.store.get(ctx, "action_manifest_ref", aid)).integration_id, "stale_acknowledged_recovery")
                except Exception: pass                                                       # telemetry only: the completion is already durable and must not be reported as a problem
            except IllegalTransition: out["skipped"].append(aid)                  # the record moved on (a live dispatch finished): there is nothing to recover
            except Exception as e: out["problems"].append({"action_id": aid, "problem": "completion failed: %s: %s" % (type(e).__name__, str(e)[:160])})
        return out
    def supply_governance_requirement(self, ctx, action_id, required, source):
        """A determination PROVIDED by its source (module, Governor policy or manifest). AUIF does not decide it (GD-03)."""
        if source not in ("MODULE_DECLARED", "GOVERNOR_POLICY", "MANIFEST_DECLARED"): raise AuifError("unknown governance source")
        rec = self.ledger.get(ctx, action_id); g = dict(rec["governance"], governance_required=bool(required), governance_required_source=source); return self.ledger.patch(ctx, action_id, governance=g)
    def dispatch(self, ctx, action_id):
        rec = self.ledger.get(ctx, action_id)
        if rec["execution_state"] != "QUEUED": return rec
        gov = rec["governance"]
        if gov["governance_required"] == "UNKNOWN": self.ledger.event(ctx, action_id, "HELD", reason="governance requirement undetermined"); raise GovernanceHold("governance requirement undetermined: action held, never sent")
        h = self.integrations.resolve(ctx, self.store.get(ctx, "action_manifest_ref", action_id)); canon = self.store.get(ctx, "action_payloads", "canon:" + action_id)["payload"]; pl = canon["payload"]
        am = self.tr.action_mapping(h.pack_ref, canon["action_type"])
        governed = gov["governance_required"] is True
        if not h.operation_allowed(am["operation"], governed): self.ledger.event(ctx, action_id, "HELD", reason="integration state does not allow this operation"); raise GovernanceHold("integration is not in a state that allows this operation: held")
        ctype, attrs = pl["canonical_type"], pl["attributes"]; classes = self.tr.model.classes(ctype, attrs)
        try: fields, vev = self.tr.translate_outbound(h.pack_ref, ctype, attrs)
        except OutboundValidationError as e:
            return self._refuse(ctx, rec, "outbound validation failed", outbound_validation={"performed": True, "validation_result": "FAILED", "constraints_ref": evidence("outbound-validation", {"violations": len(e.violations)}, "ov-" + action_id), "validated_at": self.clock.iso()})
        bd = self.boundary.enforce(ctx, attrs, classes, {"kind": h.destination_kind, "system": h.target_system_id}, {"purpose": "action", "action_type": canon["action_type"]})
        self.ledger.event(ctx, action_id, "BOUNDARY", decision=bd["decision"], per_attribute=[{k: v for k, v in e.items() if k != "basis"} for e in bd["evidence"]])
        if bd["decision"] == "REJECTED": return self._refuse(ctx, rec, "data boundary: " + bd["reason"])
        if bd["decision"] == "TRANSFORMED":
            try: fields, vev = self.tr.translate_outbound(h.pack_ref, ctype, bd["payload"])
            except OutboundValidationError: return self._refuse(ctx, rec, "outbound validation failed after boundary transformation")
        governed = governed or bd["decision"] == "NEEDS_AUTHORISATION"
        if governed:
            resp = self.gov.request_decision(ctx, {"action_id": action_id, "action_type": canon["action_type"], "target_system_id": h.target_system_id, "environment_id": h.environment_id, "payload_hash": rec["payload_hash"], "classification": top(list(classes.values()))})
            st = resp.get("status")
            if st == "DENIED": return self._refuse(ctx, rec, "governance decision denied")
            if st != "GRANTED": self.ledger.event(ctx, action_id, "HELD", reason="governance decision %s" % st); raise GovernanceHold("governance decision %s: action held" % st)
            if not resp.get("decision_ref") or not resp.get("decision_hash"): raise AuifError("malformed Governor response: a grant must carry a decision reference and hash")
            gov = dict(gov, governance_required=True, governor_decision_ref=resp["decision_ref"], governor_decision_hash=resp["decision_hash"])
        self.store.put(ctx, "action_payloads", "trans:" + action_id, {"entity": fields["entity"], "fields": fields["fields"]}); ext_id = pl["canonical_id"].split(":")[-1]
        rec = self.ledger.transition(ctx, action_id, "SENT", translated_action_ref=evidence("translated-action", fields, "trans-" + action_id), outbound_validation={"performed": True, "validation_result": "PASSED", "constraints_ref": evidence("outbound-validation", vev, "ov-" + action_id), "validated_at": self.clock.iso()},
                                     sent_at=self.clock.iso(), attempt_count=1, governance=gov)        # durable BEFORE the target is contacted
        out = h.runtime.call(ctx, h.integration_id, h.target_system_id, h.environment_id, "write", {"operation": am["operation"], "entity": fields["entity"], "id": ext_id, "fields": fields["fields"]}, idempotency_key=rec["idempotency_key"])
        rec = self.ledger.patch(ctx, action_id, attempt_count=max(1, out.attempts)); self.tel.inc(ctx.tenant_id, h.integration_id, "action_execution")
        if out.result["outcome_kind"] == "DATA_OBTAINED":
            rec = self.ledger.transition(ctx, action_id, "ACKNOWLEDGED", acknowledged_at=self.clock.iso(), external_reference=out.data["external_reference"]); return self.ledger.transition(ctx, action_id, "COMPLETED", completed_at=self.clock.iso(), result={"outcome": "APPLIED"})
        if out.may_have_applied:
            strat = "QUERY_EXTERNAL_BY_IDEMPOTENCY_KEY" if h.runtime.descriptor()["idempotency"]["outcome_reconciliation_supported"] else "OPERATOR_REVIEW"
            return self.ledger.transition(ctx, action_id, "UNKNOWN_OUTCOME", error=out.error, reconciliation={"strategy": strat, "next_check_at": self.clock.iso(self.clock.now + 30), "blind_retry_permitted": False})
        return self.ledger.transition(ctx, action_id, "FAILED", error=out.error)
    def reconcile(self, ctx, action_id):
        rec = self.ledger.get(ctx, action_id)
        h = self.integrations.resolve(ctx, self.store.get(ctx, "action_manifest_ref", action_id))
        if rec["execution_state"] == "UNKNOWN_OUTCOME": rec = self.ledger.transition(ctx, action_id, "RECONCILIATION_REQUIRED"); self.tel.inc(ctx.tenant_id, h.integration_id, "reconciliation")
        if rec["execution_state"] != "RECONCILIATION_REQUIRED": return rec
        if rec["reconciliation"]["strategy"] != "QUERY_EXTERNAL_BY_IDEMPOTENCY_KEY": self.ledger.event(ctx, action_id, "OPERATOR_REVIEW_REQUIRED"); return rec
        found = h.runtime.lookup(ctx, h.integration_id, rec["idempotency_key"])
        if found == "UNSUPPORTED": self.ledger.event(ctx, action_id, "OPERATOR_REVIEW_REQUIRED"); return rec
        if found: return self._complete(ctx, action_id, found)
        return self.ledger.transition(ctx, action_id, "FAILED", error={"code": "TIMEOUT", "retryable": False, "message_redacted": "reconciled: the target holds no record of this idempotency key; the action was not applied"})
    def _complete(self, ctx, action_id, found):
        def fn(old):
            new = {k: v for k, v in old.items() if k != "error"}; new.update(execution_state="COMPLETED", completed_at=self.clock.iso(), result={"outcome": "APPLIED_CONFIRMED_BY_RECONCILIATION"}, external_reference=found["external_reference"])
            if ("RECONCILIATION_REQUIRED", "COMPLETED") not in ACTION_TRANSITIONS or old["execution_state"] != "RECONCILIATION_REQUIRED": raise IllegalTransition("not reconcilable")
            validate("action#ActionExecutionRecord", new); return new
        return self.store.update(ctx, "action_ledger", action_id, fn)
    def operator_resolve(self, ctx, action_id, applied, evidence_ref):
        rec = self.ledger.get(ctx, action_id)
        if rec["execution_state"] != "RECONCILIATION_REQUIRED": raise IllegalTransition("only a record awaiting reconciliation can be resolved by an operator")
        self.ledger.event(ctx, action_id, "OPERATOR_RESOLVED", applied=bool(applied), evidence_id=evidence_ref["evidence_id"])
        return self._complete(ctx, action_id, {"external_reference": "operator:" + evidence_ref["evidence_id"]}) if applied else self.ledger.transition(ctx, action_id, "FAILED", error={"code": "TIMEOUT", "retryable": False, "message_redacted": "operator confirmed the action was not applied"})

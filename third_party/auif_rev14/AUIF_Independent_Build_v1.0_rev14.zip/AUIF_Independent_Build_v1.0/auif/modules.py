"""Module registry (architecture AR-18). The descriptor format is OD-22 (open): this build uses a reference descriptor {module_id, semantic_requirements, capabilities}. Binding to real Anchor modules is UNKNOWN / Amir-dependent (EP-02/EP-03)."""
from .errors import AuifError, NotFound
class ModuleRegistry:
    def __init__(self): self.m = {}
    def register(self, module):
        if not module.module_id: raise AuifError("a module must declare a module_id")
        if not isinstance(module.semantic_requirements(), list) or not isinstance(module.module_capabilities(), dict): raise AuifError("module descriptor is malformed")
        self.m[module.module_id] = module
    def get(self, module_id):
        if module_id not in self.m: raise NotFound("module %s" % module_id)
        return self.m[module_id]

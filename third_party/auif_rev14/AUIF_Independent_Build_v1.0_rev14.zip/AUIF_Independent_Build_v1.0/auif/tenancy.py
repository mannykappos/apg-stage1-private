import hashlib, hmac
from dataclasses import dataclass
from .errors import TenantContextError
from .ports import PersistencePort, TenantAuthorityPort
@dataclass(frozen=True)
class TenantContext:
    tenant_id: str; principal: str; sig: str
class TenantAuthority(TenantAuthorityPort):
    """Reference tenant authority (HMAC-signed contexts) used to prove the core REJECTS forged or missing context. The real binding is UNKNOWN / Amir-dependent (EP-01, ED-03)."""
    def __init__(self, secret=b"synthetic-tenant-authority-secret"): self._k = secret
    def _sig(self, t, p): return hmac.new(self._k, ("%s|%s" % (t, p)).encode(), hashlib.sha256).hexdigest()
    def issue(self, tenant_id, principal): return TenantContext(tenant_id, principal, self._sig(tenant_id, principal))
    def verify(self, ctx): return isinstance(ctx, TenantContext) and bool(ctx.tenant_id) and hmac.compare_digest(ctx.sig, self._sig(ctx.tenant_id, ctx.principal))
    def require(self, ctx):
        if not self.verify(ctx): raise TenantContextError("missing or forged tenant context")
        return ctx
class TenantScopedPersistence(PersistencePort):
    """Core-side guard: every persistence call carries a VERIFIED tenant context, whatever the backing store does."""
    def __init__(self, inner, authority): self.inner, self.auth = inner, authority
    def put(self, ctx, c, k, v, if_absent=False): self.auth.require(ctx); return self.inner.put(ctx, c, k, v, if_absent)
    def get(self, ctx, c, k): self.auth.require(ctx); return self.inner.get(ctx, c, k)
    def update(self, ctx, c, k, fn): self.auth.require(ctx); return self.inner.update(ctx, c, k, fn)
    def list(self, ctx, c, prefix=""): self.auth.require(ctx); return self.inner.list(ctx, c, prefix)
    def next_sequence(self, ctx, name): self.auth.require(ctx); return self.inner.next_sequence(ctx, name)

class AuifError(Exception): pass
class ContractViolation(AuifError):
    def __init__(self, ref, errors): self.ref, self.errors = ref, errors; super().__init__("%s: %s" % (ref, errors[:3]))
class TenantContextError(AuifError): pass
class SecretError(AuifError): pass
class TransportError(AuifError):
    """Raised by connector implementations. applied: NOT_APPLIED (definitely not executed by the target), MAYBE (the target may have executed it), UNKNOWN."""
    def __init__(self, code, applied="UNKNOWN", retry_after=None, status=None, message="", request_id=None):
        super().__init__(code); self.code, self.applied, self.retry_after, self.status, self.message, self.request_id = code, applied, retry_after, status, message, request_id
class MalformedResponse(AuifError): pass
class SchemaMismatch(AuifError): pass
class Cancelled(AuifError): pass
class Throttled(AuifError):
    def __init__(self, wait, why="RATE"): self.wait, self.why = wait, why; super().__init__("throttled %.3fs (%s)" % (wait, why))
class CircuitOpen(Throttled):
    def __init__(self, wait): super().__init__(wait, "CIRCUIT_OPEN")
class UntrustedInput(AuifError):
    def __init__(self, reasons): self.reasons = reasons; super().__init__("; ".join(reasons[:3]))
class PackError(AuifError): pass
class TranslationFailure(AuifError): pass
class OutboundValidationError(AuifError):
    def __init__(self, violations): self.violations = violations; super().__init__("; ".join(violations[:3]))
class BoundaryRejected(AuifError):
    def __init__(self, reason, evidence=None): self.reason, self.evidence = reason, evidence or {}; super().__init__(reason)
class IllegalTransition(AuifError): pass
class GovernanceHold(AuifError): pass
class NotFound(AuifError): pass

import calendar, datetime
class FakeClock:
    """Deterministic clock. sleep() advances time; nothing in the core calls real time."""
    def __init__(self, start=None): self.now = float(start if start is not None else calendar.timegm((2026, 10, 2, 3, 0, 0)))
    def sleep(self, s): self.now += max(0.0, float(s))
    def advance(self, s): self.sleep(s)
    def iso(self, t=None):
        d = datetime.datetime.fromtimestamp(self.now if t is None else t, datetime.timezone.utc); return d.strftime("%Y-%m-%dT%H:%M:%SZ")

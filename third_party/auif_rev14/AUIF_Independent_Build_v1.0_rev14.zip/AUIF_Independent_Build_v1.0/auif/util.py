import hashlib, json
def canon(o): return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
def sha(o):
    b = o if isinstance(o, bytes) else (o.encode() if isinstance(o, str) else canon(o).encode()); return hashlib.sha256(b).hexdigest()
class Ids:
    def __init__(self): self.n = {}
    def next(self, prefix): self.n[prefix] = self.n.get(prefix, 0) + 1; return "%s-%06d" % (prefix, self.n[prefix])
def evidence(kind, obj, ident): return {"evidence_id": ident, "evidence_hash": sha(obj), "kind": kind}

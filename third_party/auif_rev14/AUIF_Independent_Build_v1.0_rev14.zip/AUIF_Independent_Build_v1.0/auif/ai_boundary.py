"""AI-assisted mapping boundary (architecture AR-16). AI may PROPOSE; it can never validate, trust, approve, or touch governance, credentials, connectors, the ledger or any action.
Structure, not instruction: the proposer receives a read-only sandbox built from untrusted discovery data; everything it RETURNS is untrusted input too (list, members, fields); every state it claims is discarded;
VALIDATED exists only via the deterministic validator's hash-bound evidence.
FINDING F-4 (contract gap): translation#Mapping is closed (additionalProperties=false) and its `ambiguity` object has no place for resolution evidence, so a promoted mapping cannot carry it. The evidence is
therefore bound INTO the validation record (whose hash is the mapping's validation_ref) and kept in a resolution ledger; see resolution_chain(). The audited contract is not changed."""
import copy, re
from abc import ABC, abstractmethod
from .canonical import split_ref
from .contracts import validate
from .errors import AuifError, ContractViolation, UntrustedInput
from .security import InputGuard, instruction_like
from .translation import AI_EVIDENCE_KIND, AI_EVIDENCE_PREFIX, FUNC_SPEC, transform_problems
from .util import sha
SOURCE_TO_CANON = {"string": {"STRING", "ENUM", "REFERENCE", "TIMESTAMP", "DECIMAL"}, "integer": {"INTEGER", "DECIMAL", "ENUM", "BOOLEAN"}, "number": {"DECIMAL"}, "decimal": {"DECIMAL"}, "boolean": {"BOOLEAN"}}
KNOWN = {"IDENTITY", "RENAME", "ENUM_MAP", "UNIT_CONVERT", "FORMAT", "CONSTANT", "DETERMINISTIC_FUNCTION"}
MAX_PROPOSALS, MAX_ALTERNATIVES = 500, 10; HEX64 = re.compile(r"^[0-9a-f]{64}$")
_GUARD = InputGuard(max_bytes=20_000, max_depth=6, max_keys=200, max_str=2_000, max_items=50)
class UntrustedText(str): """Marks external text as DATA. Nothing in the core interprets it as an instruction."""
class PromotionRefused(AuifError): pass
class ProposerSandbox:
    """The ONLY capability a proposer holds: read-only copies of discovery fields and canonical attribute names. No attribute path leads to a store, secret, connector, ledger, Governor or action."""
    __slots__ = ("_fields", "_canon")
    def __init__(self, fields, canon): object.__setattr__(self, "_fields", fields); object.__setattr__(self, "_canon", canon)
    def __setattr__(self, k, v): raise AttributeError("read-only sandbox")
    def fields(self): return copy.deepcopy(self._fields)
    def canonical_attributes(self): return copy.deepcopy(self._canon)
class MappingProposer(ABC):
    @abstractmethod
    def propose(self, sandbox): ...             # -> [{"source_ref","canonical_ref","transform","alternatives","rationale", ("claimed_state")}]
class MappingValidator:
    def __init__(self, model): self.model = model
    def check(self, source_ref, canonical_ref, transform, alternatives, record):
        """Deterministic validation. Never raises on malformed input: every defect is a reported problem."""
        problems = list(transform_problems(transform, "in")); structural = bool(problems)
        if not isinstance(source_ref, str) or not source_ref: problems.append("source_ref must be a non-empty string"); source_ref = ""
        if not isinstance(canonical_ref, str) or not canonical_ref: problems.append("canonical_ref must be a non-empty string"); canonical_ref = ""
        if not isinstance(alternatives, list) or len(alternatives) > MAX_ALTERNATIVES or not all(isinstance(a, str) and 0 < len(a) <= 200 for a in alternatives): problems.append("alternatives must be a list of at most %d non-empty strings" % MAX_ALTERNATIVES); alternatives = []
        el = next((e for e in record["elements"] if e["element_kind"] == "FIELD" and e["name"] == source_ref), None)
        if el is None: problems.append("source field %s does not exist in the discovery record" % source_ref)
        ctype, attr = split_ref(canonical_ref)                                  # rev14 (M8-F1): a MODULE concept's name contains dots
        cdef = self.model.attributes(ctype).get(attr) if canonical_ref and self.model.has(ctype) else None
        if cdef is None: problems.append("canonical attribute %s does not exist in the model" % canonical_ref)
        info = {}
        if el is not None and cdef is not None:
            st, ct = el["detail"].get("type", "string"), cdef["type"]; info = {"source_type": st, "canonical_type": ct}
            if ct not in SOURCE_TO_CANON.get(st, set()): problems.append("source type %s is not compatible with canonical %s" % (st, ct))
            if not structural: problems += self._semantic(transform["kind"], transform.get("parameters", {}), el, cdef, ctype, attr, st, ct)
        return dict({"passed": not problems, "ambiguous": bool(alternatives), "problems": problems}, **info)
    def _semantic(self, k, p, el, cdef, ctype, attr, st, ct):
        out = []; senum = [str(v) for v in el["detail"].get("enum", [])]; cenum = cdef.get("constraints", {}).get("values")
        if k == "FORMAT":
            if st != "string": out.append("FORMAT needs a string source, not %s" % st)
            if ct not in ("STRING", "REFERENCE"): out.append("FORMAT yields text; canonical %s is not text" % ct)
        elif k == "UNIT_CONVERT":
            if st not in ("integer", "number", "decimal"): out.append("UNIT_CONVERT needs a numeric source, not %s" % st)
            if ct != "DECIMAL": out.append("UNIT_CONVERT yields a decimal; canonical %s is not DECIMAL" % ct)
        elif k == "DETERMINISTIC_FUNCTION":
            spec = FUNC_SPEC[p["in"]]
            if st not in spec["src"]: out.append("function %s does not accept a %s source" % (p["in"], st))
            if ct not in spec["canon"]: out.append("function %s does not produce canonical %s" % (p["in"], ct))
        elif k == "CONSTANT": out += [x for x in self.model.problems(ctype, {attr: p["value"]}) if "required attribute" not in x]
        elif k == "ENUM_MAP":
            if ct != "ENUM": out.append("ENUM_MAP needs an ENUM canonical attribute, not %s" % ct)
            else:
                m = p["map"]
                if senum and not set(senum) <= set(map(str, m)): out.append("enum map does not cover source values %s" % sorted(set(senum) - set(map(str, m))))
                if not set(m.values()) <= set(cenum or []): out.append("enum map targets values outside the canonical enum")
        elif ct == "ENUM" and not (senum and set(senum) == set(cenum or [])): out.append("an enum needs a covering ENUM_MAP")
        return out
class AIMappingService:
    def __init__(self, proposer, model, ids):
        self.proposer, self.model, self.ids, self.validator = proposer, model, ids, MappingValidator(model)
        self.reports, self.records, self.refs, self.ambiguous, self.resolutions = {}, {}, {}, {}, {}      # evidence id -> hash | hash-bound payload | mapping ids ever ambiguous | resolution ledger (IN MEMORY: see KNOWN_LIMITATIONS)
    def propose(self, record):
        fields = [{"name": UntrustedText(e["name"]), "detail": {k: (UntrustedText(v) if isinstance(v, str) else v) for k, v in e["detail"].items()}} for e in record["elements"] if e["element_kind"] == "FIELD"]
        flags = [str(f["name"]) for f in fields if any(instruction_like(v) for v in f["detail"].values() if isinstance(v, str))]
        canon = {c: sorted(self.model.attributes(c)) for c in self.model.concepts}; out = {"candidates": [], "rejected": [], "flags": [], "instruction_like_fields": flags}
        try: raw = self.proposer.propose(ProposerSandbox(fields, canon))
        except Exception as e: out["flags"].append("proposer failed (%s); no candidates" % type(e).__name__); return out        # a failing or hostile AI must not break the build
        if not isinstance(raw, (list, tuple)): out["flags"].append("proposer output is not a list (%s); discarded" % type(raw).__name__); return out
        if len(raw) > MAX_PROPOSALS: out["flags"].append("proposer returned %d proposals; only the first %d were considered" % (len(raw), MAX_PROPOSALS)); raw = raw[:MAX_PROPOSALS]
        for i, p in enumerate(raw):
            try: self._consider(i, p, record, out)
            except Exception as e: out["rejected"].append({"proposal": "#%d" % i, "problems": ["proposal could not be processed (%s)" % type(e).__name__]})       # one bad proposal never affects the others
        return out
    def _consider(self, i, p, record, out):
        label = "#%d" % i
        if not isinstance(p, dict): out["rejected"].append({"proposal": label, "problems": ["proposal is not an object (%s)" % type(p).__name__]}); return
        try: _GUARD.check(p)
        except UntrustedInput as e: out["rejected"].append({"proposal": label, "problems": ["proposal rejected as untrusted input: %s" % "; ".join(e.reasons[:3])]}); return
        src = p.get("source_ref") if isinstance(p.get("source_ref"), str) else label; cs = p.get("claimed_state")
        if cs is not None: out["flags"].append("claimed state %s discarded for %s" % (cs if cs in ("VALIDATED", "TRUSTED") else "of type %s" % type(cs).__name__, src))
        r = self.validator.check(p.get("source_ref"), p.get("canonical_ref"), p.get("transform"), p.get("alternatives", []), record)
        if not r["passed"]: out["rejected"].append({"proposal": src, "problems": r["problems"]}); return
        mid = "ai-%s" % sha([p["source_ref"], p["canonical_ref"]])[:10]; tr = {"kind": p["transform"]["kind"], "parameters": copy.deepcopy(p["transform"].get("parameters", {})), "deterministic": True}
        m = {"mapping_id": mid, "kind": "FIELD", "source_ref": p["source_ref"], "canonical_ref": p["canonical_ref"], "mapping_state": "AMBIGUOUS" if r["ambiguous"] else "CANDIDATE", "proposed_by": "AI_ASSISTED", "inbound": {"source_type": r["source_type"], "canonical_type": r["canonical_type"], "transform": tr}, "outbound": {"supported": False, "reason": "AI-proposed mapping is inbound-only until promoted"}}
        if r["ambiguous"]: m["ambiguity"] = {"candidate_meanings": [p["canonical_ref"]] + list(p["alternatives"]), "resolution_required": True}
        try: validate("translation#Mapping", m)
        except ContractViolation: out["rejected"].append({"proposal": src, "problems": ["proposal does not form a contract-valid mapping"]}); return
        if r["ambiguous"]: self.ambiguous[mid] = list(m["ambiguity"]["candidate_meanings"])
        out["candidates"].append(m)
    def _shape(self, m):
        if not isinstance(m, dict): return ["mapping is not an object"]
        bad = [k for k in ("mapping_id", "source_ref", "canonical_ref", "mapping_state") if not isinstance(m.get(k), str) or not m.get(k)]
        if not isinstance(m.get("inbound"), dict) or not isinstance(m["inbound"].get("transform"), dict): bad.append("inbound.transform")
        return ["mapping field %s is missing or malformed" % b for b in bad]
    def promote(self, mapping, record):
        bad = self._shape(mapping)
        if bad: raise PromotionRefused("; ".join(bad))
        if mapping["mapping_state"] == "AMBIGUOUS": raise PromotionRefused("an ambiguous mapping cannot be promoted without resolution evidence")
        mid = mapping["mapping_id"]; res = self.resolutions.get(mid)
        if mid in self.ambiguous and (res is None or res["chosen"] != mapping["canonical_ref"]): raise PromotionRefused("mapping %s was ambiguous: promotion needs matching resolution evidence" % mid)       # also closes 'strip the flag and promote'
        r = self.validator.check(mapping["source_ref"], mapping["canonical_ref"], mapping["inbound"]["transform"], [], record)
        if not r["passed"]: raise PromotionRefused("; ".join(r["problems"]))
        body = {k: v for k, v in mapping.items() if k != "validation_ref"}; body.update(mapping_state="VALIDATED", deterministic_validation_performed=True)       # the COMPLETE promoted mapping except the reference to this record (no circular hash)
        payload = {"mapping": mid, "source": mapping["source_ref"], "canonical": mapping["canonical_ref"], "transform": mapping["inbound"]["transform"], "report": r, "ambiguity_resolution": res, "mapping_body": body}; h = sha(payload)
        ev = {"evidence_id": "%s%s-%s" % (AI_EVIDENCE_PREFIX, mid, h[:8]), "evidence_hash": h, "kind": AI_EVIDENCE_KIND}; self.reports[ev["evidence_id"]] = h; self.records[ev["evidence_id"]] = copy.deepcopy(payload); self.refs[ev["evidence_id"]] = dict(ev)
        out = dict(body, validation_ref=ev); validate("translation#Mapping", out); return out
    def resolve_ambiguity(self, mapping, chosen_canonical_ref, resolution_evidence):
        bad = self._shape(mapping)
        if bad: raise PromotionRefused("; ".join(bad))
        if mapping["mapping_state"] != "AMBIGUOUS" or not isinstance(mapping.get("ambiguity"), dict): raise PromotionRefused("only an AMBIGUOUS mapping can be resolved")
        ev = resolution_evidence
        if not (isinstance(ev, dict) and isinstance(ev.get("evidence_id"), str) and 0 < len(ev["evidence_id"]) <= 128 and isinstance(ev.get("evidence_hash"), str) and HEX64.match(ev["evidence_hash"])): raise PromotionRefused("ambiguity resolution requires evidence (an evidence_id and a 64-hex evidence_hash)")
        cands = mapping["ambiguity"].get("candidate_meanings", [])
        if chosen_canonical_ref not in cands: raise PromotionRefused("the chosen meaning is not one of the candidates")
        mid = mapping["mapping_id"]; rec = {"mapping_id": mid, "source_ref": mapping["source_ref"], "candidate_meanings": list(cands), "chosen": chosen_canonical_ref, "resolution_evidence": {"evidence_id": ev["evidence_id"], "evidence_hash": ev["evidence_hash"]}}
        if self.resolutions.get(mid) not in (None, rec): raise PromotionRefused("mapping %s was already resolved differently" % mid)
        self.resolutions[mid] = rec; self.ambiguous.setdefault(mid, list(cands))
        m = {k: v for k, v in mapping.items() if k != "ambiguity"}; m.update(mapping_state="CANDIDATE", canonical_ref=chosen_canonical_ref); validate("translation#Mapping", m); return m
    def verify_promotion(self, mapping):
        """True only if the mapping is EXACTLY the promoted state this service validated: the validation record binds the complete security-relevant mapping (author, kind, state, inbound, outbound, validation flag, ids), not merely source/canonical/transform."""
        if not isinstance(mapping, dict): return False
        ref = mapping.get("validation_ref"); eid = ref.get("evidence_id") if isinstance(ref, dict) else None
        if not isinstance(eid, str): return False
        pl = self.records.get(eid)
        if pl is None or ref != self.refs.get(eid) or self.reports.get(eid) != ref.get("evidence_hash") or sha(pl) != ref["evidence_hash"]: return False
        if pl["mapping_body"] != {k: v for k, v in mapping.items() if k != "validation_ref"}: return False
        mid = mapping.get("mapping_id"); return pl["ambiguity_resolution"] == self.resolutions.get(mid) if mid in self.ambiguous else True
    def has_issued(self, mapping):
        """Did this service issue the evidence this mapping carries? (by evidence id or hash, so stripping the AI marker from the reference does not hide it.) Registry hook against provenance relabelling."""
        ref = mapping.get("validation_ref") if isinstance(mapping, dict) else None
        return isinstance(ref, dict) and ((isinstance(ref.get("evidence_id"), str) and ref["evidence_id"] in self.reports) or (isinstance(ref.get("evidence_hash"), str) and ref["evidence_hash"] in set(self.reports.values())))
    def registry_hooks(self): return {"ai_promotion_verifier": self.verify_promotion, "ai_origin": self.has_issued}
    def resolution_chain(self, mapping):
        """The auditable chain for a promoted mapping: candidate meanings -> chosen meaning -> resolution evidence -> validation record (hash-bound)."""
        ref = mapping.get("validation_ref") or {}; pl = self.records.get(ref.get("evidence_id"))
        return {"mapping_id": mapping.get("mapping_id"), "validation_ref": ref, "ambiguity_resolution": (pl or {}).get("ambiguity_resolution"), "bound_to_validation_record": bool(pl) and sha(pl) == ref.get("evidence_hash")}

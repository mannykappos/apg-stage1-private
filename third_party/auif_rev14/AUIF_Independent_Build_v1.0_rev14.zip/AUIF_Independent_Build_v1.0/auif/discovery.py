"""Discovery Engine (architecture AR-6): System Discovery Records, deterministic schema fingerprints and scoped drift detection. Discovery produces INFORMATION; it never sets VALIDATED/TRUSTED."""
import copy
from .contracts import validate
from .util import sha, canon
FP_CANON = "auif-fp-canon@0.1-draft"; VOLATILE = {"generated_at", "request_id", "etag_ts", "server_time"}
FP_SCOPE = ["ENTITIES", "FIELDS", "RELATIONSHIPS", "OPERATIONS", "EVENTS", "AUTH_REQUIREMENTS"]
KIND_KEYS = {"ENTITY": "entities", "FIELD": "entities", "RELATIONSHIP": "entities", "OPERATION": "operations", "SUPPORTED_ACTION": "operations", "EVENT": "events", "VERSION": "system_version", "PAGINATION": "pagination", "AUTH_REQUIREMENT": "auth_requirements", "RATE_LIMIT": "rate_limits", "WEBHOOK_SUPPORT": "webhook_support"}
NOT_EXPOSED_KEYS = {"webhook_support": "WEBHOOK_SUPPORT", "rate_limits": "RATE_LIMIT", "events": "EVENT", "auth_requirements": "AUTH_REQUIREMENT", "pagination": "PAGINATION"}
REQUIRED_FOR_ACTIVATION = {"ENTITY", "FIELD", "OPERATION"}
def strip_volatile(o):
    if isinstance(o, dict): return {k: strip_volatile(v) for k, v in o.items() if k not in VOLATILE}
    if isinstance(o, list): return [strip_volatile(x) for x in o]
    return o
def structure(raw):
    ents = raw.get("entities", []); ops = raw.get("operations", [])
    return {"ENTITIES": sorted(e["name"] for e in ents),
            "FIELDS": sorted("%s.%s:%s:%s" % (e["name"], f["name"], f.get("type", ""), ",".join(sorted(map(str, f.get("enum", []))))) for e in ents for f in e.get("fields", [])),
            "RELATIONSHIPS": sorted("%s.%s>%s" % (e["name"], r["name"], r.get("target", "")) for e in ents for r in e.get("relationships", [])),
            "OPERATIONS": sorted("%s:%s:%s" % (o["name"], o.get("kind", ""), ",".join(sorted(o.get("entities", [])))) for o in ops),
            "EVENTS": sorted("%s:%s" % (ev["name"], ",".join(sorted(ev.get("entities", [])))) for ev in raw.get("events", [])), "AUTH_REQUIREMENTS": strip_volatile(raw.get("auth_requirements", {}))}
def fingerprint(raw): return {"algorithm": "sha256", "canonicalization_id": FP_CANON, "value": sha(canon(strip_volatile(structure(raw)))), "scope": list(FP_SCOPE)}
def snapshot(raw):
    """Per-entity and per-operation signatures retained with the validated manifest so a later mismatch can be SCOPED to the operations it technically affects."""
    return {"entities": {e["name"]: sha(sorted("%s:%s:%s" % (f["name"], f.get("type", ""), ",".join(sorted(map(str, f.get("enum", []))))) for f in e.get("fields", []))) for e in raw.get("entities", [])},
            "operations": {o["name"]: {"kind": o.get("kind"), "entities": sorted(o.get("entities", []))} for o in raw.get("operations", [])}, "events": {e["name"]: sorted(e.get("entities", [])) for e in raw.get("events", [])}}
class DiscoveryEngine:
    def __init__(self, clock, ids): self.clock, self.ids = clock, ids
    def build_record(self, ctx, integration_id, target_system_id, environment_id, connector_ref, raw):
        els = []
        def add(kind, name, detail=None, state="DISCOVERED"): els.append({"element_id": "el-%s-%s" % (kind.lower(), sha(name)[:10]), "element_kind": kind, "name": name, "detail": detail or {}, "trust_state": state, "state_set_by": "DISCOVERY"})
        for e in raw.get("entities", []):
            add("ENTITY", e["name"], {"field_count": len(e.get("fields", []))})
            for f in e.get("fields", []): add("FIELD", "%s.%s" % (e["name"], f["name"]), {k: v for k, v in f.items() if k != "name"})
            for r in e.get("relationships", []): add("RELATIONSHIP", "%s.%s" % (e["name"], r["name"]), {"target": r.get("target")})
        for o in raw.get("operations", []):
            add("OPERATION", o["name"], {"kind": o.get("kind"), "entities": o.get("entities", [])})
            if o.get("kind") == "write": add("SUPPORTED_ACTION", o["name"], {"entities": o.get("entities", [])})
        for ev in raw.get("events", []): add("EVENT", ev["name"], {"entities": ev.get("entities", [])})
        if "system_version" in raw: add("VERSION", str(raw["system_version"]))
        if "pagination" in raw: add("PAGINATION", "pagination", dict(raw["pagination"]))
        if "auth_requirements" in raw: add("AUTH_REQUIREMENT", "auth", dict(raw["auth_requirements"]))
        if "rate_limits" in raw: add("RATE_LIMIT", "rate_limits", dict(raw["rate_limits"]))
        if "webhook_support" in raw: add("WEBHOOK_SUPPORT", "webhook_support", {"supported": bool(raw["webhook_support"])})
        declared_absent = {NOT_EXPOSED_KEYS[k] for k in raw.get("not_exposed", []) if k in NOT_EXPOSED_KEYS}
        obtained = sorted({k for k, key in KIND_KEYS.items() if key in raw and k not in declared_absent}); not_exposed = sorted(declared_absent)
        not_obtained = sorted(set(KIND_KEYS) - set(obtained) - set(not_exposed))
        rec = {"contract_kind": "SystemDiscoveryRecord", "discovery_record_id": self.ids.next("disc"), "discovery_version": "1.0.0", "tenant_id": ctx.tenant_id, "target_system_id": target_system_id, "environment_id": environment_id, "connector": connector_ref, "discovered_at": self.clock.iso(),
               "schema_fingerprint": fingerprint(raw), "authority": "NOT_AUTHORITATIVE_UNTIL_VALIDATED", "record_state": "COMPLETE" if not not_obtained else "PARTIAL", "coverage": {"obtained_kinds": obtained, "not_exposed_kinds": not_exposed, "not_obtained_kinds": not_obtained}, "elements": els}
        if "system_version" in raw: rec["observed_target_version"] = str(raw["system_version"])
        return validate("discovery#SystemDiscoveryRecord", rec)
def detect_drift(clock, ids, manifest_fp, current_fp, baseline_snapshot, current_snapshot, governed_operations):
    """Returns None when the fingerprints match; otherwise DriftEvidence scoped to the technically affected operations. The GOVERNANCE consequence is never decided here (Governor determines it)."""
    if manifest_fp["canonicalization_id"] != current_fp["canonicalization_id"]: raise ValueError("fingerprints are not comparable: canonicalization differs")
    if manifest_fp["value"] == current_fp["value"]: return None
    changed = {n for n in set(baseline_snapshot["entities"]) | set(current_snapshot["entities"]) if baseline_snapshot["entities"].get(n) != current_snapshot["entities"].get(n)}
    ops = set(baseline_snapshot["operations"]) | set(current_snapshot["operations"])
    affected = sorted(o for o in ops if baseline_snapshot["operations"].get(o) != current_snapshot["operations"].get(o) or (set((current_snapshot["operations"].get(o) or baseline_snapshot["operations"].get(o))["entities"]) & changed))
    ev = {"drift_id": ids.next("drift"), "detected_at": clock.iso(), "current_fingerprint": current_fp, "manifest_fingerprint": manifest_fp, "comparison": "MISMATCH", "technically_affected_operations": affected, "unaffected_operations_continue": sorted(ops - set(affected)),
          "governed_operations_blocked": bool(set(affected) & set(governed_operations)), "governance_consequence": {"determined_by": "GOVERNOR", "status": "PENDING" if governed_operations else "NOT_APPLICABLE_UNGOVERNED"}}
    return validate("integration#DriftEvidence", ev)

"""Operational visibility without payload leakage (handoff section 38). Records carry ids, hashes and classifications, never content."""
from .util import sha
SENSITIVE = {"payload", "body", "secret", "credential", "credentials", "token", "password", "attributes", "data", "record", "prompt"}
REQUIRED_SIGNALS = ["connection_health", "authentication_state", "discovery_state", "schema_fingerprint", "translation_version", "queue_depth", "rate_limited", "retries", "failures", "drift", "ambiguous_mappings", "action_execution", "reconciliation", "latency", "throughput"]
class Telemetry:
    def __init__(self, clock=None): self.clock, self.gauges, self.counters, self.events = clock, {}, {}, []
    def set(self, tenant, integration, signal, value): self.gauges[(tenant, integration, signal)] = value
    def inc(self, tenant, integration, signal, n=1): k = (tenant, integration, signal); self.counters[k] = self.counters.get(k, 0) + n
    def log(self, event, **fields):
        safe = {}
        for k, v in fields.items():
            if k.lower() in SENSITIVE or (isinstance(v, str) and len(v) > 200) or isinstance(v, (dict, list)): safe[k] = "<redacted sha256:%s>" % sha(v)[:16]
            else: safe[k] = v
        self.events.append({"event": event, **safe}); return safe
    def snapshot(self, tenant, integration):
        out = {}
        for (t, i, s), v in list(self.gauges.items()) + list(self.counters.items()):
            if t == tenant and i == integration: out[s] = v
        return out

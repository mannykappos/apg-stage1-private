"""AUIF reference implementation (Python, standard library only). Traceable to AUIF Architecture v1.0-DRAFT Revision 2.
This is a REFERENCE implementation: it never represents the real Anchor Engine. Every binding to the platform is UNKNOWN / Amir-dependent (see AMIR_ENGINE_DEPENDENCY_TODO.md)."""
__version__ = "0.1.0-reference"

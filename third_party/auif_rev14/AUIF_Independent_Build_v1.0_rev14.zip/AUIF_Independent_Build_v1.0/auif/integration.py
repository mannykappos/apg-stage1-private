"""Integration State Machine, manifests and activation (architecture AR-14). ACTIVE is reachable ONLY through VALIDATING -> ACTIVE on VALIDATION_COMPLETED_AND_MANIFEST_MATCHED; a successful transport call
(HTTP 200, connection established) never activates anything. The manifest is configuration (INTEGRATION_CONFIGURATION) and carries NO governance authority.
FINDING F-3: the machine defines '(none) -> DISCOVERING', but StateTransition.from_state has no value for 'no prior state'; creation is recorded as an audit event instead of a transition record."""
from .contracts import contracts, validate
from .discovery import fingerprint, snapshot, detect_drift, FP_CANON, FP_SCOPE, REQUIRED_FOR_ACTIVATION
from .errors import *
from .translation import compat_problems
from .util import sha, evidence
class StateMachine:
    def __init__(self, data): self.t = {(x["from"], x["trigger"]): x["to"] for x in data["transitions"]}
    def next(self, cur, trigger):
        if (cur, trigger) not in self.t: raise IllegalTransition("%s --%s--> not permitted" % (cur, trigger))
        return self.t[(cur, trigger)]
class IntegrationRegistry:
    def __init__(self): self.c = {}
    def add(self, ctrl): self.c[(ctrl.ctx.tenant_id, "manifest-" + ctrl.integration_id)] = ctrl
    def get(self, ctx, integration_id):
        if (ctx.tenant_id, "manifest-" + integration_id) not in self.c: raise NotFound("no integration %s in this tenant" % integration_id)
        return self.c[(ctx.tenant_id, "manifest-" + integration_id)]
    def resolve(self, ctx, mref):
        ctrl = self.c.get((ctx.tenant_id, mref["id"]))
        if ctrl is None: raise NotFound("no integration for manifest %s in this tenant" % mref["id"])
        cur = ctrl.manifest_ref()
        if cur["hash"] != mref["hash"]: raise GovernanceHold("the action references a superseded or unvalidated manifest: held")
        return ctrl
class IntegrationController:
    def __init__(self, deps, ctx, integration_id, anchor_module, target_system_id, environment_id, runtime, pack_ref, *, governed_operations=(), entities=(), destination_kind="customer-system"):
        self.d, self.ctx, self.integration_id, self.anchor_module, self.target_system_id, self.environment_id, self.runtime, self.pack_ref = deps, ctx, integration_id, anchor_module, target_system_id, environment_id, runtime, dict(pack_ref)
        self.governed_operations, self.entities, self.destination_kind, self.sm, self.raw, self.fp = list(governed_operations), list(entities), destination_kind, StateMachine(contracts().state_machine), None, None
        self.last_record = None
    def rehydrate(self):
        """Restore transient runtime state from persistence after a process restart. It does NOT re-validate anything: the persisted state and baseline are restored as they were, and check_drift() decides whether they still hold."""
        base = self.d.store.get(self.ctx, "baselines", self.integration_id)
        if base: self.fp = base["fingerprint"]
        self.last_record = None; ptr = self.d.store.get(self.ctx, "discovery_latest", self.integration_id); rec = self.d.store.get(self.ctx, "discovery_records", ptr["discovery_record_id"]) if ptr else None
        try:      # a persisted record is accepted only if it is contract-valid and belongs to THIS tenant, target and environment; anything else is ignored (the gate then fails closed)
            if rec is not None and not contracts().errors("discovery#SystemDiscoveryRecord", rec) and (rec["tenant_id"], rec["target_system_id"], rec["environment_id"]) == (self.ctx.tenant_id, self.target_system_id, self.environment_id): self.last_record = rec
        except Exception: self.last_record = None
        return self.current()
    # ---- state records
    def current(self): return self.d.store.get(self.ctx, "integration_state", self.integration_id)
    def name(self): c = self.current(); return c["state"] if c else "(none)"
    def state(self): return self.name()
    def manifest_ref(self):
        c = self.current()
        return c["manifest_ref"] if c else {"id": "manifest-" + self.integration_id, "version": "0.0.0", "hash": sha({"draft": self.integration_id})}
    def _fire(self, trigger, rule, ev_obj, **fields):
        cur = self.name(); to = self.sm.next(cur, trigger); now = self.d.clock.iso(); cu = self.current() or {}
        if cur != "(none)":
            tr = {"transition_id": self.d.ids.next("trn"), "contract_kind": "StateTransition", "integration_id": self.integration_id, "tenant_id": self.ctx.tenant_id, "from_state": cur, "to_state": to, "trigger": trigger, "deterministic_rule_id": rule, "evidence_ref": evidence("transition", ev_obj, "ev-%s" % self.d.ids.next("evd")), "occurred_at": now}
            validate("integration#StateTransition", tr); self.d.store.put(self.ctx, "integration_transitions", "%s:%06d" % (self.integration_id, self.d.store.next_sequence(self.ctx, "transitions:" + self.integration_id)), tr)
        else: self.d.store.put(self.ctx, "integration_events", "%s:created" % self.integration_id, {"kind": "CREATED", "at": now, "rule": rule})
        rec = {"contract_kind": "IntegrationState", "integration_id": self.integration_id, "tenant_id": self.ctx.tenant_id, "manifest_ref": fields.pop("manifest_ref", self.manifest_ref()), "state": to, "state_since": now,
               "trust_basis": fields.pop("trust_basis", {"manifest_validated": False, "fingerprint_matches_manifest": False, "translation_pack_pinned": False}), "transport_signals": {"informational": True}}
        rec.update(fields); validate("integration#IntegrationState", rec); self.d.store.put(self.ctx, "integration_state", self.integration_id, rec)
        self.d.tel.set(self.ctx.tenant_id, self.integration_id, "discovery_state", to); self.d.notify(self.ctx, self.anchor_module, rec); return rec
    def _fail(self, out):
        err = out.error or {"code": "UNKNOWN_EXTERNAL_ERROR", "retryable": False, "message_redacted": "external error"}
        if out.result["outcome_kind"] == "DATA_INVALID": err = dict(err, code="MALFORMED_RESPONSE")
        trig = "AUTHENTICATION_REJECTED" if err["code"] == "AUTHENTICATION_FAILED" else "CONNECTION_LOST"; return self._fire(trig, "rule-transport-failure", err, last_failure=err)
    # ---- phases
    def activate(self):
        cur = self.name()
        if cur == "ACTIVE": return self.current()
        if cur == "SUSPENDED": raise AuifError("integration is suspended; resume() first")
        if cur in ("(none)", "SCHEMA_DRIFT", "VERSION_INCOMPATIBLE") and cur != "MAPPING": self._fire("DISCOVERY_STARTED", "rule-discovery-start", {"from": cur})
        elif cur in ("TRANSLATION_INVALID", "SEMANTIC_AMBIGUITY"): self._fire("MAPPING_STARTED", "rule-remap", {"from": cur})
        elif cur in ("CONNECTION_FAILED", "AUTHENTICATION_FAILED"): self._fire("VALIDATION_STARTED", "rule-recover", {"from": cur}); self.raw = None
        return self._advance()
    def _advance(self):
        for _ in range(8):
            s = self.name()
            if s == "DISCOVERING": self._discover_phase()
            elif s == "DISCOVERED": self._fire("MAPPING_STARTED", "rule-mapping-start", {"record": "present"})
            elif s == "MAPPING": self._mapping_phase()
            elif s == "VALIDATING": self._validate_phase()
            else: break
        return self.current()
    def _discover_phase(self):
        out = self.runtime.call(self.ctx, self.integration_id, self.target_system_id, self.environment_id, "discover")
        if out.result["outcome_kind"] != "DATA_OBTAINED": return self._fail(out)
        self.raw = out.data; rec = self._record_discovery(self.raw)
        self._fire("DISCOVERY_COMPLETED", "rule-discovery-complete", {"record": rec["discovery_record_id"], "fingerprint": self.fp["value"]})
    def _record_discovery(self, raw):
        """Build, validate and PERSIST a System Discovery Record for `raw` and make it the latest one. Every path that obtains a discovery (first activation, recovery, resume, restart) goes through here."""
        rec = self.d.discovery.build_record(self.ctx, self.integration_id, self.target_system_id, self.environment_id, {"id": self.runtime.desc["connector_id"], "version": self.runtime.desc["connector_version"]}, raw)
        self.d.store.put(self.ctx, "discovery_records", rec["discovery_record_id"], rec); self.d.store.put(self.ctx, "discovery_latest", self.integration_id, {"discovery_record_id": rec["discovery_record_id"]})
        self.last_record = rec; self.fp = rec["schema_fingerprint"]; self.d.tel.set(self.ctx.tenant_id, self.integration_id, "schema_fingerprint", self.fp["value"]); return rec
    def _pack(self): return self.d.packs.get(self.pack_ref["id"], self.pack_ref["version"], self.pack_ref["hash"])
    def _reject(self, reason_list):
        diag = {"reasons": reason_list[:20]}; ev = evidence("diagnostics", diag, "diag-%s" % self.d.ids.next("evd")); self.d.store.put(self.ctx, "integration_diagnostics", ev["evidence_id"], diag); return self._fire("TRANSLATION_REJECTED", "rule-translation-rejected", diag, diagnostics_ref=ev)
    def _pack_gate(self):
        """Pack pin, compatibility, ambiguity and entity-mapping checks. Run on EVERY path into validation (first activation, recovery, resume, pack upgrade): no path reaches ACTIVE around them."""
        try: pack = self._pack()
        except PackError as e: self._reject(["pack pin cannot be honoured: %s" % e]); return False
        probs = compat_problems(pack, self.d.model.version)
        if probs:
            comp = "CANONICAL_MODEL" if "canonical" in probs[0] else "AUIF"; self._fire("VERSION_CHECK_FAILED", "rule-version-check", {"problems": probs}, incompatibility={"component": comp, "found": self.d.model.version if comp == "CANONICAL_MODEL" else "1.0.0", "required": probs[0][:200]}); return False
        amb = [m["mapping_id"] for m in pack["mappings"] if m["mapping_state"] == "AMBIGUOUS"]
        if amb:
            self.d.tel.set(self.ctx.tenant_id, self.integration_id, "ambiguous_mappings", len(amb)); self._fire("AMBIGUITY_DETECTED", "rule-ambiguity", {"mappings": amb}, ambiguity_ref=evidence("ambiguity", {"mappings": amb}, "amb-%s" % self.d.ids.next("evd"))); return False
        rec = self.last_record
        if rec is None: self._reject(["no discovery record is available for validation: discovery coverage cannot be established"]); return False        # fail closed: absence is NOT 'nothing missing'
        missing_kinds = REQUIRED_FOR_ACTIVATION - set(rec["coverage"]["obtained_kinds"])
        if missing_kinds: self._reject(["discovery coverage insufficient: %s" % sorted(missing_kinds)]); return False
        ents = {m["source_ref"] for m in pack["mappings"] if m["kind"] == "ENTITY" and m["mapping_state"] in ("VALIDATED", "TRUSTED")}; bad = [e for e in self.entities if e not in ents]
        if bad: self._reject(["no validated entity mapping for %s" % bad]); return False
        return True
    def _mapping_phase(self):
        if self._pack_gate(): self._fire("VALIDATION_STARTED", "rule-validation-start", {"pack": self._pack()["artifact_hash"]})
    def _validate_phase(self):
        if self.raw is None:        # restart, resume or recovery: take a FRESH discovery and record it, so coverage is judged on what the target exposes NOW, not on memory
            out = self.runtime.call(self.ctx, self.integration_id, self.target_system_id, self.environment_id, "discover")
            if out.result["outcome_kind"] != "DATA_OBTAINED": return self._fail(out)
            self.raw = out.data; self._record_discovery(self.raw)
        if not self._pack_gate(): return
        pack = self._pack(); cur = fingerprint(self.raw); self.fp = cur; expect = pack["schema_expectations"]["compatible_fingerprints"]
        base = self.d.store.get(self.ctx, "baselines", self.integration_id)
        if cur["value"] not in expect:
            ev = self._pack_drift(cur, expect[0], base); return self._fire("FINGERPRINT_MISMATCH", "rule-fingerprint-mismatch", ev, drift_evidence=ev)
        discovered = {"%s.%s" % (e["name"], f["name"]) for e in self.raw.get("entities", []) for f in e.get("fields", [])}; missing = []
        for m in pack["mappings"]:
            if m["mapping_state"] in ("VALIDATED", "TRUSTED") and m["kind"] == "FIELD" and m["source_ref"].split(".")[0] in self.entities and m["source_ref"] not in discovered: missing.append(m["source_ref"])
        if missing: return self._reject(["mapped source fields not present in the discovered schema: %s" % sorted(missing)])
        mver = "1.0.%d" % self.d.store.next_sequence(self.ctx, "manifest-version:" + self.integration_id); ops = self.raw.get("operations", [])
        acts = sorted({m["canonical_ref"] for m in pack["mappings"] if m["kind"] == "ACTION" and m["mapping_state"] in ("VALIDATED", "TRUSTED") and m["outbound"]["supported"] and m["source_ref"] in {o["name"] for o in ops}})
        classes = sorted({a["default_classification"] for m in pack["mappings"] if m["kind"] == "ENTITY" and self.d.model.has(m["canonical_ref"]) for a in self.d.model.attributes(m["canonical_ref"]).values()})
        man = {"contract_kind": "IntegrationManifest", "manifest_id": "manifest-" + self.integration_id, "manifest_version": mver, "tenant_id": self.ctx.tenant_id, "anchor_module": self.anchor_module, "target_system_id": self.target_system_id, "target_environment": self.environment_id,
               "connector": {"id": self.runtime.desc["connector_id"], "version": self.runtime.desc["connector_version"]}, "target_system_version": str(self.raw.get("system_version", "NOT_PROVIDED")), "schema_fingerprint": cur, "translation_pack": dict(self.pack_ref), "canonical_model_version": self.d.model.version,
               "capabilities": sorted({o.get("kind", "read") for o in ops}) or ["read"], "data_classifications": classes, "supported_actions": acts, "event_model": {"event_types": sorted(e["name"] for e in self.raw.get("events", []))}, "identity_mapping": {"scheme": "canonical_id=<canonical_type>:<source_system>:<source_id>"},
               "integration_state": "ACTIVE", "validation_state": "VALIDATED", "manifest_scope": "INTEGRATION_CONFIGURATION", "governance_authority": "NONE", "manifest_hash": "0" * 64}
        man["manifest_hash"] = sha({k: v for k, v in man.items() if k != "manifest_hash"}); validate("integration#IntegrationManifest", man); self.d.store.put(self.ctx, "integration_manifests", "%s:%s" % (man["manifest_id"], mver), man)
        self.d.store.put(self.ctx, "baselines", self.integration_id, {"fingerprint": cur, "snapshot": snapshot(self.raw), "manifest_version": mver}); self.d.tel.set(self.ctx.tenant_id, self.integration_id, "translation_version", pack["pack_version"])
        self._fire("VALIDATION_COMPLETED_AND_MANIFEST_MATCHED", "rule-validation-complete", {"manifest_hash": man["manifest_hash"]}, manifest_ref={"id": man["manifest_id"], "version": mver, "hash": man["manifest_hash"]}, trust_basis={"manifest_validated": True, "fingerprint_matches_manifest": True, "translation_pack_pinned": True})
    def _pack_drift(self, cur, expected_value, base):
        if base: 
            ev = detect_drift(self.d.clock, self.d.ids, base["fingerprint"], cur, base["snapshot"], snapshot(self.raw), self.governed_operations)
            if ev: return ev
        ops = sorted(o["name"] for o in self.raw.get("operations", []))
        ev = {"drift_id": self.d.ids.next("drift"), "detected_at": self.d.clock.iso(), "current_fingerprint": cur, "manifest_fingerprint": {"algorithm": "sha256", "canonicalization_id": FP_CANON, "value": expected_value, "scope": list(FP_SCOPE)}, "comparison": "MISMATCH", "technically_affected_operations": ops, "unaffected_operations_continue": [],
              "governed_operations_blocked": bool(self.governed_operations), "governance_consequence": {"determined_by": "GOVERNOR", "status": "PENDING" if self.governed_operations else "NOT_APPLICABLE_UNGOVERNED"}}
        return validate("integration#DriftEvidence", ev)
    # ---- runtime checks
    def _report_drift(self, ev, condition):
        """CF-1 (rev9). AUIF REPORTS; the Governor determines the consequence. The report can FAIL: the call can raise, or answer with something that is not a valid acknowledgement. Either way it is an UNACKNOWLEDGED report:
        the consequence stays PENDING, the drift evidence is still stored and the integration still moves to SCHEMA_DRIFT, so governed operations WAIT (fail-closed). Only a well-formed acknowledgement (a dict whose `acknowledged` is exactly True and whose
        `report_id` yields valid evidence) makes the consequence REPORTED. Never raises for an operational failure (a process exit such as KeyboardInterrupt is not swallowed)."""
        try: ack = self.d.governor.report_condition(self.ctx, condition)
        except Exception: ack = None
        rid = ack.get("report_id") if type(ack) is dict and ack.get("acknowledged") is True else None
        if type(rid) is str:
            try:
                cand = dict(ev, governance_consequence={"determined_by": "GOVERNOR", "status": "REPORTED", "report_ref": evidence("governor-report", {"report_id": rid}, rid)}); validate("integration#DriftEvidence", cand); return cand
            except Exception: pass                                      # an acknowledgement that does not yield valid evidence is not an acknowledgement
        self.d.tel.inc(self.ctx.tenant_id, self.integration_id, "governor_report_unacknowledged"); return ev
    def check_drift(self):
        if self.name() not in ("ACTIVE",): return None
        out = self.runtime.call(self.ctx, self.integration_id, self.target_system_id, self.environment_id, "discover")
        if out.result["outcome_kind"] != "DATA_OBTAINED": self._fail(out); return None
        raw = out.data; base = self.d.store.get(self.ctx, "baselines", self.integration_id); cur = fingerprint(raw)
        ev = detect_drift(self.d.clock, self.d.ids, base["fingerprint"], cur, base["snapshot"], snapshot(raw), self.governed_operations)
        if ev is None: return None
        self.raw = raw
        if self.governed_operations:                        # AUIF REPORTS; the Governor determines the consequence. AUIF does not invalidate any governance fact.
            ev = self._report_drift(ev, {"kind": "MANIFEST_DRIFT", "integration_id": self.integration_id, "drift_id": ev["drift_id"], "affected_operations": ev["technically_affected_operations"], "governed_operations_blocked": ev["governed_operations_blocked"], "current_fingerprint": cur["value"], "manifest_fingerprint": base["fingerprint"]["value"]})                # CF-1 (rev9): a failed or malformed report is an UNACKNOWLEDGED report, never an escape from the drift state
        validate("integration#DriftEvidence", ev); self.d.store.put(self.ctx, "drift_evidence", ev["drift_id"], ev); self.d.tel.inc(self.ctx.tenant_id, self.integration_id, "drift"); self._fire("FINGERPRINT_MISMATCH", "rule-fingerprint-mismatch", ev, drift_evidence=ev); return ev
    def operation_allowed(self, op, governed):
        c = self.current()
        if not c: return False
        if c["state"] == "ACTIVE": return True
        if c["state"] == "SCHEMA_DRIFT": return (not governed) and op in c["drift_evidence"]["unaffected_operations_continue"]        # unaffected, non-governed operations may continue; governed ones wait for the Governor
        return False
    def entity_readable(self, entity):
        c = self.current()
        if not c: return False
        if c["state"] == "ACTIVE": return True
        if c["state"] != "SCHEMA_DRIFT": return False
        base = self.d.store.get(self.ctx, "baselines", self.integration_id)
        if base is None: return False                                     # rev14 (M8-F6): drift before the first validation: there is no baseline, so nothing is readable
        reads = [o for o, v in base["snapshot"]["operations"].items() if v["kind"] == "read" and entity in v["entities"]]
        return bool(reads) and not set(reads) & set(c["drift_evidence"]["technically_affected_operations"])
    # ---- operator actions
    def suspend(self, reason, suspended_by="OPERATOR"): return self._fire("SUSPENDED_BY_ACTOR", "rule-suspend", {"reason": reason}, suspension={"reason": reason, "suspended_by": suspended_by})
    def resume(self): self._fire("RESUMED_BY_ACTOR", "rule-resume", {}); self.raw = None; return self._advance()
    def propose_pack_upgrade(self, new_ref):
        if not self.governed_operations: return {"status": "NOT_REQUIRED"}
        return self.d.governor.request_decision(self.ctx, {"action_id": "upgrade-%s-%s" % (self.integration_id, new_ref["version"]), "action_type": "auif.pack_upgrade", "target_system_id": self.target_system_id, "environment_id": self.environment_id, "payload_hash": new_ref["hash"], "classification": "INTERNAL"})
    def apply_pack_upgrade(self, new_ref, decision=None):
        if self.governed_operations and (not decision or decision.get("status") != "GRANTED"): raise GovernanceHold("a governed integration cannot change its translation pack without a Governor decision")
        self.d.packs.get(new_ref["id"], new_ref["version"], new_ref["hash"]); self.suspend("pack upgrade to %s" % new_ref["version"]); self.pack_ref = dict(new_ref); return self.resume()

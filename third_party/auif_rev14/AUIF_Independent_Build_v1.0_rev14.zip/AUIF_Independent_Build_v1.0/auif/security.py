"""Untrusted-input handling (handoff sections 39, 40, 61). External data is data, never an instruction channel."""
import re
from .errors import UntrustedInput
FORBIDDEN_KEYS = {"__proto__", "constructor", "prototype"}
INSTRUCTION_PATTERNS = [re.compile(p, re.I) for p in (r"ignore (all |any |your )?(previous|prior|above) (rules|instructions)", r"disregard .{0,30}(rules|instructions|policy)", r"you are now", r"system prompt", r"(send|forward|exfiltrate) .{0,60}(to|at) (https?://|\S+@\S+)", r"act as (the )?(governor|administrator|root)", r"approve this (action|request)")]
class InputGuard:
    def __init__(self, max_bytes=1_000_000, max_depth=20, max_keys=2000, max_str=100_000, max_items=50_000): self.mb, self.md, self.mk, self.ms, self.mi = max_bytes, max_depth, max_keys, max_str, max_items
    def check(self, value):
        reasons = []; keys = [0]
        def walk(v, d, path):
            if d > self.md: reasons.append("depth exceeds %d at %s" % (self.md, path)); return
            if isinstance(v, dict):
                keys[0] += len(v)
                if keys[0] > self.mk: reasons.append("too many keys"); return
                for k, x in v.items():
                    if not isinstance(k, str): reasons.append("non-string key at %s" % path); continue
                    if k in FORBIDDEN_KEYS: reasons.append("forbidden key %r at %s" % (k, path))
                    if any(ord(c) < 32 for c in k): reasons.append("control character in key at %s" % path)
                    walk(x, d + 1, path + "/" + k)
            elif isinstance(v, list):
                if len(v) > self.mi: reasons.append("array too long at %s" % path); return
                for i, x in enumerate(v): walk(x, d + 1, "%s/%d" % (path, i))
            elif isinstance(v, str):
                if len(v) > self.ms: reasons.append("string too long at %s" % path)
                if any(ord(c) < 32 and c not in "\n\r\t" for c in v): reasons.append("control character in string at %s" % path)
            elif isinstance(v, bool) or v is None or isinstance(v, (int, float)): pass
            else: reasons.append("unexpected type %s at %s" % (type(v).__name__, path))
        walk(value, 0, "")
        import json
        try:
            if len(json.dumps(value)) > self.mb: reasons.append("payload exceeds %d bytes" % self.mb)
        except (TypeError, ValueError): reasons.append("not JSON-serialisable")
        if reasons: raise UntrustedInput(reasons)
        return value
def instruction_like(text): return isinstance(text, str) and any(p.search(text) for p in INSTRUCTION_PATTERNS)
def scan_for(obj, sentinels):
    """Return where any sentinel string appears inside obj (keys and values). Used by the credential-boundary tests."""
    hits = []
    def w(v, path):
        if isinstance(v, dict):
            for k, x in v.items():
                for s in sentinels:
                    if s in str(k): hits.append(path + "/" + str(k))
                w(x, path + "/" + str(k))
        elif isinstance(v, (list, tuple)):
            for i, x in enumerate(v): w(x, "%s/%d" % (path, i))
        else:
            for s in sentinels:
                if s in str(v): hits.append(path)
    w(obj, ""); return hits

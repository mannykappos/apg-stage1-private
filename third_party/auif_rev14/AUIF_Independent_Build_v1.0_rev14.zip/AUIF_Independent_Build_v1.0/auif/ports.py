"""PORTS: the contract-level boundary between the AUIF core and its environment. ENGINE BINDING for every port below is UNKNOWN / Amir-dependent
(architecture AR-20, EP-01..EP-10). The core depends only on these abstractions; reference implementations live OUTSIDE the core (auif_ref/, synthetic/)."""
from abc import ABC, abstractmethod
class PersistencePort(ABC):          # EP-04 (ED-08)
    @abstractmethod
    def put(self, ctx, collection, key, value, if_absent=False): ...      # returns False if if_absent and the key exists
    @abstractmethod
    def get(self, ctx, collection, key): ...                                # dict or None
    @abstractmethod
    def update(self, ctx, collection, key, fn): ...                         # atomic read-modify-write; fn(old)->new; KeyError if missing; nothing changes if fn raises
    @abstractmethod
    def list(self, ctx, collection, prefix=""): ...                         # [(key, value)] sorted by key
    @abstractmethod
    def next_sequence(self, ctx, name): ...                                 # strictly increasing int per (tenant, name), starting at 1
class SecretPort(ABC):               # EP-05 (ED-09)
    @abstractmethod
    def resolve(self, ctx, ref): ...                                        # secretref:... -> value; tenant scoped; raises SecretError
class TenantAuthorityPort(ABC):      # EP-01 (ED-03)
    @abstractmethod
    def issue(self, tenant_id, principal): ...
    @abstractmethod
    def verify(self, ctx): ...                                              # bool
class GovernorPort(ABC):             # EP-07 (ED-11, GD-03, GD-05). AUIF REQUESTS and REPORTS; it never decides.
    @abstractmethod
    def request_decision(self, ctx, request): ...                           # {"status": GRANTED|DENIED|PENDING|UNAVAILABLE, "decision_ref","decision_hash","reason"}
    @abstractmethod
    def report_condition(self, ctx, condition): ...                         # AUIF reports drift/ambiguity; Governor determines the consequence
class PolicyPort(ABC):               # OD-09 / GD-04: where policy lives is open
    @abstractmethod
    def decide(self, ctx, classification, destination, context): ...       # {"outcome": ALLOW|TRANSFORM|MASK|REJECT|NEEDS_AUTHORISATION, "transforms": [...], "basis": str} or None if undeterminable
class ModulePort(ABC):               # EP-02, EP-03 (ED-01, ED-05, ED-06); architecture AR-18 (handoff section 42)
    module_id = None
    @abstractmethod
    def ingest_canonical_entity(self, ctx, obj): ...
    @abstractmethod
    def ingest_canonical_observation(self, ctx, observation): ...
    @abstractmethod
    def ingest_canonical_event(self, ctx, observation): ...
    @abstractmethod
    def semantic_requirements(self): ...                                    # descriptor format is OD-22 (reference format only)
    @abstractmethod
    def module_capabilities(self): ...
    @abstractmethod
    def receive_integration_state(self, ctx, state): ...
    @abstractmethod
    def receive_integration_error(self, ctx, error): ...

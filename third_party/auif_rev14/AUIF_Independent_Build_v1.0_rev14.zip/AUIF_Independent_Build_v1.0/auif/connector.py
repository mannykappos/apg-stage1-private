"""Connection Layer runtime (architecture AR-5). Wraps ANY connector implementation and enforces the Connector contract: credentials only through the secret boundary,
retry/backoff/Retry-After, throttling, the failure principle (no data / could not obtain / invalid / ambiguous / stale are distinct), idempotency-gated write retries,
cancellation, error normalisation (external error text is untrusted and is never copied into results) and provenance/correlation."""
import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from .contracts import validate
from .errors import *
from .security import InputGuard
from .util import sha, evidence
ERR = {"AUTHENTICATION_FAILED", "AUTHORIZATION_DENIED_BY_TARGET", "RATE_LIMITED", "TIMEOUT", "UNAVAILABLE", "CONNECTION_FAILED", "MALFORMED_RESPONSE", "SCHEMA_MISMATCH", "UNSUPPORTED_OPERATION", "CANCELLED", "TARGET_REJECTED_REQUEST", "UNKNOWN_EXTERNAL_ERROR"}
class Connector(ABC):
    """What a connector implementation provides. It communicates; it holds NO business semantics (handoff sections 6.1, 49)."""
    connector_id = None; connector_version = None
    @abstractmethod
    def descriptor(self): ...                 # a ConnectorDescriptor (validated by the runtime)
    @abstractmethod
    def connect(self, credentials): ...
    @abstractmethod
    def disconnect(self): ...
    @abstractmethod
    def health(self): ...
    @abstractmethod
    def discover(self): ...                    # raw target metadata (dict)
    @abstractmethod
    def read(self, request): ...               # {"items": [...], "next_cursor": str|None, "complete": bool}
    @abstractmethod
    def write(self, request): ...              # {"external_reference": str, "result": {...}}; MUST honour request["idempotency_key"] if the descriptor says it can
    @abstractmethod
    def subscribe(self, request): ...
    @abstractmethod
    def unsubscribe(self, request): ...
    @abstractmethod
    def capabilities(self): ...
    def lookup_by_idempotency_key(self, key): raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED")
@dataclass
class CallOutcome:
    result: dict; data: object = None; may_have_applied: bool = False; attempts: int = 0; error: dict = None
class ConnectorRuntime:
    def __init__(self, connector, *, secrets, throttle, telemetry, clock, guard=None, seed=7, wait_budget=60.0):
        self.c, self.secrets, self.th, self.tel, self.clock, self.guard, self.rng, self.budget = connector, secrets, throttle, telemetry, clock, guard or InputGuard(), random.Random(seed), wait_budget
        self.desc = validate("connector#ConnectorDescriptor", connector.descriptor())
        if self.desc["connector_id"] != connector.connector_id or self.desc["connector_version"] != connector.connector_version: raise AuifError("descriptor does not match the connector identity")
        self.connected, self.in_flight = set(), {}
    def descriptor(self): return self.desc
    def _err(self, code, retryable, retry_after=None, status=None, original=None):
        e = {"code": code if code in ERR else "UNKNOWN_EXTERNAL_ERROR", "retryable": bool(retryable), "message_redacted": "external error: %s" % (code if code in ERR else "UNKNOWN_EXTERNAL_ERROR")}
        if retry_after is not None: e["retry_after_seconds"] = float(retry_after)
        if status is not None: e["external_status"] = status
        return e
    def _result(self, ctx, integ, tgt, env, method, corr, kind, **extra):
        r = {"contract_kind": "ConnectorResult", "method": method, "request_correlation_id": corr, "outcome_kind": kind, "connector": {"id": self.desc["connector_id"], "version": self.desc["connector_version"]}, "tenant_id": ctx.tenant_id, "target_system_id": tgt, "environment_id": env, "completed_at": self.clock.iso()}
        r.update(extra); return validate("connector#ConnectorResult", r)
    def _ensure_connected(self, ctx, key):
        if key in self.connected: return
        cred = None; auth = self.desc["authentication"]
        if auth["handling"] != "NONE":
            try: cred = self.secrets.resolve(ctx, auth["credential_ref"])
            except SecretError: raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", message="credential reference not resolvable")
        self.c.connect({"secret": cred} if cred is not None else None); cred = None; self.connected.add(key)
    def call(self, ctx, integration_id, target_system_id, environment_id, method, request=None, idempotency_key=None, cancel=None):
        if method not in self.desc["methods"]: raise AuifError("unknown connector method %r" % method)
        key = (ctx.tenant_id, integration_id); corr = "corr-%s-%s" % (integration_id, sha([method, request, idempotency_key, self.clock.now])[:12]); write = method == "write"; idem = self.desc["idempotency"]["supported"]
        if write and idem and not idempotency_key: raise AuifError("a write without an idempotency key is refused (handoff section 27)")
        rp = self.desc["retry_policy"]; max_att = (rp["max_write_attempts"] if idem else 1) if write else rp["max_attempts"]; attempts, waited, t0 = 0, 0.0, self.clock.now
        base = lambda kind, **x: self._result(ctx, integration_id, target_system_id, environment_id, method, corr, kind, **x)
        while True:
            if self.in_flight.get(ctx.tenant_id, 0) >= self.desc["concurrency"]["per_tenant_max_in_flight"]:
                e = self._err("RATE_LIMITED", True); return CallOutcome(base("COULD_NOT_OBTAIN", error=e), None, False, attempts, e)
            try: self.th.acquire(key)
            except Throttled as t:
                if waited + t.wait <= self.budget and not isinstance(t, CircuitOpen): self.clock.sleep(t.wait); waited += t.wait; self.tel.inc(ctx.tenant_id, integration_id, "rate_limited"); continue
                code = "CONNECTION_FAILED" if isinstance(t, CircuitOpen) else "RATE_LIMITED"; e = self._err(code, True, t.wait); return CallOutcome(base("COULD_NOT_OBTAIN", error=e), None, False, attempts, e)
            attempts += 1; self.in_flight[ctx.tenant_id] = self.in_flight.get(ctx.tenant_id, 0) + 1
            try:
                if method == "connect": self.connected.discard(key)                     # an explicit connect() re-establishes the session through the secret boundary
                self._ensure_connected(ctx, key)
                self.tel.set(ctx.tenant_id, integration_id, "authentication_state", "AUTHENTICATED")
                if cancel is not None and cancel(): raise Cancelled()
                req = dict(request or {}); 
                if write: req["idempotency_key"] = idempotency_key
                raw = self._invoke(method, req); data = self.guard.check(raw) if raw is not None else {}
                self.th.success(key); self.tel.inc(ctx.tenant_id, integration_id, "throughput"); self.tel.set(ctx.tenant_id, integration_id, "latency", self.clock.now - t0); self.tel.set(ctx.tenant_id, integration_id, "connection_health", "CONNECTED")
                if method == "read" and not data.get("items") and data.get("complete"): return CallOutcome(base("NO_DATA", empty_result_confirmed=True), data, False, attempts)
                return CallOutcome(base("DATA_OBTAINED", payload_hash=sha(data)), data, False, attempts)
            except TransportError as e:
                code = e.code if e.code in ERR else "UNKNOWN_EXTERNAL_ERROR"; retryable = code in rp["retry_on"] and code not in rp["never_retry_on"]; self.th.failure(key, retryable, e.retry_after)
                if code == "AUTHENTICATION_FAILED": self.connected.discard(key); self.tel.set(ctx.tenant_id, integration_id, "authentication_state", "FAILED")
                if code == "RATE_LIMITED": self.tel.inc(ctx.tenant_id, integration_id, "rate_limited")
                self.tel.inc(ctx.tenant_id, integration_id, "failures"); self.tel.set(ctx.tenant_id, integration_id, "connection_health", "DEGRADED" if retryable else "FAILED")
                maybe = write and e.applied in ("MAYBE", "UNKNOWN")
                if maybe: err = self._err(code, False, e.retry_after, e.status); return CallOutcome(base("COULD_NOT_OBTAIN", error=err), None, True, attempts, err)      # an uncertain write is NEVER retried blindly
                if retryable and attempts < max_att:
                    delay = min(rp["max_delay_ms"], rp["base_delay_ms"] * (2 ** (attempts - 1))) / 1000.0
                    if rp["jitter"] == "FULL": delay = self.rng.uniform(0, delay)
                    if e.retry_after is not None: delay = max(delay, float(e.retry_after))
                    self.clock.sleep(delay); self.tel.inc(ctx.tenant_id, integration_id, "retries"); continue
                err = self._err(code, retryable, e.retry_after, e.status); return CallOutcome(base("COULD_NOT_OBTAIN", error=err), None, False, attempts, err)
            except (MalformedResponse, SchemaMismatch, UntrustedInput) as e:
                code = "SCHEMA_MISMATCH" if isinstance(e, SchemaMismatch) else "MALFORMED_RESPONSE"; err = self._err(code, False); self.th.failure(key, False); self.tel.inc(ctx.tenant_id, integration_id, "failures")
                diag = evidence("diagnostics", {"reason": type(e).__name__, "detail_hash": sha(str(e))}, "diag-%s" % corr)
                return CallOutcome(base("DATA_INVALID", error=err, diagnostics_ref=diag), None, False, attempts, err)
            except Cancelled:
                err = self._err("CANCELLED", False); return CallOutcome(base("COULD_NOT_OBTAIN", error=err), None, write, attempts, err)        # a cancelled write has an UNKNOWN outcome until reconciled
            finally: self.in_flight[ctx.tenant_id] -= 1
    def _invoke(self, method, req):
        c = self.c
        if method == "connect": return {"connected": True}                             # session already established by _ensure_connected (credentials never pass through a caller)
        if method == "disconnect": c.disconnect(); self.connected.clear(); return {"connected": False}
        if method == "health": return c.health()
        if method == "discover": return c.discover()
        if method == "read": return c.read(req)
        if method == "write": return c.write(req)
        if method == "subscribe": return c.subscribe(req)
        if method == "unsubscribe": return c.unsubscribe(req)
        if method == "capabilities": return c.capabilities()
    def lookup(self, ctx, integration_id, key):
        try: return self.c.lookup_by_idempotency_key(key)
        except TransportError: return "UNSUPPORTED"

"""Canonical Anchor Model FRAMEWORK (architecture AR-7): definition validation, typed attribute validation, classification and provenance. It defines the SHAPE of a model;
the concrete Anchor attribute sets are an OPEN decision (OD-08, ED-04) and are not decided here. The model used in tests is SYNTHETIC."""
import re
from .contracts import validate
RANK = ["PUBLIC", "INTERNAL", "CONFIDENTIAL", "PII", "FINANCIAL", "HEALTH", "RESTRICTED", "REGULATED"]
def rank(c): return RANK.index(c) if c in RANK else RANK.index("CONFIDENTIAL")        # unknown x- classes are treated as at least CONFIDENTIAL
def top(classes): return max(classes, key=rank) if classes else "INTERNAL"
TS = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]+)?(Z|[+-][0-9]{2}:[0-9]{2})$"); DEC = re.compile(r"^-?[0-9]+(\.[0-9]+)?$")
class CanonicalModel:
    def __init__(self, definition):
        self.d = validate("canonical#CanonicalModelDefinition", definition); self.version = definition["model_version"]; self.concepts = {c["name"]: {a["name"]: a for a in c["attributes"]} for c in definition["concepts"]}
    def has(self, ctype): return ctype in self.concepts
    def attributes(self, ctype): return self.concepts[ctype]
    def problems(self, ctype, attrs):
        if ctype not in self.concepts: return ["unknown canonical type %s" % ctype]
        defs, out = self.concepts[ctype], []
        for n, a in defs.items():
            if a["required"] and (n not in attrs or attrs[n] is None): out.append("required attribute %s missing" % n)
        for n, v in attrs.items():
            if n not in defs: out.append("unknown attribute %s" % n); continue
            if v is None: continue
            t, c = defs[n]["type"], defs[n].get("constraints", {}); ok = {"STRING": isinstance(v, str), "INTEGER": isinstance(v, int) and not isinstance(v, bool), "DECIMAL": (isinstance(v, str) and bool(DEC.match(v))), "BOOLEAN": isinstance(v, bool), "TIMESTAMP": isinstance(v, str) and bool(TS.match(v)),
                  "ENUM": v in c.get("values", []), "REFERENCE": isinstance(v, str) and len(v) > 0, "OBJECT": isinstance(v, dict), "ARRAY": isinstance(v, list)}[t]
            if not ok: out.append("attribute %s is not a valid %s" % (n, t))
            elif t == "STRING" and "max_length" in c and len(v) > c["max_length"]: out.append("attribute %s exceeds max_length" % n)
        return out
    def classes(self, ctype, attrs): return {n: self.concepts[ctype][n]["default_classification"] for n in attrs if n in self.concepts[ctype]}
ATTR = re.compile(r"^[a-z][a-z0-9_]*$")
def split_ref(ref):
    """rev14 (finding M8-F1). A FIELD mapping's canonical reference is '<concept>.<attribute>'. An attribute name never contains a dot (contracts: ^[a-z][a-z0-9_]*$) while a
    MODULE concept's name does (module.<module>.<Type>), so the attribute is the part after the LAST dot and the concept is everything before it.  -> (concept, attribute);
    ('', ref) if there is no dot."""
    concept, dot, attr = str(ref).rpartition(".")
    return (concept, attr) if dot else ("", str(ref))
REQUIRED_ORDER = ["SOURCE_SYSTEM", "SOURCE_OBJECT", "SOURCE_FIELD", "TRANSLATION_PACK", "SCHEMA_FINGERPRINT", "OBSERVATION"]
def verify_chain(chain, pack_registry=None, expected_fingerprint=None):
    """Reconstruct a provenance chain: returns a list of problems (empty = fully reconstructable)."""
    kinds = [s["step_kind"] for s in chain]; out = []
    for k in REQUIRED_ORDER:
        if k not in kinds: out.append("missing %s" % k)
    last = -1
    for k in REQUIRED_ORDER:
        if k in kinds:
            i = kinds.index(k)
            if i < last: out.append("%s out of order" % k)
            last = max(last, i)
    for s in chain:
        if s["step_kind"] == "TRANSLATION_PACK":
            if "version" not in s or "hash" not in s: out.append("pack step lacks version or hash")
            elif pack_registry is not None:
                try: pack_registry.get(s["ref"], s["version"], s["hash"])
                except Exception as e: out.append("pack does not resolve: %s" % e)
        if s["step_kind"] == "SCHEMA_FINGERPRINT" and expected_fingerprint is not None and s.get("hash") != expected_fingerprint: out.append("fingerprint differs from the expected one")
    return out

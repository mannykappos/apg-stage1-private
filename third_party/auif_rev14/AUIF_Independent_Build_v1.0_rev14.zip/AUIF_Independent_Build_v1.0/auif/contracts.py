"""Runtime enforcement of the audited Revision 2 contracts (contracts/*.schema.json) with the vendored fail-closed validator."""
import glob, json, os
from . import _schema_validator as V
from .errors import ContractViolation
_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "contracts")
class Contracts:
    def __init__(self, directory=_DIR):
        self.reg = V.load_registry(sorted(glob.glob(directory + "/*.schema.json"))); self.v = V.Validator(self.reg)
        for d in self.reg.values(): self.v.check_schema(d)
        self.uri = {u.split("/")[-2]: u for u in self.reg}; self.state_machine = json.load(open(directory + "/integration_state_machine.json"))
    def errors(self, ref, obj):
        name, d = ref.split("#"); return self.v.validate(obj, {"$ref": "%s#/$defs/%s" % (self.uri[name], d)}, "")
    def validate(self, ref, obj):
        e = self.errors(ref, obj)
        if e: raise ContractViolation(ref, e)
        return obj
_C = None
def contracts():
    global _C
    if _C is None: _C = Contracts()
    return _C
def validate(ref, obj): return contracts().validate(ref, obj)

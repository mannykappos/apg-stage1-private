# AUIF Independent Build v1.0 (reference implementation)

A reference implementation of the Anchor Universal Integration Fabric, built from the independently audited **Architecture v1.0-DRAFT Revision 2** (audited package sha256 `31cb5f988d1b04cf4c6edf37a6f53fe4e4ef3a0221d6e60c1d6bee4db7658f20`). It is proven on a **synthetic** world. It is **not** integrated with the Anchor Engine, **not** production-ready, and **no** Engine-dependent item is closed. The architecture's lock status is unchanged: it remains the audited DRAFT.

## Layout
| Path | What it is |
|---|---|
| `auif/` | The core (rev14 revises it in five files: findings M8-F1 to M8-F6, section 17 of the report). Python standard library only; imports nothing but itself (checked by `tools/static_checks.py`). |
| `auif_ref/` | Reference implementations of ports (in-memory and SQLite persistence, secret store). Not the Engine's. |
| `synthetic/` | Test doubles: three external systems, three connectors, packs, modules, Governor and policy doubles, AI stubs, the world. Never imported by the core. |
| `port_contracts/` | Conformance suites any port binding must pass, plus templates for a real binding. |
| `contracts/` | Byte copies of the audited schemas and state machine. |
| `tests/` | The test suite, including `test_acceptance.py` (AT-01..AT-30). |
| `auif_ext/` | **extensions, carried from rev8; rev12 adds one optional tenant-header setting to the REST connector; rev14 makes `BaseModule` report a handler failure to the fabric (M8-F4)** (a separate package; the core does not import it): connector kit, module client, Governor adapter. See `AUIF_EXTENSIONS.md`. |
| `auif_onboard/` | **the onboarding accelerator (rev11; rev12 adds wrapped-list, tenant-header and entity-exclusion handling; rev14 reads module-concept field references correctly)**: a drafting and review accelerator, not an onboarding authority. It sits above `auif/` and `auif_ext/`; nothing in them imports it. See `AUIF_ONBOARDING.md`. |
| `tools/` | Static checks, mutation testing (core and extensions), generators. |
| `evidence/` | Mutation, coverage and performance results; byte-identical audited inputs; the record on unexplained files. |

## Run
```
export PYTHONDONTWRITEBYTECODE=1
python3 -W ignore -m unittest discover -s tests -t .      # full suite (seconds)
python3 tools/static_checks.py                            # import graph, forbidden tokens, authority-API names
python3 tools/mutation_test.py                            # 174 guard mutants in temp copies (roughly 16 to 18 minutes on the reference machine; the shipped verifier waits for it); read-only unless --write is given
python3 -W ignore -m unittest discover -s auif_ext/tests -t .   # the extension tests (set AUIF_GOVERNOR_R14_ZIP to also run against the real R14 Governor)
python3 tools/static_checks_ext.py                        # extension imports, names, constructs, sockets, core hash
python3 tools/ext_reverse_contamination.py                # the core passes with auif_ext removed
python3 tools/mutation_ext.py                             # mutation testing of the extension guards
python3 -W ignore -m unittest discover -s auif_onboard/tests -t .   # the onboarding accelerator's tests
python3 tools/static_checks_onboard.py                    # accelerator imports, authority names, approval capability confined to review.py, secrets, core hash
python3 tools/onboard_reverse_contamination.py <core> <ext> <ext_skipped> <pinned_core_hash>   # core and extensions pass, unchanged, with auif_onboard removed
python3 tools/mutation_onboard.py                         # mutation testing of the accelerator's guards
python3 -m auif_onboard draft --spec API.json --canonical-model MODEL.json --out DIR   # draft a connector config and a candidate pack (approves nothing)
```
No network and no third-party packages are needed. The Amir handoff was prepared from rev6.1; rev10 (a core revision: CF-4, section 13 of the report; it carries rev9's CF-1 and CF-2 fixes, section 12) was independently audited and closed (as relayed by the owner; the builder does not certify closure). rev11 to rev13 changed no core file; rev11 added the onboarding accelerator `auif_onboard/` (section 14 of the report). **rev14 revises the core again** (five files, the six defects found while building APG-M8; section 17 of the report and `CHANGES_rev14.md`): it is a builder revision awaiting independent audit, not accepted.

## Regenerate derived documents (in this order)
```
python3 tools/gen_docs.py          # Amir register and port templates
python3 tools/mutation_test.py --write   # refreshes evidence/mutation_results.json
python3 tools/gen_reports.py       # ACCEPTANCE_RESULTS, both RTMs, coverage (runs the whole suite)
python3 tools/gen_final.py --force # this README, COMPONENT_STATUS, AMIR_HANDOFF, BUILD_REPORT, FILE_MANIFEST
```

## Verify a package (fresh ZIP, exactly this order)
```
python3 tools/verify_fresh_zip.py AUIF_Independent_Build_v1.0_rev14.zip
```
Checks the zip against its sidecar hash, extracts it, verifies the manifest (hash, size, missing and unlisted files, tree hash), runs the tests and static checks (and, when `auif_ext/` is present, the extension tests, extension static checks and reverse contamination, with their evidence required), (and, when `auif_onboard/` is present, the accelerator's tests, static checks, reverse contamination and recorded evidence, all required), re-verifies the manifest, runs mutation testing (core, then extensions, then the accelerator), re-verifies the manifest. Set `AUIF_GOVERNOR_R14_ZIP` to also re-run the extension tests against the real R14 Governor. Passes only if there are zero mismatches after every step. Running the tests or mutation testing never modifies a tracked file; evidence is rewritten only by `gen_reports.py` and `mutation_test.py --write`. `python3 tools/verify_package.py [root]` verifies one extracted tree.

Replay the independent audit's scenarios (each writes nothing): `python3 tools/audit_round1_replay.py`, `python3 tools/audit_round2_replay.py` and `python3 tools/audit_round3_replay.py`.

## Read first
`BUILD_REPORT.md` (result and three-category status; section 11 for the carried extensions, section 12 for the rev9 core revision, section 13 for the rev10 core revision, section 14 for the rev11 onboarding accelerator, section 15 for rev12, section 16 for rev13, section 17 for rev14), `CHANGES_rev14.md`, `AUIF_ONBOARDING.md`, `CHANGES_rev13.md`, `CHANGES_rev12.md`, `CHANGES_rev11.md`, `AUIF_EXTENSIONS.md`, `KNOWN_LIMITATIONS.md`, `AMIR_ENGINE_DEPENDENCY_TODO.md` and `AMIR_HANDOFF.md` (18 Engine-dependent items), `UNRESOLVED_GOVERNOR_DECISIONS.md`, `DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md`, `evidence/UNEXPLAINED_ARTEFACTS_STATUS.md`.

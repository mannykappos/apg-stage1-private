# rev10: what changed, and why (versus rev9)

rev10 is a **core revision**. It fixes one finding, CF-4, and nothing else. rev9 (audited and closed as a core revision, as relayed by the owner) is not modified; rev10 is a new package built from it.

## Changed (the full list of differences from rev9's package, apart from generated reports)
| File | Change |
|---|---|
| `auif/action.py` | **CF-4.** New `ActionService.recover_stale_acknowledged(ctx, stale_after_seconds)`. An ACKNOWLEDGED record that is at least `stale_after_seconds` old and carries the target's external reference and acknowledgement time is completed as APPLIED by the transition that already existed (ACKNOWLEDGED to COMPLETED). Nothing is sent, nothing is looked up, no Governor decision is requested. A record without the reference or timestamp is reported for an operator and left alone. |
| `tests/test_cf4_stale_acknowledged_recovery.py` | New: 21 regression tests (20 of the CF-4 behaviours plus the module's helper class, which the loader counts). 18 of the 20 behaviour tests fail against rev9's unfixed core; the other two pass there by design (one records the defect, one proves the CF-2 sweep still leaves ACKNOWLEDGED alone). |
| `tools/mutation_test.py` | 19 new mutants (M115 to M133) for the new guards. Six rev9 mutants (M100, M101, M102, M106, M113, M114) were re-anchored on text unique to the CF-2 method, because the new method shares its validation lines; their mutations are unchanged. |
| `tools/gen_final.py` | Wording made true for rev10; section 12 now records rev9's audited numbers as constants; a measured section 13. |
| `auif_ext/tests/test_extension_boundary.py` | The pinned core hash literal only. Everything else in `auif_ext/` is byte-identical to rev9's. |
| `KNOWN_LIMITATIONS.md`, `DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md`, `AUIF_EXTENSIONS.md` | Limitation 31 is now "fixed" with its caveats, decision D-42, a rev10 note. |
| `evidence/cf4_fix_demonstration.*`, `evidence/cf4_reproduction.*` | New demonstration (ungoverned and governed); the rev9 reproduction kept with its header clarified. |
`contracts/`, `synthetic/`, `auif_ref/` and `port_contracts/` are byte-identical to rev8's and rev9's. `auif/integration.py` (CF-1) and the rest of `auif/` are byte-identical to rev9's. The GD-05 overlay, the locked Layer 1 specification, the Governor and rev9 are untouched.

## The authoritative transition
ACKNOWLEDGED is written only after the target's reply carried its external reference, and the very next step in `dispatch()` is ACKNOWLEDGED to COMPLETED. That transition is already in the audited transition table, so the recovery takes exactly the step the crashed dispatch would have taken. No new state, no schema change, no contract change.

## Why it cannot duplicate the effect or ask for another decision
It never calls the target (no write, no read, no reconciliation query: a test asserts zero calls) and never calls the Governor port (a governed test asserts the decision count and the stored decision reference and hash are unchanged). A second sweep, a later `dispatch()` or `reconcile()` finds the record terminal and does nothing.

## Deliberately NOT changed
- **CF-3** (restart before the durable SENT asks for a second decision): accepted behaviour under G4 and G5.
- **CF-2** (`recover_stale_sent`) and **CF-1**: unchanged.
- Nothing about Layer 2, a production Governor binding, the Engine or any real system.

## Using the CF-4 sweep
Call `fabric.actions.recover_stale_acknowledged(ctx, stale_after_seconds)` periodically and serially with dispatch, alongside `recover_stale_sent`. `stale_after_seconds` must exceed the longest a live dispatch can spend between its ACKNOWLEDGED and COMPLETED writes. It reports what it completed, what was too recent, what had moved on, and anything it could not resolve.

## Evidence
See `BUILD_REPORT.md` section 13, `ACCEPTANCE_RESULTS.md`, `evidence/mutation_results.json` (core mutation), `evidence/ext_verification.json` and `evidence/cf4_fix_demonstration.txt`. Everything is for independent audit; none of it is a closure.

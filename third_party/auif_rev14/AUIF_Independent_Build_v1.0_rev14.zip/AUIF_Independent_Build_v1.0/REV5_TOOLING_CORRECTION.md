# rev5: tooling-only correction

## Why
rev4 passed the independent audit of its implementation (F1-F7), but its shipped `tools/verify_fresh_zip.py` ran the mutation step under a fixed 900 s limit. The 86-mutant run takes roughly 15 to 16 minutes on the machine used, so the shipped verifier timed out in the mutation step (observed on a quiet machine: steps 1-6 passed, then `TimeoutExpired`). rev4 could therefore not honestly claim to pass its own complete fresh-ZIP procedure. This is a verification-tool limitation, not an implementation defect.

## What changed (and nothing else)
- `tools/verify_fresh_zip.py`: the mutation step waits for the run to finish. A limit exists only if the caller passes `--mutation-timeout=SECONDS`; if that explicit limit elapses the step is reported as FAIL, "not a verdict on the package". The step also reports its elapsed seconds.
- `tests/test_verifier_tooling.py` (6 tests): no default limit; an explicit limit is parsed and honoured; nonsense limits are refused; `sh` with no timeout waits for a slow command; `sh` with an explicit timeout still stops a hung one; the mutation step takes its limit from the caller and contains no numeric literal limit.
- `KNOWN_LIMITATIONS.md` item 26; this note; the generated documents (README, BUILD_REPORT, handoff, component status, acceptance results, traceability tables, manifest) regenerated for the new test count and revision history.

## What did NOT change
No production file (`auif/`), no contract, no synthetic or reference-port file, no mutant definition and no mutation result: **the core tree hash is identical to rev4** (`024667e1ccbc1f721fd06578d616fa8343c76a0b9b4b04b617a72f6bedffdcd4`), and `evidence/mutation_results.json` is the rev4 file (86 mutants, 86 killed). The architecture, Governor and the audited package are untouched. Open limitations 18, 23, 24 and 25, decisions D-1..D-18 and findings F-1..F-4 are unchanged and unresolved.

## How rev5 is verified
The shipped verifier, taken from a fresh extraction of the rev5 zip itself, is run against that zip with no external harness: sidecar hash, extraction, manifest, self-test, tests, static checks, both replays, manifest, mutation, manifest. A package cannot contain the result of its own verification, so that result and the final byte comparison are recorded outside the zip (in the verification evidence delivered with it).

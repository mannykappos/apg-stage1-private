# rev12: what changed, and why (versus rev11)

rev12 closes the gaps that the **first real-API draft** exposed. In the Real-System Sandbox Proof the unmodified rev11 accelerator was run, offline and with no credential, on a real vendor's published OpenAPI description (an accounting API with about 40 list endpoints). The draft showed what a synthetic specification could not: rev11 could not draft that API's wrapped lists, its tenant-scoping header, or its unpaged endpoints, and it let unrelated report endpoints collapse into one entity. rev12 fixes those, **in the accelerator and in one connector setting of the extension layer, and nowhere else**. The audited core (`auif/`), Governor, GD-05 and Layer 2 are untouched; rev11 is pinned and unmodified.

**rev12 is not a real-system validation.** No credential was used and no real system was contacted. The vendor description was read as a file; every claim about the real API in this document is a claim about what its *description* says, to be tested in the gated live phase.

## What the first real draft found, and what rev12 does about it
| # | Finding (real description, rev11) | rev12 |
|---|---|---|
| F1 | Only OAuth2 authorization-code is declared; the draft correctly refused (`auth` blocking). | **Unchanged on purpose.** No authorization-code flow is added. A named human may override `auth` to client credentials when the provider offers a machine-to-machine connection for one organisation (approval recipe below); the generator never decides that. |
| F2 | Every operation requires a tenant header; the connector could not send one. | `RestConfig.tenant_header` / `tenant_id` (extension layer, `connectors/rest.py`): sent on every API call, **never** to the token endpoint, never part of the credential, validated (reserved and colliding header names refused; value limited to `[A-Za-z0-9._:-]`, 1 to 100). The generator drafts the header NAME only when every used operation requires it; the VALUE is a blocking question for the human (`tenant_id`). |
| F3 | About 20 entities had no paging style (blocking). | Page-numbered paging with a page-count object already worked in the connector (rev8); the generator now reads it correctly once the list is found (F4). Endpoints with **no** paging signal stay blocking, and now name `single_page` as the one choice a human may make (an assertion that one response is complete; larger responses are refused, not truncated). |
| F4 | Ten list endpoints return `{Records: [...], Warnings: [...]}`; the record list was "not decidable". | Deterministic rule: arrays with a known envelope name (warnings, errors, messages, validation errors, links, problems, meta) are not record lists; if several arrays remain, the one named like the last path segment. Recorded as an *assumed default* with its reason, so a human sees it; otherwise still undecidable. |
| F5 | Nine report endpoints collapsed into one entity; non-record resources were drafted as entities. | Several list endpoints resolving to one entity name: the one whose path names the entity (singular or plural) is used, else **none** is (all listed as unsupported, non-blocking). A record schema with no identifier property is **reported, not removed** (removal would drop reference data keyed by code). |
| F6 | Junk entities forced a decision about every blocking item. | A named reviewer may **exclude** an entity (`entities.<E>.list: null`); its blocking questions fall away, and once the configuration is approved the pack can no longer approve a mapping for it. |
| F7-F9 | Multi-parameter paths, several write verbs, id field naming. | Unchanged; reported as before. Listed for the live phase below. |

## Added / changed
| Path | Change |
|---|---|
| `auif_ext/connectors/rest.py` | Two optional `RestConfig` fields (`tenant_header`, `tenant_id`) and their validation and use. **The only change to any rev10 layer.** |
| `auif_ext/tests/test_rest_tenant.py` | 13+ tests: header on every call kind, not on the token endpoint, never replacing credential headers, refusals, wrapped page walk. |
| `auif_onboard/openapi.py`, `config_gen.py`, `review.py`, `validate.py`, `rest_adapter.py` | Required-header parameters read; wrapped-list rule; name-collision rule; keyless report; tenant detection; `single_page` offered; entity exclusion; pack approval consults the approved configuration; stand-in tenant for the synthetic run; adapter passes the two fields. |
| `auif_onboard/tests/test_tenant_shape.py` | New tests on a synthetic API with the real API's shapes (nothing real is named or contacted). Three older tests were updated because they asserted behaviour rev12 deliberately changes (listed in the evidence). |
| `tools/mutation_ext.py`, `tools/mutants_onboard.py` | New mutants for every new guard; seven rev11 mutants re-anchored to the changed code. |
| `tools/onboard_evidence.py`, `tools/verify_fresh_zip.py`, `tools/gen_final.py` | The "frozen layers identical" check now names the two rev12 extension files as the only permitted differences from rev10, and still demands byte identity everywhere else. |
| `CHANGES_rev12.md`, `KNOWN_LIMITATIONS.md`, `AUIF_ONBOARDING.md`, `README.md`, `BUILD_REPORT.md`, `FILE_MANIFEST.json`, `evidence/*` | Documentation and regenerated evidence. |

## Not changed (byte-identical to rev10, checked file by file)
`auif/` (core: **no change**; Governor, GD-05 and Layer 2 untouched), `auif_ref/`, `synthetic/`, `contracts/`, `port_contracts/`, `tests/`, and every `auif_ext` file except the two named above. Core tree hash `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d` (equal to rev10's and rev11's).

## Approval recipe: a tenant-scoped client-credentials connection (for the live phase)
The reviewer, named and real, approves the configuration with `HumanApproval.parameters`:
```
credential_ref: "secretref:<name>"          # a reference NAME, resolved by the host's secret store; never the secret
overrides: {
  "auth": "OAUTH2_CLIENT_CREDENTIALS", "token_url": "<the provider's token endpoint>", "scope": "<read-only scopes only>",
  "tenant_id": "<the organisation identifier>",                       # not a credential; recorded in the approved configuration
  "entities.<E>.list.pagination": "single_page",                      # only after confirming the endpoint returns every record in one response
  "entities.<Junk>.list": null                                        # exclude an entity
}
```
The credential string the host resolves is `client_id:client_secret`; the tenant identifier is configuration and is kept out of it.

## What the live phase must test (hypotheses from the description, not facts)
1. A client-credentials token request using HTTP Basic client authentication works, and the granted scopes are the requested ones.
2. The tenant header on every call is accepted; a missing or wrong one is refused with 403 or similar (mapped to AUTHORIZATION_DENIED_BY_TARGET).
3. The page-numbered endpoints honour `page` and `pageSize`, return the page-count object, and the connector walks to the end with no duplicate or missing record.
4. Unpaged endpoints tolerate the extra `limit` parameter the connector always sends, and return every record in one response; a response over `max_page_size` is refused (raise it deliberately).
5. The journal endpoint's `offset` is an item offset (the generator assumes so from the name); it may be a position marker.
6. Field names in the generated mapping sources match real records; required/optional and enum claims in the description hold.
7. Rate limiting (429 with Retry-After) is mapped and not retried blindly.
8. How the tenant identifier is obtained for a given organisation (the connector cannot call the vendor's connections endpoint, which sits outside its base URL).

## Constraints recorded for the live phase
* The vendor's developer terms (checked on its public pages on 2026-10-07) state that data obtained from its APIs **may not be used to train AI/ML models** (new developers from 2025-12-04, existing from 2026-03-02). Nothing in AUIF trains on data; live-phase evidence must contain no real customer data, and no vendor data may reach any model-training path.
* Only the vendor's free Demo Company may be used for the sandbox proof; a single-organisation connection is the intended mode.
* Credentials arrive only as a `secretref:` name; the executor never reads, prints or stores the secret; the tenant identifier is not a credential and is never merged into one.

## Hard gates, and how each is held
| Gate | Held by |
|---|---|
| No core modification | Byte comparison of every frozen layer against the untouched rev10 extraction (evidence); core hash equal to rev10's. |
| No Governor, GD-05 or Layer 2 change; no Governor authority in the accelerator | Nothing outside `auif_ext/connectors/rest.py` and `auif_onboard/` changed; static checks. |
| The generator cannot promote a mapping | Unchanged: only `review.py` can approve; `single_page`, exclusion and `tenant_id` are human overrides inside `approve_config`. |
| No secret in any artefact, log or report | Unchanged screens; the tenant identifier is configuration, never credential; a secret pasted as a tenant value is refused. |

## What the reader should know
* The three older tests that changed, and why: one asserted that no candidate was offered for an unpaged endpoint (now `single_page`); two asserted that the first of two same-name endpoints is kept and that a reviewer can never touch a list endpoint (rev12 uses neither).
* The tenant identifier appears in the approved configuration and in the review ledger. It names an organisation; it is not a credential, but it is not public either.
* `Measured on this package (builder evidence; none of it is an audit): core 410 tests (unchanged), extension 343 (20 skipped without the Governor; 343 run, 0 skipped against the R14 Governor), accelerator 407; extension mutation 187/187 killed, accelerator mutation 427/427 killed (7 documented equivalents not run); core tree hash `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d`, equal to rev10's; the only changed pre-existing file below `auif_onboard/` is `auif_ext/connectors/rest.py`, the only added one `auif_ext/tests/test_rest_tenant.py`.`

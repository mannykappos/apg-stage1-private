"""SYNTHETIC policy provider (a test double for the open OD-09 / GD-04 policy source)."""
from auif.ports import PolicyPort
class SyntheticPolicy(PolicyPort):
    def __init__(self): self.rules = {("PII", "customer-system"): {"outcome": "ALLOW"}, ("PII", "third-party-analytics"): {"outcome": "TRANSFORM", "transforms": ["mask"]}, ("FINANCIAL", "customer-system"): {"outcome": "ALLOW"}, ("FINANCIAL", "third-party-analytics"): {"outcome": "REJECT"},
                                      ("HEALTH", "customer-system"): {"outcome": "NEEDS_AUTHORISATION"}, ("REGULATED", "customer-system"): {"outcome": "REJECT"}}
    def decide(self, ctx, classification, destination, context):
        if classification in ("PUBLIC", "INTERNAL", "CONFIDENTIAL"): return {"outcome": "ALLOW", "basis": "non-sensitive"}
        r = self.rules.get((classification, destination.get("kind")))
        return None if r is None else dict(r, basis="synthetic rule")

from auif.connector import Connector
from auif.errors import TransportError
def _m(summary, **kw): return dict({"summary": summary, "preconditions": [], "postconditions": ["outcome is one of outcome_kinds"], "outcome_kinds": ["DATA_OBTAINED", "NO_DATA", "COULD_NOT_OBTAIN", "DATA_INVALID"], "side_effects": "EXTERNAL_READ", "idempotent": True, "cancellable": True, "timeout_seconds": 30}, **kw)
def make_descriptor(cid, version, protocol, *, idempotent=True, auth="OAUTH2_CLIENT_CREDENTIALS", cred_ref="secretref:synthetic/credential", per_tenant=4, retry_on=("TIMEOUT", "UNAVAILABLE", "RATE_LIMITED"), pagination="CURSOR"):
    d = {"contract_kind": "ConnectorDescriptor", "auif_contract_version": "1.0.0", "connector_id": cid, "connector_version": version, "protocol_class": protocol, "display_name": "SYNTHETIC connector (test double)", "isolation": {"business_semantics": "NONE", "target_specific_business_logic": False},
         "methods": {"connect": _m("Establish a session", side_effects="NONE"), "disconnect": _m("Close", side_effects="NONE"), "health": _m("Health", side_effects="NONE"), "discover": _m("Fetch metadata"), "read": _m("Read a page"), "write": _m("Write with an idempotency key", side_effects="EXTERNAL_WRITE", idempotent=idempotent),
                     "subscribe": _m("Subscribe"), "unsubscribe": _m("Unsubscribe", side_effects="NONE"), "capabilities": _m("Capabilities", side_effects="NONE")},
         "authentication": {"handling": auth, "token_refresh": False, "secrets_in_descriptor": False}, "timeouts": {"connect_seconds": 5, "request_seconds": 30, "overall_seconds": 120},
         "retry_policy": {"max_attempts": 4, "max_write_attempts": 3 if idempotent else 1, "backoff": "EXPONENTIAL", "base_delay_ms": 200, "max_delay_ms": 30000, "jitter": "FULL", "retry_on": list(retry_on), "never_retry_on": ["AUTHENTICATION_FAILED", "MALFORMED_RESPONSE"], "write_retry_requires_idempotency_key": True},
         "rate_limit": {"declared_limits": [{"unit": "REQUESTS_PER_SECOND", "limit": 10, "scope": "TENANT"}], "honors_retry_after": True, "treats_429_as_rate_limited": True}, "pagination": {"style": pagination, "max_page_size": 200, "resumable": True},
         "concurrency": {"max_in_flight": 8, "per_tenant_max_in_flight": per_tenant}, "cancellation": {"supported": True, "semantics": "A cancelled write has an UNKNOWN outcome until reconciled."}, "connection_state_model": {"states": ["DISCONNECTED", "CONNECTING", "CONNECTED", "DEGRADED", "FAILED"]},
         "idempotency": {"supported": idempotent, "mechanism": "IDEMPOTENCY_KEY_HEADER" if idempotent else "NONE", "outcome_reconciliation_supported": idempotent}, "provenance": {"records_external_request_correlation": True},
         "error_normalization": {"mappings": [{"external_signal": "HTTP 429", "normalized_code": "RATE_LIMITED"}, {"external_signal": "HTTP 401", "normalized_code": "AUTHENTICATION_FAILED"}, {"external_signal": "HTTP 503", "normalized_code": "UNAVAILABLE"}]}}
    if auth != "NONE": d["authentication"]["credential_ref"] = cred_ref
    return d
class _Base(Connector):
    def __init__(self, system, cred_ref): self.sys, self.cred_ref, self.connected = system, cred_ref, False
    def connect(self, credentials):
        if (credentials or {}).get("secret") != self.sys.secret: raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", status=401)
        self.connected = True
    def disconnect(self): self.connected = False
    def health(self): return {"status": "up", "connected": self.connected}
    def capabilities(self): return {"read": True, "write": True}
    def subscribe(self, request): raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED")
    def unsubscribe(self, request): return {"unsubscribed": True}
class SyntheticRestConnector(_Base):
    connector_id, connector_version = "synthetic-rest-connector", "1.0.0"
    def descriptor(self): return make_descriptor(self.connector_id, self.connector_version, "REST", cred_ref=self.cred_ref)
    def discover(self): self.sys._fault("discover"); return self.sys.metadata()
    def read(self, request): return self.sys.list(request["entity"], request.get("cursor"), request.get("page_size", 3))
    def write(self, request): return self.sys.update(request["entity"], request["id"], request["fields"], request["idempotency_key"])
    def lookup_by_idempotency_key(self, key): r = self.sys.lookup(key); return r
class SyntheticDatabaseConnector(_Base):
    connector_id, connector_version = "synthetic-database-connector", "1.0.0"
    def descriptor(self): return make_descriptor(self.connector_id, self.connector_version, "DATABASE", idempotent=False, auth="BASIC", cred_ref=self.cred_ref, pagination="OFFSET")
    def discover(self): return self.sys.metadata()
    def read(self, request): return self.sys.select(request["entity"], int(request.get("cursor") or 0), request.get("page_size", 2))
    def write(self, request): return self.sys.upsert(request["entity"], dict({"cust_id": int(request["id"])}, **request["fields"]))
class SyntheticEventConnector(_Base):
    connector_id, connector_version = "synthetic-event-connector", "1.0.0"
    def descriptor(self): return make_descriptor(self.connector_id, self.connector_version, "EVENT_INGESTION", idempotent=False, auth="API_KEY", cred_ref=self.cred_ref, pagination="TOKEN")
    def discover(self): return self.sys.metadata()
    def read(self, request): return self.sys.poll()
    def write(self, request): raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED")
    def subscribe(self, request): return {"subscribed": True}

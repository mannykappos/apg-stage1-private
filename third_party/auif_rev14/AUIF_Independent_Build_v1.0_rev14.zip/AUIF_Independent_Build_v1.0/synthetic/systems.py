import copy
from auif.errors import TransportError, MalformedResponse
class Faults:
    def __init__(self): self.q = {}
    def push(self, method, *faults): self.q.setdefault(method, []).extend(faults)
    def pop(self, method): l = self.q.get(method) or []; return l.pop(0) if l else None
def _f(name, typ, **kw): return dict({"name": name, "type": typ}, **kw)
class SystemA:
    """SYNTHETIC System A: a REST-style CRM with nested entities, string enums, cursor paging, idempotent updates and fault injection."""
    def __init__(self, secret="client-secret-A"):
        self.secret, self.faults, self.version = secret, Faults(), "2024.3"
        self.rows = {"Account": {str(i): {"id": str(i), "profile": {"name": "Account %d" % i, "email": "acct%d@example.invalid" % i}, "status": ["act", "sus", "cls"][i % 3], "balance_cents": 1000 * i, "audit_created_by": "svc", "internal_flags": "x"} for i in range(1, 8)},
                     "Property": {str(i): {"id": str(i), "address": {"street": "%d Example St" % i, "city": "Testville"}, "state": ["listed", "sold", "withdrawn"][i % 3], "owner_id": str(i)} for i in range(1, 4)}}
        self.idem, self.effects, self.log = {}, [], []
        self.schema = {"Account": [_f("id", "string"), _f("profile.name", "string"), _f("profile.email", "string"), _f("status", "string", enum=["act", "sus", "cls"]), _f("balance_cents", "integer"), _f("audit_created_by", "string"), _f("internal_flags", "string")],
                       "Property": [_f("id", "string"), _f("address.street", "string"), _f("address.city", "string"), _f("state", "string", enum=["listed", "sold", "withdrawn"]), _f("owner_id", "string")]}
    def _fault(self, method):
        f = self.faults.pop(method)
        if f is None: return None
        k = f[0]
        if k == "429": raise TransportError("RATE_LIMITED", applied="NOT_APPLIED", retry_after=f[1] if len(f) > 1 else 1.0, status=429)
        if k == "unavailable": raise TransportError("UNAVAILABLE", applied="NOT_APPLIED", status=503)
        if k == "timeout_before": raise TransportError("TIMEOUT", applied="MAYBE")
        if k == "auth": raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", status=401)
        if k == "malformed": raise MalformedResponse("not parseable")
        if k == "reject": raise TransportError("TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", status=400)
        return f
    def metadata(self):
        return {"system_version": self.version, "generated_at": "volatile", "environment": "sandbox", "auth_requirements": {"type": "oauth2_client_credentials"}, "pagination": {"style": "CURSOR", "max_page_size": 200},
                "entities": [{"name": n, "fields": copy.deepcopy(fs), "relationships": [{"name": "owner", "target": "Account"}] if n == "Property" else []} for n, fs in self.schema.items()],
                "operations": [{"name": "listAccounts", "kind": "read", "entities": ["Account"]}, {"name": "updateAccount", "kind": "write", "entities": ["Account"]}, {"name": "listProperties", "kind": "read", "entities": ["Property"]}, {"name": "updateProperty", "kind": "write", "entities": ["Property"]}],
                "events": [{"name": "account.updated", "entities": ["Account"]}], "rate_limits": {"requests_per_second": 10}, "not_exposed": ["webhook_support"]}
    def drift_rename_field(self, entity, old, new):
        for f in self.schema[entity]:
            if f["name"] == old: f["name"] = new
    def drift_add_field(self, entity, name, typ="string"): self.schema[entity].append(_f(name, typ))
    def drift_unrelated_change(self): self.version = "2024.4"          # not a schema change
    def list(self, entity, cursor=None, page_size=3):
        self._fault("read"); ids = sorted(self.rows[entity], key=int); start = int(cursor or 0); chunk = ids[start:start + page_size]; nxt = str(start + page_size) if start + page_size < len(ids) else None
        return {"items": [copy.deepcopy(self.rows[entity][i]) for i in chunk], "next_cursor": nxt, "complete": nxt is None}
    def update(self, entity, rid, changes, key):
        f = self._fault("write")
        if key in self.idem: rec = self.idem[key]
        else:
            row = self.rows[entity][rid]
            for k, v in changes.items():
                d = row; parts = k.split(".")
                for p in parts[:-1]: d = d[p]
                d[parts[-1]] = v
            rec = {"external_reference": "A-%d" % (len(self.effects) + 1), "result": {"entity": entity, "id": rid, "applied": sorted(changes)}}; self.idem[key] = rec; self.effects.append((entity, rid, dict(changes), key))
        if f and f[0] == "timeout_after_apply": raise TransportError("TIMEOUT", applied="MAYBE")
        return copy.deepcopy(rec)
    def lookup(self, key): return copy.deepcopy(self.idem.get(key))
class SystemB:
    """SYNTHETIC System B: relational-style (flat tables, integer-coded enums, different naming). Its connector declares NO idempotency support."""
    def __init__(self, secret="db-password-B"):
        self.secret, self.faults, self.effects = secret, Faults(), []
        self.tables = {"customers": {i: {"cust_id": i, "full_name": "Customer %d" % i, "email_addr": "cust%d@example.invalid" % i, "state_code": i % 3, "amount_dollars": "%d.50" % (i * 10)} for i in range(1, 6)}}
    def metadata(self):
        return {"system_version": "B-7", "environment": "sandbox", "auth_requirements": {"type": "basic"}, "pagination": {"style": "OFFSET", "max_page_size": 100},
                "entities": [{"name": "customers", "fields": [_f("cust_id", "integer"), _f("full_name", "string"), _f("email_addr", "string"), _f("state_code", "integer", enum=[0, 1, 2]), _f("amount_dollars", "string")], "relationships": []}],
                "operations": [{"name": "select_customers", "kind": "read", "entities": ["customers"]}, {"name": "upsert_customers", "kind": "write", "entities": ["customers"]}], "events": [], "not_exposed": ["webhook_support"]}
    def select(self, table, offset=0, limit=2):
        f = self.faults.pop("read")
        if f and f[0] == "unavailable": raise TransportError("UNAVAILABLE", applied="NOT_APPLIED")
        rows = [copy.deepcopy(r) for _, r in sorted(self.tables[table].items())]; chunk = rows[offset:offset + limit]; nxt = str(offset + limit) if offset + limit < len(rows) else None
        return {"items": chunk, "next_cursor": nxt, "complete": nxt is None}
    def upsert(self, table, row):
        f = self.faults.pop("write")
        self.tables[table][row["cust_id"]] = dict(self.tables[table].get(row["cust_id"], {}), **row); self.effects.append((table, row["cust_id"], dict(row)))
        if f and f[0] == "timeout_after_apply": raise TransportError("TIMEOUT", applied="MAYBE")
        return {"external_reference": "B-%d" % len(self.effects), "result": {"table": table, "cust_id": row["cust_id"]}}
class SystemC:
    """SYNTHETIC System C: an event-driven source delivering duplicated, delayed and out-of-order events with sequence numbers and causal links."""
    def __init__(self, secret="token-C"): self.secret, self.faults, self.outbox = secret, Faults(), []
    def emit(self, *events): self.outbox.extend(copy.deepcopy(list(events)))
    def metadata(self):
        return {"system_version": "C-1", "environment": "sandbox", "auth_requirements": {"type": "api_key"}, "pagination": {"style": "CURSOR", "max_page_size": 50},
                "entities": [{"name": "Ticket", "fields": [_f("id", "string"), _f("title", "string"), _f("state", "string", enum=["open", "closed"])], "relationships": []}],
                "operations": [{"name": "pollEvents", "kind": "read", "entities": ["Ticket"]}], "events": [{"name": "ticket.opened", "entities": ["Ticket"]}, {"name": "ticket.updated", "entities": ["Ticket"]}], "webhook_support": True}
    def poll(self):
        f = self.faults.pop("read")
        if f and f[0] == "malformed": raise MalformedResponse("garbled")
        evs, self.outbox = self.outbox, []; return {"items": evs, "next_cursor": None, "complete": True}

"""SYNTHETIC canonical model and Translation Packs for the synthetic systems. NOT the Anchor canonical model (OD-08/ED-04 open) and NOT any real target's pack (XD-01)."""
from auif.translation import pack_hash
from auif.util import evidence
T = lambda kind, **p: {"kind": kind, "parameters": p, "deterministic": True}
def cons(cid, kind, **spec): return {"constraint_id": cid, "kind": kind, "spec": spec}
ID = T("IDENTITY")
def fmap(mid, src, canon, inb, out=None, constraints=None, state="VALIDATED", by="DETERMINISTIC_TOOL", stype="string", ctype="STRING", meanings=None):
    m = {"mapping_id": mid, "kind": "FIELD", "source_ref": src, "canonical_ref": canon, "mapping_state": state, "proposed_by": by, "inbound": {"source_type": stype, "canonical_type": ctype, "transform": inb}}
    m["outbound"] = {"supported": True, "target_type": stype, "transform": out, "target_constraints": constraints} if out is not None else {"supported": False, "reason": "read-only on the target system"}
    if state in ("VALIDATED", "TRUSTED"): m["deterministic_validation_performed"] = True; m["validation_ref"] = evidence("mapping-validation", {"mapping": mid, "src": src, "canon": canon}, "val-" + mid)
    if state == "AMBIGUOUS": m["ambiguity"] = {"candidate_meanings": meanings or ["meaning one", "meaning two"], "resolution_required": True}
    return m
def emap(mid, kind, src, canon, target, stype="entity", writable=True):
    m = {"mapping_id": mid, "kind": kind, "source_ref": src, "canonical_ref": canon, "mapping_state": "VALIDATED", "proposed_by": "DETERMINISTIC_TOOL", "deterministic_validation_performed": True, "validation_ref": evidence("mapping-validation", {"mapping": mid}, "val-" + mid),
         "inbound": {"source_type": stype, "canonical_type": canon, "transform": ID}}
    m["outbound"] = {"supported": True, "target_type": target, "transform": ID, "target_constraints": [cons("c-%s-present" % mid, "REQUIRED")]} if writable else {"supported": False, "reason": "read-only source system"}
    return m
POLICY = {"default_outcome": "UNMAPPED", "optional_and_unused": [], "ignored_by_rule": [
    {"field_pattern": "^id$", "rule_id": "rule-identity-in-canonical-id", "justification": "Identity is carried by the canonical_id identity mapping.", "material": False},
    {"field_pattern": "^(audit_.*|internal_flags)$", "rule_id": "rule-ignore-internal", "justification": "Target-internal columns have no canonical meaning.", "material": False}]}
def build(pid, version, kind, fps, mappings, classes, policy=None, cm=("0.1.0", "0.1.99"), supersedes=None):
    p = {"contract_kind": "TranslationPack", "pack_id": pid, "pack_version": version, "artifact_hash": "0" * 64, "immutable": True, "contains_governance_logic": False, "contains_secrets": False, "pack_state": "VALIDATED", "target_system_kind": kind,
         "schema_expectations": {"compatible_fingerprints": list(fps)}, "canonical_model_compat": {"min": cm[0], "max": cm[1]}, "auif_contract_compat": {"min": "1.0.0", "max": "1.0.99"}, "mappings": mappings, "unmapped_field_policy": policy or POLICY,
         "classification_mappings": classes, "provenance_rules": {"preserve_source_object": True, "preserve_source_field": True, "preserve_pack_identity": True}}
    if supersedes: p["supersedes"] = supersedes
    p["artifact_hash"] = pack_hash(p); return p
def pack_a(fps, variant="v1"):
    status_map = {"act": "ACTIVE", "sus": "INACTIVE", "cls": "ARCHIVED"}
    if variant == "v2": status_map = {"act": "ACTIVE", "sus": "INACTIVE", "cls": "INACTIVE"}          # a SEMANTIC change: closed accounts become INACTIVE (many-to-one, so this mapping is inbound-only: it cannot be inverted for writes)
    status = fmap("a-status", "Account.status", "Party.lifecycle_state", T("ENUM_MAP", map=status_map), (None if variant == "v2" else T("ENUM_MAP", map=status_map)), [cons("c-status-enum", "ENUM", values=sorted(status_map))]) if variant != "ambiguous" else \
             fmap("a-status", "Account.status", "Party.lifecycle_state", T("ENUM_MAP", map=status_map), None, state="AMBIGUOUS", by="AI_ASSISTED", meanings=["commercial relationship state", "record lifecycle state"])
    ms = [emap("a-ent-account", "ENTITY", "Account", "Party", "Account"), emap("a-ent-property", "ENTITY", "Property", "Property", "Property"),
          fmap("a-name", "Account.profile.name", "Party.display_name", ID, ID, [cons("c-name-len", "LENGTH", max=100), cons("c-name-type", "TYPE", type="string")]),
          fmap("a-email", "Account.profile.email", "Party.contact_email", ID, ID, [cons("c-email", "DETERMINISTIC_RULE", rule="email_format")]), status,
          fmap("a-balance", "Account.balance_cents", "Party.balance", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), T("DETERMINISTIC_FUNCTION", out="decimal_to_cents"), [cons("c-bal-type", "TYPE", type="integer"), cons("c-bal-range", "RANGE", min=0)], stype="integer", ctype="DECIMAL"),
          fmap("a-street", "Property.address.street", "Property.street", ID, ID, [cons("c-street-len", "LENGTH", max=200)]), fmap("a-city", "Property.address.city", "Property.city", ID, ID, [cons("c-city-len", "LENGTH", max=100)]),
          fmap("a-pstate", "Property.state", "Property.status", T("ENUM_MAP", map={"listed": "AVAILABLE", "sold": "SOLD", "withdrawn": "WITHDRAWN"}), T("ENUM_MAP", map={"listed": "AVAILABLE", "sold": "SOLD", "withdrawn": "WITHDRAWN"}), [cons("c-pstate-enum", "ENUM", values=["listed", "sold", "withdrawn"])]),
          fmap("a-owner", "Property.owner_id", "Property.owner_ref", ID, None, ctype="REFERENCE"), emap("a-act-update-account", "ACTION", "updateAccount", "synthetic.update_party", "Account"), emap("a-act-update-property", "ACTION", "updateProperty", "synthetic.update_property", "Property")]
    return build("synthetic-pack-a", {"v1": "1.0.0", "v2": "2.0.0", "ambiguous": "1.1.0"}[variant], "synthetic-rest-crm", fps, ms, [{"source_ref": "Account.profile.email", "classification": "PII", "declared_by": "PACK_RULE"}, {"source_ref": "Account.balance_cents", "classification": "FINANCIAL", "declared_by": "TARGET_DECLARED"}])
def pack_b(fps):
    sm = {"0": "ACTIVE", "1": "INACTIVE", "2": "ARCHIVED"}
    ms = [emap("b-ent", "ENTITY", "customers", "Party", "customers"), fmap("b-name", "customers.full_name", "Party.display_name", ID, ID, [cons("c-name-len", "LENGTH", max=100)]), fmap("b-email", "customers.email_addr", "Party.contact_email", ID, ID, [cons("c-email", "DETERMINISTIC_RULE", rule="email_format")]),
          fmap("b-state", "customers.state_code", "Party.lifecycle_state", T("ENUM_MAP", map=sm), T("ENUM_MAP", map=sm), [cons("c-state-enum", "ENUM", values=[0, 1, 2])], stype="integer", ctype="ENUM"),
          fmap("b-amount", "customers.amount_dollars", "Party.balance", T("DETERMINISTIC_FUNCTION", **{"in": "dollars_to_decimal"}), T("DETERMINISTIC_FUNCTION", out="decimal_to_dollars"), [cons("c-amount-type", "TYPE", type="string")], ctype="DECIMAL"), emap("b-act-upsert", "ACTION", "upsert_customers", "synthetic.update_party", "customers")]
    pol = {"default_outcome": "UNMAPPED", "optional_and_unused": [], "ignored_by_rule": [{"field_pattern": "^cust_id$", "rule_id": "rule-identity-in-canonical-id", "justification": "Identity is carried by the canonical_id identity mapping.", "material": False}]}
    return build("synthetic-pack-b", "1.0.0", "synthetic-relational", fps, ms, [{"source_ref": "customers.email_addr", "classification": "PII", "declared_by": "PACK_RULE"}], pol)
def pack_c(fps):
    ms = [emap("c-ent", "ENTITY", "Ticket", "Task", "Ticket", writable=False), fmap("c-title", "Ticket.title", "Task.title", ID, None),
          fmap("c-state", "Ticket.state", "Task.status", T("ENUM_MAP", map={"open": "OPEN", "closed": "CLOSED"}), None)]
    pol = {"default_outcome": "UNMAPPED", "optional_and_unused": [], "ignored_by_rule": [{"field_pattern": "^id$", "rule_id": "rule-identity-in-canonical-id", "justification": "Identity is carried by the canonical_id identity mapping.", "material": False}]}
    return build("synthetic-pack-c", "1.0.0", "synthetic-event-source", fps, ms, [], pol)
def attr(n, t, req, cls, **c):
    d = {"name": n, "type": t, "required": req, "default_classification": cls}
    if c: d["constraints"] = c
    return d
MODEL_DEF = {"contract_kind": "CanonicalModelDefinition", "model_version": "0.1.0", "status": "DRAFT_EXAMPLE_ONLY", "concepts": [
    {"name": "Party", "namespace": "CORE", "attributes": [attr("display_name", "STRING", True, "INTERNAL", max_length=200), attr("contact_email", "STRING", False, "PII"), attr("lifecycle_state", "ENUM", False, "INTERNAL", values=["ACTIVE", "INACTIVE", "ARCHIVED"]), attr("balance", "DECIMAL", False, "FINANCIAL")], "extension_rules": {"module_extension_allowed": True}},
    {"name": "Property", "namespace": "CORE", "attributes": [attr("street", "STRING", True, "INTERNAL"), attr("city", "STRING", True, "INTERNAL"), attr("status", "ENUM", True, "INTERNAL", values=["AVAILABLE", "SOLD", "WITHDRAWN"]), attr("owner_ref", "REFERENCE", False, "INTERNAL")], "extension_rules": {"module_extension_allowed": True}},
    {"name": "Task", "namespace": "CORE", "attributes": [attr("title", "STRING", True, "INTERNAL"), attr("status", "ENUM", True, "INTERNAL", values=["OPEN", "CLOSED"])], "extension_rules": {"module_extension_allowed": True}},
    {"name": "Event", "namespace": "CORE", "attributes": [attr("name", "STRING", True, "INTERNAL"), attr("subject_ref", "REFERENCE", False, "INTERNAL")], "extension_rules": {"module_extension_allowed": True}},
    {"name": "module.synthetic-module-2.Listing", "namespace": "MODULE", "attributes": [attr("headline", "STRING", True, "INTERNAL")], "extension_rules": {"module_extension_allowed": False}}],
    "compatibility": {"backward_compatible_with": ["0.1.0"], "breaking_change_policy": "Major version bump; packs pin the range they support."}, "deterministic_validation": {"rules_ref": "rules-synthetic-0.1.0"}}

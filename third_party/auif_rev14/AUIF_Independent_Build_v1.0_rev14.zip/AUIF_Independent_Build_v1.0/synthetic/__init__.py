"""SYNTHETIC systems, connectors, packs, modules and doubles. Everything here is a labelled test double. None of it is the Anchor Engine, Governor, McGrath or any real customer system."""

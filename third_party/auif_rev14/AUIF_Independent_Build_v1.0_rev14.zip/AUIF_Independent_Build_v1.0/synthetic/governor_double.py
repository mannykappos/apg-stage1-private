"""SYNTHETIC GOVERNOR TEST DOUBLE. Plays the sovereign decision-maker so AUIF's boundary can be tested. It is NOT Governor, implements no Governor logic, and AUIF's core never imports it."""
from auif.ports import GovernorPort
from auif.util import sha
class GovernorDouble(GovernorPort):
    def __init__(self): self.grant, self.deny, self.pending, self.unavailable, self.decisions, self.conditions, self.n = set(), set(), set(), False, [], [], 0
    def request_decision(self, ctx, request):
        if self.unavailable: return {"status": "UNAVAILABLE"}
        at = request["action_type"]
        if at in self.deny: return {"status": "DENIED", "reason": "synthetic policy"}
        if at in self.pending: return {"status": "PENDING"}
        self.n += 1; ref = "gov-dec-%04d" % self.n; self.decisions.append((ctx.tenant_id, request)); return {"status": "GRANTED", "decision_ref": ref, "decision_hash": sha({"ref": ref, "action_id": request["action_id"], "payload_hash": request["payload_hash"]})}
    def report_condition(self, ctx, condition):
        if self.unavailable: return {"acknowledged": False}
        self.conditions.append((ctx.tenant_id, condition)); return {"acknowledged": True, "report_id": "gov-rpt-%04d" % len(self.conditions), "report_hash": sha(condition)}

# CHANGES rev14: core revision for the six defects found while building APG-M8

rev14 is built on the frozen rev13 package. rev13 is preserved unchanged: zip sha256 `61748ddeba21e8c1d71b56bd0d3ad7a376ea051f4ae6fbe56c6464c0de76e070`, manifest tree `9fbc5de7041c4cba0b177b1cb3b7fb4c7da6290a69a96ab2a939140bdf11652e`, core tree `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d`. Before any change, the untouched rev13 extraction was checked against those hashes.

**Status.** Builder-implemented and locally tested. **Not accepted.** It awaits independent audit. Nothing here is a release acceptance, production approval, or Engine or Governor integration.

**Authority.** Product owner, 2026-10-20: "Authorise AUIF rev14 as written, start now". One decision was taken at the stop point the authorisation names (finding M8-F2, below): "Strict, fix that test".

## The defects (all in the builder's own AUIF rev13; found while building APG-M8, recorded there as F-76 to F-81 and CF-50)

| Finding | Defect in rev13 | Fix in rev14 |
|---|---|---|
| M8-F1 | A field reference was split at the FIRST dot, so `module.apg.Budget.amount` meant concept `module`, attribute `apg.Budget.amount`: every field into a MODULE concept was TRANSLATION_INVALID. | `auif/canonical.py` `split_ref()`: the attribute is the part after the LAST dot. Used in inbound and outbound translation (`auif/translation.py`), the AI validator (`auif/ai_boundary.py`), and the accelerator's shadow translation and review (`auif_onboard/validate.py`, `auif_onboard/review.py`). `PackRegistry.register` refuses a pack whose FIELD mapping reference is not `<concept>.<attribute>`, or names another concept than its entity's executable mapping. |
| M8-F2 | A source identity was one field; a record without it silently got a content hash, so a composite business key got a new canonical id on every change. | `auif/fabric.py` `source_identity()`: one field, a list of fields (composite: text joined with `|`, with `\` and `|` escaped), or the declared `CONTENT_HASH`. A missing, null, blank, boolean or structured value is a per-record `IDENTITY_MISSING` error; the read goes on. |
| M8-F3 | An event that waited, was deferred, went to reconciliation or was rejected was never told to the module. | `Fabric._record_decision`: the module is told `EVENT_NOT_APPLIED` (event id, ordering state, what it waits on) for every event it did not receive, including an in-order event whose type has no entity mapping. Not counted as a failure. |
| M8-F4 | `BaseModule` swallowed a handler's exception and the fabric counted the delivery as made. | `auif_ext/module_client/client.py`: each delivery method returns `{"handler_failures": n}` when handlers failed. `auif/fabric.py`: a module that raises or returns that marker, for any delivery (entity, observation, event, state, error), is counted (`module_failures`), recorded (`module_delivery_failures`, delivery type only) and told (`MODULE_DELIVERY_FAILED`); a failing state handler never stops a transition. |
| M8-F5 | The sync report did not say whether the read reached the end. | `Fabric.sync`: `complete`, `stopped_at_page_limit`, and counts for `refused`, `conflict` and `module_failed`; `delivered` counts only what the module took. |
| M8-F6 | Sync raised: TypeError for drift found before the first validation (no baseline), ContractViolation for a blank identity value. | `auif/integration.py` `entity_readable`: no baseline, nothing readable. `auif/fabric.py`: a record the observation contract refuses is `RECORD_REFUSED`; a blank identity is `IDENTITY_MISSING`. Both are reported per record. |

## The decision at the stop point (M8-F2)

The strict identity rule broke exactly one existing rev13 test: `auif_ext/tests/test_extension_boundary.py::TestUniversality::test_three_connector_kinds_run_side_by_side_and_the_core_is_still_byte_identical`. Its CSV has no `id` column and it declared no identity, so it relied on the silent content hash. The builder stopped and asked. The owner chose **"Strict, fix that test"**: the test now declares `identity_fields={"customers": "cust_id"}`. Its assertions are unchanged.

## Changed existing files

| File | Change |
|---|---|
| `auif/canonical.py` | M8-F1: `split_ref()` and the attribute-name pattern `ATTR`. |
| `auif/translation.py` | M8-F1: the reference check in `PackRegistry.register`; `translate_inbound` and `translate_outbound` read references with `split_ref`. |
| `auif/ai_boundary.py` | M8-F1: the AI validator reads references with `split_ref`. |
| `auif/fabric.py` | M8-F2 to M8-F6: `source_identity()`, `IDENTITY_CONTENT_HASH`, the per-record statuses of `_ingest_record`, module-failure handling (`_tell`, `_module_failed`, `_failed`), `EVENT_NOT_APPLIED`, and the sync report fields. |
| `auif/integration.py` | M8-F6: `entity_readable` with no baseline. |
| `auif_ext/module_client/client.py` | M8-F4: the failure marker. |
| `auif_onboard/validate.py`, `auif_onboard/review.py` | M8-F1: `split_ref` in the shadow translation and the review's consistency check. |
| `auif_ext/tests/test_extension_boundary.py`, `auif_onboard/tests/test_separation.py` | Declared below. |
| `tools/mutation_test.py`, `tools/mutation_ext.py`, `tools/mutants_onboard.py`, `tools/onboard_evidence.py`, `tools/verify_fresh_zip.py`, `tools/gen_final.py` | Declared below. |
| `KNOWN_LIMITATIONS.md` | Items 32 to 40. |
| `DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md` | Decisions D-57 to D-62. |
| `AUIF_EXTENSIONS.md`, `AUIF_ONBOARDING.md` | A rev14 section each. |
| Generated | `README.md`, `BUILD_REPORT.md`, `AMIR_HANDOFF.md` (the test count), `ACCEPTANCE_RESULTS.*`, `RTM_IMPL_TO_TEST.*`, `FILE_MANIFEST.json`, `docs/PERSISTENCE_COLLECTIONS.md` (lists the new `module_delivery_failures` collection and its sequence), and under `evidence/`: coverage, performance, the three mutation results, the extension and accelerator verification. |

## Added files

| File | What |
|---|---|
| `CHANGES_rev14.md` | This file. |
| `tests/test_rev14_fixes.py` | 31 core tests, one class per finding. 27 fail on rev13; the other four are regression guards (the existing core packs still register; outbound takes only the requested concept's fields, in two tests; an applied event is not reported as not applied). |
| `auif_ext/tests/test_rev14_module_client.py` | 4 tests. 3 fail on rev13; the healthy-module test is a guard. |
| `auif_onboard/tests/test_rev14_module_refs.py` | 4 tests. 2 fail on rev13; 2 are guards. |
| `docs/BUILD_REPORT_rev13_sections_13_to_16.md` | rev13's report sections 13 to 16, byte for byte (see above). |

## Changed existing tests and tools (declared)

- `auif_ext/tests/test_extension_boundary.py`: the pinned core hash (rev9 and rev10 precedent) and the declared identity above. Nothing else changed.
- `auif_onboard/tests/test_separation.py`: the pinned core hash, and one test renamed from `..._equals_the_frozen_rev10_hash_...` to `..._equals_the_pinned_core_hash_...`, because the rev10 name would now be false. Its body is unchanged.
- `tools/mutation_test.py`, `tools/mutation_ext.py`, `tools/mutants_onboard.py`: new mutants only (M134 to M174, E177 to E183, V119 and V120), plus accelerator mutant V86 re-anchored on its rewritten line (same guard: a field mapped into another concept is refused).
- `tools/onboard_evidence.py` and `tools/verify_fresh_zip.py`: the pinned core hash. The frozen layers are now compared with the untouched **rev13** extraction (rev10 is not part of this hand-off), and the expected differences are exactly rev14's.
- `tools/gen_final.py`: README rows for rev14. Sections 13 to 16 of `BUILD_REPORT.md` are now reproduced from rev13's report (`docs/BUILD_REPORT_rev13_sections_13_to_16.md`) instead of being regenerated, because their figures describe rev10 to rev13. New section 17 for rev14.
- No other existing test or mutant changed.

## Deliberately NOT changed

- The Module Port contract (`auif/ports.py`), the contracts, the synthetic world, the reference implementations and the port contracts are byte-identical to rev13's. The failure marker is an optional convention of this build.
- The `"*"` key of `identity_fields` is still not a wildcard (limitation 34). This was observed and recorded; it was not part of the authorised fixes.
- No real system, credential, Governor wiring or Engine work. APG is not moved onto rev14: that is M8.1, which needs its own authorisation and ends DEV-M8-01.

## Measured on this package (builder evidence; none of it is an audit)

All on Python 3.12.3 and 3.13.16 alike, with the same counts and no skipped test other than the 20 real-Governor tests (which run only when the Governor zip is supplied):

| Check | Result |
|---|---|
| Core tests | 441 (rev13: 410; 31 new) |
| Extension tests | 347 run, 20 skipped (rev13: 343; 4 new) |
| Extension tests against the real R14 Governor (read-only zip `e6f299ca...`, Python 3.13) | 347 run, 0 skipped |
| Accelerator tests | 422 (rev13: 418; 4 new) |
| Static checks (core, extension, accelerator) | clean; core tree `923de5100f95debbbf63d5ab6e960cee2091ee57abce403792403ff049ac7839` |
| Core mutation | 174 run, 174 killed (rev13: 133; M134 to M174 new) |
| Extension mutation | 194 run, 194 killed; E110 documented as equivalent and not run (195 defined; E177 to E183 new) |
| Accelerator mutation | 437 run, 437 killed; 7 documented equivalents not run (444 defined; V119 and V120 new) |
| Reverse contamination | the core passes with `auif_ext` removed; core and extensions pass with `auif_onboard` removed |
| Layers against the untouched rev13 extraction | only the files listed above differ |
| Accelerator drafts | the three synthetic specifications give byte-identical config and pack drafts, validation reports and review flows to rev13's |
| Core line coverage | 1,508 of 1,515 lines (99.5%) |

The first core mutation pass (before the final tests) left three survivors: M139 (references were then checked only in executable mappings; the check now covers every FIELD mapping, as the authorisation says, and a test proves it), M141 (outbound concept filter; a pack with two concepts sharing an attribute name now kills it) and M149 (escaping of the escape character; a colliding pair now kills it). The fresh-ZIP verification (`tools/verify_fresh_zip.py`) result is reported with the delivery.

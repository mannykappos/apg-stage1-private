# AMIR_HANDOFF

**STATUS: RELEASED FOR HANDOFF. The implementation was independently audited in three rounds (rev6 was accepted as the current reference candidate; it is not frozen). The accompanying document AUIF_Amir_Full_Handoff_rev6.pdf is the overview; this file and AMIR_ENGINE_DEPENDENCY_TODO.md are the detailed per-item instructions.**

Everything Amir needs to close the Engine-dependent work, in order. You do not need to reverse-engineer anything: each item states what to find, what to build, how to prove it and what to send back.

## Ground rules

1. **Nothing in this package states a fact about the Anchor Engine.** Every Engine detail is UNKNOWN until you supply it with evidence. If an item's answer is not what a placeholder implies, say so; do not make the Engine fit the placeholder.
2. **Do not modify `auif/` (the core) to fit the Engine.** Bind to the ports in `auif/ports.py` from outside, or report the mismatch as a finding. Governor is out of scope and must not be modified.
3. **Staging or non-production first**, wherever an item says staging is sufficient.
4. **Return evidence exactly as each item lists it.** Put it in `evidence_from_amir/<ITEM-ID>/` with a `SHA256SUMS` file (sha256 of every file you return).

## Setup (about 5 minutes)

Python 3.12, standard library only. From the package root:

```
export PYTHONDONTWRITEBYTECODE=1
python3 -W ignore -m unittest discover -s tests -t .
python3 tools/static_checks.py
```

Expected: all tests pass (441 at packaging), static checks report no violations. If this baseline fails on your machine, stop and report that first.

## How to prove a port binding

Each port has a conformance suite in `port_contracts/`. Templates are in `port_contracts/templates/`: copy one to `tests/binding/`, fill the placeholders with your binding, run it with `python3 -W ignore -m unittest tests.binding.<name> -v`. A binding passes when every case passes. `docs/PORT_CONFORMANCE_CASES.md` lists the cases language-neutrally if the platform is not Python.
To run the whole synthetic world on a real persistence binding, set `AUIF_BINDINGS_MODULE` (test-world hook in `synthetic/world.py`; see `KNOWN_LIMITATIONS.md` item 17).

## Order of work

Items are grouped by dependency. Items in the same group can run in parallel.

- **Group 1:** AMIR-TODO-01, AMIR-TODO-17
- **Group 2:** AMIR-TODO-02, AMIR-TODO-03, AMIR-TODO-07, AMIR-TODO-08, AMIR-TODO-09, AMIR-TODO-10, AMIR-TODO-11, AMIR-TODO-15, AMIR-TODO-18
- **Group 3:** AMIR-TODO-04, AMIR-TODO-05, AMIR-TODO-06, AMIR-TODO-12
- **Group 4:** AMIR-TODO-13, AMIR-TODO-14, AMIR-TODO-16

## AMIR-TODO-01: Engine reconnaissance gate (architecture AR-22/AR-23; lock prerequisite)

- **Depends on:** None. First item.
- **Why it is blocked:** No source, database, deployment or integration of the Anchor Engine is available to this build. Every ED item is UNKNOWN / Amir-dependent.
- **Engine information required:**
Repository location and a stated commit; languages, frameworks and versions; directory layout; build, test and run commands; the list of environments.
- **Question for Amir:** Please give the AUIF executor read access to the Anchor Engine repository at a stated commit and answer requests A-01 to A-20 in 05_Amir_Request_Pack.md (architecture package), citing a file path per answer.
- **Evidence to find (source / file / config / DB):**
Commit hash; tracked-file count; top-level directory listing; dependency manifest files; answers A-01..A-20, each citing file path and line range or command output.
- **Implementation step:**
Grant read access. For each request A-01..A-20 write the answer with a file path and line range or the output of a command. Do not answer from memory.
- **Must Amir modify Engine code?** NO
- **DB access required?** NO
- **Staging sufficient?** Not applicable (read-only source access)
- **Validation procedure:**
In the Engine repository run: git rev-parse HEAD && git ls-files | wc -l   and return the output. The AUIF executor then checks every cited path exists at that commit with: test -f <path>
- **Expected result:** A 40-hex-character commit id; a non-zero file count; every cited path exists at that commit.
- **Evidence to return:**
The command output; the completed A-01..A-20 answers.
- **Unblocks:** Reconnaissance review and therefore the Architecture lock decision; every other AMIR-TODO item; real port bindings.
- **Status:** OPEN

## AMIR-TODO-17: Real AI service binding for mapping proposals

- **Depends on:** Owner decision OD-12
- **Why it is blocked:** Which AI service (if any) may be used, and its data-handling constraints, are undecided. The boundary and its deterministic validation are built and tested with scripted and adversarial doubles only.
- **Engine information required:**
Approved provider/model, data residency, what discovery content may be sent.
- **Question for Amir:** Which provider is approved and what discovery content may be sent to it?
- **Evidence to find (source / file / config / DB):**
Approval and constraints from the owner.
- **Implementation step:**
Implement MappingProposer (auif/ai_boundary.py) over the approved service. It receives only the read-only ProposerSandbox. Run the adversarial acceptance tests with the real proposer.
- **Must Amir modify Engine code?** NO
- **DB access required?** NO
- **Staging sufficient?** YES
- **Validation procedure:**
python3 -W ignore -m unittest tests.test_acceptance.TestAT25_AI -v   with the real proposer substituted for AdversarialProposer in a copy of the test
- **Expected result:** No candidate is ever VALIDATED by the proposer; claimed states are discarded and flagged; promotion happens only through AIMappingService.promote.
- **Evidence to return:**
unittest output; proposer source; the approval.
- **Unblocks:** AI-assisted pack authoring.
- **Status:** OPEN

## AMIR-TODO-02: Module Port binding (EP-02, EP-03)

- **Depends on:** AMIR-TODO-01
- **Why it is blocked:** How Anchor modules are defined, registered, invoked, how they receive data and emit requests is unknown. A binding cannot be written without inventing the interface.
- **Engine information required:**
The exact interface a module exposes to receive an entity, an observation and an event; how a module submits an action request; how a module declares its semantic requirements; API and event conventions.
- **Question for Amir:** Which exact class, function or endpoint must AUIF call to deliver (a) a canonical entity, (b) an observation, (c) an event to a module, and by which exact mechanism does a module submit an action request?
- **Evidence to find (source / file / config / DB):**
File paths and signatures of the module base class or registration; one existing module's entry points; the event bus or API convention used.
- **Implementation step:**
Implement a binding exposing the ModulePort interface (auif/ports.py::ModulePort: its 7 abstract methods and the module_id attribute) that calls the interfaces identified above. Copy port_contracts/templates/test_module_binding.py.template to tests/binding/test_module_binding.py and point the factory at the new binding. Run the suite. Add a minimal entry point to the Engine ONLY if none exists able to receive canonical objects, and return that diff.
- **Must Amir modify Engine code?** CONDITIONAL: only if the Engine has no suitable entry point. Return the diff.
- **DB access required?** NO
- **Staging sufficient?** YES: non-production is sufficient
- **Validation procedure:**
python3 -W ignore -m unittest tests.binding.test_module_binding -v   (If the Engine is not Python, implement the language-neutral cases listed for this port in docs/PORT_CONFORMANCE_CASES.md in the Engine's own test framework and return their output instead.)
- **Expected result:** All ModulePortContract cases pass: OK with zero failures.
- **Evidence to return:**
The unittest output; the binding source; the diff of any Engine change.
- **Unblocks:** AUIF-AT-01 against a real module; delivery to Anchor Real Estate; closing OD-22 (module descriptor format).
- **Status:** OPEN

## AMIR-TODO-03: Tenant and caller context binding (EP-01)

- **Depends on:** AMIR-TODO-01
- **Why it is blocked:** How the Engine authenticates callers, identifies the tenant and propagates context is unknown. The reference HMAC-signed context only proves the core rejects forged or missing context.
- **Engine information required:**
Authentication mechanism; how tenant identity is established and propagated per request or job; how background jobs obtain tenant context; how context forgery is prevented.
- **Question for Amir:** Where in the Engine is the tenant identity resolved and how is it carried into background/worker execution? Show the code that prevents a caller from selecting another tenant.
- **Evidence to find (source / file / config / DB):**
File paths for the auth middleware, tenant resolution and job-context propagation; one test in the Engine that proves cross-tenant selection is rejected.
- **Implementation step:**
Implement TenantAuthorityPort (auif/ports.py) on the Engine's tenant context so verify() is true only for contexts the Engine issued. Copy port_contracts/templates/test_tenant_binding.py.template to tests/binding/test_tenant_binding.py and point the factory at the new binding. Run the suite.
- **Must Amir modify Engine code?** NO (binding only), unless context cannot be verified server-side; then report
- **DB access required?** NO
- **Staging sufficient?** YES
- **Validation procedure:**
python3 -W ignore -m unittest tests.binding.test_tenant_binding -v   (If the Engine is not Python, implement the language-neutral cases listed for this port in docs/PORT_CONFORMANCE_CASES.md in the Engine's own test framework and return their output instead.)
- **Expected result:** All TenantAuthorityContract cases pass, including forged, retargeted and missing contexts being rejected.
- **Evidence to return:**
unittest output; binding source.
- **Unblocks:** Trusted tenant context for every AUIF service; real AUIF-AT-12.
- **Status:** OPEN

## AMIR-TODO-07: Governor port wiring (EP-07)

- **Depends on:** AMIR-TODO-01; owner decisions GD-03 and GD-05
- **Why it is blocked:** The Governor integration surface on the Engine side is unknown, and the Governor-side decisions GD-03 (who determines governance is required and decision validity) and GD-05 (AUIF-to-Governor security) are open and are NOT Amir's to close. AUIF isolates the interface and holds undetermined actions.
- **Engine information required:**
How Engine components currently call the Governor; the transport and authentication; the existing adapter instance, if any.
- **Question for Amir:** What is the exact call by which Engine code requests a Governor decision and reports a condition, and how is that call authenticated?
- **Evidence to find (source / file / config / DB):**
File paths of the Governor client/adapter; one existing call site; the authentication used. Governor-side decisions are recorded in UNRESOLVED_GOVERNOR_DECISIONS.md and need Emmanuel/Governor-side owners.
- **Implementation step:**
Implement GovernorPort.request_decision and report_condition over the existing Governor surface WITHOUT changing the locked adapter terms and WITHOUT letting AUIF decide. Copy port_contracts/templates/test_governor_binding.py.template to tests/binding/test_governor_binding.py and point the factory at the new binding. Run the suite.
- **Must Amir modify Engine code?** NO to the Governor; binding only
- **DB access required?** NO
- **Staging sufficient?** YES: a non-production Governor
- **Validation procedure:**
python3 -W ignore -m unittest tests.binding.test_governor_binding -v   then confirm against the staging Governor: a granted request returns a reference and 64-hex hash; a denied request yields a FAILED ledger record; an unavailable Governor leaves the action QUEUED and unsent.
- **Expected result:** GovernorPortContract OK; the three staging outcomes observed exactly as stated.
- **Evidence to return:**
unittest output; staging transcripts of the three outcomes with ids/hashes.
- **Unblocks:** Governed actions against the real Governor; real AUIF-AT-13; draft positions on GD-03/GD-05 can be reviewed against reality.
- **Status:** OPEN

## AMIR-TODO-08: Observability sink binding (EP-08)

- **Depends on:** AMIR-TODO-01
- **Why it is blocked:** The Engine's metrics/logging/tracing stack is unknown. AUIF's Telemetry emits the 15 required signals with payload redaction, but is not connected to any real sink.
- **Engine information required:**
Metrics, log and trace systems; label/cardinality rules; PII handling in logs.
- **Question for Amir:** Where should AUIF's gauges, counters and redacted events be sent, and what label cardinality limits apply per tenant and integration?
- **Evidence to find (source / file / config / DB):**
File paths/config of the metrics and logging setup.
- **Implementation step:**
Forward Telemetry.set / inc / log to the Engine's sinks, keeping the redaction in auif/observability.py (never forward payload or secret values). Add a test that sends a sentinel payload through an AUIF flow and scans the sink output.
- **Must Amir modify Engine code?** NO (binding only)
- **DB access required?** NO
- **Staging sufficient?** YES
- **Validation procedure:**
Run tests.test_acceptance.TestAT24_Observability against a Telemetry wired to the real sink, then search the sink for the sentinel strings SENTINEL-NAME-777 and SENTINEL-TITLE-888.
- **Expected result:** All 15 REQUIRED_SIGNALS appear in the sink; zero occurrences of either sentinel.
- **Evidence to return:**
The sink query output for the 15 signals; the zero-hit search output.
- **Unblocks:** Real AUIF-AT-24; operational dashboards.
- **Status:** OPEN

## AMIR-TODO-09: Deployment topology and egress controls (EP-06, EP-09)

- **Depends on:** AMIR-TODO-01
- **Why it is blocked:** Deployment model, environments and network egress policy are unknown. Connectors make outbound calls, so egress control is a security requirement the reference cannot prove.
- **Engine information required:**
Environments; where AUIF would run; outbound network policy; secrets/network separation per tenant.
- **Question for Amir:** From which hosts will connectors run, which outbound destinations are allow-listed, and is the cloud metadata endpoint blocked?
- **Evidence to find (source / file / config / DB):**
Network policy/egress configuration; environment list.
- **Implementation step:**
Configure the runtime so connectors can reach only registered target endpoints, then run the egress checks below from the runtime host.
- **Must Amir modify Engine code?** YES: egress configuration
- **DB access required?** NO
- **Staging sufficient?** YES
- **Validation procedure:**
From the runtime host: curl -sS -m 5 -o /dev/null -w '%{http_code}\n' https://<allow-listed-sandbox-host>/ ; curl -sS -m 5 http://169.254.169.254/ ; curl -sS -m 5 https://example.org/
- **Expected result:** The first returns an HTTP status (200/401/403); the second and third fail to connect (blocked).
- **Evidence to return:**
The three command outputs and the egress policy.
- **Unblocks:** Safe execution of real connectors; production-isolation work (AMIR-TODO-16).
- **Status:** OPEN

## AMIR-TODO-10: CI and test conventions (EP-10)

- **Depends on:** AMIR-TODO-01
- **Why it is blocked:** How the Engine's CI runs tests, its Python/runtime versions and CI database are unknown.
- **Engine information required:**
CI system, runtime versions, test runner conventions, CI database.
- **Question for Amir:** How can the AUIF suites (python3 -m unittest, standard library only) be run in the Engine's CI, and is a CI database available?
- **Evidence to find (source / file / config / DB):**
CI configuration file path; runtime version.
- **Implementation step:**
Add a CI job that runs: python3 -W ignore -m unittest discover -s tests -t . from the AUIF build directory and archives ACCEPTANCE_RESULTS.json.
- **Must Amir modify Engine code?** YES: CI configuration
- **DB access required?** OPTIONAL (needed only for the persistence binding job)
- **Staging sufficient?** YES
- **Validation procedure:**
python3 -W ignore -m unittest discover -s tests -t .
- **Expected result:** Zero failures; the test count equals the count in ACCEPTANCE_RESULTS.json.
- **Evidence to return:**
CI run URL or log and the archived results file.
- **Unblocks:** Continuous verification of the build against the Engine's CI.
- **Status:** OPEN

## AMIR-TODO-11: Real Canonical Anchor Model (replaces the synthetic model)

- **Depends on:** AMIR-TODO-01; owner decision OD-08; GD-01
- **Why it is blocked:** The Anchor canonical attribute sets are an open decision (OD-08) and depend on the Engine's existing data models (ED-04). The model in this build is SYNTHETIC (status DRAFT_EXAMPLE_ONLY).
- **Engine information required:**
Existing Engine data models for parties, properties, agreements, tasks, events; naming and classification conventions.
- **Question for Amir:** Which existing Engine entities and attributes should the canonical concepts (Party, Property, Agreement, Task, Event, ...) align to, and what is each attribute's classification?
- **Evidence to find (source / file / config / DB):**
Model definitions (file paths) and the classification of each attribute. Governor-side GD-01 (Canonical Model vs Governor Neutral Model) remains an owner decision.
- **Implementation step:**
With the owner, author a real CanonicalModelDefinition JSON (schema: contracts/canonical.schema.json#/$defs/CanonicalModelDefinition) and place it outside the core.
- **Must Amir modify Engine code?** NO
- **DB access required?** NO
- **Staging sufficient?** Not applicable
- **Validation procedure:**
python3 -c "import json; from auif.contracts import validate; validate('canonical#CanonicalModelDefinition', json.load(open('<real_model.json>'))); print('VALID')"
- **Expected result:** Prints VALID with no exception.
- **Evidence to return:**
The model file and the validation output.
- **Unblocks:** Real Translation Packs; module requirements; real AUIF-AT-01..AT-04.
- **Status:** OPEN

## AMIR-TODO-15: Existing integration code reuse assessment

- **Depends on:** AMIR-TODO-01
- **Why it is blocked:** Whether the Engine already has integration code or abstractions AUIF should reuse or replace is unknown.
- **Engine information required:**
Inventory of existing integration code, abstractions and their consumers.
- **Question for Amir:** List existing integration code (paths) and state for each whether modules depend on it.
- **Evidence to find (source / file / config / DB):**
File paths and consumers.
- **Implementation step:**
Provide the inventory; the executor writes a reuse/replace assessment against AR-4.
- **Must Amir modify Engine code?** NO
- **DB access required?** NO
- **Staging sufficient?** Not applicable
- **Validation procedure:**
For each listed path run: git log -1 --format=%H -- <path>   and return the output.
- **Expected result:** A commit id per path (proves each path exists and is tracked).
- **Evidence to return:**
Inventory with command output.
- **Unblocks:** Decision on reuse versus replacement; avoids duplicate abstractions.
- **Status:** OPEN

## AMIR-TODO-18: Existing data classification metadata and policy source

- **Depends on:** AMIR-TODO-01; owner decision GD-04
- **Why it is blocked:** Where classification metadata and the data-boundary policy live (and who owns them) is unknown; GD-04 is a Governor-side decision. The reference policy is a synthetic table.
- **Engine information required:**
Existing classification metadata; policy source of truth.
- **Question for Amir:** Where is data classification currently recorded, and which system owns the data-boundary policy?
- **Evidence to find (source / file / config / DB):**
DB-10 evidence; policy source location; GD-04 decision by the owner.
- **Implementation step:**
Implement PolicyPort.decide over the real policy source: return None when a classification/destination pair is not covered. Copy port_contracts/templates/test_policy_binding.py.template to tests/binding/test_policy_binding.py and point the factory at the new binding. Run the suite.
- **Must Amir modify Engine code?** NO (binding only)
- **DB access required?** CONDITIONAL: read access to classification metadata (non-production)
- **Staging sufficient?** YES
- **Validation procedure:**
python3 -W ignore -m unittest tests.binding.test_policy_binding -v   (If the Engine is not Python, implement the language-neutral cases listed for this port in docs/PORT_CONFORMANCE_CASES.md in the Engine's own test framework and return their output instead.)
- **Expected result:** All PolicyPortContract cases pass: undeterminable pairs return None; unknown destinations are never implicitly allowed.
- **Evidence to return:**
unittest output; binding source.
- **Unblocks:** Real AUIF-AT-21; removes the synthetic policy dependency.
- **Status:** OPEN

## AMIR-TODO-04: Persistence binding (EP-04) and DB-dependent closure items

- **Depends on:** AMIR-TODO-01, AMIR-TODO-03
- **Why it is blocked:** Storage technology, tenant isolation mechanism, transactional guarantees and migration tooling are unknown. AUIF persists only through PersistencePort; the reference stores prove the port, not the platform's database.
- **Engine information required:**
Data stores and versions; tenant isolation mechanism at the data layer; transaction semantics for read-modify-write; unique-constraint support; migration tooling; backup/retention.
- **Question for Amir:** Which store will hold AUIF's collections (see docs/PERSISTENCE_COLLECTIONS.md), how is tenant isolation enforced at the data layer, and can a per-(tenant, collection, key) unique constraint and an atomic read-modify-write be provided?
- **Evidence to find (source / file / config / DB):**
Per DB-01..DB-09 in 03_AUIF_Open_Decisions_and_Dependency_Register.json: the exact_amir_instruction of each is reproduced in the generated section below.
- **Implementation step:**
Implement PersistencePort (put, get, update, list, next_sequence) over the Engine's store with a unique key on (tenant, collection, key) and an atomic update. Create the collections listed in docs/PERSISTENCE_COLLECTIONS.md via the Engine's migration tooling. Copy port_contracts/templates/test_persistence_binding.py.template to tests/binding/test_persistence_binding.py and point the factory at the new binding. Run the suite, then the acceptance suite on the binding (command below).
- **Must Amir modify Engine code?** YES: adds storage objects and migrations to the Engine (non-production first)
- **DB access required?** YES: a non-production database is sufficient; no production data
- **Staging sufficient?** YES: a non-production environment and database are sufficient; production data must not be used
- **Validation procedure:**
python3 -W ignore -m unittest tests.binding.test_persistence_binding -v   then   AUIF_BINDINGS_MODULE=<your_module> python3 -W ignore -m unittest discover -s tests -t .   (your_module must expose make_persistence() returning the binding)
- **Expected result:** PersistenceContract: all cases OK. Full suite: the same pass count as the reference run recorded in ACCEPTANCE_RESULTS.json, with zero failures.
- **Evidence to return:**
Both unittest outputs; migration scripts; the DB-01..DB-09 evidence listed in the register.
- **Unblocks:** Durable Action Execution Ledger, observations, manifests, discovery records; AUIF-AT-12 and AUIF-AT-11 on real storage; DB-dependent closure items.
- **Status:** OPEN

## AMIR-TODO-05: Secret store binding (EP-05)

- **Depends on:** AMIR-TODO-01, AMIR-TODO-03
- **Why it is blocked:** How the Engine stores and resolves credentials (vault/KMS/env) is unknown. The reference store only proves the core handles secrets by reference and never logs them.
- **Engine information required:**
Secret store technology; reference format; tenant scoping; rotation; access audit.
- **Question for Amir:** Which secret manager holds tenant integration credentials, how is a reference like secretref:<path> resolved per tenant, and how is access audited?
- **Evidence to find (source / file / config / DB):**
File paths/config for secret resolution; the policy or ACL that scopes a secret to a tenant.
- **Implementation step:**
Implement SecretPort.resolve(ctx, ref) over the Engine's secret store, tenant-scoped, raising SecretError when unresolvable. Copy port_contracts/templates/test_secret_binding.py.template to tests/binding/test_secret_binding.py and point the factory at the new binding. Run the suite.
- **Must Amir modify Engine code?** NO (binding only)
- **DB access required?** NO
- **Staging sufficient?** YES
- **Validation procedure:**
python3 -W ignore -m unittest tests.binding.test_secret_binding -v   (If the Engine is not Python, implement the language-neutral cases listed for this port in docs/PORT_CONFORMANCE_CASES.md in the Engine's own test framework and return their output instead.)
- **Expected result:** All SecretPortContract cases pass: another tenant cannot resolve the reference; unknown reference raises SecretError.
- **Evidence to return:**
unittest output; binding source.
- **Unblocks:** Connectors authenticating with real credentials; real AUIF-AT-20.
- **Status:** OPEN

## AMIR-TODO-06: Queue / worker / scheduler binding (EP-06)

- **Depends on:** AMIR-TODO-01, AMIR-TODO-03
- **Why it is blocked:** The Engine's queue and worker infrastructure is unknown. The core's FairScheduler and Throttle are in-process references of the required behaviour (bounded per-(tenant, integration) queues, tenant-fair service, Retry-After isolation).
- **Engine information required:**
Queue technology; worker model; retry/backoff facilities; per-tenant fairness controls; concurrency limits.
- **Question for Amir:** Which queue and workers will run Fabric.sync / ingest_events / actions.dispatch, and can work be partitioned and rate-limited per (tenant, integration)?
- **Evidence to find (source / file / config / DB):**
File paths/config for queues and workers; concurrency and retry settings.
- **Implementation step:**
Run AUIF tasks on the Engine's workers, keeping one bounded queue per (tenant, integration) and tenant-fair service; use Throttle for Retry-After and circuit state. Reproduce the fairness case below on the real workers.
- **Must Amir modify Engine code?** YES: worker registration/config
- **DB access required?** NO
- **Staging sufficient?** YES
- **Validation procedure:**
Enqueue 20 tasks for tenant A against a stub target returning 429 with Retry-After 300, and 20 tasks each for tenants B and C against a healthy stub. Record completion times. Reference behaviour: tests/test_foundation.py::TestFairScheduler::test_AT_30_throttled_tenant_does_not_stall_others
- **Expected result:** All B and C tasks complete without waiting for A; A's 20 tasks stay queued until Retry-After elapses; no queue grows beyond its bound.
- **Evidence to return:**
Timeline log of task completions per tenant; queue-depth samples; worker config.
- **Unblocks:** AUIF-AT-30 and AUIF-AT-08 on real infrastructure.
- **Status:** OPEN

## AMIR-TODO-12: Anchor Real Estate module specifics

- **Depends on:** AMIR-TODO-01, AMIR-TODO-02, AMIR-TODO-11
- **Why it is blocked:** The real first module's semantic requirements and entry points are unknown; the two synthetic modules are not Anchor Real Estate.
- **Engine information required:**
The module's concepts, attributes, actions it requests, events it consumes.
- **Question for Amir:** What canonical concepts and attributes does Anchor Real Estate require, and which actions will it request from external systems?
- **Evidence to find (source / file / config / DB):**
File paths of the module's data model and its integration points.
- **Implementation step:**
Write the module descriptor (OD-22 format as decided) and a ModulePort binding (AMIR-TODO-02) for it; add an acceptance run with this module registered.
- **Must Amir modify Engine code?** CONDITIONAL: as in AMIR-TODO-02
- **DB access required?** NO
- **Staging sufficient?** YES
- **Validation procedure:**
Register the real module in a World-equivalent and run: python3 -W ignore -m unittest tests.test_acceptance.TestAT01_02_16_Universality -v
- **Expected result:** AT-01 passes with the real module and core tree hash unchanged (tools/static_checks.py prints the same core_tree_sha256).
- **Evidence to return:**
unittest output and the two core_tree_sha256 values.
- **Unblocks:** The first real proving ground leg (Anchor Real Estate side).
- **Status:** OPEN

## AMIR-TODO-13: McGrath proof (AUIF-AT-15) and external-system access

- **Depends on:** AMIR-TODO-05, AMIR-TODO-09, AMIR-TODO-11, AMIR-TODO-12
- **Why it is blocked:** No representative McGrath/customer system, documentation, sandbox or test credentials is available. The McGrath proof cannot be performed or simulated honestly.
- **Engine information required:**
Access to a representative system or sandbox, its API/schema documentation, test credentials, rate limits, supported auth.
- **Question for Amir:** Can a McGrath sandbox (or an equivalent representative system) with documentation and test credentials be provided for the AT-15 procedure?
- **Evidence to find (source / file / config / DB):**
Sandbox endpoint, documentation, credential reference stored in the Engine's secret store, rate limits.
- **Implementation step:**
1. Provision test credentials into the secret store (AMIR-TODO-05). 2. Implement or select the connector for the system's protocol. 3. Author a Translation Pack for it with the owner. 4. Execute the AT-15 steps from 07_AUIF_Acceptance_Test_Specification.json (reproduced in the generated section below). 5. Run tools/static_checks.py to show no McGrath-specific code entered the core.
- **Must Amir modify Engine code?** NO to the Engine
- **DB access required?** NO
- **Staging sufficient?** YES: the sandbox is the proof environment
- **Validation procedure:**
Execute the AUIF-AT-15 steps (generated below), then: python3 tools/static_checks.py
- **Expected result:** AT-15 expected results hold; static_checks.py exit code 0 and an unchanged core_tree_sha256.
- **Evidence to return:**
Per-step evidence defined by AT-15; static_checks output; connector and pack files.
- **Unblocks:** AUIF-AT-15; the commercial proving claim.
- **Status:** OPEN

## AMIR-TODO-14: Performance measurement (AUIF-AT-29)

- **Depends on:** AMIR-TODO-04, AMIR-TODO-06; owner thresholds
- **Why it is blocked:** Performance thresholds and a production-like environment are not available. The reference measurement (evidence/performance_measurement.json) is explicitly non-representative.
- **Engine information required:**
Target throughput/latency thresholds (owner decision) and a production-like environment with representative data volumes.
- **Question for Amir:** What throughput and latency are required per tenant and per integration, and in which environment may AUIF be measured?
- **Evidence to find (source / file / config / DB):**
Threshold document; environment description; DB write-rate baseline (DB-06).
- **Implementation step:**
Run the measurement on the real persistence binding in the production-like environment and compare with thresholds.
- **Must Amir modify Engine code?** NO
- **DB access required?** YES: production-like non-production
- **Staging sufficient?** YES: production-like staging
- **Validation procedure:**
AUIF_BINDINGS_MODULE=<your_module> AUIF_PERF_OUT=./amir_performance.json python3 -W ignore -m unittest tests.test_acceptance.TestAT29_Performance -v   then read ./amir_performance.json (the tracked evidence file is not touched)
- **Expected result:** Measured values meet the owner's thresholds (to be supplied).
- **Evidence to return:**
The JSON file, environment description, thresholds.
- **Unblocks:** AUIF-AT-29.
- **Status:** OPEN

## AMIR-TODO-16: Production isolation verification (cross-tenant, real infrastructure)

- **Depends on:** AMIR-TODO-03, AMIR-TODO-04, AMIR-TODO-09
- **Why it is blocked:** Cross-tenant isolation in the real data layer and runtime cannot be proven by the reference. Only the core's own guards are proven.
- **Engine information required:**
Data-layer isolation mechanism and a staging environment with two test tenants.
- **Question for Amir:** Can two non-production test tenants be provisioned so isolation tests can be run against the real data layer?
- **Evidence to find (source / file / config / DB):**
DB-02 evidence plus the test output below.
- **Implementation step:**
Provision tenants 'tenant-a' and 'tenant-b' in staging; run the isolation acceptance tests on the persistence binding; run the data-layer query below.
- **Must Amir modify Engine code?** NO
- **DB access required?** YES: non-production
- **Staging sufficient?** YES
- **Validation procedure:**
AUIF_BINDINGS_MODULE=<your_module> python3 -W ignore -m unittest tests.test_acceptance.TestAT12_Isolation -v   then in the database count rows visible to tenant-b whose tenant column is tenant-a
- **Expected result:** All AT-12 tests pass; the cross-tenant row count is 0.
- **Evidence to return:**
unittest output; the query and its result.
- **Unblocks:** Real AUIF-AT-12; production readiness assessment (not claimed here).
- **Status:** OPEN

## When you finish

Return `evidence_from_amir/` and a one-line status per item (CLOSED / PARTIAL / BLOCKED, with the reason). Nothing is CLOSED without its evidence. Closure of an item does not change the Architecture's lock status: that is a separate gate.

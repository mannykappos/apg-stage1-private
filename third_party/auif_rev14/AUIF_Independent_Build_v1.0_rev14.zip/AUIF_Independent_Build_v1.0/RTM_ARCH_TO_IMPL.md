# RTM_ARCH_TO_IMPL: architecture (AR-0..AR-23) to implementation

Source: audited Architecture v1.0-DRAFT Revision 2. Scope columns say exactly what is verified on the synthetic world, what still needs the real environment, and what is blocked.

| AR | Title | Implementation | Verified (synthetic) | Environment-dependent | Blocked | Amir items |
|---|---|---|---|---|---|---|
| AR-0 | Reading rules and tagging | evidence/audited_inputs/; contracts/ | Audited inputs copied byte-identically (verified) | - | - | - |
| AR-1 | Purpose and commercial shape | - | Document only | - | - | - |
| AR-2 | Separation of concerns | auif/ports.py; tools/static_checks.py | Core depends only on stdlib and itself; ports are the only boundary (static check, AT-17/28) | - | - | - |
| AR-3 | Governor boundary | auif/ports.py; auif/action.py; auif/integration.py; tools/static_checks.py | AUIF requests and reports only; no authority API exists (static scan); governed action never sent without a decision (AT-13, M11/M25/M28) | Real Governor wiring (EP-07); GD-03/GD-05 open | - | 07 |
| AR-4 | Component model and isolation | auif/; synthetic/; tools/static_checks.py | Core/synthetic separation; core tree hash unchanged when a 4th system is added (AT-01/02/16) | - | - | - |
| AR-5 | Connection Layer / Connector contract | auif/connector.py; synthetic/connectors.py | Contract enforcement, retry/Retry-After, idempotency-gated writes, failure principle, cancellation, credential boundary (AT-08/11/14/18/20) | Real transports and credentials | - | 05, 09 |
| AR-6 | Discovery, fingerprint, drift | auif/discovery.py; auif/integration.py | Records, deterministic fingerprints, scoped drift (AT-05) | Materiality policy (OD-05) is a draft position | - | - |
| AR-7 | Canonical Anchor Model boundary | auif/canonical.py | Framework, typed validation, classification, provenance chain (AT-19/22) | - | The REAL Anchor canonical attribute sets (OD-08) | 11 |
| AR-8 | Translation Packs | auif/translation.py; synthetic/packs.py | Immutable hashed registry, pinning, bidirectional translation, explicit outcomes, outbound validation (AT-03/04/06/19/23); ONE shared transform validator for the registry, runtime and AI validator, and hostile data values are explicit per-field failures (audit round 1: F1, F5) | - | Real target packs (McGrath) | 13 |
| AR-9 | Ambiguity and AI boundary | auif/ai_boundary.py; synthetic/ai_stub.py | AI proposes only; deterministic promotion with full transform validation; sandbox; proposer OUTPUT treated as untrusted input; ambiguity-resolution evidence hash-bound into the validation record; untrusted text (AT-07/25; audit round 1: F1, F2, F3); promotion evidence binds the complete mapping and the registry recognises AI promotion by its evidence (audit round 2: F6) | Real AI service binding | - | 17 |
| AR-10 | Observations, provenance, ordering | auif/observation.py; auif/fabric.py | Envelopes, causal ordering, bounded wait then reconcile, dedupe (AT-09/10/22) | - | - | - |
| AR-11 | Backpressure and throttling | auif/throttle.py; auif/connector.py | Token bucket, Retry-After, circuit breaker, bounded queues, tenant-fair scheduling (AT-08/30) | Fairness on the platform's real workers | - | 06 |
| AR-12 | Classification and boundary enforcement | auif/classification.py; synthetic/policy.py | Policy-driven allow/transform/reject; undeterminable means reject (AT-21) | The real policy source (GD-04/OD-09) | - | 18 |
| AR-13 | Actions, ledger, idempotency | auif/action.py | Ledger transition table, durable before send, idempotency, no blind retry, reconciliation (AT-11/13); submission is a resumable write-ahead intent: a failure at any single write cannot strand an action or a key (audit round 2: F7); an action's tenant must equal the authenticated context before any record is written (audit round 3: F9) | Durable ledger on real storage | - | 04 |
| AR-14 | Integration state machine and manifest | auif/integration.py; contracts/integration_state_machine.json | ACTIVE only via validation; failure distinctions; manifests carry no authority; discovery record persisted, restored on restart and re-taken on resume, and the pack gate fails closed without one (AT-05/06; audit round 1: F4) | - | - | - |
| AR-15 | Tenant isolation, credentials, security | auif/tenancy.py; auif/security.py; auif/observability.py; auif_ref/secrets.py | Forged/missing context refused; hostile input; no secret in outputs (AT-12/14/20/24); a caller-supplied action tenant is verified against the authenticated context (audit round 3: F9) | Isolation on real data layer, secrets and infrastructure | - | 03, 05, 16 |
| AR-16 | Versioning | auif/translation.py; auif/integration.py | Pack/model/contract compatibility checks; manifest versions | - | - | - |
| AR-17 | Observability and performance | auif/observability.py; evidence/performance_measurement.json | 15 required signals, redaction (AT-24); synthetic performance measured (AT-29) | Real sink and real performance | - | 08, 14 |
| AR-18 | Anchor module contract | auif/modules.py; auif/ports.py; synthetic/modules.py | Module Port against reference modules; module isolation | Real module binding; descriptor format OD-22 is reference-only | Anchor Real Estate specifics | 02, 12 |
| AR-19 | Proving ground and testing strategy | tests/; synthetic/world.py; tools/mutation_test.py; tools/static_checks.py | Synthetic world, acceptance, mutation testing (see evidence/mutation_results.json), static checks | - | McGrath proof (AT-15) | 13 |
| AR-20 | Engine boundary (ED-01..14) | auif/ports.py; port_contracts/; AMIR_ENGINE_DEPENDENCY_TODO.md | Ports and conformance suites exist; every Engine fact recorded as UNKNOWN | All bindings | Reconnaissance | 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 15 |
| AR-21 | Reference vs production; DB-dependent closure | auif_ref/; docs/PERSISTENCE_COLLECTIONS.md | Two reference stores pass the persistence conformance suite | DB-dependent closure items (DB-01..DB-10) | - | 04, 18 |
| AR-22 | Order, gates, evidence, change control | tools/; evidence/; FILE_MANIFEST.json | Evidence, manifest and hashes | Architecture LOCK remains gated on reconnaissance review | - | 01 |
| AR-23 | What remains open | UNRESOLVED_GOVERNOR_DECISIONS.md; KNOWN_LIMITATIONS.md | Open items recorded; none resolved here | - | - | - |

## Handoff headings (67) to architecture, implementation and acceptance evidence

| Handoff | Heading | Architecture | Implementation | Acceptance tests (result) | Dependencies |
|---|---|---|---|---|---|
| BT | Build Timing | AR-0 | contracts/; evidence/audited_inputs/ | - | ED-04, XD-01 |
| 1 | PRIMARY OBJECTIVE | AR-1 | - | AT-16 | - |
| 2 | CORE ARCHITECTURAL PRINCIPLE | AR-2 | auif/ports.py; tools/static_checks.py | AT-03, AT-16 | ED-01, ED-11 |
| 3 | HIGH-LEVEL ARCHITECTURE | AR-2, AR-4 | auif/; auif/ports.py; synthetic/; tools/static_checks.py | AT-16 | ED-01, ED-11 |
| 4 | NON-NEGOTIABLE GOVERNOR BOUNDARY | AR-3, AR-13 | auif/action.py; auif/integration.py; auif/ports.py; tools/static_checks.py | AT-13, AT-27 | ED-08, ED-11 |
| 5 | O(N + M) OBJECTIVE | AR-1 | - | AT-02, AT-16 | - |
| 6 | MAJOR COMPONENTS | AR-2, AR-4 | auif/; auif/ports.py; synthetic/; tools/static_checks.py | AT-02 | ED-01, ED-11 |
| 6.1 | Connection Layer | AR-4, AR-5 | auif/; auif/connector.py; synthetic/; synthetic/connectors.py; tools/static_checks.py | AT-02 | - |
| 7 | CONNECTOR CONTRACT | AR-5 | auif/connector.py; synthetic/connectors.py | AT-02, AT-18 | - |
| 8 | DISCOVERY ENGINE | AR-6 | auif/discovery.py; auif/integration.py | AT-02 | ED-08, ED-13 |
| 9 | DISCOVERY MUST NOT EQUAL AUTHORITY | AR-6 | auif/discovery.py; auif/integration.py | AT-07 | ED-08, ED-13 |
| 10 | SCHEMA FINGERPRINTING AND DRIFT | AR-6 | auif/discovery.py; auif/integration.py | AT-05 | ED-08, ED-13 |
| 11 | CANONICAL ANCHOR MODEL | AR-7 | auif/canonical.py | AT-04 | ED-04 |
| 12 | CANONICAL MODEL BOUNDARY | AR-7 | auif/canonical.py | AT-16 | ED-04 |
| 13 | TRANSLATION PACKS | AR-8 | auif/translation.py; synthetic/packs.py | AT-03 | ED-08 |
| 14 | BIDIRECTIONAL TRANSLATION | AR-8 | auif/translation.py; synthetic/packs.py | AT-04 | ED-08 |
| 15 | TRANSLATION PACK IMMUTABILITY | AR-8 | auif/translation.py; synthetic/packs.py | AT-06, AT-23 | ED-08 |
| 16 | SEMANTIC AMBIGUITY | AR-9 | auif/ai_boundary.py; synthetic/ai_stub.py | AT-07, AT-25 | ED-07 |
| 17 | AI-ASSISTED MAPPING | AR-9 | auif/ai_boundary.py; synthetic/ai_stub.py | AT-07, AT-25 | ED-07 |
| 18 | OBSERVATION MODEL | AR-10 | auif/fabric.py; auif/observation.py | AT-22 | - |
| 19 | EVENT ORDERING | AR-10 | auif/fabric.py; auif/observation.py | AT-09, AT-10 | - |
| 20 | ORDERING UNCERTAINTY | AR-10 | auif/fabric.py; auif/observation.py | AT-09 | - |
| 21 | RATE LIMITING AND BACKPRESSURE | AR-5, AR-11 | auif/connector.py; auif/throttle.py; synthetic/connectors.py | AT-08, AT-30 | ED-07, ED-12, ID-03 |
| 22 | RATE-LIMIT ISOLATION | AR-5, AR-11 | auif/connector.py; auif/throttle.py; synthetic/connectors.py | AT-30 | ED-07, ED-12, ID-03 |
| 23 | DATA CLASSIFICATION | AR-7, AR-12 | auif/canonical.py; auif/classification.py; synthetic/policy.py | AT-21 | ED-04, ED-11 |
| 24 | DATA BOUNDARY ENFORCEMENT | AR-12 | auif/classification.py; synthetic/policy.py | AT-21 | ED-11 |
| 25 | ACTION DELIVERY | AR-13 | auif/action.py | AT-11, AT-13, AT-21 | ED-08, ED-11 |
| 26 | ACTION EXECUTION LEDGER | AR-13 | auif/action.py | AT-11 | ED-08, ED-11 |
| 27 | IDEMPOTENCY | AR-13 | auif/action.py | AT-11 | ED-08, ED-11 |
| 28 | INTEGRATION STATE MACHINE | AR-14 | auif/integration.py; contracts/integration_state_machine.json | AT-05, AT-18 | ED-08 |
| 29 | TENANT ISOLATION | AR-15 | auif/observability.py; auif/security.py; auif/tenancy.py; auif_ref/secrets.py | AT-12 | ED-03, ED-07, ED-08, ED-09, ED-11, ED-12, ID-01, ID-04 |
| 30 | CREDENTIAL / SECRET BOUNDARY | AR-15 | auif/observability.py; auif/security.py; auif/tenancy.py; auif_ref/secrets.py | AT-20, AT-24 | ED-03, ED-07, ED-08, ED-09, ED-11, ED-12, ID-01, ID-04 |
| 31 | PROVENANCE | AR-10 | auif/fabric.py; auif/observation.py | AT-22 | - |
| 32 | VERSIONING | AR-8, AR-16 | auif/integration.py; auif/translation.py; synthetic/packs.py | AT-06, AT-23 | ED-08 |
| 33 | MANIFEST | AR-14 | auif/integration.py; contracts/integration_state_machine.json | AT-06 | ED-08 |
| 34 | DRIFT RESPONSE | AR-6, AR-14 | auif/discovery.py; auif/integration.py; contracts/integration_state_machine.json | AT-05 | ED-08, ED-13 |
| 35 | CONNECTOR FAILURE | AR-5, AR-14 | auif/connector.py; auif/integration.py; contracts/integration_state_machine.json; syntheti | AT-18 | ED-08 |
| 36 | CANONICAL MODEL FAILURE | AR-7 | auif/canonical.py | AT-19 | ED-04 |
| 37 | NO SILENT DATA LOSS | AR-7, AR-8 | auif/canonical.py; auif/translation.py; synthetic/packs.py | AT-19 | ED-04, ED-08 |
| 38 | OBSERVABILITY | AR-17 | auif/observability.py; evidence/performance_measurement.json | AT-24 | ED-07, ED-13, XD-01 |
| 39 | SECURITY MODEL | AR-15 | auif/observability.py; auif/security.py; auif/tenancy.py; auif_ref/secrets.py | AT-14, AT-23 | ED-03, ED-07, ED-08, ED-09, ED-11, ED-12, ID-01, ID-04 |
| 40 | AI SECURITY | AR-9 | auif/ai_boundary.py; synthetic/ai_stub.py | AT-14, AT-25 | ED-07 |
| 41 | EXTENSION MODEL | AR-4, AR-18 | auif/; auif/modules.py; auif/ports.py; synthetic/; synthetic/modules.py; tools/static_chec | AT-01 | ED-01, ED-05, ED-06 |
| 42 | ANCHOR MODULE CONTRACT | AR-18 | auif/modules.py; auif/ports.py; synthetic/modules.py | AT-01 | ED-01, ED-05, ED-06 |
| 43 | FIRST PROVING GROUND — ANCHOR REAL ESTATE | AR-8, AR-19 | auif/translation.py; synthetic/packs.py; synthetic/world.py; tests/; tools/mutation_test.p | AT-15, AT-17 | ED-08, ED-14, XD-01 |
| 44 | FIRST PROVING-GROUND DATA FLOW | AR-19 | synthetic/world.py; tests/; tools/mutation_test.py; tools/static_checks.py | AT-15 | ED-14, XD-01 |
| 45 | TESTING STRATEGY | AR-19 | synthetic/world.py; tests/; tools/mutation_test.py; tools/static_checks.py | - | ED-14, XD-01 |
| 46 | REQUIRED ARCHITECTURAL ACCEPTANCE TESTS | AR-19 | synthetic/world.py; tests/; tools/mutation_test.py; tools/static_checks.py | AT-01, AT-02, AT-03, AT-04, AT-05, AT-06, AT-07, AT-08, AT-09, AT-10, AT-11, AT-12, AT-13, AT-14, AT-15 | ED-14, XD-01 |
| 47 | UNIVERSALITY TEST | AR-19 | synthetic/world.py; tests/; tools/mutation_test.py; tools/static_checks.py | AT-16 | ED-14, XD-01 |
| 48 | REVERSE CONTAMINATION TEST | AR-19 | synthetic/world.py; tests/; tools/mutation_test.py; tools/static_checks.py | AT-17 | ED-14, XD-01 |
| 49 | NO BESPOKE BUSINESS LOGIC IN CONNECTORS | AR-4, AR-5, AR-19 | auif/; auif/connector.py; synthetic/; synthetic/connectors.py; synthetic/world.py; tests/; | AT-03, AT-17 | ED-14, XD-01 |
| 50 | NO TARGET SYSTEM AS SOURCE OF TRUTH | AR-3, AR-19 | auif/action.py; auif/integration.py; auif/ports.py; synthetic/world.py; tests/; tools/muta | AT-26 | ED-11, ED-14, XD-01 |
| 51 | IMPLEMENTATION ORDER | AR-20, AR-22 | AMIR_ENGINE_DEPENDENCY_TODO.md; FILE_MANIFEST.json; auif/ports.py; evidence/; port_contrac | AT-28 | ED-01, ED-02, ED-03, ED-04, ED-05, ED-06, ED-07, ED-08, ED-09, ED-10, ED-11, ED-12, ED-13, ED-14, XD-01 |
| 52 | BUILD DISCIPLINE | AR-0, AR-20, AR-22 | AMIR_ENGINE_DEPENDENCY_TODO.md; FILE_MANIFEST.json; auif/ports.py; contracts/; evidence/;  | - | ED-01, ED-02, ED-03, ED-04, ED-05, ED-06, ED-07, ED-08, ED-09, ED-10, ED-11, ED-12, ED-13, ED-14, XD-01 |
| 53 | CHANGE CONTROL | AR-0, AR-3, AR-22 | FILE_MANIFEST.json; auif/action.py; auif/integration.py; auif/ports.py; contracts/; eviden | AT-27 | ED-01, ED-04, ED-08, ED-11, ED-12, ED-14, XD-01 |
| 54 | GOVERNOR INTEGRATION | AR-3 | auif/action.py; auif/integration.py; auif/ports.py; tools/static_checks.py | AT-13, AT-27 | ED-11 |
| 55 | EVIDENCE REQUIREMENT | AR-22 | FILE_MANIFEST.json; evidence/; tools/ | - | ED-01, ED-04, ED-08, ED-11, ED-12, ED-14, XD-01 |
| 56 | AUDIT HANDOFF REQUIREMENT | AR-22 | FILE_MANIFEST.json; evidence/; tools/ | - | ED-01, ED-04, ED-08, ED-11, ED-12, ED-14, XD-01 |
| 57 | DATABASE-DEPENDENT WORK | AR-0, AR-20, AR-21 | AMIR_ENGINE_DEPENDENCY_TODO.md; auif/ports.py; auif_ref/; contracts/; docs/PERSISTENCE_COL | AT-28 | ED-01, ED-02, ED-03, ED-04, ED-05, ED-06, ED-07, ED-08, ED-09, ED-10, ED-11, ED-12, ED-13, ED-14, ID-01, ID-02, ID-03, ID-04, XD-01 |
| 58 | PRODUCTION VS REFERENCE IMPLEMENTATION | AR-0, AR-20, AR-21 | AMIR_ENGINE_DEPENDENCY_TODO.md; auif/ports.py; auif_ref/; contracts/; docs/PERSISTENCE_COL | AT-28 | ED-01, ED-02, ED-03, ED-04, ED-05, ED-06, ED-07, ED-08, ED-09, ED-10, ED-11, ED-12, ED-13, ED-14, ID-01, ID-02, ID-03, ID-04, XD-01 |
| 59 | PERFORMANCE | AR-11, AR-17 | auif/connector.py; auif/observability.py; auif/throttle.py; evidence/performance_measureme | AT-29 | ED-07, ED-12, ED-13, ID-03, XD-01 |
| 60 | FAILURE PRINCIPLE | AR-5, AR-6, AR-14 | auif/connector.py; auif/discovery.py; auif/integration.py; contracts/integration_state_mac | AT-18 | ED-08, ED-13 |
| 61 | SECURITY PRINCIPLE | AR-15 | auif/observability.py; auif/security.py; auif/tenancy.py; auif_ref/secrets.py | AT-14, AT-20 | ED-03, ED-07, ED-08, ED-09, ED-11, ED-12, ID-01, ID-04 |
| 62 | COMMERCIAL DESIGN PRINCIPLE | AR-1 | - | AT-01, AT-02, AT-16 | - |
| 63 | SUCCESS CONDITION | AR-1 | - | AT-16 | - |
| 64 | FINAL ARCHITECTURAL RULE | AR-1 | - | - | - |
| 65 | BUILDER INSTRUCTION | AR-0, AR-20, AR-22 | AMIR_ENGINE_DEPENDENCY_TODO.md; FILE_MANIFEST.json; auif/ports.py; contracts/; evidence/;  | AT-28 | ED-01, ED-02, ED-03, ED-04, ED-05, ED-06, ED-07, ED-08, ED-09, ED-10, ED-11, ED-12, ED-13, ED-14, XD-01 |

Handoff-row status is in `RTM_ARCH_TO_IMPL.json` (`handoff_rows`).

import copy
from synthetic.world import World, ref
from synthetic.connectors import _Base, make_descriptor
from synthetic.packs import build, emap, fmap, ID
from synthetic.systems import Faults
from auif.errors import TransportError
def act(w, tenant, n, attrs, *, cid="party:synthetic-system-a:3", gov=False, integ="rest", atype="synthetic.update_party", ctype="Party", key=None, module="synthetic-module-1", target="synthetic-system-a"):
    c = w.integrations[(tenant, integ)]
    return {"contract_kind": "CanonicalAction", "action_id": "act-%04d" % n, "tenant_id": tenant, "source_module": module, "target_system_id": target, "environment_id": "env-sandbox", "manifest_ref": c.manifest_ref(), "idempotency_key": key or "idem-%s-%04d-abc" % (tenant, n), "correlation_id": "corr-%04d" % n, "requested_at": "2026-10-02T03:00:00Z",
            "canonical_action": {"action_type": atype, "payload": {"canonical_type": ctype, "canonical_id": cid, "attributes": attrs}}, "governance": {"governance_required": gov, "governance_required_source": "UNKNOWN" if gov == "UNKNOWN" else "MODULE_DECLARED", "governor_decision_ref": None}}
def ev(i, deps=(), seq=None, title="t", state="open", typ="ticket.updated", payload=None):
    e = {"event_id": i, "type": typ, "depends_on": list(deps), "payload": payload if payload is not None else {"id": i.upper(), "title": title, "state": state}}
    if seq: e["source_sequence"] = seq
    return e
class SystemD:
    """SYNTHETIC fourth external system with its own naming, defined OUTSIDE the core and added at run time (AT-02 / AT-16)."""
    secret = "d-secret-token"
    def __init__(self): self.faults, self.rows = Faults(), [{"cid": str(i), "nm": "Dee %d" % i, "mail": "d%d@example.invalid" % i} for i in range(1, 4)]
    def metadata(self): return {"system_version": "D-1", "auth_requirements": {"type": "token"}, "entities": [{"name": "Contact", "fields": [{"name": "cid", "type": "string"}, {"name": "nm", "type": "string"}, {"name": "mail", "type": "string"}], "relationships": []}], "operations": [{"name": "fetchContacts", "kind": "read", "entities": ["Contact"]}], "events": [], "rate_limits": {"requests_per_second": 5}, "not_exposed": ["webhook_support"]}
class DConnector(_Base):
    connector_id, connector_version = "synthetic-graphql-connector", "1.0.0"
    def descriptor(self): return make_descriptor(self.connector_id, self.connector_version, "GRAPHQL", idempotent=False, auth="API_KEY", cred_ref=self.cred_ref, pagination="TOKEN")
    def discover(self): return self.sys.metadata()
    def read(self, request): return {"items": copy.deepcopy(self.sys.rows), "next_cursor": None, "complete": True}
    def write(self, request): raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED")
def pack_d(fp):
    pol = {"default_outcome": "UNMAPPED", "optional_and_unused": [], "ignored_by_rule": [{"field_pattern": "^cid$", "rule_id": "rule-identity-in-canonical-id", "justification": "Identity is carried by the canonical_id identity mapping.", "material": False}]}
    return build("synthetic-pack-d", "1.0.0", "synthetic-graphql", [fp], [emap("d-ent", "ENTITY", "Contact", "Party", "Contact", writable=False), fmap("d-name", "Contact.nm", "Party.display_name", ID, None), fmap("d-mail", "Contact.mail", "Party.contact_email", ID, None)], [], pol)

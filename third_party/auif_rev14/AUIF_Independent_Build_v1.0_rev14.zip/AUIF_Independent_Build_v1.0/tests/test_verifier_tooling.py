"""Rev5 tooling regression tests: the fresh-ZIP verifier must not impose a hidden wall-clock limit on the mutation step (the shipped 900 s constant made a correct package fail its own verification)."""
import importlib.util, os, re, subprocess, sys, unittest
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); SRC = os.path.join(ROOT, "tools", "verify_fresh_zip.py")
def load():
    spec = importlib.util.spec_from_file_location("verify_fresh_zip_under_test", SRC); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
class TestVerifierWaitsForMutationToFinish(unittest.TestCase):
    def setUp(self): self.v = load()
    def test_by_default_there_is_no_wall_clock_limit(self): self.assertIsNone(self.v.mutation_timeout(["pkg.zip"])); self.assertIsNone(self.v.mutation_timeout(["pkg.zip", "--skip-mutation"]))
    def test_an_explicit_limit_is_honoured_and_parsed_as_seconds(self): self.assertEqual(self.v.mutation_timeout(["pkg.zip", "--mutation-timeout=2500"]), 2500.0); self.assertEqual(self.v.mutation_timeout(["--mutation-timeout=0.5", "pkg.zip"]), 0.5)
    def test_nonsense_limits_are_refused_not_silently_ignored(self):
        for bad in ("abc", "0", "-5", "", "nan"):
            with self.subTest(bad):
                with self.assertRaises(SystemExit): self.v.mutation_timeout(["pkg.zip", "--mutation-timeout=" + bad])
    def test_sh_with_no_timeout_waits_for_a_slow_command_to_finish(self):
        rc, out = self.v.sh([sys.executable, "-c", "import time; time.sleep(2); print('finished')"], ROOT, None); self.assertEqual(rc, 0); self.assertIn("finished", out)
    def test_sh_with_an_explicit_timeout_still_stops_a_hung_command(self):
        with self.assertRaises(subprocess.TimeoutExpired): self.v.sh([sys.executable, "-c", "import time; time.sleep(30)"], ROOT, 1)
    def test_the_mutation_step_takes_its_limit_from_the_caller_not_from_a_constant(self):
        src = open(SRC).read(); self.assertIn("mutation_timeout(sys.argv)", src); self.assertIsNone(re.search(r"mutation_test\.py\"\], root, \d", src), "a numeric literal limit on the mutation step")
if __name__ == "__main__": unittest.main()

"""Integration failure states and recoveries (AR-14 failure distinctions) and the remaining measured coverage gaps. Found by line-coverage measurement: before these tests no test drove an integration into
CONNECTION_FAILED, AUTHENTICATION_FAILED, VERSION_INCOMPATIBLE or a bad pack pin, nor recovered from them."""
import unittest
from auif.ai_boundary import MappingValidator
from auif.clock import FakeClock
from auif.discovery import DiscoveryEngine, fingerprint
from auif.errors import *
from auif.fabric import Fabric
from auif.throttle import Throttle, FairScheduler
from auif.translation import apply_transform, check_constraint, pack_hash
from auif.util import Ids
from synthetic.connectors import SyntheticRestConnector, SyntheticDatabaseConnector
from synthetic.packs import pack_a, MODEL_DEF
from synthetic.systems import SystemA, SystemB
from synthetic.world import World, ref
from tests.helpers import Env
A = "tenant-a"; REFA = "secretref:synthetic/rest"
class N(unittest.TestCase):
    """A world that is NOT yet activated, so the failure path of activation itself can be driven."""
    def setUp(self): self.w = World(); self.a = self.w.ctx[A]; self.sa = self.w.sys[A]["A"]; self.c = self.w.integrations[(A, "rest")]; self.f = self.w.fabric
    def states(self): return [s["state"] for s in self.w.m1.by_tenant[A]["states"]]
    def extra(self, pack, iid="ia-extra", module="synthetic-module-1"): return self.f.add_integration(self.a, iid, anchor_module=module, connector=SyntheticRestConnector(self.sa, REFA), pack_ref=ref(pack), target_system_id="synthetic-system-a", environment_id="env-sandbox", entities=["Account"])
    def variant(self, **over):
        p = pack_a([fingerprint(self.sa.metadata())["value"]]); p["pack_version"] = "9.0.0"; p.update(over); p["artifact_hash"] = pack_hash(p); self.w.packs.register(p); return p
class TestConnectionAndAuthenticationFailure(N):
    def test_unreachable_target_during_activation_is_CONNECTION_FAILED_not_empty_or_active(self):
        self.sa.faults.push("discover", *([("unavailable",)] * 10)); st = self.c.activate()
        self.assertEqual(st["state"], "CONNECTION_FAILED"); self.assertEqual(st["last_failure"]["code"], "UNAVAILABLE"); self.assertFalse(st["trust_basis"]["manifest_validated"])
        self.assertFalse(self.c.operation_allowed("updateAccount", False)); self.assertTrue(self.f.sync(self.a, "ia-rest", "Account")["not_allowed"])           # a failure is never served as 'no data'
    def test_recovery_from_CONNECTION_FAILED_revalidates_before_returning_to_ACTIVE(self):
        self.sa.faults.push("discover", *([("unavailable",)] * 10)); self.c.activate(); self.sa.faults.q.clear(); st = self.c.activate()
        self.assertEqual(st["state"], "ACTIVE"); self.assertTrue(all(st["trust_basis"].values())); self.assertIn("CONNECTION_FAILED", self.states()); self.assertEqual(self.states()[-2:], ["VALIDATING", "ACTIVE"])
    def test_wrong_credential_is_AUTHENTICATION_FAILED_and_distinct_from_connection_failure(self):
        self.w.secrets.put(A, REFA, "WRONG-SECRET"); st = self.c.activate(); self.assertEqual((st["state"], st["last_failure"]["code"]), ("AUTHENTICATION_FAILED", "AUTHENTICATION_FAILED"))
        self.w.secrets.put(A, REFA, self.sa.secret); self.assertEqual(self.c.activate()["state"], "ACTIVE")
    def test_malformed_discovery_response_is_recorded_as_a_failure_with_the_malformed_code(self):
        self.sa.faults.push("discover", ("malformed",)); st = self.c.activate(); self.assertEqual((st["state"], st["last_failure"]["code"]), ("CONNECTION_FAILED", "MALFORMED_RESPONSE"))
    def test_failure_of_an_ACTIVE_integration_moves_it_out_of_ACTIVE(self):
        self.w.activate_all(); self.assertEqual(self.c.state(), "ACTIVE"); self.sa.faults.push("discover", *([("unavailable",)] * 10)); self.assertIsNone(self.c.check_drift()); self.assertEqual(self.c.state(), "CONNECTION_FAILED")
class TestVersionAndPackPinFailures(N):
    def test_canonical_model_outside_the_packs_range_is_VERSION_INCOMPATIBLE(self):
        p = self.variant(canonical_model_compat={"min": "0.2.0", "max": "0.2.9"}); st = self.extra(p).activate(); self.assertEqual(st["state"], "VERSION_INCOMPATIBLE"); self.assertEqual(st["incompatibility"]["component"], "CANONICAL_MODEL")
    def test_AUIF_contract_outside_the_packs_range_is_VERSION_INCOMPATIBLE_for_AUIF(self):
        p = self.variant(auif_contract_compat={"min": "2.0.0", "max": "2.0.9"}); st = self.extra(p).activate(); self.assertEqual((st["state"], st["incompatibility"]["component"]), ("VERSION_INCOMPATIBLE", "AUIF"))
    def test_VERSION_INCOMPATIBLE_recovers_only_by_repinning_to_a_compatible_pack_then_revalidating(self):
        c = self.extra(self.variant(canonical_model_compat={"min": "0.2.0", "max": "0.2.9"})); self.assertEqual(c.activate()["state"], "VERSION_INCOMPATIBLE"); self.assertEqual(c.activate()["state"], "VERSION_INCOMPATIBLE")      # nothing changed: still refused
        c.pack_ref = ref(self.w.pA); self.assertEqual(c.activate()["state"], "ACTIVE")
    def test_a_pack_pin_that_cannot_be_honoured_is_TRANSLATION_INVALID_with_diagnostics(self):
        c = self.f.add_integration(self.a, "ia-badpin", anchor_module="synthetic-module-1", connector=SyntheticRestConnector(self.sa, REFA), pack_ref={"id": "synthetic-pack-a", "version": "1.0.0", "hash": "f" * 64}, target_system_id="synthetic-system-a", environment_id="env-sandbox", entities=["Account"])
        st = c.activate(); self.assertEqual(st["state"], "TRANSLATION_INVALID"); d = self.w.store.get(self.a, "integration_diagnostics", st["diagnostics_ref"]["evidence_id"]); self.assertIn("pack pin cannot be honoured", d["reasons"][0])
        c.pack_ref = ref(self.w.pA); self.assertEqual(c.activate()["state"], "ACTIVE")
    def test_SEMANTIC_AMBIGUITY_recovers_through_a_validated_pack_not_by_itself(self):
        c = self.extra(self.w.pAamb); self.assertEqual(c.activate()["state"], "SEMANTIC_AMBIGUITY"); self.assertEqual(c.activate()["state"], "SEMANTIC_AMBIGUITY"); c.pack_ref = ref(self.w.pA); self.assertEqual(c.activate()["state"], "ACTIVE")
class TestDriftPersistsThroughRevalidation(N):
    def test_revalidating_while_the_drift_persists_stays_in_SCHEMA_DRIFT_with_fresh_evidence(self):
        self.w.activate_all(); self.sa.drift_rename_field("Account", "profile.name", "profile.full_name"); first = self.c.check_drift(); self.assertEqual(self.c.state(), "SCHEMA_DRIFT")
        st = self.c.activate(); self.assertEqual(st["state"], "SCHEMA_DRIFT"); self.assertIn("updateAccount", st["drift_evidence"]["technically_affected_operations"]); self.assertNotEqual(st["drift_evidence"]["drift_id"], first["drift_id"])
class TestMissingModuleDoesNotCrashTheRuntime(N):
    def test_notifications_and_errors_for_an_unregistered_module_are_dropped_safely(self):
        c = self.extra(self.w.pA, "ia-ghost", module="ghost-module"); self.assertEqual(c.activate()["state"], "ACTIVE"); self.sa.faults.push("read", *([("unavailable",)] * 10)); self.assertEqual(self.f.sync(self.a, "ia-ghost", "Account")["failed"], "UNAVAILABLE")
class TestRemainingBranches(unittest.TestCase):
    def test_scheduler_requeues_a_task_that_is_throttled_and_runs_it_later(self):
        c = FakeClock(); sch = FairScheduler(c, Throttle(c)); calls = []
        def task():
            calls.append(1)
            if len(calls) == 1: raise Throttled(1.0)
        sch.submit(("t", "i"), task); done = sch.run(passes=6); self.assertEqual((len(calls), done[("t", "i")]), (2, 1))
    def test_per_tenant_in_flight_limit_refuses_excess_concurrency_as_RATE_LIMITED(self):
        e = Env(); e.secrets.put("tenant-a", REFA, "client-secret-A"); codes = []
        class Nest(SyntheticRestConnector):
            def read(self, request):
                d = request.get("depth", 0)
                if d < 6: o = self.rt.call(e.A, "i", "t", "env", "read", {"entity": "Account", "depth": d + 1}); codes.append(o.error["code"] if o.error else "ok")
                return {"items": [], "next_cursor": None, "complete": True}
        con = Nest(SystemA(), REFA); rt = e.runtime(con); con.rt = rt; rt.call(e.A, "i", "t", "env", "read", {"entity": "Account"})
        self.assertIn("RATE_LIMITED", codes); self.assertEqual(rt.in_flight["tenant-a"], 0)
    def test_lookup_on_a_connector_without_reconciliation_support_reports_UNSUPPORTED(self):
        e = Env(); self.assertEqual(e.runtime(SyntheticDatabaseConnector(SystemB(), REFA)).lookup(e.A, "i", "k"), "UNSUPPORTED")
    def test_unsupported_transform_and_unknown_constraint_kinds_are_pack_errors_not_silent(self):
        with self.assertRaises(PackError): apply_transform({"kind": "SPLIT", "parameters": {}, "deterministic": True}, "x", "in")
        with self.assertRaises(PackError): check_constraint({"constraint_id": "c", "kind": "MYSTERY", "spec": {}}, "x")
    def test_outbound_enum_value_with_no_target_equivalent_is_a_violation_not_a_guess(self):
        from auif.canonical import CanonicalModel
        from auif.translation import PackRegistry, Translator
        reg = PackRegistry(); p = pack_a([fingerprint(SystemA().metadata())["value"]]); reg.register(p); tr = Translator(CanonicalModel(MODEL_DEF), reg, Ids(), FakeClock())
        with self.assertRaises(OutboundValidationError) as e: tr.translate_outbound({"id": p["pack_id"], "version": p["pack_version"], "hash": p["artifact_hash"]}, "Party", {"lifecycle_state": "ARCHIVED_BY_MISTAKE"})
        self.assertIn("lifecycle_state", str(e.exception))
    def test_ai_validator_rejects_malformed_canonical_ref_and_uncovered_enum_identity(self):
        rec = DiscoveryEngine(FakeClock(), Ids()).build_record(Env().A, "i", "t", "e", {"id": "c", "version": "1.0.0"}, SystemA().metadata()); from auif.canonical import CanonicalModel; v = MappingValidator(CanonicalModel(MODEL_DEF)); ID = {"kind": "IDENTITY", "parameters": {}, "deterministic": True}
        self.assertTrue(any("does not exist in the model" in p for p in v.check("Property.state", "NoDotRef", ID, [], rec)["problems"]))
        self.assertTrue(any("covering ENUM_MAP" in p for p in v.check("Property.state", "Property.status", ID, [], rec)["problems"]))
class TestActivationPreconditions(N):
    def reasons(self, st): return self.w.store.get(self.a, "integration_diagnostics", st["diagnostics_ref"]["evidence_id"])["reasons"]
    def test_discovery_that_did_not_obtain_the_required_kinds_cannot_activate(self):
        class NoOps(SystemA):
            def metadata(self): m = super().metadata(); del m["operations"]; return m
        s = NoOps(secret=self.sa.secret); c = self.f.add_integration(self.a, "ia-noops", anchor_module="synthetic-module-1", connector=SyntheticRestConnector(s, REFA), pack_ref=ref(self.w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", entities=["Account"])
        st = c.activate(); self.assertEqual(st["state"], "TRANSLATION_INVALID"); self.assertFalse(st["trust_basis"]["manifest_validated"]); self.assertTrue(any("coverage insufficient" in r and "OPERATION" in r for r in self.reasons(st)))
    def test_an_entity_the_pack_has_no_validated_mapping_for_cannot_activate(self):
        c = self.f.add_integration(self.a, "ia-ledger", anchor_module="synthetic-module-1", connector=SyntheticRestConnector(self.sa, REFA), pack_ref=ref(self.w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", entities=["Account", "Ledger"])
        st = c.activate(); self.assertEqual(st["state"], "TRANSLATION_INVALID"); self.assertTrue(any("no validated entity mapping" in r and "Ledger" in r for r in self.reasons(st)))

"""Tests that remove the cover behind three guards the first mutation run could not detect (M03, M20, M26). Each guard had a REDUNDANT defence that masked it; these tests isolate the guard itself.
(M03) the throttle also records Retry-After, so the runtime's own wait was invisible; (M20) the only drift test held a governed action on an AFFECTED operation; (M26) the canonical model catches a bad enum value downstream, hiding the transform's own rejection."""
import unittest
from tests.helpers import Env
from tests.acceptance_support import act
from tests.test_acceptance import W, A
from auif.errors import TranslationFailure
from auif.translation import apply_transform
from synthetic.connectors import SyntheticRestConnector
from synthetic.systems import SystemA
REF = "secretref:synthetic/credential"
class NullThrottle:
    """A throttle that remembers nothing: the connector runtime alone must honour Retry-After."""
    def acquire(self, key): pass
    def success(self, key): pass
    def failure(self, key, retryable=True, retry_after=None): pass
    def peek(self, key): return 0.0
class TestRetryAfterIsHonouredByTheRuntimeItself(unittest.TestCase):
    def test_AT_08_runtime_waits_at_least_retry_after_even_without_throttle_state(self):
        e = Env(); s = SystemA(); e.secrets.put("tenant-a", REF, "client-secret-A"); e.th = NullThrottle(); rt = e.runtime(SyntheticRestConnector(s, REF)); s.faults.push("read", ("429", 7.0)); t0 = e.clock.now
        o = rt.call(e.A, "i", "t", "env", "read", {"entity": "Account"}); self.assertEqual((o.result["outcome_kind"], o.attempts), ("DATA_OBTAINED", 2)); self.assertGreaterEqual(e.clock.now - t0, 7.0)
class TestGovernedOperationsStayBlockedDuringDrift(W):
    def test_governed_action_on_an_UNAFFECTED_operation_is_held_while_the_integration_is_in_drift(self):
        """AUIF position (draft): while a governed integration is in SCHEMA_DRIFT only NON-governed unaffected operations continue; a governed action waits for the Governor, whichever operation it targets."""
        self.sa.drift_rename_field("Account", "profile.name", "profile.full_name"); self.assertEqual(self.ctrl(A, "rest").check_drift()["unaffected_operations_continue"], ["listProperties", "updateProperty"])
        held = self.f.request_action(self.a, "synthetic-module-1", act(self.w, A, 1, {"city": "Newtown"}, cid="property:synthetic-system-a:1", atype="synthetic.update_property", ctype="Property", gov=True))
        self.assertEqual(held["execution_state"], "QUEUED"); self.assertEqual(self.sa.effects, []); self.assertEqual(self.w.gov.decisions, [])          # nothing was sent and no decision was even requested
class TestTransformRejectsUnmappedEnumValues(unittest.TestCase):
    TR = {"kind": "ENUM_MAP", "parameters": {"map": {"act": "ACTIVE", "sus": "INACTIVE"}}, "deterministic": True}
    def test_inbound_unmapped_value_is_rejected_by_the_transform_itself(self):
        self.assertEqual(apply_transform(self.TR, "act", "in"), "ACTIVE")
        with self.assertRaises(TranslationFailure): apply_transform(self.TR, "zzz", "in")
    def test_outbound_unmapped_value_is_rejected_by_the_transform_itself(self):
        self.assertEqual(apply_transform(self.TR, "INACTIVE", "out"), "sus")
        with self.assertRaises(TranslationFailure): apply_transform(self.TR, "ARCHIVED", "out")

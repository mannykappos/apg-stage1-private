import unittest
from auif.tenancy import TenantAuthority
from auif_ref.secrets import InMemorySecretStore
from port_contracts.other_contracts import *
from synthetic.governor_double import GovernorDouble
from synthetic.modules import module_one, module_two
from synthetic.policy import SyntheticPolicy
class TestSecretRef(SecretPortContract, unittest.TestCase):
    def make_secrets(self): s = InMemorySecretStore(); return s, s.put
class TestTenantRef(TenantAuthorityContract, unittest.TestCase):
    def make_authority(self): return TenantAuthority()
class TestGovernorDouble(GovernorPortContract, unittest.TestCase):
    def make_governor(self): return GovernorDouble()
class TestPolicyRef(PolicyPortContract, unittest.TestCase):
    def make_policy(self): return SyntheticPolicy()
class TestModuleOne(ModulePortContract, unittest.TestCase):
    def make_module(self): return module_one()
class TestModuleTwo(ModulePortContract, unittest.TestCase):
    def make_module(self): return module_two()

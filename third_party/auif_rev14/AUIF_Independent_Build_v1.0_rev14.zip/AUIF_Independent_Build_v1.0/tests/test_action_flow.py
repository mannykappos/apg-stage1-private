import copy, unittest
from tests.helpers import Env
from auif.action import ActionService, ACTION_TRANSITIONS, Ledger
from auif.canonical import CanonicalModel
from auif.classification import BoundaryEnforcer
from auif.contracts import validate
from auif.discovery import fingerprint
from auif.errors import *
from auif.observation import Sequencer, ObservationFactory
from auif.security import scan_for
from auif.translation import PackRegistry, Translator
from auif.util import Ids, sha
from synthetic.connectors import SyntheticRestConnector, SyntheticDatabaseConnector
from synthetic.governor_double import GovernorDouble
from synthetic.packs import *
from synthetic.policy import SyntheticPolicy
from synthetic.systems import SystemA, SystemB
REF = "secretref:synthetic/credential"
class Handle:
    def __init__(self, rt, pack_ref, integ, tgt, kind="customer-system", state="ACTIVE", allowed=None): self.runtime, self.pack_ref, self.integration_id, self.target_system_id, self.environment_id, self.destination_kind, self.state, self.allowed = rt, pack_ref, integ, tgt, "env-sandbox", kind, state, allowed
    def operation_allowed(self, op, governed): return self.state == "ACTIVE" if self.allowed is None else self.allowed(op, governed)
class Resolver:
    def __init__(self): self.h = {}
    def resolve(self, ctx, mref): return self.h[mref["id"]]
def mk_action(n, action_type="synthetic.update_party", attrs=None, cid="party:synthetic-system-a:3", governed=False, manifest="manifest-a", key=None, target="synthetic-system-a"):
    return {"contract_kind": "CanonicalAction", "action_id": "act-%04d" % n, "tenant_id": "tenant-a", "source_module": "synthetic-module-1", "target_system_id": target, "environment_id": "env-sandbox", "manifest_ref": {"id": manifest, "version": "1.0.0", "hash": "a" * 64}, "idempotency_key": key or "idem-key-%04d-abc" % n,
            "correlation_id": "corr-%04d" % n, "requested_at": "2026-10-02T03:00:00Z", "canonical_action": {"action_type": action_type, "payload": {"canonical_type": "Party", "canonical_id": cid, "attributes": attrs or {"display_name": "Renamed"}}},
            "governance": {"governance_required": governed, "governance_required_source": "MODULE_DECLARED", "governor_decision_ref": None}}
class ActBase(unittest.TestCase):
    def setUp(self):
        self.e = Env(); self.ids = Ids(); self.sysA = SystemA(); self.e.secrets.put("tenant-a", REF, "client-secret-A"); self.rt = self.e.runtime(SyntheticRestConnector(self.sysA, REF)); fp = fingerprint(self.sysA.metadata())["value"]; self.reg = PackRegistry(); pa = pack_a([fp]); self.reg.register(pa)
        self.model = CanonicalModel(MODEL_DEF); self.tr = Translator(self.model, self.reg, self.ids, self.e.clock); self.gov = GovernorDouble(); self.pol = SyntheticPolicy(); self.res = Resolver(); self.ref = {"id": pa["pack_id"], "version": "1.0.0", "hash": pa["artifact_hash"]}
        self.h = Handle(self.rt, self.ref, "int-a", "synthetic-system-a"); self.res.h["manifest-a"] = self.h
        self.svc = ActionService(self.e.store, self.e.clock, self.ids, self.e.tel, self.tr, BoundaryEnforcer(self.pol), self.gov, self.res); self.ctx = self.e.A
    def state(self, n): return self.svc.ledger.get(self.ctx, "act-%04d" % n)["execution_state"]
class TestSequencer(unittest.TestCase):
    def setUp(self): self.e = Env(); self.sq = Sequencer(self.e.store, self.e.clock, {"*": {"on_missing": "QUEUE", "wait_seconds": 30}}); self.c = self.e.A
    def ev(self, i, deps=(), seq=None, payload=None, t="ticket.updated"): return dict({"event_id": i, "type": t, "depends_on": list(deps), "payload": payload or {"v": i}}, **({"source_sequence": seq} if seq else {}))
    def states(self, ds): return [(d["event"]["event_id"], d["ordering_state"]) for d in ds]
    def test_AT_09_in_order_events_apply_immediately(self): self.assertEqual(self.states(self.sq.receive(self.c, "i", self.ev("e1"))), [("e1", "IN_ORDER")]); self.assertEqual(self.states(self.sq.receive(self.c, "i", self.ev("e2", ["e1"]))), [("e2", "IN_ORDER")])
    def test_AT_09_out_of_order_event_waits_then_releases_in_causal_order(self):
        self.assertEqual(self.states(self.sq.receive(self.c, "i", self.ev("e3", ["e2"]))), [("e3", "QUEUED_AWAITING_PREDECESSOR")]); self.assertEqual(self.states(self.sq.receive(self.c, "i", self.ev("e2", ["e1"]))), [("e2", "QUEUED_AWAITING_PREDECESSOR")])
        self.assertEqual(self.states(self.sq.receive(self.c, "i", self.ev("e1"))), [("e1", "IN_ORDER"), ("e2", "IN_ORDER"), ("e3", "IN_ORDER")]); self.assertEqual(self.sq.pending(self.c, "i"), [])
    def test_AT_09_timestamps_do_not_establish_order(self):
        late = self.ev("b", ["a"], payload={"observed_at": "2020-01-01T00:00:00Z"}); early = self.ev("a", payload={"observed_at": "2030-01-01T00:00:00Z"}); self.assertEqual(self.states(self.sq.receive(self.c, "i", late)), [("b", "QUEUED_AWAITING_PREDECESSOR")]); self.assertEqual([s for _, s in self.states(self.sq.receive(self.c, "i", early))], ["IN_ORDER", "IN_ORDER"])
    def test_source_sequence_gap_waits_for_the_missing_number(self):
        self.sq.receive(self.c, "i", self.ev("s1", seq=1)); self.assertEqual(self.states(self.sq.receive(self.c, "i", self.ev("s3", seq=3)))[0][1], "QUEUED_AWAITING_PREDECESSOR"); self.assertEqual([s for _, s in self.states(self.sq.receive(self.c, "i", self.ev("s2", seq=2)))], ["IN_ORDER", "IN_ORDER"])
    def test_AT_10_duplicate_is_suppressed_and_has_no_second_effect(self):
        self.sq.receive(self.c, "i", self.ev("d1")); self.assertEqual(self.states(self.sq.receive(self.c, "i", self.ev("d1")))[0][1], "DUPLICATE_SUPPRESSED"); self.assertEqual(len(self.e.store.list(self.c, "seq_applied:i")), 1)
    def test_duplicate_while_still_queued_is_suppressed(self): self.sq.receive(self.c, "i", self.ev("q", ["missing"])); self.assertEqual(self.states(self.sq.receive(self.c, "i", self.ev("q", ["missing"])))[0][1], "DUPLICATE_SUPPRESSED")
    def test_AT_10_same_id_different_content_is_a_conflict_not_silently_applied(self):
        self.sq.receive(self.c, "i", self.ev("x", payload={"v": 1})); d = self.sq.receive(self.c, "i", self.ev("x", payload={"v": 2}))[0]; self.assertEqual(d["ordering_state"], "RECONCILIATION_PENDING"); self.assertTrue(d["conflict"]); self.assertEqual(len(self.e.store.list(self.c, "seq_conflicts:i")), 1)
    def test_AT_09_bounded_wait_then_reconcile_and_no_fabricated_state(self):
        self.sq.receive(self.c, "i", self.ev("late", ["never-arrives"])); self.e.clock.sleep(10); self.assertEqual(self.sq.tick(self.c, "i"), []); self.e.clock.sleep(25); out = self.sq.tick(self.c, "i"); self.assertEqual(self.states(out), [("late", "RECONCILIATION_PENDING")])
        self.assertEqual(self.e.store.list(self.c, "seq_applied:i"), []); self.assertEqual(len(self.e.store.list(self.c, "seq_reconcile:i")), 1); self.assertEqual(self.sq.pending(self.c, "i"), [])
    def test_policy_variants_defer_reject_reconcile(self):
        for mode, want in (("DEFER", "DEFERRED"), ("REJECT", "REJECTED_BY_POLICY"), ("RECONCILE", "RECONCILIATION_PENDING")):
            sq = Sequencer(self.e.store, self.e.clock, {"*": {"on_missing": mode}}); self.assertEqual(sq.receive(self.c, "i-" + mode, self.ev("z", ["nope"]))[0]["ordering_state"], want)
    def test_AT_12_sequencer_state_is_tenant_isolated(self):
        self.sq.receive(self.c, "i", self.ev("e1")); self.assertEqual(self.sq.receive(self.e.B, "i", self.ev("e1"))[0]["ordering_state"], "IN_ORDER"); self.assertEqual(self.sq.receive(self.e.B, "i", self.ev("e2", ["e1"]))[0]["ordering_state"], "IN_ORDER")
class TestObservationEnvelope(ActBase):
    def test_envelope_is_contract_valid_with_monotonic_adapter_sequence(self):
        f = ObservationFactory(self.e.store, self.ids, self.e.clock); kw = dict(anchor_module="m", target_system_id="t", environment_id="e", connector_id="c", source_system="s", source_object={"object_type": "Account", "object_id": "1"}, source_version=None, pack_ref=self.ref, schema_fingerprint="a" * 64, payload={"x": 1}, classification="INTERNAL", confidence={"value": 1.0, "basis": "deterministic"}, provenance=[{"step_kind": "SOURCE_SYSTEM", "ref": "s"}])
        a, b = f.build(self.ctx, "i", **kw), f.build(self.ctx, "i", **kw); self.assertEqual((a["adapter_sequence"], b["adapter_sequence"]), (1, 2)); self.assertEqual(a["source_version"], "NOT_PROVIDED_BY_SOURCE")
class TestBoundary(ActBase):
    def enf(self, attrs, classes, kind): return BoundaryEnforcer(self.pol).enforce(self.ctx, attrs, classes, {"kind": kind}, {})
    def test_AT_21_same_data_different_destination_different_outcome(self):
        a = {"contact_email": "person@example.invalid"}; c = {"contact_email": "PII"}; self.assertEqual(self.enf(a, c, "customer-system")["decision"], "ALLOW"); r = self.enf(a, c, "third-party-analytics"); self.assertEqual(r["decision"], "TRANSFORMED"); self.assertEqual(r["payload"]["contact_email"], "*" * 20 + "id")
    def test_AT_21_reject_and_needs_authorisation_and_undeterminable(self):
        self.assertEqual(self.enf({"balance": "1.00"}, {"balance": "FINANCIAL"}, "third-party-analytics")["decision"], "REJECTED"); self.assertEqual(self.enf({"x": "1"}, {"x": "HEALTH"}, "customer-system")["decision"], "NEEDS_AUTHORISATION")
        r = self.enf({"x": "1"}, {"x": "PII"}, "unknown-destination"); self.assertEqual(r["decision"], "REJECTED"); self.assertIsNone(r["payload"]); self.assertEqual(r["evidence"][0]["outcome"], "UNDETERMINABLE")
    def test_one_rejected_attribute_rejects_the_whole_payload_with_no_partial_leak(self): r = self.enf({"a": "1", "b": "2"}, {"a": "INTERNAL", "b": "REGULATED"}, "customer-system"); self.assertEqual((r["decision"], r["payload"]), ("REJECTED", None))
    def test_transforms_pseudonymise_omit_redact(self):
        for t, chk in (("pseudonymise", lambda v: v.startswith("pseud:")), ("redact", lambda v: v == "[REDACTED]")): self.pol.rules[("PII", "x")] = {"outcome": "TRANSFORM", "transforms": [t]}; self.assertTrue(chk(self.enf({"e": "a@b.c"}, {"e": "PII"}, "x")["payload"]["e"]))
        self.pol.rules[("PII", "y")] = {"outcome": "TRANSFORM", "transforms": ["omit"]}; self.assertEqual(self.enf({"e": "a@b.c"}, {"e": "PII"}, "y")["payload"], {})
    def test_evidence_contains_no_values(self): r = self.enf({"e": "secret-value-123"}, {"e": "PII"}, "third-party-analytics"); self.assertEqual(scan_for(r["evidence"], ["secret-value-123"]), [])
class TestActionHappyPathAndIdempotency(ActBase):
    def test_AT_11_non_governed_action_completes_with_full_ledger(self):
        self.svc.submit(self.ctx, mk_action(1)); self.assertEqual(self.state(1), "QUEUED"); rec = self.svc.dispatch(self.ctx, "act-0001"); validate("action#ActionExecutionRecord", rec)
        self.assertEqual(rec["execution_state"], "COMPLETED"); self.assertEqual(rec["outbound_validation"]["validation_result"], "PASSED"); self.assertEqual(rec["attempt_count"], 1); self.assertEqual(self.sysA.rows["Account"]["3"]["profile"]["name"], "Renamed"); self.assertEqual(len(self.sysA.effects), 1)
    def test_AT_11_ledger_entry_exists_in_SENT_before_the_target_is_contacted(self):
        seen = []; orig = self.sysA.update
        def spy(*a, **k): seen.append(self.svc.ledger.get(self.ctx, "act-0001")["execution_state"]); return orig(*a, **k)
        self.sysA.update = spy; self.svc.submit(self.ctx, mk_action(1)); self.svc.dispatch(self.ctx, "act-0001"); self.assertEqual(seen, ["SENT"])
    def test_AT_11_duplicate_submission_is_a_single_action(self):
        a = self.svc.submit(self.ctx, mk_action(1)); b = self.svc.submit(self.ctx, mk_action(2, key="idem-key-0001-abc")); self.assertEqual(a["action_id"], b["action_id"]); self.svc.dispatch(self.ctx, "act-0001"); self.svc.dispatch(self.ctx, "act-0001"); self.assertEqual(len(self.sysA.effects), 1)
    def test_same_key_different_content_is_refused(self):
        self.svc.submit(self.ctx, mk_action(1)); with_other = mk_action(2, key="idem-key-0001-abc", attrs={"display_name": "Different"})
        with self.assertRaises(AuifError): self.svc.submit(self.ctx, with_other)
    def test_idempotency_is_per_tenant(self):
        self.svc.submit(self.ctx, mk_action(1)); other = mk_action(1); other["tenant_id"] = "tenant-b"; r = self.svc.submit(self.e.B, other); self.assertEqual(r["tenant_id"], "tenant-b")
    def test_AT_04_outbound_validation_failure_is_FAILED_before_any_send(self):
        self.svc.submit(self.ctx, mk_action(1, attrs={"display_name": "x" * 101})); rec = self.svc.dispatch(self.ctx, "act-0001"); self.assertEqual(rec["execution_state"], "FAILED"); self.assertEqual(rec["outbound_validation"]["validation_result"], "FAILED"); self.assertEqual(self.sysA.effects, []); self.assertNotIn("sent_at", rec)
    def test_invalid_contract_and_hostile_payload_rejected_at_submit(self):
        bad = mk_action(1); del bad["idempotency_key"]
        with self.assertRaises(ContractViolation): self.svc.submit(self.ctx, bad)
        h = mk_action(2); h["canonical_action"]["payload"]["attributes"] = {"__proto__": {"x": 1}}
        with self.assertRaises(UntrustedInput): self.svc.submit(self.ctx, h)
    def test_integration_not_active_means_not_sent(self):
        self.h.state = "SCHEMA_DRIFT"; self.svc.submit(self.ctx, mk_action(1))
        with self.assertRaises(GovernanceHold): self.svc.dispatch(self.ctx, "act-0001")
        self.assertEqual((self.state(1), self.sysA.effects), ("QUEUED", []))
class TestUnknownOutcomeAndReconciliation(ActBase):
    def test_AT_11_lost_response_becomes_UNKNOWN_OUTCOME_with_no_blind_retry(self):
        self.sysA.faults.push("write", ("timeout_after_apply",)); self.svc.submit(self.ctx, mk_action(1)); rec = self.svc.dispatch(self.ctx, "act-0001")
        self.assertEqual(rec["execution_state"], "UNKNOWN_OUTCOME"); self.assertFalse(rec["reconciliation"]["blind_retry_permitted"]); self.assertEqual(rec["reconciliation"]["strategy"], "QUERY_EXTERNAL_BY_IDEMPOTENCY_KEY"); self.assertEqual(len(self.sysA.effects), 1)
        again = self.svc.dispatch(self.ctx, "act-0001"); self.assertEqual(again["execution_state"], "UNKNOWN_OUTCOME"); self.assertEqual(len(self.sysA.effects), 1)             # dispatch is a no-op, never a resend
    def test_reconciliation_finds_the_applied_action_and_completes_without_resending(self):
        self.sysA.faults.push("write", ("timeout_after_apply",)); self.svc.submit(self.ctx, mk_action(1)); self.svc.dispatch(self.ctx, "act-0001"); rec = self.svc.reconcile(self.ctx, "act-0001")
        self.assertEqual(rec["execution_state"], "COMPLETED"); self.assertEqual(rec["result"]["outcome"], "APPLIED_CONFIRMED_BY_RECONCILIATION"); self.assertNotIn("error", rec); self.assertEqual(len(self.sysA.effects), 1)
    def test_reconciliation_not_found_fails_the_action_and_never_resends(self):
        self.sysA.faults.push("write", ("timeout_before",)); self.svc.submit(self.ctx, mk_action(1)); self.assertEqual(self.svc.dispatch(self.ctx, "act-0001")["execution_state"], "UNKNOWN_OUTCOME"); rec = self.svc.reconcile(self.ctx, "act-0001")
        self.assertEqual(rec["execution_state"], "FAILED"); self.assertIn("not applied", rec["error"]["message_redacted"]); self.assertEqual(self.sysA.effects, [])
    def test_non_reconcilable_connector_requires_operator_review(self):
        sb = SystemB(); self.e.secrets.put("tenant-a", REF, "db-password-B"); rt = self.e.runtime(SyntheticDatabaseConnector(sb, REF)); fp = fingerprint(sb.metadata())["value"]; pb = pack_b([fp]); self.reg.register(pb)
        self.res.h["manifest-b"] = Handle(rt, {"id": pb["pack_id"], "version": "1.0.0", "hash": pb["artifact_hash"]}, "int-b", "synthetic-system-b"); sb.faults.push("write", ("timeout_after_apply",))
        self.svc.submit(self.ctx, mk_action(1, cid="party:synthetic-system-b:2", manifest="manifest-b", target="synthetic-system-b")); rec = self.svc.dispatch(self.ctx, "act-0001"); self.assertEqual(rec["execution_state"], "UNKNOWN_OUTCOME"); self.assertEqual(rec["reconciliation"]["strategy"], "OPERATOR_REVIEW")
        rec = self.svc.reconcile(self.ctx, "act-0001"); self.assertEqual(rec["execution_state"], "RECONCILIATION_REQUIRED"); self.assertEqual(len(sb.effects), 1)
        done = self.svc.operator_resolve(self.ctx, "act-0001", True, {"evidence_id": "ticket-9", "evidence_hash": "b" * 64}); self.assertEqual(done["execution_state"], "COMPLETED")
    def test_definitive_rejection_is_FAILED_not_unknown(self):
        self.sysA.faults.push("write", ("reject",)); self.svc.submit(self.ctx, mk_action(1)); rec = self.svc.dispatch(self.ctx, "act-0001"); self.assertEqual((rec["execution_state"], rec["error"]["code"]), ("FAILED", "TARGET_REJECTED_REQUEST"))
    def test_retryable_not_applied_failure_retries_with_same_key_and_applies_once(self):
        self.sysA.faults.push("write", ("429", 1.0), ("unavailable",)); self.svc.submit(self.ctx, mk_action(1)); rec = self.svc.dispatch(self.ctx, "act-0001"); self.assertEqual((rec["execution_state"], rec["attempt_count"], len(self.sysA.effects)), ("COMPLETED", 3, 1))
class TestLedgerRules(ActBase):
    def test_every_forbidden_transition_is_refused(self):
        states = ["CREATED", "QUEUED", "SENT", "ACKNOWLEDGED", "UNKNOWN_OUTCOME", "RECONCILIATION_REQUIRED", "COMPLETED", "FAILED"]
        for a in states:
            for b in states:
                if (a, b) in ACTION_TRANSITIONS: continue
                with self.subTest(a=a, b=b):
                    rec = {"contract_kind": "ActionExecutionRecord", "action_id": "x", "tenant_id": "tenant-a", "source_module": "m", "target_system_id": "t", "environment_id": "e", "canonical_action_ref": {"evidence_id": "c", "evidence_hash": "0" * 64}, "payload_hash": "0" * 64, "idempotency_key": "k" * 12, "correlation_id": "c" * 8, "attempt_count": 0, "created_at": "2026-10-02T03:00:00Z", "execution_state": "CREATED", "governance": {"governance_required": False, "governance_required_source": "MODULE_DECLARED", "governor_decision_ref": None}}
                    self.e.store.put(self.ctx, "action_ledger", "x-%s-%s" % (a, b), dict(rec, action_id="x-%s-%s" % (a, b), execution_state=a)); 
                    with self.assertRaises((IllegalTransition, ContractViolation)): self.svc.ledger.transition(self.ctx, "x-%s-%s" % (a, b), b)
    def test_terminal_records_are_immutable(self):
        self.svc.submit(self.ctx, mk_action(1)); self.svc.dispatch(self.ctx, "act-0001")
        with self.assertRaises(IllegalTransition): self.svc.ledger.patch(self.ctx, "act-0001", attempt_count=9)
    def test_ledger_and_events_contain_no_payload_values(self):
        self.svc.submit(self.ctx, mk_action(1, attrs={"display_name": "SENTINEL-PERSON-NAME"})); self.svc.dispatch(self.ctx, "act-0001"); self.assertEqual(scan_for([self.svc.ledger.get(self.ctx, "act-0001"), self.svc.ledger.events(self.ctx, "act-0001"), self.e.tel.events], ["SENTINEL-PERSON-NAME", "client-secret-A"]), [])
    def test_AT_12_ledger_is_tenant_isolated(self):
        self.svc.submit(self.ctx, mk_action(1))
        with self.assertRaises(NotFound): self.svc.ledger.get(self.e.B, "act-0001")

"""Audit round 2 regression tests (independent re-audit of rev3).
F6: promotion evidence binds the COMPLETE security-relevant mapping, and the registry recognises AI promotion by its evidence, not only by the declared author.
F7: submission is a resumable write-ahead intent; a failure at ANY single write can never strand an action or an idempotency key."""
import copy, unittest
from auif.ai_boundary import AIMappingService
from auif.discovery import fingerprint
from auif.errors import AuifError, NotFound
from auif.translation import PackRegistry, claims_ai_promotion, pack_hash
from synthetic.ai_stub import ScriptedProposer
from synthetic.packs import pack_a
from synthetic.world import World
from tests.acceptance_support import act
from tests.test_audit_round1 import Base, T, cand, NAME, STATUS, EV, GOOD
A, B = "tenant-a", "tenant-b"
# ------------------------------------------------------------------------------------------------------------------------------- F6
def mutations():
    return [("mapping_id", lambda m: m.update(mapping_id="ai-other")), ("kind -> ENTITY", lambda m: m.update(kind="ENTITY")), ("kind -> ACTION", lambda m: m.update(kind="ACTION")), ("source_ref", lambda m: m.update(source_ref="Account.profile.email")), ("canonical_ref", lambda m: m.update(canonical_ref="Party.contact_email")),
            ("mapping_state -> TRUSTED", lambda m: m.update(mapping_state="TRUSTED")), ("mapping_state -> CANDIDATE", lambda m: m.update(mapping_state="CANDIDATE")), ("mapping_state -> REJECTED", lambda m: m.update(mapping_state="REJECTED")),
            ("proposed_by -> HUMAN", lambda m: m.update(proposed_by="HUMAN")), ("proposed_by -> DETERMINISTIC_TOOL", lambda m: m.update(proposed_by="DETERMINISTIC_TOOL")), ("deterministic_validation_performed -> False", lambda m: m.update(deterministic_validation_performed=False)),
            ("deterministic_validation_performed removed", lambda m: m.pop("deterministic_validation_performed")), ("inbound.source_type", lambda m: m["inbound"].update(source_type="integer")), ("inbound.canonical_type", lambda m: m["inbound"].update(canonical_type="ENUM")),
            ("inbound transform parameter", lambda m: m["inbound"]["transform"]["parameters"].update(op="lower")), ("inbound transform kind", lambda m: m["inbound"]["transform"].update(kind="RENAME")), ("inbound removed", lambda m: m.pop("inbound")),
            ("outbound enabled", lambda m: m.update(outbound={"supported": True, "transform": T("IDENTITY")})), ("outbound reason", lambda m: m["outbound"].update(reason="changed")), ("outbound removed", lambda m: m.pop("outbound")),
            ("unknown field added", lambda m: m.update(extra="x")), ("ambiguity added", lambda m: m.update(ambiguity={"candidate_meanings": ["a", "b"], "resolution_required": True})),
            ("validation_ref.evidence_id", lambda m: m["validation_ref"].update(evidence_id="val-ai-forged")), ("validation_ref.evidence_hash", lambda m: m["validation_ref"].update(evidence_hash="0" * 64)), ("validation_ref.kind", lambda m: m["validation_ref"].update(kind="mapping-validation")),
            ("validation_ref.kind removed", lambda m: m["validation_ref"].pop("kind")), ("validation_ref extra field", lambda m: m["validation_ref"].update(x=1)), ("validation_ref removed", lambda m: m.pop("validation_ref")), ("validation_ref None", lambda m: m.update(validation_ref=None)), ("validation_ref a string", lambda m: m.update(validation_ref="x"))]
class TestF6_PromotionEvidenceBindsTheWholeMapping(Base):
    def promoted(self, mid="ai-p"): return self.svc.promote(cand(NAME, T("FORMAT", op="upper"), mid=mid), self.rec)
    def pack(self, mapping, ver):
        p = pack_a([fingerprint(self.w.sys[A]["A"].metadata())["value"]]); p["pack_version"] = ver; p["mappings"].append(mapping); p["artifact_hash"] = pack_hash(p); return p
    def test_the_untouched_promoted_mapping_verifies_and_key_order_is_irrelevant(self):
        m = self.promoted(); self.assertTrue(self.svc.verify_promotion(m)); self.assertTrue(self.svc.verify_promotion(dict(reversed(list(m.items())))))
    def test_mutating_any_security_relevant_field_after_promotion_makes_verification_fail(self):
        base = self.promoted()
        for label, mut in mutations():
            with self.subTest(label): t = copy.deepcopy(base); mut(t); self.assertFalse(self.svc.verify_promotion(t), label)
    def test_the_same_holds_for_a_mapping_promoted_after_ambiguity_resolution(self):
        self.svc.proposer = ScriptedProposer([dict(GOOD, alternatives=["Party.contact_email"])]); amb = self.svc.propose(self.rec)["candidates"][0]; base = self.svc.promote(self.svc.resolve_ambiguity(amb, NAME[1], EV), self.rec); self.assertTrue(self.svc.verify_promotion(base))
        for label, mut in mutations():
            if label in ("canonical_ref", "ambiguity added"): pass
            with self.subTest(label): t = copy.deepcopy(base); mut(t); self.assertFalse(self.svc.verify_promotion(t), label)
    def test_verification_never_crashes_on_malformed_input(self):
        for bad in (None, "x", 5, [], {}, {"validation_ref": 5}, {"validation_ref": {}}, {"validation_ref": {"evidence_id": ["x"]}}, {"validation_ref": {"evidence_id": "val-ai-x", "evidence_hash": "a" * 64}}):
            with self.subTest(str(bad)[:40]): self.assertFalse(self.svc.verify_promotion(bad))
    def test_ai_evidence_is_marked_so_it_is_recognisable_whatever_the_mapping_claims(self):
        m = self.promoted(); self.assertEqual(m["validation_ref"]["kind"], "ai-mapping-validation"); self.assertTrue(m["validation_ref"]["evidence_id"].startswith("val-ai-")); self.assertTrue(claims_ai_promotion(m)); self.assertTrue(self.svc.has_issued(m))
        for pk in (self.w.pA, self.w.pB, self.w.pC):                                                            # ordinary human/tool mappings are not mistaken for AI promotions
            self.assertFalse(any(claims_ai_promotion(x) for x in pk["mappings"]))
    def test_relabelling_the_author_cannot_bypass_the_ai_verification_requirement(self):
        reg = PackRegistry(**self.svc.registry_hooks()); m = self.promoted(); reg.register(self.pack(m, "8.0.0"))                       # control: the untouched AI mapping is accepted
        for label, mut in (("proposed_by -> HUMAN", lambda t: t.update(proposed_by="HUMAN")), ("proposed_by -> DETERMINISTIC_TOOL", lambda t: t.update(proposed_by="DETERMINISTIC_TOOL"))):
            with self.subTest(label):
                t = copy.deepcopy(m); mut(t)
                with self.assertRaises(AuifError) as e: PackRegistry(**self.svc.registry_hooks()).register(self.pack(t, "8.1.0"))
                self.assertIn("provenance mismatch", str(e.exception))
    def test_an_ai_promoted_mapping_cannot_be_raised_to_TRUSTED(self):
        t = copy.deepcopy(self.promoted()); t["mapping_state"] = "TRUSTED"
        with self.assertRaises(AuifError): PackRegistry(**self.svc.registry_hooks()).register(self.pack(t, "8.2.0"))
    def test_stripping_the_ai_marker_from_the_reference_is_still_caught_by_the_issuing_service(self):
        t = copy.deepcopy(self.promoted()); t["proposed_by"] = "HUMAN"; t["validation_ref"] = {"evidence_id": "val-human-1", "evidence_hash": t["validation_ref"]["evidence_hash"]}; self.assertFalse(claims_ai_promotion(t))
        with self.assertRaises(AuifError) as e: PackRegistry(**self.svc.registry_hooks()).register(self.pack(t, "8.3.0"))
        self.assertIn("provenance mismatch", str(e.exception))
    def test_after_a_restart_the_marked_evidence_is_still_recognised_and_nothing_AI_promoted_is_accepted_unverified(self):
        m = self.promoted(); fresh = AIMappingService(ScriptedProposer([]), self.w.model, self.w.ids)                              # a new process: the in-memory ledger is gone (known limitation 18)
        t = copy.deepcopy(m); t["proposed_by"] = "HUMAN"
        with self.assertRaises(AuifError) as e: PackRegistry(**fresh.registry_hooks()).register(self.pack(t, "8.4.0"))
        self.assertIn("provenance mismatch", str(e.exception))                                                                     # recognised by the marker alone
        with self.assertRaises(AuifError): PackRegistry(**fresh.registry_hooks()).register(self.pack(m, "8.5.0"))                    # fails closed: cannot be verified, so not accepted
    def test_each_ai_marker_independently_identifies_ai_evidence_without_any_ledger(self):
        m = self.promoted(); fresh = AIMappingService(ScriptedProposer([]), self.w.model, self.w.ids)
        for label, ref in (("kind intact, id replaced", {"evidence_id": "val-human-1", "evidence_hash": "e" * 64, "kind": "ai-mapping-validation"}), ("id prefix intact, kind replaced", {"evidence_id": m["validation_ref"]["evidence_id"], "evidence_hash": "e" * 64, "kind": "mapping-validation"}), ("id prefix intact, kind removed", {"evidence_id": m["validation_ref"]["evidence_id"], "evidence_hash": "e" * 64})):
            with self.subTest(label):
                t = copy.deepcopy(m); t["proposed_by"] = "HUMAN"; t["validation_ref"] = ref; self.assertTrue(claims_ai_promotion(t))
                with self.assertRaises(AuifError) as e: PackRegistry(**fresh.registry_hooks()).register(self.pack(t, "8.8.%d" % len(label)))
                self.assertIn("provenance mismatch", str(e.exception))
    def test_KNOWN_LIMITATION_23_a_fully_forged_human_claim_after_a_restart_is_not_detectable_by_AUIF(self):
        """Pins the residual gap so it cannot be forgotten: a mapping whose author AND evidence reference were both rewritten to look human-validated, presented to a process that never saw the AI promotion, is indistinguishable from a genuine human-validated mapping.
        AUIF has no verifier for human/tool validation claims and packs are hash-addressed, not signed (an Amir/owner dependency: pack signing or an attested human-review record)."""
        m = self.promoted(); t = copy.deepcopy(m); t["proposed_by"] = "HUMAN"; t["validation_ref"] = {"evidence_id": "val-human-1", "evidence_hash": "e" * 64, "kind": "mapping-validation"}; fresh = AIMappingService(ScriptedProposer([]), self.w.model, self.w.ids)
        PackRegistry(**fresh.registry_hooks()).register(self.pack(t, "8.6.0"))
    def test_ordinary_human_and_tool_packs_are_unaffected(self):
        reg = PackRegistry(**self.svc.registry_hooks())
        for p in (self.w.pA, self.w.pB, self.w.pC, self.w.pA2, self.w.pAamb): reg.register(p)
    def test_a_human_mapping_that_carries_ai_evidence_is_refused(self):
        t = copy.deepcopy(self.w.pA["mappings"][1]); t["validation_ref"] = dict(t["validation_ref"], evidence_id="val-ai-claimed", kind="ai-mapping-validation"); self.assertEqual(t["mapping_state"], "VALIDATED")
        with self.assertRaises(AuifError): PackRegistry(**self.svc.registry_hooks()).register(self.pack(t, "8.7.0"))
# ------------------------------------------------------------------------------------------------------------------------------- F7
class Boom(Exception): pass
class Fault:
    """Counts every store write (put/update) from now on. Raises Boom at the Nth, or runs a hook just BEFORE the Nth (to interleave a duplicate submission at an exact point)."""
    def __init__(self, store):
        self.store, self.n, self.fail_at, self.hook_at, self.hook, self.on, self.log = store, 0, None, None, None, True, []; self.op, self.ou = store.put, store.update; store.put, store.update = self._put, self._upd
    def _tick(self, kind, coll):
        if not self.on: return
        self.n += 1; self.log.append("%s:%s" % (kind, coll))
        if self.n == self.fail_at: raise Boom("injected persistence failure at write #%d (%s:%s)" % (self.n, kind, coll))
        if self.n == self.hook_at and self.hook:
            self.on = False
            try: self.hook()
            finally: self.on = True
    def _put(self, c, coll, key, val, **kw): self._tick("put", coll); return self.op(c, coll, key, val, **kw)
    def _upd(self, c, coll, key, fn): self._tick("update", coll); return self.ou(c, coll, key, fn)
    def arm(self, fail_at=None, hook_at=None, hook=None): self.n, self.fail_at, self.hook_at, self.hook, self.log = 0, fail_at, hook_at, hook, []
class F7(unittest.TestCase):
    def setUp(self): self.fresh()
    def fresh(self):
        self.w = World(); self.w.activate_all(); self.ctx = self.w.ctx[A]; self.svc = self.w.fabric.actions; self.sa = self.w.sys[A]["A"]; self.f = Fault(self.w.store)
    def action(self, n=1, tenant=A, **kw): return act(self.w, tenant, n, {"display_name": "Zed"}, **kw)
    def idem(self, a, ctx=None): return self.w.store.get(ctx or self.ctx, "action_idem", a["idempotency_key"])
    def ids(self): return [k for k, _ in self.w.store.list(self.ctx, "action_ledger")]
    def writes(self):
        self.fresh(); self.f.arm(); self.svc.submit(self.ctx, self.action()); return list(self.f.log)
    def assert_healthy(self, a, dispatch=True):
        """One action, committed reservation without a lingering intent, payload and manifest ref present, queued, and (optionally) sent exactly once."""
        self.assertEqual(self.ids(), [a["action_id"]]); i = self.idem(a); self.assertEqual(i["state"], "COMMITTED"); self.assertNotIn("intent", i)
        self.assertIsNotNone(self.w.store.get(self.ctx, "action_payloads", "canon:" + a["action_id"])); self.assertIsNotNone(self.w.store.get(self.ctx, "action_manifest_ref", a["action_id"])); self.assertIn(self.w.store.get(self.ctx, "action_ledger", a["action_id"])["execution_state"], ("QUEUED", "COMPLETED"))
        if dispatch:
            self.f.arm(); self.assertEqual(self.svc.dispatch(self.ctx, a["action_id"])["execution_state"], "COMPLETED"); self.assertEqual(len(self.sa.effects), 1); self.svc.dispatch(self.ctx, a["action_id"]); self.assertEqual(len(self.sa.effects), 1)
class TestF7_ResumableSubmission(F7):
    def test_normal_submission_commits_and_leaves_no_pending_state(self):
        a = self.action(); self.f.arm(); r = self.svc.submit(self.ctx, a); self.assertEqual(r["execution_state"], "QUEUED"); self.assert_healthy(a); self.assertEqual(self.svc.recover_pending(self.ctx), {"completed": [], "unrecoverable": []})
    def test_the_clean_submission_has_the_documented_write_sequence(self):
        self.assertEqual(self.writes(), ["put:action_idem", "put:action_payloads", "put:action_ledger", "put:action_manifest_ref", "update:action_ledger", "update:action_idem"])
    def test_a_reservation_is_one_atomic_record_that_already_holds_everything_needed_to_finish(self):
        a = self.action(); self.f.arm(fail_at=2)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
        i = self.idem(a); self.assertEqual(i["state"], "RESERVED"); self.assertEqual(i["intent"]["action"], a); self.assertEqual(self.ids(), []); self.assertIsNone(self.w.store.get(self.ctx, "action_payloads", "canon:" + a["action_id"]))
    def test_a_failure_at_every_single_write_is_recovered_by_a_retry(self):
        for k in range(1, len(self.writes()) + 1):
            with self.subTest("fail write #%d" % k):
                self.fresh(); a = self.action(); self.f.arm(fail_at=k)
                with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
                self.f.arm(); r = self.svc.submit(self.ctx, a); self.assertEqual(r["execution_state"], "QUEUED", "was: NotFound, or a silent stall in CREATED"); self.assert_healthy(a)
    def test_a_failure_at_every_single_write_is_recovered_by_the_sweep_without_any_retry(self):
        for k in range(1, len(self.writes()) + 1):
            with self.subTest("fail write #%d" % k):
                self.fresh(); a = self.action(); self.f.arm(fail_at=k)
                with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
                self.f.arm(); out = self.svc.recover_pending(self.ctx); self.assertEqual(out["unrecoverable"], [])
                if k == 1: self.assertEqual((out["completed"], self.ids(), self.idem(a)), ([], [], None)); self.svc.submit(self.ctx, a)          # nothing was reserved: a normal submission simply works
                else: self.assertEqual(out["completed"], [a["action_id"]])
                self.assert_healthy(a); self.assertEqual(self.svc.recover_pending(self.ctx)["completed"], [])                                       # idempotent
    def test_repeated_failures_during_recovery_never_wedge_the_action(self):
        n = len(self.writes())
        for k in range(1, n + 1):
            for j in range(1, n + 1):
                with self.subTest("first attempt fails at #%d, recovery fails at #%d" % (k, j)):
                    self.fresh(); a = self.action(); self.f.arm(fail_at=k)
                    with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
                    self.f.arm(fail_at=j)
                    try: self.svc.submit(self.ctx, a)
                    except Boom: pass
                    self.f.arm(); self.svc.submit(self.ctx, a); self.assert_healthy(a)
    def test_a_duplicate_submission_interleaved_at_every_write_yields_exactly_one_action(self):
        for k in range(1, len(self.writes()) + 1):
            with self.subTest("duplicate arrives just before write #%d" % k):
                self.fresh(); a = self.action(); a["governance"].update(governor_decision_ref="forged-decision-1", governor_decision_hash="a" * 64); seen = []; self.f.arm(hook_at=k, hook=lambda: seen.append(self.svc.submit(self.ctx, a)))
                r = self.svc.submit(self.ctx, a); self.assertEqual(len(seen), 1); self.assertEqual({r["action_id"], seen[0]["action_id"]}, {a["action_id"]}); self.assert_healthy(a)
                kinds = [e["kind"] for e in self.svc.ledger.events(self.ctx, a["action_id"])]; self.assertEqual(kinds.count("IGNORED_SUPPLIED_DECISION_REF"), 1); self.assertLessEqual(kinds.count("SUBMISSION_RECOVERED"), 1)
    def test_a_retry_with_a_new_action_id_after_a_crash_completes_the_ORIGINAL_action_not_a_second_one(self):
        a1 = self.action(1); a2 = copy.deepcopy(a1); a2["action_id"] = "act-0002"; self.f.arm(fail_at=2)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, a1)
        self.f.arm(); r = self.svc.submit(self.ctx, a2); self.assertEqual(r["action_id"], "act-0001"); self.assertEqual(r["execution_state"], "QUEUED"); self.assert_healthy(a1); self.assertIsNone(self.w.store.get(self.ctx, "action_ledger", "act-0002")); self.assertIsNone(self.w.store.get(self.ctx, "action_payloads", "canon:act-0002"))
    def test_a_reused_key_with_different_content_is_refused_while_reserved_and_after_commit_and_never_disturbs_the_original(self):
        for stage in ("reserved", "committed"):
            with self.subTest(stage):
                self.fresh(); a = self.action()
                if stage == "reserved":
                    self.f.arm(fail_at=3)
                    with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
                else: self.svc.submit(self.ctx, a)
                other = copy.deepcopy(a); other["canonical_action"]["payload"]["attributes"] = {"display_name": "SOMEONE ELSE"}; self.f.arm()
                with self.assertRaises(AuifError) as e: self.svc.submit(self.ctx, other)
                self.assertIn("different content", str(e.exception)); self.svc.submit(self.ctx, a); self.assert_healthy(a)
                self.assertEqual(self.w.store.get(self.ctx, "action_payloads", "canon:act-0001")["payload"]["payload"]["attributes"], {"display_name": "Zed"})
    def test_a_terminal_duplicate_returns_the_terminal_record_and_sends_nothing_more(self):
        a = self.action(); self.svc.submit(self.ctx, a); done = self.svc.dispatch(self.ctx, a["action_id"]); self.assertEqual((done["execution_state"], len(self.sa.effects)), ("COMPLETED", 1))
        r = self.svc.submit(self.ctx, a); self.assertEqual((r["execution_state"], r["attempt_count"], len(self.sa.effects), self.ids()), ("COMPLETED", done["attempt_count"], 1, ["act-0001"]))
        b = copy.deepcopy(a); b["action_id"] = "act-0002"; r = self.svc.submit(self.ctx, b); self.assertEqual((r["action_id"], r["execution_state"], len(self.sa.effects)), ("act-0001", "COMPLETED", 1))
    def test_recovery_is_recorded_as_evidence_once_and_only_when_it_happened(self):
        a = self.action(); self.svc.submit(self.ctx, a); self.assertNotIn("SUBMISSION_RECOVERED", [e["kind"] for e in self.svc.ledger.events(self.ctx, a["action_id"])])
        self.fresh(); a = self.action(); self.f.arm(fail_at=4)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
        self.f.arm(); self.svc.submit(self.ctx, a); self.svc.submit(self.ctx, a); self.svc.recover_pending(self.ctx); self.assertEqual([e["kind"] for e in self.svc.ledger.events(self.ctx, a["action_id"])].count("SUBMISSION_RECOVERED"), 1)
    def test_recovery_after_the_action_was_already_dispatched_never_regresses_it(self):
        a = self.action(); self.f.arm(fail_at=6)                                                                                  # everything except the final COMMIT is durable: the action is already QUEUED and visible to a dispatcher
        with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
        self.f.arm(); self.assertEqual(self.idem(a)["state"], "RESERVED"); self.assertEqual(self.svc.dispatch(self.ctx, a["action_id"])["execution_state"], "COMPLETED")
        r = self.svc.submit(self.ctx, a); self.assertEqual(r["execution_state"], "COMPLETED"); self.assertEqual(self.svc.recover_pending(self.ctx), {"completed": [], "unrecoverable": []}); self.assertEqual(self.idem(a)["state"], "COMMITTED"); self.assertEqual(len(self.sa.effects), 1)
    def test_recover_pending_also_completes_without_regressing_a_dispatched_action(self):
        a = self.action(); self.f.arm(fail_at=6)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
        self.f.arm(); self.svc.dispatch(self.ctx, a["action_id"]); self.assertEqual(self.svc.recover_pending(self.ctx)["completed"], [a["action_id"]]); self.assertEqual(self.w.store.get(self.ctx, "action_ledger", a["action_id"])["execution_state"], "COMPLETED"); self.assertEqual(len(self.sa.effects), 1)
    def test_created_at_is_the_reservation_time_so_recovery_does_not_rewrite_history(self):
        a = self.action(); self.f.arm(fail_at=3)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
        reserved = self.idem(a)["reserved_at"]; self.w.clock.advance(500); self.f.arm(); self.assertNotEqual(reserved, self.w.clock.iso()); self.assertEqual(self.svc.submit(self.ctx, a)["created_at"], reserved)
    def test_the_sweep_is_tenant_scoped(self):
        a, b = self.action(1), self.action(2, tenant=B); cb = self.w.ctx[B]
        for x, c in ((a, self.ctx), (b, cb)):
            self.f.arm(fail_at=2)
            with self.assertRaises(Boom): self.svc.submit(c, x)
        self.f.arm(); self.assertEqual(self.svc.recover_pending(self.ctx)["completed"], ["act-0001"]); self.assertEqual(self.idem(b, cb)["state"], "RESERVED"); self.assertEqual(self.svc.recover_pending(cb)["completed"], ["act-0002"]); self.assertEqual(self.idem(b, cb)["state"], "COMMITTED")
class TestF7_IntegrityFailuresAreLoudNotSilent(F7):
    def test_a_committed_reservation_whose_action_is_missing_is_an_integrity_failure_not_NotFound(self):
        a = self.action(); h = __import__("auif.util", fromlist=["sha"]).sha(a["canonical_action"]); self.w.store.put(self.ctx, "action_idem", a["idempotency_key"], {"action_id": a["action_id"], "content_hash": h, "state": "COMMITTED", "reserved_at": "2026-10-02T00:00:00Z"})
        with self.assertRaises(AuifError) as e: self.svc.submit(self.ctx, a)
        self.assertNotIsInstance(e.exception, NotFound); self.assertIn("integrity failure", str(e.exception)); self.assertEqual(self.ids(), [])                       # and nothing is silently re-created
    def test_a_reservation_without_a_usable_intent_is_refused_and_the_sweep_reports_it_but_still_completes_the_others(self):
        bad, good = self.action(1), self.action(2, key="idem-good-2"); h = __import__("auif.util", fromlist=["sha"]).sha(bad["canonical_action"])
        self.w.store.put(self.ctx, "action_idem", bad["idempotency_key"], {"action_id": bad["action_id"], "content_hash": h, "state": "RESERVED", "reserved_at": "2026-10-02T00:00:00Z"})
        with self.assertRaises(AuifError) as e: self.svc.submit(self.ctx, bad)
        self.assertIn("integrity failure", str(e.exception)); self.f.arm(fail_at=2)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, good)
        self.f.arm(); out = self.svc.recover_pending(self.ctx); self.assertEqual(out["completed"], ["act-0002"]); self.assertEqual([u["action_id"] for u in out["unrecoverable"]], ["act-0001"]); self.assertEqual(self.ids(), ["act-0002"])
    def test_a_tampered_intent_is_never_executed(self):
        a = self.action(); self.f.arm(fail_at=2)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
        def evil(old): n = copy.deepcopy(old); n["intent"]["action"]["canonical_action"]["payload"]["attributes"] = {"display_name": "EVIL"}; return n
        self.w.store.update(self.ctx, "action_idem", a["idempotency_key"], evil); self.f.arm()
        with self.assertRaises(AuifError) as e: self.svc.submit(self.ctx, a)
        self.assertIn("integrity failure", str(e.exception)); self.assertEqual(self.ids(), []); self.assertEqual(self.svc.recover_pending(self.ctx)["completed"], []); self.assertEqual(len(self.sa.effects), 0)
    def test_an_intent_for_a_different_action_id_is_refused(self):
        a = self.action(); self.f.arm(fail_at=2)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, a)
        def swap(old): n = copy.deepcopy(old); n["action_id"] = "act-9999"; return n
        self.w.store.update(self.ctx, "action_idem", a["idempotency_key"], swap); self.f.arm()
        with self.assertRaises(AuifError): self.svc.submit(self.ctx, a)
if __name__ == "__main__": unittest.main()

"""rev14: the six defects found in AUIF rev13 while building APG-M8 (findings M8-F1 to M8-F6), each fixed and each pinned here.  Every test here fails on rev13 except four regression guards (the existing core packs still register; outbound takes only the requested concept's fields, in two tests; an applied event is not reported as not applied).
  M8-F1  a field reference is <concept>.<attribute> with the attribute after the LAST dot, so a MODULE concept (whose name has dots) translates, inbound, outbound and in the AI validator;
         a malformed reference in a validated mapping is refused when the pack is registered
  M8-F2  a source identity may be several fields; a content-hash identity only when declared (IDENTITY_CONTENT_HASH); a missing identity is a per-record error, never a silent hash
  M8-F3  the module is told about every event that was not applied to it (waiting, deferred, sent to reconciliation, rejected, or with no entity mapping)
  M8-F4  a module that fails to take a delivery is counted, recorded and told; the delivery is not reported as made
  M8-F5  the sync report says whether the read reached the end, or stopped at the page limit
  M8-F6  sync reports instead of raising: drift before the first validation, a blank identity, a record the observation contract refuses"""
import unittest
from auif.ai_boundary import MappingValidator
from auif.canonical import CanonicalModel, split_ref
from auif.discovery import fingerprint
from auif.errors import OutboundValidationError, PackError
from auif.fabric import IDENTITY_CONTENT_HASH, source_identity
from auif.translation import PackRegistry, Translator, pack_hash
from auif.util import Ids
from auif.clock import FakeClock
from synthetic.modules import RecordingModule
from synthetic.packs import ID, MODEL_DEF, build, cons, emap, fmap, pack_a, pack_b
from synthetic.systems import SystemA, SystemC
from synthetic.world import World, ref
A = "tenant-a"
LISTING = "module.synthetic-module-2.Listing"
POL = {"default_outcome": "UNMAPPED", "optional_and_unused": [], "ignored_by_rule": [{"field_pattern": "^(id|state)$", "rule_id": "r", "justification": "not carried", "material": False}]}
def listing_pack(canon_field=LISTING + ".headline", entity_concept=LISTING, writable=True):
    fp = fingerprint(SystemC().metadata())["value"]
    return build("rev14-listing-pack", "1.0.0", "synthetic-event-source", [fp], [emap("l-ent", "ENTITY", "Ticket", entity_concept, "Ticket", writable=writable), fmap("l-headline", "Ticket.title", canon_field, ID, ID if writable else None, [cons("c-headline-len", "LENGTH", max=200)] if writable else None)], [], POL), fp
def errors(w, module="m1", kind=None): return [e for e in getattr(w, module).by_tenant.get(A, {}).get("errors", []) if kind is None or e["kind"] == kind]


class TestF1FieldReferences(unittest.TestCase):
    def test_split_ref_takes_the_attribute_after_the_last_dot(self):
        self.assertEqual(split_ref("Party.display_name"), ("Party", "display_name"))
        self.assertEqual(split_ref(LISTING + ".headline"), (LISTING, "headline"))
        self.assertEqual(split_ref("display_name"), ("", "display_name"))
    def test_a_field_maps_into_a_module_concept_inbound_and_outbound(self):
        p, fp = listing_pack(); reg = PackRegistry(); reg.register(p); model = CanonicalModel(MODEL_DEF); t = Translator(model, reg, Ids(), FakeClock())
        o = t.translate_inbound(World().ctx[A], ref(p), "Ticket", {"id": "7", "title": "Bright flat", "state": "open"}, source_system="s", observation_id="obs-1", schema_fingerprint=fp, source_id="7")
        self.assertEqual((o["validation_state"], o["canonical_type"], o["attributes"]), ("VALID", LISTING, {"headline": "Bright flat"}))
        out = t.translate_outbound(ref(p), LISTING, {"headline": "New"})
        self.assertEqual(out, ({"entity": "Ticket", "fields": {"title": "New"}}, {"constraints_checked": 1, "violations": 0}))
    def test_the_ai_validator_accepts_a_module_attribute_and_still_refuses_an_unknown_one(self):
        v = MappingValidator(CanonicalModel(MODEL_DEF)); rec = {"elements": [{"element_kind": "FIELD", "name": "Ticket.title", "detail": {"type": "string"}}]}
        self.assertTrue(v.check("Ticket.title", LISTING + ".headline", ID, [], rec)["passed"])
        self.assertFalse(v.check("Ticket.title", LISTING + ".nope", ID, [], rec)["passed"])
    def test_a_malformed_validated_field_reference_is_refused_at_pack_registration(self):
        for bad in ("Party.display_name",                     # another concept than the entity's
                    LISTING + ".Headline",                     # not an attribute name
                    "headline",                                # no concept at all
                    "module.synthetic-module-2.headline"):     # the old <first dot> reading of the contract form
            p, _ = listing_pack(bad)
            with self.assertRaises(PackError, msg=bad): PackRegistry().register(p)
    def test_translation_still_refuses_a_field_into_another_concept_if_a_pack_ever_bypassed_registration(self):
        """Defence in depth behind the registration check: a registry that hands out an unchecked pack still cannot put a field into another concept."""
        p, fp = listing_pack(); p["mappings"][1]["canonical_ref"] = "Party.display_name"
        class Unchecked:
            def get(self, *a): return p
        o = Translator(CanonicalModel(MODEL_DEF), Unchecked(), Ids(), FakeClock()).translate_inbound(World().ctx[A], ref(p), "Ticket", {"id": "7", "title": "x", "state": "open"}, source_system="s", observation_id="obs-1", schema_fingerprint=fp, source_id="7")
        self.assertEqual(o["validation_state"], "TRANSLATION_INVALID"); self.assertIn("title maps into Party, not " + LISTING, repr(o["diagnostics"]))
    def test_outbound_takes_only_the_fields_of_the_requested_concept(self):
        from synthetic.systems import SystemA as SA
        reg = PackRegistry(); pa = pack_a([fingerprint(SA().metadata())["value"]]); reg.register(pa); t = Translator(CanonicalModel(MODEL_DEF), reg, Ids(), FakeClock())
        rec, _ = t.translate_outbound(ref(pa), "Party", {"display_name": "Ann"}); self.assertEqual(rec, {"entity": "Account", "fields": {"profile": {"name": "Ann"}}})
        with self.assertRaisesRegex(OutboundValidationError, "street has no outbound mapping"): t.translate_outbound(ref(pa), "Party", {"display_name": "Ann", "street": "1 Main St"})
    def test_a_malformed_reference_is_refused_even_in_a_mapping_that_does_not_run(self):
        for state in ("CANDIDATE", "AMBIGUOUS"):
            p, _ = listing_pack(); m = p["mappings"][1]; m.update(fmap("l-headline", "Ticket.title", "headline", ID, None, state=state, by="AI_ASSISTED" if state == "AMBIGUOUS" else "DETERMINISTIC_TOOL")); p["artifact_hash"] = pack_hash(p)
            with self.assertRaises(PackError, msg=state): PackRegistry().register(p)
    def test_outbound_never_takes_a_same_named_attribute_of_another_concept(self):
        fp = fingerprint(SystemC().metadata())["value"]
        p = build("rev14-two-status", "1.0.0", "k", [fp], [emap("p", "ENTITY", "Property", "Property", "Property"), fmap("ps", "Property.state", "Property.status", ID, ID, [cons("c1", "LENGTH", max=20)]),
                                                         emap("t", "ENTITY", "Ticket", "Task", "Ticket"), fmap("ts", "Ticket.state", "Task.status", ID, ID, [cons("c2", "LENGTH", max=20)])], [], POL)
        reg = PackRegistry(); reg.register(p); t = Translator(CanonicalModel(MODEL_DEF), reg, Ids(), FakeClock())
        self.assertEqual(t.translate_outbound(ref(p), "Property", {"status": "SOLD"}), ({"entity": "Property", "fields": {"state": "SOLD"}}, {"constraints_checked": 1, "violations": 0}))
    def test_the_existing_core_packs_still_register(self):
        from synthetic.systems import SystemB
        reg = PackRegistry(); reg.register(pack_a([fingerprint(SystemA().metadata())["value"]])); reg.register(pack_b([fingerprint(SystemB().metadata())["value"]]))


class TestF2Identity(unittest.TestCase):
    def test_a_composite_identity_is_stable_and_unambiguous(self):
        self.assertEqual(source_identity(["a", "b"], {"a": "1", "b": 2}), ("1|2", None))
        self.assertNotEqual(source_identity(["a", "b"], {"a": "x|y", "b": "z"})[0], source_identity(["a", "b"], {"a": "x", "b": "y|z"})[0])
        self.assertNotEqual(source_identity(["a", "b"], {"a": "a\\", "b": "b|c"})[0], source_identity(["a", "b"], {"a": "a|b\\", "b": "c"})[0])      # equal if the escape character were not itself escaped
    def test_a_missing_blank_or_structured_identity_is_refused_never_hashed(self):
        for rec in ({}, {"id": None}, {"id": ""}, {"id": "  "}, {"id": {"x": 1}}, {"id": [1]}, {"id": True}):
            sid, why = source_identity("id", rec); self.assertIsNone(sid, rec); self.assertIn("id", why)
        self.assertIsNone(source_identity(["a", "b"], {"a": "1"})[0])
        self.assertIsNone(source_identity([], {"a": "1"})[0]); self.assertIsNone(source_identity(["a", ""], {"a": "1"})[0])
    def test_a_content_hash_identity_only_when_declared(self):
        sid, _ = source_identity(IDENTITY_CONTENT_HASH, {"x": 1}); self.assertRegex(sid, r"^[0-9a-f]{12}$")
        self.assertIsNone(source_identity("id", {"x": 1})[0])
    def test_composite_identity_end_to_end_keeps_the_canonical_id_when_other_fields_change(self):
        w = World(); A_ = w.ctx[A]; w.integrations[(A, "db")].activate(); w.fabric.cfg[(A, "ia-db")]["identity"] = {"customers": ["cust_id", "email_addr"]}
        w.fabric.sync(A_, "ia-db", "customers"); first = sorted(o["canonical_id"] for o in w.m1.by_tenant[A]["entities"]); self.assertEqual(len(first), 5)
        sids = sorted(ob["source_object"]["object_id"] for ob in w.m1.by_tenant[A]["observations"]); self.assertTrue(all("|" in x and "@" in x for x in sids), sids)
        for r in w.sys[A]["B"].tables["customers"].values(): r["full_name"] = r["full_name"] + " X"
        w.m1.by_tenant[A]["entities"] = []; w.fabric.sync(A_, "ia-db", "customers"); self.assertEqual(sorted(o["canonical_id"] for o in w.m1.by_tenant[A]["entities"]), first)
    def test_a_record_without_its_identity_is_one_refused_record_and_the_read_goes_on(self):
        w = World(); w.activate_all(); del w.sys[A]["A"].rows["Account"]["3"]["id"]
        rep = w.fabric.sync(w.ctx[A], "ia-rest", "Account"); self.assertEqual((rep["delivered"], rep["refused"], rep["complete"]), (6, 1, True))
        self.assertEqual(len(errors(w, kind="IDENTITY_MISSING")), 1)


class TestF3EventsNotApplied(unittest.TestCase):
    def ev(self, eid, deps=(), etype="ticket.opened", **p): return {"event_id": eid, "type": etype, "depends_on": list(deps), "payload": dict({"id": eid, "title": "t", "state": "open"}, **p)}
    def setUp(self): self.w = World(); self.w.activate_all(); self.c = self.w.ctx[A]; self.f = self.w.fabric
    def told(self): return [(e["event_id"], e["ordering_state"]) for e in errors(self.w, "m2", "EVENT_NOT_APPLIED")]
    def test_a_waiting_event_is_told_with_what_it_waits_on_and_is_not_a_failure(self):
        self.f.ingest_events(self.c, "ia-evt", [self.ev("e2", ["e1"])]); e = errors(self.w, "m2", "EVENT_NOT_APPLIED")
        self.assertEqual(self.told(), [("e2", "QUEUED_AWAITING_PREDECESSOR")]); self.assertEqual(e[0]["waiting_on"], ["e1"])
        self.assertEqual(self.w.tel.counters.get((A, "ia-evt", "failures"), 0), 0)
        self.f.ingest_events(self.c, "ia-evt", [self.ev("e1")]); self.assertEqual(len(self.w.m2.by_tenant[A]["events"]), 2); self.assertEqual(self.told(), [("e2", "QUEUED_AWAITING_PREDECESSOR")])
    def test_an_event_sent_to_reconciliation_is_told(self):
        self.f.ingest_events(self.c, "ia-evt", [self.ev("late", ["never"])]); self.w.clock.sleep(31); self.f.tick(self.c, "ia-evt")
        self.assertEqual(self.told(), [("late", "QUEUED_AWAITING_PREDECESSOR"), ("late", "RECONCILIATION_PENDING")])
    def test_an_in_order_event_with_no_entity_mapping_is_told(self):
        r = self.f.ingest_events(self.c, "ia-evt", [self.ev("x1", etype="ticket.archived")]); self.assertEqual(r[0]["ordering_state"], "IN_ORDER"); self.assertFalse(r[0]["delivered"])
        self.assertEqual(self.told(), [("x1", "IN_ORDER")]); self.assertIn("no entity mapping", errors(self.w, "m2", "EVENT_NOT_APPLIED")[0]["reason"])
    def test_rejected_and_deferred_events_are_told(self):
        for pol, want in (("REJECT", "REJECTED_BY_POLICY"), ("DEFER", "DEFERRED")):
            w = World(sequencer_policy={"*": {"on_missing": pol, "wait_seconds": 30}}); w.activate_all(); w.fabric.ingest_events(w.ctx[A], "ia-evt", [self.ev("q", ["p"])])
            self.assertEqual([(e["event_id"], e["ordering_state"]) for e in errors(w, "m2", "EVENT_NOT_APPLIED")], [("q", want)], pol)
    def test_an_applied_event_is_not_told(self):
        self.f.ingest_events(self.c, "ia-evt", [self.ev("ok")]); self.assertEqual(self.told(), [])


class FailingModule(RecordingModule):
    def __init__(self, mid, req, raise_on=(), marker_on=()): super().__init__(mid, req); self.raise_on, self.marker_on = set(raise_on), set(marker_on)
    def _go(self, what, f, ctx, x):
        f(ctx, x)
        if what in self.raise_on: raise RuntimeError("module bug")
        if what in self.marker_on: return {"handler_failures": 1}
    def ingest_canonical_entity(self, ctx, o): return self._go("entity", super().ingest_canonical_entity, ctx, o)
    def ingest_canonical_observation(self, ctx, o): return self._go("observation", super().ingest_canonical_observation, ctx, o)
    def receive_integration_state(self, ctx, s): return self._go("state", super().receive_integration_state, ctx, s)
    def receive_integration_error(self, ctx, e): return self._go("error", super().receive_integration_error, ctx, e)


class TestF4ModuleFailures(unittest.TestCase):
    def run_with(self, **kw):
        w = World(); m = FailingModule("rev14-module", [{"concept": "Party", "attributes": ["display_name"]}], **kw); w.fabric.register_module(m)
        c = w.fabric.add_integration(w.ctx[A], "ia-r14", anchor_module="rev14-module", connector=__import__("synthetic.connectors", fromlist=["x"]).SyntheticRestConnector(w.sys[A]["A"], "secretref:synthetic/rest"), pack_ref=ref(w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", entities=["Account"])
        st = c.activate(); return w, m, st
    def failures(self, w): return len(w.store.list(w.ctx[A], "module_delivery_failures")), w.tel.counters.get((A, "ia-r14", "module_failures"), 0)
    def test_a_raising_entity_handler_is_counted_recorded_and_not_reported_as_delivered(self):
        w, m, _ = self.run_with(raise_on={"entity"}); rep = w.fabric.sync(w.ctx[A], "ia-r14", "Account")
        self.assertEqual((rep["delivered"], rep["module_failed"]), (0, 7)); self.assertEqual(self.failures(w), (7, 7))
        self.assertEqual(len([e for e in m.by_tenant[A]["errors"] if e["kind"] == "MODULE_DELIVERY_FAILED"]), 7)
    def test_a_failure_marker_from_the_observation_handler_counts_too(self):
        w, m, _ = self.run_with(marker_on={"observation"}); rep = w.fabric.sync(w.ctx[A], "ia-r14", "Account"); self.assertEqual((rep["delivered"], rep["module_failed"]), (0, 7))
    def test_a_state_handler_failure_never_stops_the_transition_and_is_counted(self):
        w, m, st = self.run_with(raise_on={"state"}); self.assertEqual(st["state"], "ACTIVE"); self.assertGreaterEqual(self.failures(w)[1], 1)
        self.assertEqual({r["delivery"] for _, r in w.store.list(w.ctx[A], "module_delivery_failures")}, {"state"})
    def test_an_error_handler_failure_is_counted_and_does_not_loop(self):
        w, m, _ = self.run_with(raise_on={"error"}); w.sys[A]["A"].rows["Account"]["2"]["id"] = ""; rep = w.fabric.sync(w.ctx[A], "ia-r14", "Account")
        self.assertEqual((rep["refused"], rep["delivered"]), (1, 6)); self.assertEqual(self.failures(w), (1, 1))
    def test_a_healthy_module_records_no_failure(self):
        w, m, _ = self.run_with(); rep = w.fabric.sync(w.ctx[A], "ia-r14", "Account"); self.assertEqual((rep["delivered"], rep["module_failed"]), (7, 0)); self.assertEqual(self.failures(w), (0, 0))


class TestF5ReadCompleteness(unittest.TestCase):
    def setUp(self): self.w = World(); self.w.activate_all(); self.c = self.w.ctx[A]
    def test_a_read_cut_short_by_the_page_limit_says_so(self):
        rep = self.w.fabric.sync(self.c, "ia-rest", "Account", max_pages=1); self.assertEqual((rep["pages"], rep["delivered"], rep["complete"], rep["stopped_at_page_limit"]), (1, 3, False, True))
    def test_a_read_that_reaches_the_end_exactly_at_the_limit_is_complete(self):
        rep = self.w.fabric.sync(self.c, "ia-rest", "Account", max_pages=3); self.assertEqual((rep["pages"], rep["complete"], rep["stopped_at_page_limit"]), (3, True, False))
    def test_a_failed_read_is_neither_complete_nor_at_the_limit(self):
        self.w.sys[A]["A"].faults.push("read", ("auth",)); rep = self.w.fabric.sync(self.c, "ia-rest", "Account")
        self.assertIsNotNone(rep["failed"]); self.assertEqual((rep["complete"], rep["stopped_at_page_limit"]), (False, False))
    def test_an_empty_source_is_complete(self):
        self.w.sys[A]["A"].rows["Account"].clear(); rep = self.w.fabric.sync(self.c, "ia-rest", "Account"); self.assertTrue(rep["complete"]); self.assertFalse(rep["stopped_at_page_limit"])


class TestF6SyncReports(unittest.TestCase):
    def test_drift_before_the_first_validation_is_not_readable_and_does_not_raise(self):
        w = World(); w.sys[A]["A"].drift_rename_field("Account", "profile.name", "profile.full_name"); self.assertEqual(w.integrations[(A, "rest")].activate()["state"], "SCHEMA_DRIFT")
        rep = w.fabric.sync(w.ctx[A], "ia-rest", "Account"); self.assertEqual((rep["not_allowed"], rep["delivered"], rep["complete"]), (True, 0, False))
    def test_a_blank_identity_value_is_one_refused_record(self):
        w = World(); w.activate_all(); w.sys[A]["A"].rows["Account"]["2"]["id"] = " "
        rep = w.fabric.sync(w.ctx[A], "ia-rest", "Account"); self.assertEqual((rep["refused"], rep["delivered"], rep["complete"]), (1, 6, True))
    def test_a_record_the_observation_contract_refuses_is_reported_not_raised(self):
        w = World(); w.activate_all(); w.fabric.cfg[(A, "ia-rest")]["identity"] = {"Account": "status"}       # a legal identity field whose value is then made too long for the observation contract
        w.sys[A]["A"].rows["Account"]["1"]["status"] = "act"
        import auif.observation as O
        real = O.ObservationFactory.build
        def build(self, *a, **k):
            if k.get("source_object", {}).get("object_id") == "act" and k.get("payload", {}).get("id") == "1": raise __import__("auif.errors", fromlist=["x"]).ContractViolation("observation", ["refused"])
            return real(self, *a, **k)
        O.ObservationFactory.build = build
        try: rep = w.fabric.sync(w.ctx[A], "ia-rest", "Account")
        finally: O.ObservationFactory.build = real
        self.assertEqual(rep["refused"], 1); self.assertEqual(len(errors(w, kind="RECORD_REFUSED")), 1); self.assertTrue(rep["complete"])


if __name__ == "__main__": unittest.main()

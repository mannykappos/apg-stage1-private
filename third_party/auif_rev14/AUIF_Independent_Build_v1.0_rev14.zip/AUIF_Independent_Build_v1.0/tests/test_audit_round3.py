"""Audit round 3 regression tests. F9: a CanonicalAction's tenant_id must equal the authenticated TenantContext, and the refusal must happen BEFORE any durable record (idempotency, payload, ledger, manifest ref, event) is written."""
import copy, dataclasses, unittest
from auif.errors import AuifError, ContractViolation, TenantContextError
from auif.util import sha
from tests.acceptance_support import act
from tests.test_audit_round2 import Boom, F7
A, B = "tenant-a", "tenant-b"; COLLS = ("action_idem", "action_ledger", "action_payloads", "action_manifest_ref", "action_events")
class TestF9_ActionTenantIsBoundToTheAuthenticatedContext(F7):
    def records(self): return {t: {c: len(self.w.store.list(self.w.ctx[t], c)) for c in COLLS} for t in (A, B)}
    def assert_nothing_stored(self): self.assertEqual(self.records(), {A: {c: 0 for c in COLLS}, B: {c: 0 for c in COLLS}})
    def test_a_matching_tenant_is_accepted_and_flows_end_to_end(self):
        a = self.action(1); r = self.svc.submit(self.ctx, a); self.assertEqual((r["execution_state"], r["tenant_id"]), ("QUEUED", A)); self.assert_healthy(a)
    def test_a_mismatched_tenant_is_rejected_with_TenantContextError(self):
        for tid in (B, "tenant-zzz", "TENANT-A", "tenant-b", "x"):
            with self.subTest(tid):
                a = self.action(1); a["tenant_id"] = tid
                with self.assertRaises((TenantContextError, ContractViolation)): self.svc.submit(self.ctx, a)
        a = self.action(1); a["tenant_id"] = B
        with self.assertRaises(TenantContextError) as e: self.svc.submit(self.ctx, a)
        self.assertIn("does not match", str(e.exception))
    def test_the_rejection_happens_before_ANY_store_write(self):
        for tid in (B, "tenant-zzz", "TENANT-A"):
            with self.subTest(tid):
                self.fresh(); a = self.action(1); a["tenant_id"] = tid; self.f.arm()
                with self.assertRaises(AuifError): self.svc.submit(self.ctx, a)
                self.assertEqual(self.f.log, [], "no put or update of any kind may precede the refusal"); self.assert_nothing_stored()
    def test_no_idempotency_ledger_payload_manifest_or_event_record_exists_in_either_tenant_after_a_mismatch(self):
        a = self.action(1); a["tenant_id"] = B
        with self.assertRaises(TenantContextError): self.svc.submit(self.ctx, a)
        for t in (A, B):
            c = self.w.ctx[t]; self.assertIsNone(self.w.store.get(c, "action_idem", a["idempotency_key"])); self.assertIsNone(self.w.store.get(c, "action_ledger", a["action_id"])); self.assertIsNone(self.w.store.get(c, "action_payloads", "canon:" + a["action_id"])); self.assertIsNone(self.w.store.get(c, "action_manifest_ref", a["action_id"]))
        self.assert_nothing_stored()
    def test_the_submitted_tenant_id_is_never_silently_overwritten(self):
        a = self.action(1); a["tenant_id"] = B; before = copy.deepcopy(a)
        with self.assertRaises(TenantContextError): self.svc.submit(self.ctx, a)
        self.assertEqual(a, before); self.assertEqual(a["tenant_id"], B)
    def test_the_durable_intent_never_holds_a_tenant_other_than_the_authenticated_one(self):
        a = self.action(1); a["tenant_id"] = B; self.f.arm(fail_at=2)
        with self.assertRaises(TenantContextError): self.svc.submit(self.ctx, a)
        self.assertIsNone(self.idem(a))                                                                                           # rejected before the reservation: no intent exists at all
        ok = self.action(2); self.f.arm(fail_at=2)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, ok)
        self.assertEqual(self.idem(ok)["intent"]["action"]["tenant_id"], A)                                                       # a legitimate in-flight intent carries the authenticated tenant
    def test_a_rejected_mismatch_cannot_be_recovered_by_the_sweep_in_either_tenant(self):
        a = self.action(1); a["tenant_id"] = B
        with self.assertRaises(TenantContextError): self.svc.submit(self.ctx, a)
        for t in (A, B): self.assertEqual(self.svc.recover_pending(self.w.ctx[t]), {"completed": [], "unrecoverable": []})
        self.assert_nothing_stored()
    def test_a_retry_under_the_wrong_tenant_context_cannot_recover_another_tenants_action(self):
        a1 = self.action(1); self.f.arm(fail_at=2)
        with self.assertRaises(Boom): self.svc.submit(self.ctx, a1)                                                               # tenant-a's submission is left RESERVED
        cb = self.w.ctx[B]; self.f.arm()
        with self.assertRaises(TenantContextError): self.svc.submit(cb, a1)                                                       # retried under tenant-b's context
        self.assertEqual(self.records()[B], {c: 0 for c in COLLS}); self.assertEqual(self.idem(a1)["state"], "RESERVED")
        self.assertEqual(self.svc.recover_pending(cb), {"completed": [], "unrecoverable": []}); self.assertEqual(self.idem(a1)["state"], "RESERVED")
        self.assertEqual(self.svc.recover_pending(self.ctx)["completed"], [a1["action_id"]]); self.assert_healthy(a1)                 # only its own tenant can recover it
    def test_idempotency_keys_remain_independent_per_tenant(self):
        a, b = self.action(1, key="idem-shared-key-0001"), self.action(1, tenant=B, key="idem-shared-key-0001")
        ra, rb = self.svc.submit(self.ctx, a), self.svc.submit(self.w.ctx[B], b); self.assertEqual((ra["tenant_id"], rb["tenant_id"]), (A, B)); self.assertEqual(self.records()[A]["action_ledger"], 1); self.assertEqual(self.records()[B]["action_ledger"], 1)
    def test_a_reservation_holding_another_tenants_action_is_never_completed(self):
        for planted_under, action_tenant in ((A, B), (B, A)):
            with self.subTest("planted under %s holding %s's action" % (planted_under, action_tenant)):
                self.fresh(); a = self.action(1, tenant=action_tenant); pc = self.w.ctx[planted_under]
                self.w.store.put(pc, "action_idem", a["idempotency_key"], {"action_id": a["action_id"], "content_hash": sha(a["canonical_action"]), "state": "RESERVED", "reserved_at": "2026-10-02T00:00:00Z", "intent": {"action": a}}, if_absent=True)
                out = self.svc.recover_pending(pc); self.assertEqual(out["completed"], []); self.assertEqual(len(out["unrecoverable"]), 1); self.assertIn("different tenant", out["unrecoverable"][0]["problem"])
                self.assertIsNone(self.w.store.get(pc, "action_ledger", a["action_id"])); self.assertIsNone(self.w.store.get(pc, "action_payloads", "canon:" + a["action_id"])); self.assertEqual(self.w.store.get(pc, "action_idem", a["idempotency_key"])["state"], "RESERVED")
    def test_a_forged_context_cannot_satisfy_the_check(self):
        a = self.action(1, tenant=B); forged = dataclasses.replace(self.ctx, tenant_id=B); self.f.arm()
        with self.assertRaises(TenantContextError): self.svc.submit(forged, a)
        self.assert_nothing_stored()
    def test_the_public_entry_point_still_refuses_a_mismatch_and_a_matching_action_completes(self):
        with self.assertRaises(TenantContextError): self.w.fabric.request_action(self.ctx, "synthetic-module-1", self.action(1, tenant=B))
        self.assert_nothing_stored(); r = self.w.fabric.request_action(self.ctx, "synthetic-module-1", self.action(2)); self.assertEqual(r["execution_state"], "COMPLETED"); self.assertEqual(len(self.sa.effects), 1)
class TestRequestActionGuardIsEnforcedAtTheEntryPointItself(F7):
    """Found by mutation testing after F9: M31 (disable the whole entry-point guard) survived, because the only test of that guard was a TENANT mismatch, which the service-level check now also catches. The MODULE clause had never had a test of its own. Each clause, and the fact that the entry point refuses BEFORE delegating, is now tested directly."""
    def spy(self):
        calls = []; real = self.w.fabric.actions.submit
        def submit(ctx, action): calls.append(action["action_id"]); return real(ctx, action)
        self.w.fabric.actions.submit = submit; return calls
    def test_the_entry_point_refuses_a_module_that_did_not_author_the_action_before_delegating(self):
        a = self.action(1); self.assertEqual(a["source_module"], "synthetic-module-1"); calls = self.spy(); self.f.arm()
        with self.assertRaises(TenantContextError) as e: self.w.fabric.request_action(self.ctx, "synthetic-module-2", a)
        self.assertIn("does not belong", str(e.exception)); self.assertEqual(calls, [], "the service must never be reached"); self.assertEqual(self.f.log, [])
    def test_the_entry_point_refuses_a_tenant_mismatch_itself_before_delegating_to_the_service(self):
        a = self.action(1, tenant=B); calls = self.spy(); self.f.arm()
        with self.assertRaises(TenantContextError) as e: self.w.fabric.request_action(self.ctx, "synthetic-module-1", a)
        self.assertIn("does not belong", str(e.exception)); self.assertEqual(calls, [], "the service must never be reached"); self.assertEqual(self.f.log, [])
    def test_a_request_whose_module_and_tenant_both_match_is_delegated_exactly_once(self):
        a = self.action(1); calls = self.spy(); r = self.w.fabric.request_action(self.ctx, "synthetic-module-1", a); self.assertEqual(calls, [a["action_id"]]); self.assertEqual(r["execution_state"], "COMPLETED")
if __name__ == "__main__": unittest.main()

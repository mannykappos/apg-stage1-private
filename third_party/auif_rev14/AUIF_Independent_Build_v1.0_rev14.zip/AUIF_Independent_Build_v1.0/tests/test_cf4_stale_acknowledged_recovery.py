"""CF-4 (rev10) regression: a crash between the durable ACKNOWLEDGED and COMPLETED left an action in ACKNOWLEDGED forever, although the target had already replied and the effect was confirmed; dispatch(), reconcile() and the CF-2 sweep all left it alone.
recover_stale_acknowledged() completes it by the one transition that already existed (ACKNOWLEDGED -> COMPLETED, the step dispatch() would have taken) and by nothing else: nothing is sent, nothing is looked up, no Governor decision is requested (G5), and a record whose confirmation is not on the record is never completed."""
import math, unittest
import tests.test_action_flow as TF
from auif.errors import AuifError, IllegalTransition
from tests.test_action_flow import mk_action
class Crash(Exception): pass
class W(TF.ActBase):
    def runTest(self): pass
def world(): x = W(); x.setUp(); x.calls = []; return x
def count_calls(x, rt=None):
    rt = rt or x.rt; orig = rt.call
    def w(*a, **k): x.calls.append(a[4] if len(a) > 4 else k.get("method")); return orig(*a, **k)
    rt.call = w; return orig
def crash_after_ack(x, n=1, governed=False, **kw):
    """The target applies the write and replies; the ACKNOWLEDGED is durable; the process dies before the COMPLETED."""
    x.svc.submit(x.ctx, mk_action(n, governed=governed, **kw)); led = x.svc.ledger; orig = led.transition; done = []
    def boom(ctx, a, state, **k):
        if state == "COMPLETED" and not done: done.append(1); raise Crash()
        return orig(ctx, a, state, **k)
    led.transition = boom
    try: x.svc.dispatch(x.ctx, "act-%04d" % n)
    except Crash: pass
    led.transition = orig; count_calls(x)
def writes(x): return [c for c in x.calls if c == "write"]
def events(x, n=1): return [e["kind"] for e in x.svc.ledger.events(x.ctx, "act-%04d" % n)]
def rec(x, n=1): return x.svc.ledger.get(x.ctx, "act-%04d" % n)
def overwrite(x, n=1, **fields):
    r = dict(rec(x, n)); r.update(fields)
    for k in [k for k, v in fields.items() if v is ...]: del r[k]
    x.svc.store.put(x.ctx, "action_ledger", "act-%04d" % n, r)
class TestStrandedAcknowledgedRecovery(unittest.TestCase):
    def test_the_defect_a_crash_after_ACKNOWLEDGED_strands_the_action_and_dispatch_reconcile_and_the_CF2_sweep_do_nothing(self):
        x = world(); crash_after_ack(x); self.assertEqual((x.state(1), len(x.sysA.effects)), ("ACKNOWLEDGED", 1)); self.assertTrue(rec(x)["external_reference"])
        x.svc.dispatch(x.ctx, "act-0001"); x.svc.reconcile(x.ctx, "act-0001"); x.e.clock.sleep(99999); x.svc.recover_stale_sent(x.ctx, 3600)
        self.assertEqual((x.state(1), len(x.sysA.effects), writes(x)), ("ACKNOWLEDGED", 1, []))
    def test_the_stranded_action_is_completed_as_applied_with_the_effect_exactly_once_and_nothing_sent(self):
        x = world(); crash_after_ack(x); before = rec(x); x.e.clock.sleep(3601); r = x.svc.recover_stale_acknowledged(x.ctx, 3600)
        self.assertEqual((r["completed"], r["not_stale"], r["skipped"], r["problems"]), (["act-0001"], 0, [], [])); after = rec(x)
        self.assertEqual((after["execution_state"], after["result"], len(x.sysA.effects), writes(x)), ("COMPLETED", {"outcome": "APPLIED"}, 1, []))
        self.assertEqual((after["external_reference"], after["acknowledged_at"], after["sent_at"], after["attempt_count"]), (before["external_reference"], before["acknowledged_at"], before["sent_at"], before["attempt_count"])); self.assertTrue(after["completed_at"])
    def test_no_lookup_of_any_kind_is_made_at_the_target(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(4000); x.svc.recover_stale_acknowledged(x.ctx, 3600); self.assertEqual(x.calls, [])           # not a write, not a read, not a reconciliation query
    def test_a_governed_action_requests_no_new_decision_and_keeps_its_stored_governance(self):
        x = world(); crash_after_ack(x, governed=True); self.assertEqual(x.state(1), "ACKNOWLEDGED"); before = (len(x.gov.decisions), dict(rec(x)["governance"])); self.assertTrue(before[1].get("governor_decision_ref")); x.e.clock.sleep(7200)
        r = x.svc.recover_stale_acknowledged(x.ctx, 3600); self.assertEqual(r["completed"], ["act-0001"]); self.assertEqual((len(x.gov.decisions), rec(x)["governance"], x.state(1), writes(x)), (before[0], before[1], "COMPLETED", []))
    def test_the_recovery_is_recorded_once_in_the_event_trail_and_in_telemetry(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(4000); x.svc.recover_stale_acknowledged(x.ctx, 3600); x.svc.recover_stale_acknowledged(x.ctx, 3600)
        self.assertEqual(events(x).count("STRANDED_ACKNOWLEDGED_COMPLETED"), 1); self.assertEqual(sum(v for (t, i, s), v in x.e.tel.counters.items() if s == "stale_acknowledged_recovery"), 1)
        self.assertEqual([v for k, v in x.e.tel.counters.items() if k[2] == "stale_acknowledged_recovery"], [1]); self.assertEqual([k[1] for k in x.e.tel.counters if k[2] == "stale_acknowledged_recovery"], [x.h.integration_id])
    def test_dispatching_again_after_recovery_sends_nothing(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(4000); x.svc.recover_stale_acknowledged(x.ctx, 3600); x.svc.dispatch(x.ctx, "act-0001"); x.svc.dispatch(x.ctx, "act-0001"); x.svc.reconcile(x.ctx, "act-0001"); self.assertEqual((len(x.sysA.effects), writes(x), x.state(1)), (1, [], "COMPLETED"))
    def test_the_sweep_is_idempotent(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(4000); x.svc.recover_stale_acknowledged(x.ctx, 3600); done = rec(x); r2 = x.svc.recover_stale_acknowledged(x.ctx, 3600)
        self.assertEqual((r2["completed"], r2["not_stale"], r2["skipped"], r2["problems"]), ([], 0, [], [])); self.assertEqual(rec(x), done)
    def test_the_normal_path_is_unchanged_a_live_dispatch_still_completes_and_the_sweep_finds_nothing(self):
        x = world(); x.svc.submit(x.ctx, mk_action(1)); x.svc.dispatch(x.ctx, "act-0001"); x.e.clock.sleep(99999); r = x.svc.recover_stale_acknowledged(x.ctx, 3600)
        self.assertEqual((x.state(1), len(x.sysA.effects), r), ("COMPLETED", 1, {"completed": [], "not_stale": 0, "skipped": [], "problems": []}))
class TestInFlightAndScope(unittest.TestCase):
    def test_a_record_that_is_not_yet_stale_is_never_touched_and_the_boundary_is_inclusive_to_the_second(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(3599); r = x.svc.recover_stale_acknowledged(x.ctx, 3600)
        self.assertEqual((r["completed"], r["not_stale"]), ([], 1)); self.assertEqual(x.state(1), "ACKNOWLEDGED"); x.e.clock.sleep(1); r = x.svc.recover_stale_acknowledged(x.ctx, 3600); self.assertEqual((r["completed"], x.state(1)), (["act-0001"], "COMPLETED"))
    def test_only_the_stale_record_is_completed_when_a_recent_one_exists(self):
        x = world(); crash_after_ack(x, 1); x.e.clock.sleep(5000); crash_after_ack(x, 2); r = x.svc.recover_stale_acknowledged(x.ctx, 3600)
        self.assertEqual((r["completed"], r["not_stale"]), (["act-0001"], 1)); self.assertEqual((x.state(1), x.state(2)), ("COMPLETED", "ACKNOWLEDGED"))
    def test_only_ACKNOWLEDGED_records_are_considered(self):
        x = world(); x.svc.submit(x.ctx, mk_action(1)); x.svc.submit(x.ctx, mk_action(2)); x.svc.dispatch(x.ctx, "act-0002")                              # act-0001 stays QUEUED, act-0002 COMPLETED
        x.sysA.faults.push("write", ("timeout_before",)); x.svc.submit(x.ctx, mk_action(3)); x.svc.dispatch(x.ctx, "act-0003")                           # UNKNOWN_OUTCOME
        x.svc.submit(x.ctx, mk_action(4)); led = x.svc.ledger; orig = led.patch; led.patch = lambda *a, **k: (_ for _ in ()).throw(Crash()); count_calls(x)
        try: x.svc.dispatch(x.ctx, "act-0004")                                                                                                          # SENT
        except Crash: pass
        led.patch = orig; x.e.clock.sleep(99999); before = [x.state(i) for i in (1, 2, 3, 4)]; self.assertEqual(before, ["QUEUED", "COMPLETED", "UNKNOWN_OUTCOME", "SENT"])
        r = x.svc.recover_stale_acknowledged(x.ctx, 3600); self.assertEqual(([x.state(i) for i in (1, 2, 3, 4)], r), (before, {"completed": [], "not_stale": 0, "skipped": [], "problems": []}))
    def test_the_CF2_sweep_does_not_touch_an_ACKNOWLEDGED_record_so_the_two_recoveries_stay_separate(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(99999); r = x.svc.recover_stale_sent(x.ctx, 3600); self.assertEqual((r["recovered"], x.state(1)), ([], "ACKNOWLEDGED"))
    def test_another_tenant_cannot_complete_this_tenants_records(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(4000); r = x.svc.recover_stale_acknowledged(x.e.B, 3600); self.assertEqual((r["completed"], r["not_stale"]), ([], 0)); self.assertEqual(x.state(1), "ACKNOWLEDGED")
    def test_a_record_that_moved_on_between_the_listing_and_the_transition_is_skipped_not_corrupted(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(4000); led = x.svc.ledger; orig = led.transition
        def moved(*a, **k): raise IllegalTransition("COMPLETED -> COMPLETED")
        led.transition = moved; r = x.svc.recover_stale_acknowledged(x.ctx, 3600); led.transition = orig; self.assertEqual((r["completed"], r["skipped"], r["problems"]), ([], ["act-0001"], [])); self.assertEqual(x.state(1), "ACKNOWLEDGED")
    def test_a_failure_while_completing_is_reported_not_raised_and_a_later_sweep_finishes_it(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(4000); led = x.svc.ledger; orig = led.transition
        def down(*a, **k): raise RuntimeError("the store is down")
        led.transition = down; r = x.svc.recover_stale_acknowledged(x.ctx, 3600); led.transition = orig
        self.assertEqual((r["completed"], len(r["problems"])), ([], 1)); self.assertEqual(r["problems"][0]["action_id"], "act-0001"); self.assertIn("completion failed: RuntimeError", r["problems"][0]["problem"]); self.assertEqual((x.state(1), len(x.sysA.effects), writes(x)), ("ACKNOWLEDGED", 1, []))
        r = x.svc.recover_stale_acknowledged(x.ctx, 3600); self.assertEqual((r["completed"], r["problems"], x.state(1)), (["act-0001"], [], "COMPLETED"))
    def test_an_integration_that_cannot_be_resolved_does_not_block_the_completion(self):
        x = world(); crash_after_ack(x); x.e.clock.sleep(4000); x.res.h.clear(); r = x.svc.recover_stale_acknowledged(x.ctx, 3600)
        self.assertEqual((r["completed"], r["problems"], x.state(1), writes(x)), (["act-0001"], [], "COMPLETED", [])); self.assertEqual(sum(v for k, v in x.e.tel.counters.items() if k[2] == "stale_acknowledged_recovery"), 0)      # the confirmation is already on the record; only the counter is lost
    def test_any_failure_of_the_telemetry_lookup_never_turns_a_durable_completion_into_a_problem(self):
        for exc in (RuntimeError("down"), KeyError("gone"), ValueError("bad")):
            x = world(); crash_after_ack(x); x.e.clock.sleep(4000)
            def broken(*a, **k): raise exc
            x.svc.integrations.resolve = broken; r = x.svc.recover_stale_acknowledged(x.ctx, 3600); self.assertEqual((r["completed"], r["problems"], x.state(1), writes(x)), (["act-0001"], [], "COMPLETED", []))
class TestConfirmationMustBeOnTheRecord(unittest.TestCase):
    def test_an_ACKNOWLEDGED_record_without_the_targets_reference_or_timestamp_is_never_completed(self):
        for label, change in (("no reference", {"external_reference": ...}), ("empty reference", {"external_reference": ""}), ("non-string reference", {"external_reference": 7}), ("null reference", {"external_reference": None}),
                              ("no timestamp", {"acknowledged_at": ...}), ("empty timestamp", {"acknowledged_at": ""}), ("non-string timestamp", {"acknowledged_at": 5})):
            with self.subTest(label):
                x = world(); crash_after_ack(x); x.e.clock.sleep(99999); overwrite(x, **change); r = x.svc.recover_stale_acknowledged(x.ctx, 3600)
                self.assertEqual((r["completed"], r["not_stale"], r["skipped"]), ([], 0, [])); self.assertEqual(len(r["problems"]), 1); self.assertEqual(r["problems"][0]["action_id"], "act-0001"); self.assertIn("confirmation cannot be established", r["problems"][0]["problem"])
                self.assertEqual((x.state(1), writes(x)), ("ACKNOWLEDGED", []))
    def test_one_unconfirmed_record_does_not_stop_the_sweep_from_completing_a_confirmed_one(self):
        x = world(); crash_after_ack(x, 1); crash_after_ack(x, 2); x.e.clock.sleep(99999); overwrite(x, 1, external_reference=...); r = x.svc.recover_stale_acknowledged(x.ctx, 3600)
        self.assertEqual((r["completed"], len(r["problems"]), x.state(1), x.state(2)), (["act-0002"], 1, "ACKNOWLEDGED", "COMPLETED"))
    def test_the_threshold_must_be_a_positive_finite_number(self):
        x = world()
        for bad in (0, -1, -0.5, True, False, "3600", None, [3600], math.nan, math.inf, -math.inf, 3600j):
            with self.subTest(repr(bad)), self.assertRaises(AuifError): x.svc.recover_stale_acknowledged(x.ctx, bad)
        x.svc.recover_stale_acknowledged(x.ctx, 1); x.svc.recover_stale_acknowledged(x.ctx, 0.5)
if __name__ == "__main__": unittest.main()

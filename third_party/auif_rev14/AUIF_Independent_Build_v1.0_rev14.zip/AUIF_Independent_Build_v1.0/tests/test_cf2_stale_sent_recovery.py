"""CF-2 (rev9) regression: a crash after the durable SENT left an action in SENT forever (before the send, or after the target applied the write but before the outcome was recorded); dispatch() and reconcile() both left it alone.
recover_stale_sent() resolves it by the rules that already govern an unknown outcome and by nothing else: SENT -> UNKNOWN_OUTCOME -> reconcile (found: COMPLETED; not found: FAILED; no lookup: operator review). NOTHING is ever re-sent (G5) and no Governor decision is requested."""
import math, unittest
import tests.test_action_flow as TF
from auif.errors import AuifError, IllegalTransition
from tests.test_action_flow import mk_action
class Crash(Exception): pass
class W(TF.ActBase):
    def runTest(self): pass
def world(): x = W(); x.setUp(); x.calls = []; return x
def count_calls(x, rt=None):
    rt = rt or x.rt; orig = rt.call
    def w(*a, **k): x.calls.append(a[4] if len(a) > 4 else k.get("method")); return orig(*a, **k)
    rt.call = w; return orig
def crash_before_send(x, n=1, governed=False, rt=None, **kw):
    rt = rt or x.rt; x.svc.submit(x.ctx, mk_action(n, governed=governed, **kw)); orig = rt.call
    def boom(*a, **k): raise Crash()
    rt.call = boom
    try: x.svc.dispatch(x.ctx, "act-%04d" % n)
    except Crash: pass
    rt.call = orig; count_calls(x, rt)
def crash_after_apply(x, n=1, governed=False):
    x.svc.submit(x.ctx, mk_action(n, governed=governed)); led = x.svc.ledger; orig = led.patch; done = []
    def boom(*a, **k):
        if not done: done.append(1); raise Crash()
        return orig(*a, **k)
    led.patch = boom
    try: x.svc.dispatch(x.ctx, "act-%04d" % n)
    except Crash: pass
    led.patch = orig; count_calls(x)
def writes(x): return [c for c in x.calls if c == "write"]
def events(x, n=1): return [e["kind"] for e in x.svc.ledger.events(x.ctx, "act-%04d" % n)]
class TestStaleSentRecovery(unittest.TestCase):
    def test_the_defect_a_crash_after_SENT_strands_the_action_and_dispatch_and_reconcile_do_nothing(self):
        for crash in (crash_before_send, crash_after_apply):
            x = world(); crash(x); self.assertEqual(x.state(1), "SENT"); x.svc.dispatch(x.ctx, "act-0001"); x.svc.reconcile(x.ctx, "act-0001"); self.assertEqual(x.state(1), "SENT"); self.assertEqual(writes(x), [])
    def test_a_crash_before_the_send_ends_FAILED_by_reconciliation_and_nothing_is_ever_sent(self):
        x = world(); crash_before_send(x); x.e.clock.sleep(3601); r = x.svc.recover_stale_sent(x.ctx, 3600)
        self.assertEqual((r["recovered"], r["reconciled"], r["not_stale"], r["skipped"], r["problems"]), (["act-0001"], {"act-0001": "FAILED"}, 0, [], []))
        self.assertEqual((x.state(1), len(x.sysA.effects), writes(x)), ("FAILED", 0, []))
        rec = x.svc.ledger.get(x.ctx, "act-0001"); self.assertIn("not applied", rec["error"]["message_redacted"]); self.assertIs(rec["reconciliation"]["blind_retry_permitted"], False)
    def test_a_crash_after_the_target_applied_ends_COMPLETED_by_reconciliation_with_no_second_effect(self):
        x = world(); crash_after_apply(x); self.assertEqual(len(x.sysA.effects), 1); x.e.clock.sleep(3601); r = x.svc.recover_stale_sent(x.ctx, 3600)
        self.assertEqual((r["recovered"], r["reconciled"]), (["act-0001"], {"act-0001": "COMPLETED"})); rec = x.svc.ledger.get(x.ctx, "act-0001")
        self.assertEqual((rec["execution_state"], len(x.sysA.effects), writes(x)), ("COMPLETED", 1, [])); self.assertTrue(rec["external_reference"]); self.assertEqual(rec["result"], {"outcome": "APPLIED_CONFIRMED_BY_RECONCILIATION"})
    def test_a_governed_action_requests_no_new_decision_and_keeps_its_stored_governance(self):
        for crash in (crash_before_send, crash_after_apply):
            x = world(); crash(x, governed=True); before = (len(x.gov.decisions), dict(x.svc.ledger.get(x.ctx, "act-0001")["governance"])); x.e.clock.sleep(7200); r = x.svc.recover_stale_sent(x.ctx, 3600)
            self.assertEqual(len(r["recovered"]), 1); self.assertEqual((len(x.gov.decisions), x.svc.ledger.get(x.ctx, "act-0001")["governance"]), before); self.assertEqual(writes(x), [])
    def test_the_recovery_is_recorded_once_in_the_event_trail_and_in_telemetry(self):
        x = world(); crash_before_send(x); x.e.clock.sleep(4000); x.svc.recover_stale_sent(x.ctx, 3600); x.svc.recover_stale_sent(x.ctx, 3600)
        self.assertEqual(events(x).count("STALE_SENT_RECOVERED"), 1); self.assertEqual(sum(v for (t, i, s), v in x.e.tel.counters.items() if s == "stale_sent_recovery"), 1)
    def test_dispatching_again_after_recovery_still_sends_nothing(self):
        for crash in (crash_before_send, crash_after_apply):
            x = world(); crash(x); x.e.clock.sleep(4000); x.svc.recover_stale_sent(x.ctx, 3600); eff = len(x.sysA.effects); x.svc.dispatch(x.ctx, "act-0001"); x.svc.dispatch(x.ctx, "act-0001"); self.assertEqual((len(x.sysA.effects), writes(x)), (eff, []))
    def test_the_sweep_is_idempotent(self):
        x = world(); crash_after_apply(x); x.e.clock.sleep(4000); x.svc.recover_stale_sent(x.ctx, 3600); rec = x.svc.ledger.get(x.ctx, "act-0001"); r2 = x.svc.recover_stale_sent(x.ctx, 3600)
        self.assertEqual((r2["recovered"], r2["reconciled"], r2["not_stale"], r2["skipped"], r2["problems"]), ([], {}, 0, [], [])); self.assertEqual(x.svc.ledger.get(x.ctx, "act-0001"), rec)
class TestInFlightAndScope(unittest.TestCase):
    def test_a_record_that_is_not_yet_stale_is_never_touched(self):
        x = world(); crash_before_send(x); x.e.clock.sleep(3599); r = x.svc.recover_stale_sent(x.ctx, 3600)
        self.assertEqual((r["recovered"], r["not_stale"]), ([], 1)); self.assertEqual(x.state(1), "SENT"); x.e.clock.sleep(1); r = x.svc.recover_stale_sent(x.ctx, 3600); self.assertEqual(r["recovered"], ["act-0001"])      # the boundary is inclusive, to the second
    def test_only_the_stale_record_is_recovered_when_a_recent_one_exists(self):
        x = world(); crash_before_send(x, 1); x.e.clock.sleep(5000); crash_before_send(x, 2); r = x.svc.recover_stale_sent(x.ctx, 3600)
        self.assertEqual((r["recovered"], r["not_stale"]), (["act-0001"], 1)); self.assertEqual((x.state(1), x.state(2)), ("FAILED", "SENT"))
    def test_only_SENT_records_are_considered(self):
        x = world(); x.svc.submit(x.ctx, mk_action(1)); x.svc.submit(x.ctx, mk_action(2)); x.svc.dispatch(x.ctx, "act-0002")                              # act-0001 stays QUEUED, act-0002 COMPLETED
        x.sysA.faults.push("write", ("timeout_before",)); x.svc.submit(x.ctx, mk_action(3)); x.svc.dispatch(x.ctx, "act-0003")                           # UNKNOWN_OUTCOME
        x.e.clock.sleep(99999); before = [x.state(i) for i in (1, 2, 3)]; r = x.svc.recover_stale_sent(x.ctx, 3600); self.assertEqual(before, ["QUEUED", "COMPLETED", "UNKNOWN_OUTCOME"]); self.assertEqual(([x.state(i) for i in (1, 2, 3)], r), (before, {"recovered": [], "reconciled": {}, "not_stale": 0, "skipped": [], "problems": []}))      # they are not even looked at
    def test_another_tenant_cannot_recover_this_tenants_records(self):
        x = world(); crash_before_send(x); x.e.clock.sleep(4000); r = x.svc.recover_stale_sent(x.e.B, 3600); self.assertEqual((r["recovered"], r["not_stale"]), ([], 0)); self.assertEqual(x.state(1), "SENT")
    def test_a_record_that_moved_on_between_the_listing_and_the_transition_is_skipped_not_corrupted(self):
        x = world(); crash_before_send(x); x.e.clock.sleep(4000); led = x.svc.ledger; orig = led.transition
        def moved(*a, **k): raise IllegalTransition("COMPLETED -> UNKNOWN_OUTCOME")
        led.transition = moved; r = x.svc.recover_stale_sent(x.ctx, 3600); led.transition = orig; self.assertEqual((r["recovered"], r["skipped"], r["problems"]), ([], ["act-0001"], [])); self.assertEqual(x.state(1), "SENT")
    def test_a_record_whose_integration_cannot_be_resolved_is_reported_and_left_alone(self):
        x = world(); crash_before_send(x); x.e.clock.sleep(4000); x.res.h.clear(); r = x.svc.recover_stale_sent(x.ctx, 3600)
        self.assertEqual(r["recovered"], []); self.assertEqual(len(r["problems"]), 1); self.assertEqual(r["problems"][0]["action_id"], "act-0001"); self.assertEqual(x.state(1), "SENT")
    def test_a_failure_while_reconciling_is_reported_not_raised_and_the_record_stays_UNKNOWN_OUTCOME_with_nothing_sent(self):
        x = world(); crash_after_apply(x); x.e.clock.sleep(4000); real = x.svc.reconcile
        def down(ctx, aid): raise RuntimeError("the lookup is down")
        x.svc.reconcile = down; r = x.svc.recover_stale_sent(x.ctx, 3600); x.svc.reconcile = real
        self.assertEqual((r["recovered"], r["reconciled"]), (["act-0001"], {})); self.assertEqual(len(r["problems"]), 1); self.assertIn("RuntimeError", r["problems"][0]["problem"]); self.assertEqual((x.state(1), len(x.sysA.effects), writes(x)), ("UNKNOWN_OUTCOME", 1, []))
        x.svc.reconcile(x.ctx, "act-0001"); self.assertEqual((x.state(1), len(x.sysA.effects), writes(x)), ("COMPLETED", 1, []))                    # the normal reconciliation can finish it later
    def test_the_threshold_must_be_a_positive_finite_number(self):
        x = world()
        for bad in (0, -1, -0.5, True, False, "3600", None, [3600], math.nan, math.inf, -math.inf, 3600j):
            with self.subTest(repr(bad)), self.assertRaises(AuifError): x.svc.recover_stale_sent(x.ctx, bad)
        x.svc.recover_stale_sent(x.ctx, 1); x.svc.recover_stale_sent(x.ctx, 0.5)
class TestTargetThatCannotBeQueried(unittest.TestCase):
    def build_b(self, x):
        sb = TF.SystemB(); x.e.secrets.put("tenant-a", TF.REF, "db-password-B"); rt = x.e.runtime(TF.SyntheticDatabaseConnector(sb, TF.REF)); fp = TF.fingerprint(sb.metadata())["value"]; pb = TF.pack_b([fp]); x.reg.register(pb)
        x.res.h["manifest-b"] = TF.Handle(rt, {"id": pb["pack_id"], "version": "1.0.0", "hash": pb["artifact_hash"]}, "int-b", "synthetic-system-b"); return sb, x.res.h["manifest-b"].runtime
    def test_without_a_lookup_the_record_goes_to_operator_review_and_is_never_sent(self):
        x = world(); sb, rt = self.build_b(x); crash_before_send(x, 1, rt=rt, cid="party:synthetic-system-b:2", manifest="manifest-b", target="synthetic-system-b"); x.e.clock.sleep(4000)
        r = x.svc.recover_stale_sent(x.ctx, 3600); rec = x.svc.ledger.get(x.ctx, "act-0001")
        self.assertEqual((r["recovered"], r["reconciled"]), (["act-0001"], {"act-0001": "RECONCILIATION_REQUIRED"})); self.assertEqual(rec["reconciliation"]["strategy"], "OPERATOR_REVIEW"); self.assertIn("OPERATOR_REVIEW_REQUIRED", events(x)); self.assertEqual((len(sb.effects), writes(x)), (0, []))
        x.svc.operator_resolve(x.ctx, "act-0001", False, {"evidence_id": "op-ev-1"}); self.assertEqual(x.state(1), "FAILED"); self.assertEqual((len(sb.effects), writes(x)), (0, []))
if __name__ == "__main__": unittest.main()

"""Restart safety: a new runtime over the SAME persisted store must resume the integration without re-activating it and without losing the manifest binding or drift detection."""
import unittest
from auif.fabric import Fabric
from synthetic.connectors import SyntheticRestConnector
from synthetic.modules import module_one, module_two
from synthetic.world import World, ref
A = "tenant-a"
class TestRestart(unittest.TestCase):
    def setUp(self):
        self.w = World(); self.w.activate_all(); self.a = self.w.ctx[A]; self.sa = self.w.sys[A]["A"]; self.old = self.w.integrations[(A, "rest")]; self.old_ref = self.old.manifest_ref()
        w = self.w; self.f2 = Fabric(store=w.store, authority=w.auth, secrets=w.secrets, governor=w.gov, policy=w.policy, clock=w.clock, telemetry=w.tel, ids=w.ids, model=w.model, packs=w.packs, throttle=w.th)
        self.m1 = module_one(); self.f2.register_module(self.m1); self.f2.register_module(module_two())
        self.c2 = self.f2.add_integration(self.a, "ia-rest", anchor_module="synthetic-module-1", connector=SyntheticRestConnector(self.sa, "secretref:synthetic/rest"), pack_ref=ref(w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", governed_operations=["updateAccount"], entities=["Account", "Property"])
    def test_restored_integration_is_ACTIVE_with_the_same_manifest_and_no_revalidation(self):
        self.assertEqual(self.c2.state(), "ACTIVE"); self.assertEqual(self.c2.manifest_ref(), self.old_ref); self.assertEqual(self.c2.fp, self.old.fp)
    def test_restored_integration_can_sync_immediately(self): self.assertEqual(self.f2.sync(self.a, "ia-rest", "Account")["delivered"], 7); self.assertEqual(len(self.m1.by_tenant[A]["entities"]), 7)
    def test_restored_integration_still_detects_drift_against_the_persisted_baseline(self):
        self.sa.drift_rename_field("Account", "profile.name", "profile.full_name"); ev = self.c2.check_drift(); self.assertIsNotNone(ev); self.assertEqual(self.c2.state(), "SCHEMA_DRIFT"); self.assertEqual(ev["technically_affected_operations"], ["listAccounts", "updateAccount"])
    def test_a_never_activated_integration_rehydrates_to_nothing(self):
        c = self.f2.add_integration(self.a, "ia-new", anchor_module="synthetic-module-1", connector=SyntheticRestConnector(self.sa, "secretref:synthetic/rest"), pack_ref=ref(self.w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", entities=["Account"]); self.assertEqual(c.state(), "(none)"); self.assertIsNone(c.fp)

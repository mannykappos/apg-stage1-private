"""Audit round 1 regression tests (independent audit of rev2). One class per finding.
F1 transform validation | F2 malformed proposer output | F3 resolution-evidence provenance | F4 restart/resume discovery coverage | F5 hostile DATA values (found while fixing F1)."""
import copy, unittest
from auif.ai_boundary import AIMappingService, MappingProposer, PromotionRefused, MAX_PROPOSALS
from auif.contracts import validate
from auif.discovery import fingerprint
from auif.errors import *
from auif.fabric import Fabric
from auif.translation import PackRegistry, apply_transform, pack_hash, transform_problems
from auif.util import sha
from synthetic.ai_stub import ScriptedProposer
from synthetic.connectors import SyntheticRestConnector
from synthetic.modules import module_one, module_two
from synthetic.packs import pack_a
from synthetic.world import World, ref
A = "tenant-a"; NAME, BAL, STATUS = ("Account.profile.name", "Party.display_name"), ("Account.balance_cents", "Party.balance"), ("Account.status", "Party.lifecycle_state")
def T(kind, **p): return {"kind": kind, "parameters": p, "deterministic": True}
def cand(pair, tr, mid="ai-t", state="CANDIDATE"): return {"mapping_id": mid, "kind": "FIELD", "source_ref": pair[0], "canonical_ref": pair[1], "mapping_state": state, "proposed_by": "AI_ASSISTED", "inbound": {"source_type": "string", "canonical_type": "STRING", "transform": tr}, "outbound": {"supported": False, "reason": "AI-proposed mapping is inbound-only until promoted"}}
class Out(MappingProposer):
    def __init__(self, out): self.out = out
    def propose(self, sandbox): return self.out
class Base(unittest.TestCase):
    def setUp(self): self.w = World(); self.w.activate_all(); self.rec = self.w.integrations[(A, "rest")].last_record; self.svc = AIMappingService(ScriptedProposer([]), self.w.model, self.w.ids)
    def propose(self, out): return AIMappingService(Out(out), self.w.model, self.w.ids).propose(self.rec)
GOOD = {"source_ref": NAME[0], "canonical_ref": NAME[1], "transform": T("IDENTITY")}
# ------------------------------------------------------------------------------------------------------------------------------- F1
BAD = [("UNIT_CONVERT no factor", "in", T("UNIT_CONVERT")), ("UNIT_CONVERT factor 0", "in", T("UNIT_CONVERT", factor=0)), ("UNIT_CONVERT factor '0'", "in", T("UNIT_CONVERT", factor="0")), ("UNIT_CONVERT NaN", "in", T("UNIT_CONVERT", factor="NaN")), ("UNIT_CONVERT sNaN", "in", T("UNIT_CONVERT", factor="sNaN")),
       ("UNIT_CONVERT Infinity", "in", T("UNIT_CONVERT", factor="Infinity")), ("UNIT_CONVERT float inf", "in", T("UNIT_CONVERT", factor=float("inf"))), ("UNIT_CONVERT bool", "in", T("UNIT_CONVERT", factor=True)), ("UNIT_CONVERT text", "in", T("UNIT_CONVERT", factor="abc")), ("UNIT_CONVERT list", "in", T("UNIT_CONVERT", factor=[1])),
       ("UNIT_CONVERT huge exponent", "in", T("UNIT_CONVERT", factor="1e999")), ("UNIT_CONVERT tiny exponent", "in", T("UNIT_CONVERT", factor="1e-999")), ("UNIT_CONVERT decimals -1", "in", T("UNIT_CONVERT", factor=2, decimals=-1)), ("UNIT_CONVERT decimals True", "in", T("UNIT_CONVERT", factor=2, decimals=True)),
       ("UNIT_CONVERT decimals 11", "in", T("UNIT_CONVERT", factor=2, decimals=11)), ("UNIT_CONVERT decimals str", "in", T("UNIT_CONVERT", factor=2, decimals="2")), ("UNIT_CONVERT decimals float", "in", T("UNIT_CONVERT", factor=2, decimals=2.5)),
       ("DET_FUNC no params", "in", T("DETERMINISTIC_FUNCTION")), ("DET_FUNC unknown name", "in", T("DETERMINISTIC_FUNCTION", **{"in": "no_such_fn"})), ("DET_FUNC non-string name", "in", T("DETERMINISTIC_FUNCTION", **{"in": 5})), ("DET_FUNC out-only function used inbound", "in", T("DETERMINISTIC_FUNCTION", **{"in": "decimal_to_cents"})),
       ("DET_FUNC in-only function used outbound", "out", T("DETERMINISTIC_FUNCTION", out="cents_to_decimal")), ("DET_FUNC wrong direction key", "out", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"})), ("DET_FUNC builtin name", "in", T("DETERMINISTIC_FUNCTION", **{"in": "eval"})),
       ("FORMAT no op", "in", T("FORMAT")), ("FORMAT unknown op", "in", T("FORMAT", op="reverse")), ("FORMAT non-string op", "in", T("FORMAT", op=5)), ("CONSTANT no value", "in", T("CONSTANT")), ("CONSTANT list value", "in", T("CONSTANT", value=[1])), ("CONSTANT dict value", "in", T("CONSTANT", value={"a": 1})),
       ("ENUM_MAP map not a dict", "in", T("ENUM_MAP", map="x")), ("ENUM_MAP empty", "in", T("ENUM_MAP", map={})), ("ENUM_MAP int keys", "in", T("ENUM_MAP", map={1: "a"})), ("ENUM_MAP None value", "in", T("ENUM_MAP", map={"a": None})), ("ENUM_MAP list value", "in", T("ENUM_MAP", map={"a": [1]})),
       ("ENUM_MAP not invertible outbound", "out", T("ENUM_MAP", map={"a": "X", "b": "X"})), ("IDENTITY stray parameter", "in", T("IDENTITY", evil="x")), ("RENAME stray parameter", "in", T("RENAME", to="x")), ("unsupported kind COMPOSE", "in", T("COMPOSE")), ("unsupported kind SPLIT", "in", T("SPLIT")),
       ("unknown kind", "in", T("EVAL", code="x")), ("kind is not a string", "in", {"kind": ["IDENTITY"], "parameters": {}, "deterministic": True}), ("kind is a dict", "in", {"kind": {"a": 1}, "parameters": {}, "deterministic": True}), ("kind is None", "in", {"kind": None, "parameters": {}, "deterministic": True}), ("kind is an int", "in", {"kind": 5, "parameters": {}, "deterministic": True}), ("parameters not an object", "in", {"kind": "IDENTITY", "parameters": "x", "deterministic": True}), ("not marked deterministic", "in", {"kind": "IDENTITY", "parameters": {}, "deterministic": False}),
       ("deterministic missing", "in", {"kind": "IDENTITY", "parameters": {}}), ("unknown top-level field", "in", dict(T("IDENTITY"), extra=1)), ("transform is None", "in", None), ("transform is a string", "in", "IDENTITY"), ("transform is a list", "in", [])]
GOODS = [("UNIT_CONVERT 0.01", "in", T("UNIT_CONVERT", factor="0.01", decimals=2)), ("UNIT_CONVERT int factor", "out", T("UNIT_CONVERT", factor=100, decimals=0)), ("UNIT_CONVERT float factor", "in", T("UNIT_CONVERT", factor=0.5)), ("DET_FUNC in", "in", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"})),
         ("DET_FUNC out", "out", T("DETERMINISTIC_FUNCTION", out="decimal_to_cents")), ("FORMAT upper", "in", T("FORMAT", op="upper")), ("CONSTANT", "in", T("CONSTANT", value="x")), ("ENUM_MAP", "in", T("ENUM_MAP", map={"a": "X", "b": "X"})), ("ENUM_MAP invertible outbound", "out", T("ENUM_MAP", map={"a": "X", "b": "Y"})),
         ("IDENTITY", "in", T("IDENTITY")), ("RENAME", "out", T("RENAME"))]
PROMOTE_BAD = [(BAL, T("UNIT_CONVERT")), (BAL, T("UNIT_CONVERT", factor=0)), (BAL, T("UNIT_CONVERT", factor="NaN")), (BAL, T("DETERMINISTIC_FUNCTION", **{"in": "no_such_fn"})), (BAL, T("DETERMINISTIC_FUNCTION")), (BAL, T("DETERMINISTIC_FUNCTION", **{"in": "decimal_to_cents"})), (NAME, T("FORMAT", op="reverse")),
               (NAME, T("FORMAT")), (NAME, T("CONSTANT")), (STATUS, T("ENUM_MAP", map="x")), (STATUS, T("ENUM_MAP", map={})), (NAME, T("IDENTITY", evil="x")), (NAME, T("COMPOSE")), (NAME, None), (NAME, "IDENTITY")]
class TestF1_TransformValidation(Base):
    def test_every_malformed_transform_is_reported_as_a_problem(self):
        for label, d, tr in BAD:
            with self.subTest(label): self.assertTrue(transform_problems(tr, d), label)
    def test_well_formed_transforms_pass_so_the_check_is_not_simply_refusing_everything(self):
        for label, d, tr in GOODS:
            with self.subTest(label): self.assertEqual(transform_problems(tr, d), [], label)
    def test_promote_refuses_each_malformed_transform_and_never_returns_VALIDATED(self):
        for pair, tr in PROMOTE_BAD:
            with self.subTest(str(tr)[:60]):
                with self.assertRaises(PromotionRefused): self.svc.promote(cand(pair, tr), self.rec)
    def test_the_two_audit_reproductions(self):
        with self.assertRaises(PromotionRefused): self.svc.promote(cand(BAL, T("UNIT_CONVERT")), self.rec)                                    # was: VALIDATED then KeyError 'factor'
        with self.assertRaises(PromotionRefused): self.svc.promote(cand(BAL, T("DETERMINISTIC_FUNCTION", **{"in": "no_such_fn"})), self.rec)  # was: VALIDATED
    def test_proposals_carrying_malformed_transforms_never_become_candidates(self):
        out = self.propose([dict(GOOD, source_ref=p[0], canonical_ref=p[1], transform=tr) for p, tr in PROMOTE_BAD]); self.assertEqual(out["candidates"], []); self.assertEqual(len(out["rejected"]), len(PROMOTE_BAD))
    def test_semantic_mismatches_between_transform_and_types_are_refused(self):
        for label, pair, tr in (("FORMAT on an integer source", ("Account.balance_cents", "Party.display_name"), T("FORMAT", op="upper")), ("UNIT_CONVERT on a string source", ("Account.profile.name", "Party.balance"), T("UNIT_CONVERT", factor=2)), ("UNIT_CONVERT into a non-decimal", ("Account.balance_cents", "Party.display_name"), T("UNIT_CONVERT", factor=2)),
                                ("cents_to_decimal on a string source", ("Account.profile.name", "Party.balance"), T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"})), ("ENUM_MAP onto a non-enum", NAME, T("ENUM_MAP", map={"a": "x"})), ("CONSTANT outside the canonical enum", STATUS, T("CONSTANT", value="BOGUS")), ("CONSTANT of the wrong type", NAME, T("CONSTANT", value=5))):
            with self.subTest(label):
                with self.assertRaises(PromotionRefused): self.svc.promote(cand(pair, tr), self.rec)
    def test_type_rules_reachable_end_to_end_an_integer_source_into_an_enum_is_refused_for_numeric_transforms(self):
        for label, tr in (("UNIT_CONVERT into an ENUM", T("UNIT_CONVERT", factor=2)), ("cents_to_decimal into an ENUM", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}))):
            with self.subTest(label):
                with self.assertRaises(PromotionRefused) as e: self.svc.promote(cand(("Account.balance_cents", "Party.lifecycle_state"), tr), self.rec)
                self.assertTrue(any(w in str(e.exception) for w in ("yields a decimal", "does not produce canonical")), str(e.exception))
    def test_each_semantic_rule_is_enforced_directly_independent_of_the_generic_compatibility_table(self):
        sem = self.svc.validator._semantic; el = lambda t: {"detail": {"type": t}}; cd = lambda t, **c: dict({"type": t}, **({"constraints": c} if c else {}))
        for label, args, want in (("FORMAT on a non-string source", ("FORMAT", {"op": "upper"}, el("integer"), cd("STRING"), "Party", "display_name", "integer", "STRING"), "FORMAT needs a string source"), ("FORMAT into a non-text canonical", ("FORMAT", {"op": "upper"}, el("string"), cd("INTEGER"), "Party", "x", "string", "INTEGER"), "FORMAT yields text"),
                                  ("UNIT_CONVERT into INTEGER", ("UNIT_CONVERT", {"factor": 2}, el("integer"), cd("INTEGER"), "Party", "x", "integer", "INTEGER"), "UNIT_CONVERT yields a decimal"), ("UNIT_CONVERT from a string", ("UNIT_CONVERT", {"factor": 2}, el("string"), cd("DECIMAL"), "Party", "balance", "string", "DECIMAL"), "UNIT_CONVERT needs a numeric source"),
                                  ("function from a wrong source type", ("DETERMINISTIC_FUNCTION", {"in": "cents_to_decimal"}, el("string"), cd("DECIMAL"), "Party", "balance", "string", "DECIMAL"), "does not accept"), ("function into a wrong canonical type", ("DETERMINISTIC_FUNCTION", {"in": "cents_to_decimal"}, el("integer"), cd("INTEGER"), "Party", "x", "integer", "INTEGER"), "does not produce")):
            with self.subTest(label): self.assertTrue(any(want in x for x in sem(*args)), (label, sem(*args)))
        self.assertEqual(sem("UNIT_CONVERT", {"factor": 2}, el("integer"), cd("DECIMAL"), "Party", "balance", "integer", "DECIMAL"), []); self.assertEqual(sem("FORMAT", {"op": "upper"}, el("string"), cd("STRING"), "Party", "display_name", "string", "STRING"), [])
    def test_valid_promotions_succeed_verify_and_actually_execute(self):
        cases = [(BAL, T("UNIT_CONVERT", factor="0.01", decimals=2), 12345, "123.45"), (BAL, T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), 2000, "20.00"), (NAME, T("FORMAT", op="upper"), "abc", "ABC"), (NAME, T("CONSTANT", value="fixed"), "ignored", "fixed"), (NAME, T("IDENTITY"), "same", "same"),
                 (STATUS, T("ENUM_MAP", map={"act": "ACTIVE", "sus": "INACTIVE", "cls": "ARCHIVED"}), "sus", "INACTIVE")]
        for i, (pair, tr, val, want) in enumerate(cases):
            with self.subTest(str(tr)[:50]):
                m = self.svc.promote(cand(pair, tr, mid="ai-ok%d" % i), self.rec); validate("translation#Mapping", m); self.assertEqual((m["mapping_state"], m["deterministic_validation_performed"]), ("VALIDATED", True)); self.assertTrue(self.svc.verify_promotion(m)); self.assertEqual(apply_transform(m["inbound"]["transform"], val, "in"), want)
    def test_a_tampered_promoted_mapping_no_longer_verifies(self):
        m = self.svc.promote(cand(NAME, T("FORMAT", op="upper")), self.rec); self.assertTrue(self.svc.verify_promotion(m))
        for label, mut in (("transform changed", lambda x: x["inbound"]["transform"]["parameters"].update(op="lower")), ("canonical changed", lambda x: x.update(canonical_ref="Party.contact_email")), ("source changed", lambda x: x.update(source_ref="Account.profile.email")), ("evidence hash changed", lambda x: x["validation_ref"].update(evidence_hash="0" * 64)), ("evidence id changed", lambda x: x["validation_ref"].update(evidence_id="val-forged")), ("validation_ref removed", lambda x: x.pop("validation_ref"))):
            with self.subTest(label): t = copy.deepcopy(m); mut(t); self.assertFalse(self.svc.verify_promotion(t))
    def test_pack_registry_refuses_a_malformed_transform_on_an_executable_mapping_whoever_proposed_it(self):
        fp = fingerprint(self.w.sys[A]["A"].metadata())["value"]
        for label, mut in (("UNIT_CONVERT without a factor", lambda m: m["inbound"].update(transform=T("UNIT_CONVERT"))), ("unknown function", lambda m: m["inbound"].update(transform=T("DETERMINISTIC_FUNCTION", **{"in": "nope"}))), ("stray parameter", lambda m: m["inbound"].update(transform=T("IDENTITY", x=1))),
                           ("non-invertible outbound enum", lambda m: m["outbound"].update(transform=T("ENUM_MAP", map={"a": "X", "b": "X"})))):
            with self.subTest(label):
                p = pack_a([fp]); p["pack_version"] = "8.0.0"; target = next(m for m in p["mappings"] if m["mapping_id"] == ("a-status" if "outbound" in label else "a-balance")); mut(target); p["artifact_hash"] = pack_hash(p)
                with self.assertRaises(PackError): PackRegistry().register(p)
    def test_an_ai_mapping_marked_validated_with_a_forged_or_tampered_evidence_is_refused_by_the_registry(self):
        fp = fingerprint(self.w.sys[A]["A"].metadata())["value"]; svc = self.svc; m = svc.promote(cand(NAME, T("FORMAT", op="upper"), mid="ai-reg"), self.rec); reg = PackRegistry(ai_promotion_verifier=svc.verify_promotion)
        def pack(mapping, ver): p = pack_a([fp]); p["pack_version"] = ver; p["mappings"].append(mapping); p["artifact_hash"] = pack_hash(p); return p
        reg.register(pack(m, "8.1.0")); t = copy.deepcopy(m); t["inbound"]["transform"]["parameters"]["op"] = "lower"
        with self.assertRaises(PackError): reg.register(pack(t, "8.2.0"))
# ------------------------------------------------------------------------------------------------------------------------------- F2
class BadDict(dict):
    def get(self, *a): raise RuntimeError("hostile get")
class TestF2_MalformedProposerOutput(Base):
    SHAPES = [("a string member (audit case)", ["not a dict"]), ("None", None), ("a dict, not a list", {"a": 1}), ("a bare string", "oops"), ("a number", 5), ("a generator", None), ("[None]", [None]), ("[[1, 2]]", [[1, 2]]), ("[5]", [5]), ("[True]", [True]), ("an empty dict member", [{}]), ("missing source_ref", [{"canonical_ref": NAME[1], "transform": T("IDENTITY")}]),
              ("missing canonical_ref", [{"source_ref": NAME[0], "transform": T("IDENTITY")}]), ("missing transform", [{"source_ref": NAME[0], "canonical_ref": NAME[1]}]), ("source_ref int", [dict(GOOD, source_ref=5)]), ("source_ref list", [dict(GOOD, source_ref=[NAME[0]])]), ("source_ref empty", [dict(GOOD, source_ref="")]),
              ("canonical_ref None", [dict(GOOD, canonical_ref=None)]), ("transform string", [dict(GOOD, transform="IDENTITY")]), ("transform None", [dict(GOOD, transform=None)]), ("transform list", [dict(GOOD, transform=[])]), ("transform kind list", [dict(GOOD, transform={"kind": ["IDENTITY"], "parameters": {}, "deterministic": True})]),
              ("transform parameters string", [dict(GOOD, transform={"kind": "IDENTITY", "parameters": "x", "deterministic": True})]), ("alternatives a string", [dict(GOOD, alternatives="abc")]), ("alternatives of ints", [dict(GOOD, alternatives=[1, 2])]), ("alternatives with empty", [dict(GOOD, alternatives=[""])]), ("alternatives None", [dict(GOOD, alternatives=None)]),
              ("alternatives too many", [dict(GOOD, alternatives=["Party.contact_email"] * 11)]), ("__proto__ key", [dict(GOOD, **{"__proto__": {"a": 1}})]), ("deeply nested", [dict(GOOD, rationale={"a": {"a": {"a": {"a": {"a": {"a": {"a": {"a": 1}}}}}}}})]), ("control characters", [dict(GOOD, rationale="x\x00y")]), ("huge string", [dict(GOOD, rationale="x" * 5000)]),
              ("non-string key", [{1: "x"}]), ("bytes member", [b"bytes"]), ("a set member", [{1, 2}])]
    def test_no_malformed_output_escapes_the_boundary_and_none_becomes_a_candidate(self):
        for label, out in self.SHAPES:
            with self.subTest(label):
                if label == "a generator": out = (x for x in [GOOD])
                r = self.propose(out); self.assertEqual(r["candidates"], [], label); self.assertTrue(r["rejected"] or r["flags"], "something must be recorded: " + label); self.assertEqual(set(r), {"candidates", "rejected", "flags", "instruction_like_fields"})
    def test_one_bad_proposal_never_affects_the_good_ones(self):
        r = self.propose(["junk", GOOD, None, dict(GOOD, transform=T("UNIT_CONVERT")), BadDict(GOOD), dict(GOOD, source_ref="Account.profile.email", canonical_ref="Party.contact_email")])
        self.assertEqual([c["source_ref"] for c in r["candidates"]], [NAME[0], "Account.profile.email"]); self.assertEqual(len(r["rejected"]), 4)
        self.assertTrue(any("could not be processed" in x for rj in r["rejected"] for x in rj["problems"]))      # the hostile object that raises inside processing is isolated, not fatal
    def test_rejection_reasons_are_precise_not_just_present(self):
        why = lambda out: " | ".join(x for rj in self.propose(out)["rejected"] for x in rj["problems"])
        for label, out, want in (("non-object members", ["s", None, [1], 5, True], "is not an object"), ("alternatives a string", [dict(GOOD, alternatives="abc")], "alternatives must be"), ("alternatives ints", [dict(GOOD, alternatives=[1, 2])], "alternatives must be"), ("alternatives empty member", [dict(GOOD, alternatives=[""])], "alternatives must be"),
                                 ("alternatives too many", [dict(GOOD, alternatives=["Party.contact_email"] * 11)], "alternatives must be"), ("alternatives None", [dict(GOOD, alternatives=None)], "alternatives must be"), ("source_ref wrong type", [dict(GOOD, source_ref=5)], "source_ref must be"), ("canonical_ref wrong type", [dict(GOOD, canonical_ref=None)], "canonical_ref must be"),
                                 ("transform wrong type", [dict(GOOD, transform="IDENTITY")], "transform is not an object"), ("untrusted input", [dict(GOOD, **{"__proto__": 1})], "untrusted input")):
            with self.subTest(label): self.assertIn(want, why(out))
    def test_a_tuple_of_proposals_is_accepted(self): self.assertEqual(len(self.propose((GOOD,))["candidates"]), 1)
    def test_an_oversized_proposal_list_is_truncated_and_flagged(self):
        r = self.propose([GOOD] * (MAX_PROPOSALS + 20)); self.assertLessEqual(len(r["candidates"]), MAX_PROPOSALS); self.assertTrue(any("only the first" in f for f in r["flags"]))
    def test_every_hostile_claimed_state_is_discarded_and_never_applied(self):
        for cs in ("VALIDATED", "TRUSTED", "validated", "CANDIDATE", {"a": 1}, ["VALIDATED"], 5, True, "x" * 50):
            with self.subTest(str(cs)[:20]):
                r = self.propose([dict(GOOD, claimed_state=cs)]); self.assertEqual(len(r["candidates"]), 1); self.assertEqual(r["candidates"][0]["mapping_state"], "CANDIDATE"); self.assertTrue(any("claimed state" in f for f in r["flags"]))
        r = self.propose([dict(GOOD, claimed_state="y" * 5000)]); self.assertEqual(r["candidates"], [])                                           # oversize: rejected outright as untrusted input
    def test_candidates_are_contract_valid_deterministic_and_carry_truthful_types(self):
        r = self.propose([GOOD, dict(GOOD, source_ref=STATUS[0], canonical_ref=STATUS[1], transform=T("ENUM_MAP", map={"act": "ACTIVE", "sus": "INACTIVE", "cls": "ARCHIVED"}))])
        for c in r["candidates"]: validate("translation#Mapping", c); self.assertTrue(c["inbound"]["transform"]["deterministic"]); self.assertEqual(c["mapping_state"], "CANDIDATE")
        self.assertEqual([(c["inbound"]["source_type"], c["inbound"]["canonical_type"]) for c in r["candidates"]], [("string", "STRING"), ("string", "ENUM")])
    def test_candidate_parameters_are_copied_so_the_proposer_cannot_mutate_them_afterwards(self):
        p = dict(GOOD, transform=T("FORMAT", op="upper"), source_ref=NAME[0]); r = self.propose([p]); p["transform"]["parameters"]["op"] = "lower"; self.assertEqual(r["candidates"][0]["inbound"]["transform"]["parameters"]["op"], "upper")
    def test_a_proposer_that_raises_is_still_handled(self):
        class Boom(MappingProposer):
            def propose(self, s): raise MemoryError("x")
        self.assertEqual(AIMappingService(Boom(), self.w.model, self.w.ids).propose(self.rec)["candidates"], [])
    def test_promote_and_resolve_also_refuse_malformed_mapping_objects_without_crashing(self):
        for bad in (None, "x", [], {}, {"mapping_id": 5}, dict(cand(NAME, T("IDENTITY")), inbound=None), dict(cand(NAME, T("IDENTITY")), inbound={"transform": "x"}), dict(cand(NAME, T("IDENTITY")), source_ref=None)):
            with self.subTest(str(bad)[:40]):
                with self.assertRaises(PromotionRefused): self.svc.promote(bad, self.rec)
                with self.assertRaises(PromotionRefused): self.svc.resolve_ambiguity(bad, "x", {"evidence_id": "e", "evidence_hash": "a" * 64})
# ------------------------------------------------------------------------------------------------------------------------------- F3
EV = {"evidence_id": "ticket-42", "evidence_hash": "c" * 64}
class TestF3_ResolutionEvidence(Base):
    def ambiguous(self, svc=None, alts=("Party.contact_email",)):
        svc = svc or self.svc; svc.proposer = ScriptedProposer([dict(GOOD, alternatives=list(alts))]); m = svc.propose(self.rec)["candidates"][0]; self.assertEqual(m["mapping_state"], "AMBIGUOUS"); return m
    def test_evidence_survives_resolution_and_promotion_in_a_hash_bound_chain(self):
        m = self.ambiguous(); r = self.svc.resolve_ambiguity(m, NAME[1], EV); p = self.svc.promote(r, self.rec); ch = self.svc.resolution_chain(p)
        self.assertEqual(ch["ambiguity_resolution"], {"mapping_id": m["mapping_id"], "source_ref": NAME[0], "candidate_meanings": [NAME[1], "Party.contact_email"], "chosen": NAME[1], "resolution_evidence": EV}); self.assertTrue(ch["bound_to_validation_record"])
        self.assertEqual(ch["validation_ref"]["evidence_hash"], sha(self.svc.records[ch["validation_ref"]["evidence_id"]])); self.assertTrue(self.svc.verify_promotion(p))
    def test_the_promoted_mapping_stays_contract_valid_because_the_contract_has_no_field_for_the_evidence(self):
        p = self.svc.promote(self.svc.resolve_ambiguity(self.ambiguous(), NAME[1], EV), self.rec); validate("translation#Mapping", p); self.assertNotIn("ticket-42", str(sorted(p)))
        self.assertIn("additionalProperties", str(__import__("json").load(open("contracts/translation.schema.json"))["$defs"]["Mapping"]))      # documents WHY: Mapping is closed (finding F-4)
    def test_different_resolution_evidence_yields_a_different_validation_record(self):
        a = self.svc.promote(self.svc.resolve_ambiguity(self.ambiguous(), NAME[1], EV), self.rec); s2 = AIMappingService(ScriptedProposer([]), self.w.model, self.w.ids); b = s2.promote(s2.resolve_ambiguity(self.ambiguous(s2), NAME[1], {"evidence_id": "ticket-43", "evidence_hash": "d" * 64}), self.rec)
        self.assertNotEqual(a["validation_ref"]["evidence_hash"], b["validation_ref"]["evidence_hash"])
    def test_a_different_resolved_meaning_is_what_gets_promoted_and_recorded(self):
        m = self.ambiguous(); r = self.svc.resolve_ambiguity(m, "Party.contact_email", EV); p = self.svc.promote(r, self.rec); self.assertEqual(p["canonical_ref"], "Party.contact_email"); self.assertEqual(self.svc.resolution_chain(p)["ambiguity_resolution"]["chosen"], "Party.contact_email")
    def test_tampering_with_the_ledger_or_the_record_breaks_verification(self):
        m = self.ambiguous(); p = self.svc.promote(self.svc.resolve_ambiguity(m, NAME[1], EV), self.rec); self.assertTrue(self.svc.verify_promotion(p)); mid = m["mapping_id"]
        saved = copy.deepcopy(self.svc.resolutions[mid]); self.svc.resolutions[mid]["resolution_evidence"]["evidence_id"] = "forged"; self.assertFalse(self.svc.verify_promotion(p)); self.svc.resolutions[mid] = saved; self.assertTrue(self.svc.verify_promotion(p))
        del self.svc.resolutions[mid]; self.assertFalse(self.svc.verify_promotion(p)); self.svc.resolutions[mid] = saved
        self.svc.records[p["validation_ref"]["evidence_id"]]["ambiguity_resolution"]["chosen"] = "x"; self.assertFalse(self.svc.verify_promotion(p))
    def test_an_ambiguous_mapping_cannot_be_promoted_without_resolution(self):
        m = self.ambiguous()
        with self.assertRaises(PromotionRefused): self.svc.promote(m, self.rec)
    def test_stripping_the_ambiguity_flag_does_not_bypass_resolution(self):
        m = self.ambiguous(); s = {k: v for k, v in m.items() if k != "ambiguity"}; s["mapping_state"] = "CANDIDATE"
        with self.assertRaises(PromotionRefused): self.svc.promote(s, self.rec)                      # was: promoted with no resolution at all
    def test_a_resolved_mapping_whose_meaning_is_changed_afterwards_cannot_be_promoted(self):
        r = self.svc.resolve_ambiguity(self.ambiguous(), NAME[1], EV); r["canonical_ref"] = "Party.contact_email"
        with self.assertRaises(PromotionRefused): self.svc.promote(r, self.rec)
    def test_resolution_input_is_validated(self):
        m = self.ambiguous()
        for label, ev in (("None", None), ("empty", {}), ("no hash", {"evidence_id": "e"}), ("no id", {"evidence_hash": "a" * 64}), ("short hash", {"evidence_id": "e", "evidence_hash": "abc"}), ("uppercase hash", {"evidence_id": "e", "evidence_hash": "A" * 64}), ("hash not a string", {"evidence_id": "e", "evidence_hash": 5}), ("id not a string", {"evidence_id": 5, "evidence_hash": "a" * 64}), ("empty id", {"evidence_id": "", "evidence_hash": "a" * 64}), ("long id", {"evidence_id": "e" * 129, "evidence_hash": "a" * 64}), ("a string", "evidence")):
            with self.subTest(label):
                with self.assertRaises(PromotionRefused): self.svc.resolve_ambiguity(m, NAME[1], ev)
        with self.assertRaises(PromotionRefused): self.svc.resolve_ambiguity(m, "Party.not_a_candidate", EV)
        with self.assertRaises(PromotionRefused): self.svc.resolve_ambiguity(cand(NAME, T("IDENTITY")), NAME[1], EV)               # only AMBIGUOUS mappings can be resolved
    def test_re_resolving_identically_is_idempotent_and_differently_is_refused(self):
        m = self.ambiguous(); self.svc.resolve_ambiguity(m, NAME[1], EV); self.svc.resolve_ambiguity(m, NAME[1], EV)
        with self.assertRaises(PromotionRefused): self.svc.resolve_ambiguity(m, "Party.contact_email", EV)
        with self.assertRaises(PromotionRefused): self.svc.resolve_ambiguity(m, NAME[1], {"evidence_id": "other", "evidence_hash": "e" * 64})
# ------------------------------------------------------------------------------------------------------------------------------- F4
class TestF4_RestartResumeDiscoveryCoverage(unittest.TestCase):
    def setUp(self):
        self.w = World(); self.w.activate_all(); self.a = self.w.ctx[A]; self.sa = self.w.sys[A]["A"]; self.old = self.w.integrations[(A, "rest")]; self.old_rec = copy.deepcopy(self.old.last_record)
    def fabric(self):
        w = self.w; f = Fabric(store=w.store, authority=w.auth, secrets=w.secrets, governor=w.gov, policy=w.policy, clock=w.clock, telemetry=w.tel, ids=w.ids, model=w.model, packs=w.packs, throttle=w.th); f.register_module(module_one()); f.register_module(module_two()); return f
    def restart(self, iid="ia-rest"):
        return self.fabric().add_integration(self.a, iid, anchor_module="synthetic-module-1", connector=SyntheticRestConnector(self.sa, "secretref:synthetic/rest"), pack_ref=ref(self.w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", governed_operations=["updateAccount"], entities=["Account", "Property"])
    def latest(self): return self.w.store.get(self.a, "discovery_latest", "ia-rest")["discovery_record_id"]
    def drop_coverage(self): orig = self.sa.metadata; self.sa.metadata = lambda: {k: v for k, v in orig().items() if k not in ("entities", "operations")}
    def reasons(self, c): return self.w.store.get(self.a, "integration_diagnostics", c.current()["diagnostics_ref"]["evidence_id"])["reasons"]
    def test_rehydrate_restores_the_persisted_discovery_record(self):
        c2 = self.restart(); self.assertIsNotNone(c2.last_record); self.assertEqual(c2.last_record, self.old_rec); self.assertEqual(c2.last_record["discovery_record_id"], self.latest()); self.assertEqual(c2.state(), "ACTIVE")
    def test_a_never_activated_integration_has_no_record(self): self.assertIsNone(self.restart("ia-never").last_record)
    def test_a_missing_tampered_or_foreign_persisted_record_is_ignored_not_trusted(self):
        rid = self.latest(); good = self.w.store.get(self.a, "discovery_records", rid)
        for label, bad in (("target changed", dict(good, target_system_id="some-other-system")), ("environment changed", dict(good, environment_id="env-production")), ("tenant changed", dict(good, tenant_id="tenant-b")), ("contract-invalid", {k: v for k, v in good.items() if k != "coverage"}), ("authority forged", dict(good, authority="VALIDATED"))):
            with self.subTest(label): self.w.store.put(self.a, "discovery_records", rid, bad); self.assertIsNone(self.restart().last_record, label)
        self.w.store.put(self.a, "discovery_records", rid, good); self.assertIsNotNone(self.restart().last_record)
        self.w.store.put(self.a, "discovery_latest", "ia-rest", {"discovery_record_id": "disc-does-not-exist"}); self.assertIsNone(self.restart().last_record)         # dangling pointer
    def test_the_gate_fails_closed_when_there_is_no_discovery_record(self):
        c = self.restart(); c.suspend("audit"); c._fire("RESUMED_BY_ACTOR", "rule-resume", {}); self.assertEqual(c.state(), "VALIDATING"); c.raw = {"entities": [], "operations": []}; c.last_record = None
        c._validate_phase(); self.assertEqual(c.state(), "TRANSLATION_INVALID"); self.assertIn("no discovery record", " ".join(self.reasons(c)))                  # was: absence treated as 'nothing missing'
    def test_the_gate_still_passes_with_a_complete_record(self):
        c = self.restart(); c.suspend("audit"); self.assertEqual(c.resume()["state"], "ACTIVE")
    def test_suspend_then_resume_takes_and_persists_a_fresh_record_and_returns_to_active(self):
        before = self.old.last_record["discovery_record_id"]; mv = self.old.manifest_ref()["version"]; self.old.suspend("audit"); st = self.old.resume()
        self.assertEqual(st["state"], "ACTIVE"); self.assertNotEqual(self.old.last_record["discovery_record_id"], before); self.assertEqual(self.latest(), self.old.last_record["discovery_record_id"]); self.assertEqual(self.old.last_record["schema_fingerprint"], fingerprint(self.sa.metadata()))
        self.assertNotEqual(self.old.manifest_ref()["version"], mv); self.assertTrue(all(st["trust_basis"].values()))
    def test_process_restart_then_suspend_then_resume(self):
        c2 = self.restart(); restored = c2.last_record["discovery_record_id"]; c2.suspend("audit"); self.assertEqual(c2.state(), "SUSPENDED"); st = c2.resume(); self.assertEqual(st["state"], "ACTIVE"); self.assertNotEqual(c2.last_record["discovery_record_id"], restored); self.assertEqual(self.latest(), c2.last_record["discovery_record_id"])
    def test_resume_after_restart_with_insufficient_coverage_is_refused_even_though_the_restored_record_looked_fine(self):
        c2 = self.restart(); self.assertEqual(set(c2.last_record["coverage"]["obtained_kinds"]) >= {"ENTITY", "FIELD", "OPERATION"}, True); c2.suspend("audit"); self.drop_coverage(); mref = c2.manifest_ref(); st = c2.resume()
        self.assertEqual(st["state"], "TRANSLATION_INVALID"); self.assertIn("discovery coverage insufficient", " ".join(self.reasons(c2))); self.assertFalse(st["trust_basis"]["manifest_validated"]); self.assertEqual(c2.manifest_ref(), mref)
        self.assertNotIn("ENTITY", c2.last_record["coverage"]["obtained_kinds"]); self.assertEqual(self.latest(), c2.last_record["discovery_record_id"]); self.assertFalse(c2.operation_allowed("updateAccount", False))
    def test_resume_without_a_restart_with_insufficient_coverage_is_refused(self):
        self.old.suspend("audit"); self.drop_coverage(); st = self.old.resume(); self.assertEqual(st["state"], "TRANSLATION_INVALID"); self.assertIn("discovery coverage insufficient", " ".join(self.reasons(self.old)))
    def test_a_failed_rediscovery_on_resume_is_a_failure_not_a_pass(self):
        self.old.suspend("audit"); self.sa.faults.push("discover", *([("unavailable",)] * 10)); st = self.old.resume(); self.assertEqual(st["state"], "CONNECTION_FAILED"); self.assertFalse(st["trust_basis"]["manifest_validated"])
    def test_recovery_from_a_connection_failure_rebuilds_the_record_before_returning_to_active(self):
        before = self.old.last_record["discovery_record_id"]; self.sa.faults.push("discover", *([("unavailable",)] * 10)); self.assertIsNone(self.old.check_drift()); self.assertEqual(self.old.state(), "CONNECTION_FAILED"); self.sa.faults.q.clear(); st = self.old.activate()
        self.assertEqual(st["state"], "ACTIVE"); self.assertNotEqual(self.old.last_record["discovery_record_id"], before); self.assertEqual(self.latest(), self.old.last_record["discovery_record_id"])
    def test_recovery_with_insufficient_coverage_is_refused(self):
        self.sa.faults.push("discover", *([("unavailable",)] * 10)); self.old.check_drift(); self.sa.faults.q.clear(); self.drop_coverage(); st = self.old.activate(); self.assertEqual(st["state"], "TRANSLATION_INVALID")
    def test_pack_upgrade_path_also_judges_a_fresh_record(self):
        p = pack_a([fingerprint(self.sa.metadata())["value"]]); p["pack_version"] = "1.0.7"; p["artifact_hash"] = pack_hash(p); self.w.packs.register(p); rid = self.old.last_record["discovery_record_id"]
        d = self.old.propose_pack_upgrade(ref(p)); st = self.old.apply_pack_upgrade(ref(p), d); self.assertEqual(st["state"], "ACTIVE"); self.assertNotEqual(self.old.last_record["discovery_record_id"], rid)
# ------------------------------------------------------------------------------------------------------------------------------- F5
class TestF5_HostileDataValues(Base):
    def test_a_valid_transform_given_a_hostile_value_is_an_explicit_translation_failure_never_a_crash(self):
        for label, tr, val in (("cents_to_decimal text", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), "abc"), ("cents_to_decimal list", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), [1]), ("cents_to_decimal None", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), None), ("cents_to_decimal float is refused not truncated", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), 12.7), ("cents_to_decimal bool", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), True), ("cents_to_decimal decimal text", T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), "1e3"), ("dollars_to_decimal NaN", T("DETERMINISTIC_FUNCTION", **{"in": "dollars_to_decimal"}), "NaN"), ("dollars_to_decimal Infinity", T("DETERMINISTIC_FUNCTION", **{"in": "dollars_to_decimal"}), "Infinity"), ("dollars_to_decimal bool", T("DETERMINISTIC_FUNCTION", **{"in": "dollars_to_decimal"}), True), ("FORMAT on int", T("FORMAT", op="upper"), 5), ("FORMAT on None", T("FORMAT", op="strip"), None),
                               ("UNIT_CONVERT text", T("UNIT_CONVERT", factor=2), "x"), ("UNIT_CONVERT NaN", T("UNIT_CONVERT", factor=2), "NaN"), ("UNIT_CONVERT Infinity", T("UNIT_CONVERT", factor=2), "Infinity"), ("UNIT_CONVERT huge", T("UNIT_CONVERT", factor=2), "1e999999"), ("UNIT_CONVERT dict", T("UNIT_CONVERT", factor=2), {"a": 1}),
                               ("ENUM_MAP unhashable", T("ENUM_MAP", map={"a": "X"}), [1]), ("ENUM_MAP unknown value", T("ENUM_MAP", map={"a": "X"}), "zzz")):
            with self.subTest(label):
                with self.assertRaises(TranslationFailure): apply_transform(tr, val, "in")
    def test_outbound_functions_also_refuse_non_finite_and_non_numeric_values(self):
        for fn, val in (("decimal_to_cents", "NaN"), ("decimal_to_cents", "Infinity"), ("decimal_to_cents", True), ("decimal_to_cents", [1]), ("decimal_to_dollars", "NaN"), ("decimal_to_dollars", None)):
            with self.subTest("%s(%r)" % (fn, val)):
                with self.assertRaises(TranslationFailure): apply_transform(T("DETERMINISTIC_FUNCTION", out=fn), val, "out")
    def test_the_documented_good_values_still_convert_exactly(self):
        self.assertEqual(apply_transform(T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), 2000, "in"), "20.00"); self.assertEqual(apply_transform(T("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), "2000", "in"), "20.00"); self.assertEqual(apply_transform(T("DETERMINISTIC_FUNCTION", out="decimal_to_cents"), "20.00", "out"), 2000)
        self.assertEqual(apply_transform(T("DETERMINISTIC_FUNCTION", **{"in": "dollars_to_decimal"}), "10.5", "in"), "10.50"); self.assertEqual(apply_transform(T("UNIT_CONVERT", factor="0.01", decimals=2), 12345, "in"), "123.45"); self.assertEqual(apply_transform(T("UNIT_CONVERT", factor="0.01", decimals=2), "123.45", "out"), "12345.00")
    def test_outbound_with_a_value_that_cannot_be_transformed_is_an_outbound_validation_failure(self):
        for attrs in ({"balance": "abc"}, {"balance": "NaN"}, {"balance": [1]}):
            with self.subTest(str(attrs)):
                with self.assertRaises(OutboundValidationError): self.w.fabric.translator.translate_outbound(ref(self.w.pA), "Party", attrs)
    def test_one_hostile_record_does_not_destroy_the_batch(self):
        sa = self.w.sys[A]["A"]; sa.rows["Account"]["2"]["balance_cents"] = "abc"; sa.rows["Account"]["4"]["balance_cents"] = {"x": 1}; sa.rows["Account"]["5"]["profile"]["name"] = 12345
        rep = self.w.fabric.sync(self.w.ctx[A], "ia-rest", "Account"); self.assertEqual(rep["failed"], None); self.assertEqual((rep["delivered"], rep["invalid"]), (4, 3))                   # was: ValueError aborted the whole sync
        obs = [o for _, o in self.w.store.list(self.w.ctx[A], "observations") if o["source_object"]["object_type"] == "Account"]; self.assertEqual(len(obs), 7)
    def test_a_runtime_given_a_malformed_transform_raises_pack_error_not_a_bare_key_error(self):
        for tr in (T("UNIT_CONVERT"), T("FORMAT"), T("DETERMINISTIC_FUNCTION"), T("CONSTANT")):
            with self.assertRaises(PackError): apply_transform(tr, 1, "in")
if __name__ == "__main__": unittest.main()

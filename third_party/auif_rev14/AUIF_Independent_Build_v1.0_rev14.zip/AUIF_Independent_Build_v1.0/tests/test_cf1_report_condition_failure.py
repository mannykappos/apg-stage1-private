"""CF-1 (rev9) regression: a failing Governor report must NEVER let an integration escape the drift state. rev6.1 to rev8 called report_condition unguarded BEFORE storing the drift evidence and firing the state change, so a raising or malformed report left the
integration ACTIVE and let governed writes run against a drifted target. Every way a report can fail is enumerated here; each must end in SCHEMA_DRIFT with the evidence stored, the consequence PENDING, and governed operations held."""
import unittest
import tests.test_acceptance as TA
import tests.test_action_flow as TF
NAME = "test_AT_05_drift_is_scoped_reported_to_governor_and_unaffected_operations_continue"
SIGNAL = "governor_report_unacknowledged"
class OkBut(dict): pass
class RaisingAttr:
    def get(self, *a): raise RuntimeError("get fails")
def world(report):
    t = TA.TestAT05_06_Drift_And_Pinning(NAME); t.setUp(); t.w.gov.report_condition = report; return t
def ev_of(t): return [v for _, v in t.w.store.list(t.a, "drift_evidence")]
def counter(t): return t.w.tel.counters.get((t.a.tenant_id, t.ctrl(TA.A, "rest").integration_id, SIGNAL), 0)
def raiser(exc):
    def f(ctx, cond): raise exc
    return f
def returner(v):
    def f(ctx, cond): return v
    return f
class TestAFailedReportNeverFailsOpen(unittest.TestCase):
    def check_held(self, t, status="PENDING"):
        c = t.ctrl(TA.A, "rest"); evs = ev_of(t)
        self.assertEqual(c.state(), "SCHEMA_DRIFT"); self.assertEqual(len(evs), 1); self.assertEqual(evs[0]["governance_consequence"]["status"], status); self.assertEqual(evs[0]["governance_consequence"]["determined_by"], "GOVERNOR")
        self.assertFalse(c.operation_allowed("updateAccount", True)); self.assertTrue(evs[0]["governed_operations_blocked"])
        r = t.f.request_action(t.a, "synthetic-module-1", TA.act(t.w, TA.A, 1, {"display_name": "Governed write after drift"}, gov=True)); self.assertEqual((r["execution_state"], len(t.sa.effects)), ("QUEUED", 0))      # a governed write waits
        for op in evs[0]["unaffected_operations_continue"]: self.assertTrue(c.operation_allowed(op, False), op)                                                                      # unaffected non-governed operations still continue
        return evs[0]
    def test_a_raising_report_is_an_unacknowledged_report(self):
        for exc in (RuntimeError("network"), KeyError("k"), ValueError("v"), TimeoutError("t"), OSError("o"), AttributeError("a"), TypeError("t"), ZeroDivisionError(), AssertionError("a"), type("Custom", (Exception,), {})("c")):
            with self.subTest(type(exc).__name__):
                t = world(raiser(exc)); t.drift(); self.check_held(t); self.assertEqual(counter(t), 1)
    def test_a_malformed_answer_is_an_unacknowledged_report(self):
        for ans in (None, "acknowledged", 5, 5.5, True, [], ["acknowledged"], (), {}, {"acknowledged": False}, {"acknowledged": None}, {"acknowledged": True}, {"acknowledged": True, "report_id": None}, {"acknowledged": True, "report_id": 5}, {"acknowledged": True, "report_id": ""},
                    {"acknowledged": True, "report_id": "bad id with spaces"}, {"acknowledged": True, "report_id": "x" * 129}, {"acknowledged": True, "report_id": "-leading"}, {"acknowledged": True, "report_id": "line\nbreak"}, {"acknowledged": True, "report_id": b"gov-1"},
                    {"acknowledged": 1, "report_id": "gov-1"}, {"acknowledged": "yes", "report_id": "gov-1"}, {"acknowledged": [True], "report_id": "gov-1"}, {"report_id": "gov-1"}, OkBut(acknowledged=True, report_id="gov-1"), RaisingAttr()):
            with self.subTest(repr(ans)[:60]):
                t = world(returner(ans)); t.drift(); self.check_held(t); self.assertEqual(counter(t), 1)
    def test_a_well_formed_acknowledgement_is_still_reported_and_is_not_counted_as_unacknowledged(self):
        for ack in ({"acknowledged": True, "report_id": "gov-report-1"}, {"acknowledged": True, "report_id": "G" + "x" * 127, "extra": "ignored"}):
            t = world(returner(ack)); t.drift(); e = self.check_held(t, "REPORTED"); self.assertEqual(e["governance_consequence"]["report_ref"]["evidence_id"], ack["report_id"]); self.assertEqual(counter(t), 0)
    def test_the_report_still_carries_the_same_condition_to_the_governor(self):
        seen = []
        def spy(ctx, cond): seen.append(cond); return {"acknowledged": True, "report_id": "gov-report-2"}
        t = world(spy); t.drift(); self.assertEqual(len(seen), 1); c = seen[0]; self.assertEqual((c["kind"], c["integration_id"]), ("MANIFEST_DRIFT", t.ctrl(TA.A, "rest").integration_id)); self.assertTrue({"drift_id", "affected_operations", "governed_operations_blocked", "current_fingerprint"} <= set(c))
    def test_the_unavailable_governor_path_is_unchanged(self):
        t = TA.TestAT05_06_Drift_And_Pinning(NAME); t.setUp(); t.w.gov.unavailable = True; t.drift(); self.check_held(t); self.assertEqual(counter(t), 1)
    def test_a_process_exit_is_not_swallowed(self):
        for exc in (KeyboardInterrupt(), SystemExit(2)):
            t = world(raiser(exc))
            with self.assertRaises(type(exc)): t.drift()
    def test_ungoverned_drift_makes_no_report_at_all(self):
        t = TA.TestAT05_06_Drift_And_Pinning(NAME); t.setUp(); calls = []; t.w.gov.report_condition = lambda ctx, cond: calls.append(cond) or {"acknowledged": True, "report_id": "x"}
        c = t.ctrl(TA.A, "rest")
        if c.governed_operations: c.governed_operations = []                      # make this integration ungoverned
        t.drift(); self.assertEqual(calls, [])
class TestOtherGovernorCallSitesFailClosed(unittest.TestCase):
    """The review of every Governor port call in the core (rev9): the other two call sites already fail closed, and this pins it."""
    def world(self): x = TF.ActBase("runTest") if False else type("W", (TF.ActBase,), {"runTest": lambda s: None})(); x.setUp(); return x
    def test_a_governor_that_raises_or_answers_badly_at_dispatch_leaves_the_action_queued_and_nothing_sent(self):
        for bad in (raiser(RuntimeError("down")), returner(None), returner("GRANTED"), returner({}), returner({"status": "GRANTED"}), returner({"status": "GRANTED", "decision_ref": "r"}), returner({"status": "GRANTED", "decision_hash": "h" * 64}), returner({"status": "UNKNOWN"}), returner({"status": "PENDING"})):
            with self.subTest(repr(bad)[:40]):
                x = self.world(); x.gov.request_decision = bad; x.svc.submit(x.ctx, TF.mk_action(1, governed=True))
                try: x.svc.dispatch(x.ctx, "act-0001")
                except Exception: pass
                self.assertEqual((x.state(1), len(x.sysA.effects)), ("QUEUED", 0))
    def test_a_pack_upgrade_proposal_to_a_failing_governor_changes_nothing(self):
        t = TA.TestAT05_06_Drift_And_Pinning(NAME); t.setUp(); c = t.ctrl(TA.A, "rest"); before = (c.state(), dict(c.pack_ref)); new = dict(c.pack_ref, version="9.9.9")
        t.w.gov.request_decision = raiser(RuntimeError("down"))
        with self.assertRaises(RuntimeError): c.propose_pack_upgrade(new)
        self.assertEqual((c.state(), dict(c.pack_ref)), before)
        with self.assertRaises(Exception): c.apply_pack_upgrade(new, decision={"status": "UNAVAILABLE"})
        self.assertEqual((c.state(), dict(c.pack_ref)), before)
if __name__ == "__main__": unittest.main()

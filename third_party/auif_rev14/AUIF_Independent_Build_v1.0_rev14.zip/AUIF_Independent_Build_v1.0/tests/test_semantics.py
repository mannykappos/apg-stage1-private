import copy, json, unittest
from tests.helpers import Env
from auif.canonical import CanonicalModel, verify_chain, top
from auif.contracts import validate
from auif.discovery import DiscoveryEngine, fingerprint, snapshot, detect_drift, structure
from auif.errors import *
from auif.translation import PackRegistry, Translator, pack_hash, compat_problems
from auif.util import Ids, sha
from synthetic.packs import *
from synthetic.systems import SystemA, SystemB, SystemC
class Base(unittest.TestCase):
    def setUp(self):
        self.e = Env(); self.ids = Ids(); self.sysA = SystemA(); self.fpA = fingerprint(self.sysA.metadata()); self.model = CanonicalModel(MODEL_DEF); self.reg = PackRegistry(); self.packA = pack_a([self.fpA["value"]]); self.reg.register(self.packA)
        self.tr = Translator(self.model, self.reg, self.ids, self.e.clock); self.ref = {"id": "synthetic-pack-a", "version": "1.0.0", "hash": self.packA["artifact_hash"]}
    def inbound(self, entity, rec, ref=None, sid="1"): return self.tr.translate_inbound(self.e.A, ref or self.ref, entity, rec, source_system="synthetic-system-a", observation_id="obs-1", schema_fingerprint=self.fpA["value"], source_id=sid)
class TestDiscovery(Base):
    def rec(self, raw=None): return DiscoveryEngine(self.e.clock, self.ids).build_record(self.e.A, "i1", "synthetic-system-a", "env-sandbox", {"id": "synthetic-rest-connector", "version": "1.0.0"}, raw or self.sysA.metadata())
    def test_record_is_contract_valid_unvalidated_and_distinguishes_not_exposed_from_not_obtained(self):
        r = self.rec(); self.assertEqual(r["authority"], "NOT_AUTHORITATIVE_UNTIL_VALIDATED"); self.assertIn("WEBHOOK_SUPPORT", r["coverage"]["not_exposed_kinds"]); self.assertEqual(r["record_state"], "COMPLETE")
        self.assertTrue(all(el["trust_state"] == "DISCOVERED" and el["state_set_by"] == "DISCOVERY" for el in r["elements"]))
        rb = DiscoveryEngine(self.e.clock, self.ids).build_record(self.e.A, "i2", "b", "env", {"id": "x", "version": "1.0.0"}, SystemB().metadata()); self.assertEqual(rb["record_state"], "PARTIAL"); self.assertIn("RATE_LIMIT", rb["coverage"]["not_obtained_kinds"])
    def test_discovery_cannot_produce_validated_or_trusted_elements(self):
        r = self.rec(); r["elements"][0]["trust_state"] = "TRUSTED"; r["elements"][0]["validation_evidence_ref"] = {"evidence_id": "e", "evidence_hash": "0" * 64}
        with self.assertRaises(ContractViolation): validate("discovery#SystemDiscoveryRecord", r)
    def test_fingerprint_is_deterministic_order_insensitive_and_ignores_volatile_fields(self):
        raw = self.sysA.metadata(); f1 = fingerprint(raw); raw2 = copy.deepcopy(raw); raw2["entities"].reverse(); raw2["operations"].reverse(); raw2["generated_at"] = "something else"; raw2["system_version"] = "9.9"
        self.assertEqual(f1["value"], fingerprint(raw2)["value"]); self.assertEqual(f1, fingerprint(self.sysA.metadata()))
    def test_fingerprint_changes_for_any_in_scope_change(self):
        base = fingerprint(self.sysA.metadata())["value"]
        for mut in (lambda r: r["entities"][0]["fields"].append({"name": "new", "type": "string"}), lambda r: r["entities"][0]["fields"][0].update({"type": "integer"}), lambda r: r["operations"].append({"name": "x", "kind": "read", "entities": []}), lambda r: r["events"].clear(), lambda r: r["auth_requirements"].update({"type": "other"}), lambda r: r["entities"][0]["fields"][3].update({"enum": ["act"]})):
            raw = copy.deepcopy(self.sysA.metadata()); mut(raw); self.assertNotEqual(fingerprint(raw)["value"], base)
    def drift(self, mutate):
        base_raw = self.sysA.metadata(); mutate(self.sysA); cur = self.sysA.metadata()
        return detect_drift(self.e.clock, self.ids, fingerprint(base_raw), fingerprint(cur), snapshot(base_raw), snapshot(cur), ["updateAccount"])
    def test_AT_05_drift_is_scoped_to_affected_operations_and_governed_ops_are_blocked(self):
        d = self.drift(lambda s: s.drift_rename_field("Account", "profile.name", "profile.full_name")); validate("integration#DriftEvidence", d)
        self.assertEqual(d["technically_affected_operations"], ["listAccounts", "updateAccount"]); self.assertEqual(d["unaffected_operations_continue"], ["listProperties", "updateProperty"]); self.assertTrue(d["governed_operations_blocked"]); self.assertEqual(d["governance_consequence"]["determined_by"], "GOVERNOR")
    def test_unrelated_entity_drift_does_not_block_governed_operations_on_other_entities(self):
        d = self.drift(lambda s: s.drift_add_field("Property", "new_col")); self.assertEqual(d["technically_affected_operations"], ["listProperties", "updateProperty"]); self.assertFalse(d["governed_operations_blocked"])
    def test_non_schema_version_change_is_not_drift(self): self.assertIsNone(self.drift(lambda s: s.drift_unrelated_change()))
    def test_fingerprints_with_different_canonicalization_are_not_comparable(self):
        f = fingerprint(self.sysA.metadata()); g = dict(f, canonicalization_id="other@1")
        with self.assertRaises(ValueError): detect_drift(self.e.clock, self.ids, f, g, snapshot(self.sysA.metadata()), snapshot(self.sysA.metadata()), [])
class TestCanonical(Base):
    def test_model_definition_validated_and_module_namespaces_separate_from_core(self): self.assertTrue(self.model.has("Party")); self.assertTrue(self.model.has("module.synthetic-module-2.Listing")); self.assertFalse(self.model.has("RealEstateListing"))
    def test_attribute_validation_types_required_and_unknown(self):
        self.assertEqual(self.model.problems("Party", {"display_name": "x"}), []); self.assertIn("required attribute display_name missing", self.model.problems("Party", {}))
        self.assertTrue(self.model.problems("Party", {"display_name": 5})); self.assertTrue(self.model.problems("Party", {"display_name": "x", "lifecycle_state": "BOGUS"})); self.assertTrue(self.model.problems("Party", {"display_name": "x", "mystery": 1}))
    def test_invalid_model_definition_rejected(self):
        bad = copy.deepcopy(MODEL_DEF); bad["concepts"][0]["attributes"] = []
        with self.assertRaises(ContractViolation): CanonicalModel(bad)
    def test_classification_precedence(self): self.assertEqual(top(["INTERNAL", "PII", "FINANCIAL"]), "FINANCIAL"); self.assertEqual(top(["INTERNAL", "x-custom"]), "x-custom")
class TestTranslationInbound(Base):
    def rec(self, i="1"): return copy.deepcopy(self.sysA.rows["Account"][i])
    def test_valid_translation_preserves_provenance_classification_and_field_outcomes(self):
        o = self.inbound("Account", self.rec("2"), sid="2"); self.assertEqual(o["validation_state"], "VALID"); self.assertEqual(o["attributes"], {"display_name": "Account 2", "contact_email": "acct2@example.invalid", "lifecycle_state": "ARCHIVED", "balance": "20.00"})
        self.assertEqual(o["attribute_classifications"]["contact_email"], "PII"); self.assertEqual(o["classification"], "FINANCIAL"); self.assertEqual(verify_chain(o["provenance_chain"], self.reg, self.fpA["value"]), [])
        outcomes = {f["source_field"]: f["outcome"] for f in o["field_outcomes"]}; self.assertEqual(outcomes["id"], "IGNORED_BY_RULE"); self.assertEqual(outcomes["audit_created_by"], "IGNORED_BY_RULE"); self.assertEqual(outcomes["profile.name"], "MAPPED")
    def test_AT_19_every_field_has_an_outcome_and_nothing_disappears(self):
        r = self.rec(); r["surprise_field"] = "x"; o = self.inbound("Account", r); got = {f["source_field"] for f in o["field_outcomes"]}
        from auif.translation import leaves
        self.assertTrue(set(leaves(r)) <= got); self.assertEqual({f["source_field"]: f["outcome"] for f in o["field_outcomes"]}["surprise_field"], "UNMAPPED")
    def test_AT_19_invalid_translation_never_fabricates_data(self):
        r = self.rec(); r["status"] = "zzz"; o = self.inbound("Account", r); self.assertEqual(o["validation_state"], "TRANSLATION_INVALID"); self.assertNotIn("attributes", o); self.assertTrue(o["diagnostics"]["reasons"])
        r2 = self.rec(); del r2["profile"]["name"]; o2 = self.inbound("Account", r2); self.assertEqual(o2["validation_state"], "TRANSLATION_INVALID"); self.assertNotIn("attributes", o2)
    def test_reject_policy_turns_unmapped_fields_into_translation_invalid(self):
        p = pack_a([self.fpA["value"]]); p["pack_version"] = "1.0.1"; p["unmapped_field_policy"] = dict(p["unmapped_field_policy"], default_outcome="REJECTED"); p["artifact_hash"] = pack_hash(p); self.reg.register(p); ref = {"id": p["pack_id"], "version": "1.0.1", "hash": p["artifact_hash"]}
        r = self.rec(); r["surprise"] = 1; self.assertEqual(self.inbound("Account", r, ref)["validation_state"], "TRANSLATION_INVALID")
    def test_AT_07_ambiguous_mapping_yields_ambiguous_object_with_no_authoritative_attributes(self):
        p = pack_a([self.fpA["value"]], "ambiguous"); self.reg.register(p); ref = {"id": p["pack_id"], "version": "1.1.0", "hash": p["artifact_hash"]}
        o = self.inbound("Account", self.rec(), ref); self.assertEqual(o["validation_state"], "AMBIGUOUS"); self.assertNotIn("attributes", o); self.assertIn("ambiguous", " ".join(o["diagnostics"]["reasons"]))
    def test_property_translation_and_unknown_entity(self):
        o = self.inbound("Property", copy.deepcopy(self.sysA.rows["Property"]["1"])); self.assertEqual(o["canonical_type"], "Property"); self.assertEqual(o["attributes"]["status"], "SOLD")
        with self.assertRaises(TranslationFailure): self.inbound("Nope", {"a": 1})
    def test_translation_is_deterministic(self):
        a = self.inbound("Account", self.rec(), sid="1"); b = self.inbound("Account", self.rec(), sid="1"); a.pop("diagnostics", None); self.assertEqual(json.dumps(a, sort_keys=True), json.dumps(b, sort_keys=True))
class TestTranslationOutbound(Base):
    def test_AT_04_roundtrip_both_directions(self):
        o = self.inbound("Account", copy.deepcopy(self.sysA.rows["Account"]["4"]), sid="4"); out, ev = self.tr.translate_outbound(self.ref, "Party", o["attributes"])
        self.assertEqual(out["entity"], "Account"); self.assertEqual(out["fields"]["status"], "sus"); self.assertEqual(out["fields"]["balance_cents"], 4000); self.assertEqual(out["fields"]["profile"]["name"], "Account 4"); self.assertGreater(ev["constraints_checked"], 3)
    def test_AT_04_outbound_violating_a_target_constraint_is_rejected_before_delivery(self):
        for attrs in ({"display_name": "x" * 101}, {"contact_email": "not-an-email"}, {"balance": "-5.00"}):
            with self.assertRaises(OutboundValidationError): self.tr.translate_outbound(self.ref, "Party", attrs)
    def test_outbound_to_read_only_or_unmapped_attributes_is_rejected(self):
        with self.assertRaises(OutboundValidationError) as e: self.tr.translate_outbound(self.ref, "Property", {"owner_ref": "x"}); self.assertIn("cannot be written", str(e.exception))
        with self.assertRaises(OutboundValidationError): self.tr.translate_outbound(self.ref, "Party", {"mystery": 1})
    def test_canonical_value_is_not_blindly_sent(self):
        out, _ = self.tr.translate_outbound(self.ref, "Party", {"lifecycle_state": "ARCHIVED"}); self.assertEqual(out["fields"]["status"], "cls")      # canonical ARCHIVED is "cls" for this target, never the canonical string
    def test_action_mapping_resolution(self): self.assertEqual(self.tr.action_mapping(self.ref, "synthetic.update_party"), {"operation": "updateAccount", "entity": "Account"}); self.assertRaises(TranslationFailure, self.tr.action_mapping, self.ref, "synthetic.nope")
class TestPackRegistry(Base):
    def test_AT_23_tampered_pack_refused_at_registration(self):
        p = copy.deepcopy(self.packA); p["pack_version"] = "1.0.9"; p["mappings"][2]["canonical_ref"] = "Party.contact_email"
        with self.assertRaises(PackError): self.reg.register(p)
    def test_AT_23_same_version_different_content_is_refused_immutability(self):
        p = copy.deepcopy(self.packA); p["mappings"][2]["canonical_ref"] = "Party.contact_email"; p["artifact_hash"] = pack_hash(p)
        with self.assertRaises(PackError): self.reg.register(p)
    def test_AT_23_post_registration_tampering_and_wrong_hash_detected_on_get(self):
        with self.assertRaises(PackError): self.reg.get("synthetic-pack-a", "1.0.0", "f" * 64)
        k = ("synthetic-pack-a", "1.0.0"); obj = json.loads(self.reg._s[k]); obj["mappings"][2]["canonical_ref"] = "Party.contact_email"; self.reg._s[k] = json.dumps(obj, sort_keys=True, separators=(",", ":"))
        with self.assertRaises(PackError): self.reg.get("synthetic-pack-a", "1.0.0", self.packA["artifact_hash"])
    def test_pack_with_governance_logic_or_secrets_is_rejected_by_contract(self):
        for k in ("contains_governance_logic", "contains_secrets"):
            p = copy.deepcopy(self.packA); p[k] = True; p["pack_version"] = "3.0.0"; p["artifact_hash"] = pack_hash(p)
            with self.assertRaises(ContractViolation): self.reg.register(p)
    def test_unregistered_pack_and_reregistering_identical_pack_is_idempotent(self):
        self.reg.register(self.packA); self.assertEqual(self.reg.versions("synthetic-pack-a"), ["1.0.0"]); self.assertRaises(PackError, self.reg.get, "ghost", "1.0.0", "0" * 64)
    def test_compat_check(self): self.assertEqual(compat_problems(self.packA, "0.1.0"), []); self.assertTrue(compat_problems(self.packA, "0.2.0")); self.assertTrue(compat_problems(self.packA, "0.1.0", "2.0.0"))
class TestProvenance(Base):
    def test_AT_22_chain_reconstructs_and_missing_or_wrong_links_are_detected(self):
        o = self.inbound("Account", copy.deepcopy(self.sysA.rows["Account"]["1"])); ch = o["provenance_chain"]; self.assertEqual(verify_chain(ch, self.reg, self.fpA["value"]), [])
        self.assertIn("missing OBSERVATION", verify_chain([s for s in ch if s["step_kind"] != "OBSERVATION"])); self.assertTrue(verify_chain(ch, self.reg, "f" * 64))
        bad = copy.deepcopy(ch); [s for s in bad if s["step_kind"] == "TRANSLATION_PACK"][0]["hash"] = "e" * 64; self.assertTrue(any("does not resolve" in p for p in verify_chain(bad, self.reg)))
    def test_canonical_object_without_provenance_is_contract_invalid(self):
        o = self.inbound("Account", copy.deepcopy(self.sysA.rows["Account"]["1"])); o["provenance_chain"] = []
        with self.assertRaises(ContractViolation): validate("canonical#CanonicalObject", o)

# UNRESOLVED_GOVERNOR_DECISIONS

These Governor-side decisions are OPEN and are NOT resolved by this build. AUIF isolates the interface and implements the audited DRAFT position only. Governor is unmodified.

## GD-01: Canonical Anchor Model versus Governor Neutral Model

- **Audited issue:** The handoff's Canonical Anchor Model and the locked Governor Neutral Model (the target of Normalize()) are separate models that share the names Observation, Resource, Change and Environment. Neither document defines their relationship.
- **Audited open decisions:** ["OD-01"]
- **Isolated in code at:** auif/canonical.py (framework only)
- **What AUIF does meanwhile:** AUIF keeps its own canonical model framework; it does not map into the Governor Neutral Model and defines no Governor-side translation.
- **Status:** OPEN (decision belongs to the owner / Governor side; not Amir)

## GD-02: Scope of 'authoritative' for the Integration Manifest

- **Audited issue:** Handoff section 33 calls the Integration Manifest authoritative for the integration configuration; the locked specification puts the Target Manifest at level 3 of the authority model and makes Declare() a proposal requiring Governor validation.
- **Audited open decisions:** ["OD-02"]
- **Isolated in code at:** auif/integration.py::_validate_phase; contracts/integration.schema.json (manifest_scope and governance_authority are constants)
- **What AUIF does meanwhile:** The manifest is INTEGRATION_CONFIGURATION with governance_authority NONE; the schema rejects anything else.
- **Status:** OPEN (decision belongs to the owner / Governor side; not Amir)

## GD-03: Who determines that governance is required, and decision-reference validity

- **Audited issue:** Neither document says who determines whether an action requires governance, what AUIF does when that is undetermined, or how long a Governor decision reference remains valid and who verifies it at the target.
- **Audited open decisions:** ["OD-03", "OD-04"]
- **Isolated in code at:** auif/action.py::ActionService.dispatch / submit; auif/ports.py::GovernorPort
- **What AUIF does meanwhile:** An action whose governance requirement is UNKNOWN is held and never sent; a decision reference supplied by a module is ignored and logged; decisions are obtained only from GovernorPort; AUIF carries ref and hash and never verifies or issues them.
- **Status:** OPEN (decision belongs to the owner / Governor side; not Amir)

## GD-04: Policy and authorisation source for data boundary enforcement

- **Audited issue:** Handoff section 24 requires policy and authorisation before data leaves the boundary but not where policy lives or how authorisation is requested.
- **Audited open decisions:** ["OD-09"]
- **Isolated in code at:** auif/ports.py::PolicyPort; auif/classification.py::BoundaryEnforcer
- **What AUIF does meanwhile:** Policy is an input port. Undeterminable policy for a datum means the whole payload is rejected; AUIF never authors policy.
- **Status:** OPEN (decision belongs to the owner / Governor side; not Amir)

## GD-05: Security of the AUIF to Governor interaction

- **Audited issue:** How AUIF authenticates to Governor and how the locked adapter authentication relates to AUIF's own operations is not defined.
- **Audited open decisions:** ["OD-04"]
- **Isolated in code at:** auif/ports.py::GovernorPort
- **What AUIF does meanwhile:** Only request_decision and report_condition exist. No authentication, signing or transport is implemented because none has been decided.
- **Status:** OPEN (decision belongs to the owner / Governor side; not Amir)

# BUILD_REPORT: AUIF Independent Build v1.0

**Status: reference implementation proven on a synthetic world. Not integrated with the Anchor Engine. Not production-ready. No Engine-dependent item is closed. Governor integration is not complete. Architecture lock status is unchanged (audited DRAFT).**

## 1. Measured results

| Measure | Result |
|---|---|
| Tests | 441 run, 441 passed, 0 failed |
| Mutation testing | 174 mutants, 174 killed, 0 survived, 0 invalid |
| Static checks | clean: True |
| Core tree sha256 | `923de5100f95debbbf63d5ab6e960cee2091ee57abce403792403ff049ac7839` |
| Python | 3.13.16 (standard library only) |
| Audited architecture package | sha256 `31cb5f988d1b04cf4c6edf37a6f53fe4e4ef3a0221d6e60c1d6bee4db7658f20` |

Line coverage of the core is in `RTM_IMPL_TO_TEST.md` and `evidence/coverage_by_core_file.json`. Coverage shows lines were executed, not that every behaviour was asserted; mutation results show the chosen safety-critical guards (see `evidence/mutation_results.json`) are tested, not that no defect exists elsewhere.

## 2. The three categories

- **BUILT BUT ENVIRONMENT-DEPENDENT** (10 of 30 acceptance tests): 01, 05, 12, 13, 20, 21, 24, 27, 29, 30
- **BUILT AND VERIFIED** (19 of 30 acceptance tests): 02, 03, 04, 06, 07, 08, 09, 10, 11, 14, 16, 17, 18, 19, 22, 23, 25, 26, 28
- **BLOCKED - AMIR REQUIRED** (1 of 30 acceptance tests): 15

Component-level status by architecture section is in `COMPONENT_STATUS.md`. AT-15 (the McGrath proof) is **not executed and not claimed**; a guard test asserts that.

## 3. Engine-dependent work (BLOCKED - AMIR REQUIRED)

**18 items**, each with the full set of required fields, in `AMIR_ENGINE_DEPENDENCY_TODO.md` / `.json` and in dependency order in `AMIR_HANDOFF.md`.

- Group 1: AMIR-TODO-01, AMIR-TODO-17
- Group 2: AMIR-TODO-02, AMIR-TODO-03, AMIR-TODO-07, AMIR-TODO-08, AMIR-TODO-09, AMIR-TODO-10, AMIR-TODO-11, AMIR-TODO-15, AMIR-TODO-18
- Group 3: AMIR-TODO-04, AMIR-TODO-05, AMIR-TODO-06, AMIR-TODO-12
- Group 4: AMIR-TODO-13, AMIR-TODO-14, AMIR-TODO-16

The first item (the Engine reconnaissance gate) gates the others, as the audited sequencing requires.

## 4. Remaining architectural decisions

- **Governor-side GD-01..GD-05** (5): open, isolated in code, not resolved. See `UNRESOLVED_GOVERNOR_DECISIONS.md`. These belong to the owner and the Governor side, not Amir.
- **Audited open decisions OD-01..OD-22** (22): remain open in the audited register. Draft positions were implemented where the audited draft gave one.
- **Design decisions D-1..D-19** made where the draft is silent: need ratification (`DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md`).
- **Findings F-1..F-4** against the audited draft (error-code gap, missing may-have-reached-target field, no `from_state` for creation, no field for ambiguity-resolution evidence): for the auditor. The audited package was not changed.

## 5. Provenance and verification caveat

Part of the tree was written by a process other than the executor of this report; this was observed, preserved, reviewed and recorded in `evidence/UNEXPLAINED_ARTEFACTS_STATUS.md`. The owner states they started one executor. Authorship of that part is still unestablished. The implementation has since been independently audited in three rounds (sections 6 to 8): the auditor re-ran the tests, static checks and replays, reviewed the code, and checked the preserved foreign-origin material for dangerous patterns. A complete line-by-line manual review of every foreign-origin file has not been done. Before packaging, the tree was copied to a private directory and the tests, static checks, mutation run and byte-comparison of the audited inputs and contracts were re-run there, with the results reported above. **The audit does not establish who wrote that part of the tree.**

## 6. Audit round 1 (independent audit of rev2): resolved and confirmed by the round-2 audit

| Finding | Class | Severity | Status |
|---|---|---|---|
| F1 The AI validator promoted malformed transforms (e.g. `UNIT_CONVERT` with `{}`, unknown function names) to VALIDATED | DEFECT | HIGH | Fixed: one shared, strict transform validator |
| F2 Malformed proposer output (e.g. `["not a dict"]`) escaped the AI boundary | DEFECT | HIGH | Fixed: proposer output is untrusted input at every level |
| F3 Ambiguity-resolution evidence was required, then discarded | DEFECT | MEDIUM | Fixed: hash-bound chain (the audited contract has no field for it: DESIGN GAP F-4) |
| F4 Restart/resume did not restore or rebuild the discovery record; the gate treated its absence as no missing coverage | DEFECT | MEDIUM | Fixed: persisted, restored and re-taken; the gate fails closed |
| F5 A hostile data VALUE crashed a whole sync (found by the executor while fixing F1) | DEFECT | HIGH | Fixed: explicit per-field failure |

Evidence: 51 new regression tests (F1: 12, F2: 10, F3: 10, F4: 13, F5: 6); 26 new mutants M43-M68, all killed; `tools/audit_round1_replay.py` passes 20/20 (the pre-fix code passes 2/20). Details, the exact production diff and the reasoning are in `AUDIT_ROUND1_RESOLUTION.md`. **The core tree hash changed INTENTIONALLY** (`089afcbd2579c16e75f53be942f99471399820bbaa0d53b71e028d2fa36a8357` to the value in section 1); three core files changed.

## 7. Audit round 2 (re-audit of rev3): resolved and confirmed by the round-3 audit

| Finding | Class | Severity | Status |
|---|---|---|---|
| F6 AI promotion evidence did not bind the complete mapping (author, kind, outbound, validation flag and state could change and still verify); the registry's AI check depended on the declared author | DEFECT | HIGH | Fixed: evidence binds the whole mapping and the registry recognises AI promotion by its evidence |
| F7 A persistence failure between the idempotency reservation and ledger creation stranded the action; failure at any of the writes left it stranded or silently stalled in CREATED | DEFECT | HIGH | Fixed: resumable write-ahead intent (`docs/ACTION_SUBMISSION_STATE_MACHINE.md`) |
| F8 AI evidence ledgers are in memory (known limitation 18) | DESIGN GAP | n/a | **OPEN, unchanged:** owner/Amir-dependent |

Evidence: 32 new regression tests in `tests/test_audit_round2.py`; 18 new mutants M69-M86, all 86 killed; `tools/audit_round2_replay.py` passes 17/17 (rev3 passes 5/17). Details: `AUDIT_ROUND2_RESOLUTION.md`. The core tree hash changed INTENTIONALLY again (see section 1); three core files changed.

## 8. Audit round 3 (final audit of rev5): F9 resolved; rev6 independently accepted (not frozen)

| Finding | Class | Severity | Status |
|---|---|---|---|
| F9 A CanonicalAction's `tenant_id` was not bound to the authenticated TenantContext: a mismatched action was accepted, the ledger was stamped with the context's tenant while the durable intent kept the submitted one, and tenant-a's action retried under tenant-b's context was accepted | DEFECT | HIGH | Fixed: checked before any write; defence in depth on recovery |

Evidence: 12 new regression tests in `tests/test_audit_round3.py`; 2 new mutants M87-M88; `tools/audit_round3_replay.py` passes 17/17 (rev5 passes 3/17). Production change: `auif/action.py` only (the core tree hash changed INTENTIONALLY, see section 1). Details: `AUDIT_ROUND3_RESOLUTION.md`.

## 9. Package integrity and revisions

**rev1** (superseded, zip sha256 `e88b50542dd8bcf687365c98892626ec2b248a37abcb71ffc8e9fee606ac3a8e`) had a package-integrity defect: running the test suite rewrote `evidence/performance_measurement.json`, so the manifest failed after a test run. **rev2** (superseded by rev3; zip sha256 `45c0df434384de5ec54521c0355dcbe38035a536e988c986c9dbf317cebd2f63`) fixed it (AT-29 and `mutation_test.py` write evidence only when asked; `tools/verify_fresh_zip.py` verifies the manifest after every step). **rev3** (superseded, preserved untouched) was the round-1 candidate; the round-2 audit found F6 and F7 in it. **rev4** (superseded; the clean rev4 candidate, zip sha256 `ffc2aeafa7a463af3fb6116f5c7ab8576df425d095741898787bd1061867531f`) carried the round-1 and round-2 fixes and passed the independent audit of F1-F7, but its shipped verifier's fixed 900 s mutation limit was shorter than the 86-mutant run, so it could not complete its own fresh-ZIP verification (a verification-tool limitation, not an implementation defect). **rev5** (preserved unchanged; zip sha256 `146cdfb6173c4245006f4050ba13633f831ad2dd366964d848b337696fdaa226`) is a TOOLING-ONLY correction of rev4 (the shipped verifier waits for the mutation run to finish; see `REV5_TOOLING_CORRECTION.md`); the independent audit accepted it. The same audit found F9, so rev5 is superseded by rev6, which has since been independently audited. **rev6** (zip sha256 `b7956f0094150cd49cf177a970f24a37bbe56e51b30bea425c7591e5111b5332`) carries the F9 fix (production change in `auif/action.py` only) and was accepted as the current reference implementation candidate; it is not frozen. **rev6.1** (this package) is a DOCUMENTATION-ONLY correction of rev6 made before handoff: no file under `auif/`, `contracts/`, `synthetic/`, `auif_ref/`, `port_contracts/` or `tests/` changed, and the core tree hash is identical to rev6's (see `DOCUMENTATION_CORRECTIONS_rev6.1.md`).

## 10. Exact next actions

1. **Released for handoff to Amir** after the independent audit (owner decision). Start with `AMIR_ENGINE_DEPENDENCY_TODO.md` and the accompanying full handoff document.
2. Done: rev6 was independently audited and accepted as the current reference candidate (not frozen); rev6.1 differs from it only in documentation (`DOCUMENTATION_CORRECTIONS_rev6.1.md`). rev7 adds the separate extension package of section 11 and changes no core file; it needs its own independent audit. rev9 REVISED the core in two files (section 12; independently audited and closed, as relayed to the builder by the owner) and rev10 REVISES it in one more file (section 13) and needs its own independent audit. Any further change to AUIF needs a new audit round.
3. Executor: any further finding is corrected in a new audited revision; none is open against F1 to F7 and F9.
4. Owner: ratify or amend D-1..D-19; route F-1..F-4 to the auditor; decide GD-01..GD-05 on the Governor side; rule on the in-memory AI evidence ledger (known limitations 18 and 25) and on the unattested human/tool validation claims (limitation 23).
5. The 18-item handoff to Amir contains only genuinely Engine-dependent work.
6. Confirm or stop any second executor still writing into the shared build folder.
7. Do not describe AUIF as integrated, production-ready or Governor-integrated until the evidence for those claims exists.


## 11. Extension package (carried from rev8; rev12 adds one optional tenant-header setting, section 15)

**rev10** carries rev8's extension package unchanged (it builds on the rev7 extension candidate, zip sha256 `62f5441934fea206a4c7f653a4a0608d0d5b5359678c26f233db9902a688d8d2`, whose independent audit results were relayed to the builder by the owner) on top of a core REVISED in three files across rev9 and rev10 (sections 12 and 13; `contracts/`, `synthetic/`, `auif_ref/` and `port_contracts/` are byte-identical to rev8's), plus a separate `auif_ext/` package (connector kit, module client, Governor adapter; see `AUIF_EXTENSIONS.md`), extension tools under `tools/`, and documentation additions (this section, the README rows, the extension sections of `KNOWN_LIMITATIONS.md` and `DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md`, and `evidence/EXT_PROVENANCE.md`). The extensions operationalise the existing core contracts; they do not mean the core was incomplete, and the REST / OAuth2, webhook and CSV / JSON implementations are the first extension implementations, not locked architecture requirements. **rev7 is a candidate awaiting independent audit; it is not frozen.**

| Evidence | Result |
|---|---|
| Core tree hash | `923de5100f95debbbf63d5ab6e960cee2091ee57abce403792403ff049ac7839` (equal to the audited core hash recorded in section 1) |
| Extension tests (always on) | **347 run, 20 skipped, ok=True** |
| Extension tests against the REAL Governor R14 (zip sha256 `e6f299ca51fc10d4a0a95ca2a9e3086c72aacff71b6a9bf8eb08587859c3ee42`) | **347 run, 0 skipped, ok=True** |
| Extension static checks | 16 files checked; import, Governor, network, real-system-name, forbidden-construct and authority-name violations: none |
| Reverse contamination | core tests with `auif_ext` removed: 441 run, ok=True |
| Extension mutation | **194 mutants run: 194 killed, 0 survived, 0 invalid**; 195 defined, of which E110 documented as equivalent and not run (`tools/mutation_ext.py`; one guard sabotaged per mutant; the always-on extension tests only) |

Not claimed: **no real external system is integrated** and every extension test ran against local loopback servers, so no connector is verified against a real system (AT-15 cannot be claimed); GD-05 / ED-11 is open, so the Governor adapter's decision delivery fails closed; R14 is a verified candidate, not a closed Governor, and the adapter is not Governor-integrated: it implements the contract and passes the AT-27 boundary checks against the R14 code only. See `KNOWN_LIMITATIONS.md` (Extension limitations E-1 to E-14) and `DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md` (D-20 to D-31), and the provenance record `evidence/EXT_PROVENANCE.md`.


## 12. rev9: core revision (CF-1 and CF-2)

rev9 revises the audited core in exactly two files, `auif/integration.py` (CF-1) and `auif/action.py` (CF-2), and adds two regression test files (`tests/test_cf1_report_condition_failure.py`, `tests/test_cf2_stale_sent_recovery.py`). `auif_ext/` is byte-identical to rev8's apart from one pinned core-hash literal in `auif_ext/tests/test_extension_boundary.py`. Details, what was NOT changed (CF-3 is accepted behaviour; CF-4 was recorded, not fixed, in rev9; rev10 fixes it, section 13) and how to read the evidence: `CHANGES_rev9.md`.

| Evidence | Result |
|---|---|
| rev9 core tree hash | `a18fd7aa98fdbb4a7ca28fa25b4b98275e2d2c3f3b100629a6300c46128e7146` (rev8's was `5f27396249ea4f036fbc51bc9dad69134389d667a46a9962e8948d819bdb84d9`); rev9 zip sha256 `5b8a15fc2a83b3860a0b4afa4ae6ee7932bd45c60716c5dad551981ef9d4617e` |
| Core tests (rev9, as audited) | **389 run, all passing** (rev8: 363) |
| Core mutation (rev9, as audited) | **114 mutants: 114 killed, 0 survived, 0 invalid** (rev8: 90; 24 new mutants guard the CF-1 and CF-2 code) |

rev9 was independently audited and closed as a core revision (the auditor's result was relayed to the builder by the owner; the builder does not certify closure). This section records its audited numbers; the current build's measured numbers are in section 13. Not claimed: production readiness, Engine integration, Governor integration, Layer 2 or any real-system behaviour. `KNOWN_LIMITATIONS.md` limitations 28 to 31 record the scope and the caveats.


_Sections 13 to 16 are reproduced from rev13's report and describe rev10 to rev13 as built (`docs/BUILD_REPORT_rev13_sections_13_to_16.md`). rev14's measured figures are in section 1 and section 17._
## 13. rev10: core revision (CF-4)

rev10 revises the audited rev9 core in exactly one file, `auif/action.py` (CF-4: `ActionService.recover_stale_acknowledged`), and adds one regression test file (`tests/test_cf4_stale_acknowledged_recovery.py`). `auif_ext/` is byte-identical to rev9's apart from one pinned core-hash literal in `auif_ext/tests/test_extension_boundary.py`. Details, what was NOT changed and how to read the evidence: `CHANGES_rev10.md`.

| Evidence | Result |
|---|---|
| rev10 core tree hash | `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d` (rev9's was `a18fd7aa98fdbb4a7ca28fa25b4b98275e2d2c3f3b100629a6300c46128e7146`) |
| Core tests (all of `tests/`, including the CF-4 regression tests) | **410 run, all passing** (rev9: 389) |
| Core mutation (`tools/mutation_test.py`) | **133 mutants: 133 killed, 0 survived, 0 invalid** (rev9: 114; 19 new mutants guard the CF-4 code) |

Not claimed: this is a core revision for independent audit, not a closure. Production readiness, Engine integration, Governor integration, Layer 2 and any real-system behaviour are all unclaimed. `KNOWN_LIMITATIONS.md` limitation 31 records the scope and its caveats.


## 14. rev11: the onboarding accelerator (`auif_onboard`)

rev11 adds a **drafting and review accelerator, not an onboarding authority**: Discover, Draft, Propose, Validate (synthetic only), Present for human approval. It generates a draft connector configuration from an OpenAPI/Swagger JSON document, a candidate translation pack through the existing mapping boundary, and a synthetic validation report; every mapping is a candidate until a named human approves it, and the generator cannot promote anything. Design, the approval model and the limitations are in `AUIF_ONBOARDING.md`; what changed is in `CHANGES_rev11.md`.

| Evidence | Result |
|---|---|
| Core tree hash | `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d` (equal to the pinned rev10 hash: True) |
| Frozen layers (`auif`, `auif_ext`, `auif_ref`, `synthetic`, `contracts`, `tests`, `port_contracts`) against the untouched rev10 extraction | 116 files identical; 1 changed, 1 added, 0 removed |
| Core tests | 410 run, all passing (unchanged) |
| Extension tests | 343 run, 20 skipped, all passing (unchanged) |
| Accelerator tests (`auif_onboard/tests`) | **418 run, all passing** |
| Accelerator mutation (`tools/mutation_onboard.py`) | **435 mutants run: 435 killed, 0 survived, 0 invalid**; 7 further mutants are documented as equivalent and are not run (each with its reason, in `evidence/mutation_onboard_results.json`) |
| Reverse contamination | with `auif_onboard` removed, 410 core and 343 extension tests still pass, static checks are clean and the core hash is unchanged: True |

Three materially different synthetic specifications, each drafted, validated against its own synthetic loopback vendor, and taken through a test-reviewer approval flow:

| Spec | Auth | Entities | Synthetic validation | Mappings approved (test reviewer) | Items left pending |
|---|---|---|---|---|---|
| crm_cursor_apikey | API_KEY | 2 | 14 PASS, 1 ATTENTION, 0 FAIL | 9 | 5 |
| helpdesk_link_swagger2 | API_KEY | 1 | 8 PASS, 1 ATTENTION, 0 FAIL | 3 | 5 |
| ledger_offset_oauth2 | OAUTH2_CLIENT_CREDENTIALS | 1 | 9 PASS, 2 ATTENTION, 0 FAIL | 5 | 3 |

A canary secret planted in every untrusted text field of the specifications appears in no artefact, ledger or report. The approvals in this evidence were made by a test reviewer inside the test suite: they demonstrate the mechanism, they are not approvals of anything. Not claimed: validation against any real system (a separate, gated phase that has not started and needs a named sandbox target), authentication of the human behind an approval, production readiness, Engine, Governor or Layer 2 integration. `KNOWN_LIMITATIONS.md` items O-1 onwards record the limitations.


## 15. rev12: fixes from the first real-API draft (tenant header, wrapped lists, entity exclusion)

rev12 closes the gaps that the first draft of a real vendor's published API description exposed (offline: no credential, no real system contacted). It changes **one optional setting of the REST connector** (`tenant_header` / `tenant_id`, extension layer) and the accelerator. The core, Governor, GD-05 and Layer 2 are untouched; rev11 is pinned. Findings, the approval recipe and the hypotheses the live phase must test are in `CHANGES_rev12.md`.

| Evidence | Result |
|---|---|
| Core tree hash | `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d` (equal to the pinned rev10 hash: True) |
| Layers against the untouched rev10 extraction | 116 files identical; changed: `auif_ext/connectors/rest.py`; added: `auif_ext/tests/test_rest_tenant.py`; removed: 0; any difference outside `auif_ext/`: 0 |
| Core tests | 410 run, all passing (unchanged) |
| Extension tests | 343 run, 20 skipped, all passing |
| Accelerator tests | **418 run, all passing** |
| Extension mutation | **187 mutants run: 187 killed, 0 survived, 0 invalid** (188 defined) |
| Accelerator mutation | **435 mutants run: 435 killed, 0 survived, 0 invalid**; 7 further mutants documented as equivalent and not run |
| Reverse contamination | with `auif_onboard` removed, 410 core and 343 extension tests still pass, core hash unchanged: True |

Not claimed: validation against any real system (the live phase is a separate, gated step), authentication of the human behind an approval, production readiness, Engine, Governor or Layer 2 integration. `KNOWN_LIMITATIONS.md` items E-20 and O-15 to O-23 record the limits.


## 16. rev13: one approval-consistency fix in the accelerator (audit finding REV12-AUD-01)

The independent audit of rev12 found that a reviewer could approve an outbound mapping and then approve a configuration that removes that entity's write endpoint, leaving an approved configuration (not writable) and an assembled pack (outbound enabled) that disagree. rev13 refuses such a configuration approval, for approved ENTITY, FIELD and ACTION outbound mappings, so the outcome no longer depends on the order of human decisions. The change is one guard in `auif_onboard/review.py`; the extension layer, the core, Governor, GD-05, Layer 2 and the frozen rev12 package are untouched. Details: `CHANGES_rev13.md`.

| Evidence | Result |
|---|---|
| Core tree hash | `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d` (equal to the pinned rev10 hash: True) |
| Accelerator tests | **418 run, all passing** (11 new, in `test_write_consistency.py`) |
| Accelerator mutation | **435 mutants run: 435 killed, 0 survived, 0 invalid**; 7 documented equivalents not run (8 new mutants for the guard) |

## 17. rev14: core revision (the six defects found while building APG-M8)

Building APG-M8 on the frozen rev13 found six defects in this build (M8-F1 to M8-F6). rev14 fixes them, on the owner's authorisation: a field reference into a MODULE concept is read as `<concept>.<attribute>` with the attribute after the LAST dot (inbound, outbound, the AI validator and the accelerator), and a malformed reference is refused when the pack is registered (F1); a source identity may be several fields, a content-hash identity must be declared, and a missing identity is a per-record error (F2); the module is told about every event that was not applied to it (F3); a module's failure to take a delivery is counted, recorded and told, never swallowed (F4); the sync report says whether the read reached the end (F5); sync reports instead of raising (F6). Details, the one changed existing test (an owner decision) and what was NOT changed: `CHANGES_rev14.md`. rev13 is preserved unchanged.

| Evidence | Result |
|---|---|
| rev14 core tree hash | `923de5100f95debbbf63d5ab6e960cee2091ee57abce403792403ff049ac7839` (rev10 to rev13: `74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d`) |
| Layers against the untouched rev13 extraction | 111 files identical; changed: `auif/ai_boundary.py`, `auif/canonical.py`, `auif/fabric.py`, `auif/integration.py`, `auif/translation.py`, `auif_ext/module_client/client.py`, `auif_ext/tests/test_extension_boundary.py`; added: `auif_ext/tests/test_rev14_module_client.py`, `tests/test_rev14_fixes.py`; removed: 0 |
| Core tests | **441 run, all passing** (rev13: 410) |
| Extension tests | **347 run, 20 skipped, all passing** (rev13: 343, 20 skipped) |
| Accelerator tests | **422 run, all passing** (rev13: 418) |
| Core mutation | **174 mutants: 174 killed, 0 survived, 0 invalid** (rev13: 133) |
| Extension mutation | **194 mutants run: 194 killed, 0 survived, 0 invalid** (195 defined) |
| Accelerator mutation | **437 mutants run: 437 killed, 0 survived, 0 invalid**; 7 documented equivalents not run |
| Reverse contamination | with `auif_onboard` removed, 441 core and 347 extension tests still pass, core hash unchanged: True |

Not claimed: acceptance (this revision awaits independent audit), production readiness, Engine, Governor or Layer 2 integration, or any real-system behaviour. APG-M8's deviation DEV-M8-01 is not ended by this revision; moving APG onto rev14 is separate work. `KNOWN_LIMITATIONS.md` items 32 to 40 record the limits.

"""Mutation testing of the safety-critical guards. Each mutant disables ONE guard in a temporary COPY of the tree; the full suite must then FAIL (mutant killed). A mutant that survives is reported with the reason it matters.
A mutant whose target text does not match exactly once is INVALID (never counted as killed)."""
import concurrent.futures, json, os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def failing_classes(stderr):
    """Names of the test classes that failed, parsed defensively: subtest labels may themselves contain parentheses and dots."""
    out = set()
    for l in stderr.splitlines():
        if l.startswith(("FAIL:", "ERROR:")):
            m = re.search(r"\(([\w.]+)\)", l)           # the FIRST '(dotted.path)' is the test id; later brackets are subtest labels
            if m and "." in m.group(1): out.add(m.group(1).split(".")[-2] if m.group(1).count(".") >= 2 else m.group(1))
    return sorted(out)[:4]
# rev10: recover_stale_sent (CF-2) and recover_stale_acknowledged (CF-4) share their validation lines; the CF-2 mutants are anchored on the text that follows the validation so each anchor still matches exactly once
V2 = 'raise AuifError("stale_after_seconds must be a positive, finite number of seconds")\n        cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"recovered"'
M = [  # (id, file, old, new, guard being tested)
 ("M01", "auif/connector.py", "if write and idem and not idempotency_key: raise AuifError(", "if False: raise AuifError(", "writes require an idempotency key"),
 ("M02", "auif/connector.py", 'maybe = write and e.applied in ("MAYBE", "UNKNOWN")', "maybe = False", "an uncertain write is never retried blindly"),
 ("M03", "auif/connector.py", "if e.retry_after is not None: delay = max(delay, float(e.retry_after))", "if False: delay = delay", "Retry-After is honoured"),
 ("M04", "auif/fabric.py", 'rep["failed"] = out.error["code"]; self._error(', 'rep["empty"] = True; (lambda *a, **k: None)(', "failure is never reported as empty"),
 ("M05", "auif/integration.py", "if not self._pack_gate(): return", "pass", "pack gate runs on every path into validation"),
 ("M06", "auif/integration.py", 'if cur["value"] not in expect:', "if False:", "ACTIVE requires the fingerprint the pack expects"),
 ("M07", "auif/translation.py", 'if pack_hash(pack) != pack["artifact_hash"] or pack["artifact_hash"] != expected_hash: raise PackError(', "if False: raise PackError(", "pack hash is verified on use and pin"),
 ("M08", "auif/tenancy.py", "def verify(self, ctx): return isinstance(ctx, TenantContext) and bool(ctx.tenant_id) and hmac.compare_digest(ctx.sig, self._sig(ctx.tenant_id, ctx.principal))", "def verify(self, ctx): return True", "tenant context is verified"),
 ("M09", "auif/translation.py", "if violations: raise OutboundValidationError(violations)", "if False: raise OutboundValidationError(violations)", "outbound validation before delivery"),
 ("M10", "auif/ai_boundary.py", '"mapping_state": "AMBIGUOUS" if r["ambiguous"] else "CANDIDATE"', '"mapping_state": p.get("claimed_state") or ("AMBIGUOUS" if r["ambiguous"] else "CANDIDATE")', "AI cannot set a mapping state"),
 ("M11", "auif/action.py", "        if governed:\n            resp = self.gov.request_decision(", "        if False:\n            resp = self.gov.request_decision(", "a governed action needs a Governor decision"),
 ("M12", "auif/action.py", 'if rec["execution_state"] != "QUEUED": return rec', 'if rec["execution_state"] not in ("QUEUED", "UNKNOWN_OUTCOME"): return rec', "no re-dispatch after an unknown outcome"),
 ('M13', 'auif/action.py', 'won = self.store.put(ctx, "action_idem", key, resv, if_absent=True)', 'won = self.store.put(ctx, "action_idem", key, resv, if_absent=False)', 'idempotency key is unique per tenant (the atomic reservation)'),
 ("M14", "auif/observation.py", 'if prev["payload_hash"] == h: return [self._decision(ev, "DUPLICATE_SUPPRESSED", aseq)]', 'if prev["payload_hash"] == h: return [self._decision(ev, "IN_ORDER", aseq)]', "duplicates are suppressed"),
 ("M15", "auif/security.py", "if k in FORBIDDEN_KEYS: reasons.append(", "if False: reasons.append(", "forbidden keys rejected"),
 ("M16", "auif/classification.py", 'reject = reject or "policy undeterminable for %s data to %s" % (cls, destination.get("kind")); per.append', "out[a] = v; per.append", "undeterminable policy never allows data"),
 ("M17", "auif/discovery.py", '"FIELDS": sorted("%s.%s:%s:%s"', '"FIELDS": [] and sorted("%s.%s:%s:%s"', "fingerprint covers fields"),
 ("M18", "auif/throttle.py", 'if s["half"] or s["fails"] >= self.thr:', "if False:", "circuit breaker opens"),
 ("M19", "auif/integration.py", "if self.governed_operations:                        # AUIF REPORTS", "if False:                        # AUIF REPORTS", "drift on a governed integration is reported to the Governor"),
 ("M20", "auif/integration.py", 'return (not governed) and op in c["drift_evidence"]["unaffected_operations_continue"]', 'return op in c["drift_evidence"]["unaffected_operations_continue"]', "governed operations are blocked during drift"),
 ("M21", "auif/fabric.py", 'if cur and cur["source_system"] != source_system and self.sot.get(obj["canonical_type"]) != source_system:', "if False:", "single owning source per canonical id"),
 ("M22", "auif/tenancy.py", "def get(self, ctx, c, k): self.auth.require(ctx); return self.inner.get(ctx, c, k)", "def get(self, ctx, c, k): return self.inner.get(ctx, c, k)", "persistence reads verify tenant context"),
 ("M23", "auif/observability.py", "if k.lower() in SENSITIVE or (isinstance(v, str) and len(v) > 200) or isinstance(v, (dict, list)):", "if False:", "telemetry redacts payload fields"),
 ("M24", "auif/action.py", 'if old["execution_state"] in TERMINAL: raise IllegalTransition("terminal record is immutable")', 'if False: raise IllegalTransition("terminal record is immutable")', "terminal ledger records are immutable"),
 ("M25", "auif/action.py", 'if st == "DENIED": return self._refuse(ctx, rec, "governance decision denied")', 'if False: return self._refuse(ctx, rec, "governance decision denied")', "a denied decision fails the action"),
 ("M26", "auif/translation.py", 'if key is None: raise TranslationFailure("unmapped enum value %r" % (value,))', "if key is None: return value", "an unmapped enum value is rejected at the transform"),
 ("M27", "auif/observation.py", 'or self.clock.now < p["deadline"]: continue', ": continue", "queued events wait for the bounded period"),
 ("M28", "auif/action.py", 'if gov["governance_required"] == "UNKNOWN": self.ledger.event(', 'if False: self.ledger.event(', "undetermined governance requirement holds the action"),
 ("M29", "auif/action.py", "if not h.operation_allowed(am[\"operation\"], governed):", "if False:", "integration state gates writes"),
 ("M30", "auif/integration.py", 'if cur["hash"] != mref["hash"]: raise GovernanceHold(', "if False: raise GovernanceHold(", "an action bound to a superseded manifest is held"),
 ("M31", "auif/fabric.py", 'if action["source_module"] != module_id or action["tenant_id"] != ctx.tenant_id: raise TenantContextError(', "if False: raise TenantContextError(", "an action must belong to the requesting module and tenant"),
 ('M32', 'auif/action.py', 'a["governance"].get("governor_decision_ref")', 'None', '(logging of a module-supplied decision reference)'),
 ('M33', 'auif/action.py', '"governance": {k: v for k, v in a["governance"].items() if k not in ("governor_decision_ref", "governor_decision_hash")} | {"governor_decision_ref": None}', '"governance": dict(a["governance"])', 'a module-supplied decision reference is discarded'),
 ('M34', 'auif/integration.py', 'trig = "AUTHENTICATION_REJECTED" if err["code"] == "AUTHENTICATION_FAILED" else "CONNECTION_LOST"', 'trig = "CONNECTION_LOST"', 'an authentication failure is distinct from a connection failure'),
 ('M35', 'auif/integration.py', '        if probs:\n', '        if False:\n', 'an incompatible pack or model version is refused'),
 ('M36', 'auif/integration.py', 'if missing_kinds: self._reject(', 'if False: self._reject(', 'insufficient discovery coverage blocks activation'),
 ('M37', 'auif/integration.py', 'if bad: self._reject(', 'if False: self._reject(', 'an entity with no validated mapping blocks activation'),
 ('M38', 'auif/throttle.py', 'except Throttled: self.q[key].append(task)', 'except Throttled: pass', 'a throttled task is requeued, never dropped'),
 ('M39', 'auif/connector.py', 'if self.in_flight.get(ctx.tenant_id, 0) >= self.desc["concurrency"]["per_tenant_max_in_flight"]:', 'if False:', 'per-tenant concurrency limit'),
 ('M40', 'auif/translation.py', 'raise PackError("unknown constraint kind %s" % k)', 'return True', 'an unknown constraint kind never passes silently'),
 ('M41', 'auif/translation.py', 'if not isinstance(k, str) or k not in PARAMS: return out +', 'if False: return out +', 'an unsupported transform is an error, never a pass-through'),
 ('M42', 'auif/integration.py', 'if base: self.fp = base["fingerprint"]', 'pass', 'a restarted controller restores its fingerprint from the persisted baseline'),
 ('M43', 'auif/translation.py', 'if d is None or not d.is_finite() or d == 0 or abs(d.adjusted()) > 20 or len(str(f)) > 40: out.append(', 'if False: out.append(', 'UNIT_CONVERT needs a finite, non-zero, bounded factor'),
 ('M44', 'auif/translation.py', 'if not isinstance(name, str) or name not in FUNC_SPEC: out.append(', 'if False: out.append(', 'a deterministic function must be an available one'),
 ('M45', 'auif/translation.py', 'elif FUNC_SPEC[name]["dir"] != direction: out.append(', 'elif False: out.append(', 'a function is used only in its own direction'),
 ('M46', 'auif/translation.py', 'if bad: raise PackError("mapping %s has a malformed transform: %s" % (m["mapping_id"], bad[0]))', 'if False: raise PackError("mapping %s has a malformed transform: %s" % (m["mapping_id"], bad[0]))', 'the registry refuses malformed executable transforms'),
 ('M47', 'auif/translation.py', 'except (ValueError, TypeError, ArithmeticError, AttributeError) as e: raise TranslationFailure(', 'except (KeyError,) as e: raise TranslationFailure(', 'hostile data values are explicit failures, not crashes'),
 ('M48', 'auif/translation.py', 'if not d.is_finite(): raise ValueError("non-finite number")', 'if False: raise ValueError("non-finite number")', 'NaN/Infinity are never accepted as numbers'),
 ('M49', 'auif/translation.py', 'elif direction == "out" and len(set(m.values())) != len(m): out.append(', 'elif False: out.append(', 'a many-to-one enum map cannot be used outbound'),
 ('M50', 'auif/translation.py', 'if bad: raise PackError("malformed transform: %s" % bad[0])', 'if False: raise PackError("malformed transform: %s" % bad[0])', 'the runtime refuses a malformed transform (defence in depth)'),
 ('M51', 'auif/translation.py', 'if set(p) - PARAMS[k]: out.append(', 'if False: out.append(', 'unknown transform parameters are refused'),
 ('M52', 'auif/ai_boundary.py', 'if not isinstance(raw, (list, tuple)): out["flags"].append(', 'if False: out["flags"].append(', 'non-list proposer output is discarded'),
 ('M53', 'auif/ai_boundary.py', 'except Exception as e: out["rejected"].append({"proposal": "#%d" % i,', 'except KeyError as e: out["rejected"].append({"proposal": "#%d" % i,', 'one bad proposal never affects the others'),
 ('M54', 'auif/ai_boundary.py', 'if not isinstance(p, dict): out["rejected"].append(', 'if False: out["rejected"].append(', 'a non-object proposal is rejected'),
 ('M55', 'auif/ai_boundary.py', 'try: _GUARD.check(p)', 'try: pass', 'proposals are untrusted input (size, depth, forbidden keys)'),
 ('M56', 'auif/ai_boundary.py', '"report": r, "ambiguity_resolution": res, "mapping_body": body}', '"report": r, "ambiguity_resolution": None, "mapping_body": body}', 'resolution evidence is bound into the validation record'),
 ('M57', 'auif/ai_boundary.py', 'if mid in self.ambiguous and (res is None or res["chosen"] != mapping["canonical_ref"]): raise PromotionRefused(', 'if False: raise PromotionRefused(', 'an ever-ambiguous mapping needs matching resolution to promote'),
 ('M58', 'auif/ai_boundary.py', 'return pl["ambiguity_resolution"] == self.resolutions.get(mid) if mid in self.ambiguous else True', 'return True', 'verification binds the ambiguity-resolution chain'),
 ('M59', 'auif/ai_boundary.py', 'isinstance(ev.get("evidence_hash"), str) and HEX64.match(ev["evidence_hash"])): raise PromotionRefused(', 'isinstance(ev.get("evidence_hash"), str)): raise PromotionRefused(', 'resolution evidence needs a well-formed hash'),
 ('M60', 'auif/ai_boundary.py', 'if ct != "DECIMAL": out.append("UNIT_CONVERT yields', 'if False: out.append("UNIT_CONVERT yields', 'unit conversion must target a decimal'),
 ('M61', 'auif/ai_boundary.py', 'if st != "string": out.append("FORMAT needs a string source', 'if False: out.append("FORMAT needs a string source', 'FORMAT needs a text source'),
 ('M62', 'auif/ai_boundary.py', 'not all(isinstance(a, str) and 0 < len(a) <= 200 for a in alternatives)', 'not all(True for a in alternatives)', 'alternatives must be strings'),
 ('M63', 'auif/integration.py', 'if rec is None: self._reject(["no discovery record is available', 'if False: self._reject(["no discovery record is available', 'the pack gate fails closed without a discovery record'),
 ('M64', 'auif/integration.py', 'self.raw = out.data; self._record_discovery(self.raw)', 'self.raw = out.data; self.fp = fingerprint(self.raw)', 'a fresh discovery is recorded before validation'),
 ('M65', 'auif/integration.py', '== (self.ctx.tenant_id, self.target_system_id, self.environment_id): self.last_record = rec', '== (self.ctx.tenant_id, self.target_system_id, self.environment_id): self.last_record = None', 'restart restores the persisted discovery record'),
 ('M66', 'auif/integration.py', 'and (rec["tenant_id"], rec["target_system_id"], rec["environment_id"]) == (self.ctx.tenant_id, self.target_system_id, self.environment_id): self.last_record = rec', 'and True: self.last_record = rec', 'a restored record must belong to this tenant, target and environment'),
 ('M67', 'auif/integration.py', 'not contracts().errors("discovery#SystemDiscoveryRecord", rec) and', 'True and', 'a restored record must be contract-valid'),
 ('M68', 'auif/integration.py', 'self.d.store.put(self.ctx, "discovery_latest", self.integration_id, {"discovery_record_id": rec["discovery_record_id"]})', 'pass', 'the latest discovery record is persisted'),
 ('M69', 'auif/ai_boundary.py', 'if pl["mapping_body"] != {k: v for k, v in mapping.items() if k != "validation_ref"}: return False', 'if False: return False', 'verification binds the complete promoted mapping'),
 ('M70', 'auif/ai_boundary.py', 'or ref != self.refs.get(eid) or', 'or False or', 'the evidence reference itself must be exactly the issued one'),
 ('M71', 'auif/ai_boundary.py', 'if not isinstance(eid, str): return False', 'if False: return False', 'verification never crashes on a malformed evidence id'),
 ('M72', 'auif/translation.py', 'elif claims_ai_promotion(m) or (self.ai_origin and self.ai_origin(m)): raise PackError(', 'elif False: raise PackError(', 'the registry recognises AI promotion by its evidence, not the declared author'),
 ('M73', 'auif/translation.py', 'ref.get("kind") == AI_EVIDENCE_KIND or str(', 'False or str(', 'the AI evidence KIND marks a promotion'),
 ('M74', 'auif/translation.py', 'or str(ref.get("evidence_id", "")).startswith(AI_EVIDENCE_PREFIX))', 'or False)', 'the AI evidence ID prefix marks a promotion'),
 ('M75', 'auif/translation.py', 'or (self.ai_origin and self.ai_origin(m)): raise PackError(', 'or False: raise PackError(', 'the issuing service recognises its own evidence even if the marker is stripped'),
 ('M76', 'auif/action.py', 'if resv["content_hash"] != h: raise AuifError("idempotency key reused with different content")', "if False: raise AuifError('x')", 'a reused idempotency key with different content is refused'),
 ('M77', 'auif/action.py', 'if resv.get("state") == "COMMITTED": return self._committed(ctx, resv)', 'if False: return self._committed(ctx, resv)', 'a committed duplicate returns the existing record'),
 ('M78', 'auif/action.py', 'if rec is None: raise AuifError("integrity failure: the idempotency record for action', 'if False: raise AuifError("integrity failure: the idempotency record for action', 'a committed reservation with no action is a loud integrity failure'),
 ('M79', 'auif/action.py', 'or sha(a.get("canonical_action")) != resv.get("content_hash"): raise AuifError(', 'or False: raise AuifError(', 'a tampered intent is never executed'),
 ('M80', 'auif/action.py', 'if old["execution_state"] != "CREATED": return old', 'if False: return old', 'completing a submission never regresses an advanced action'),
 ('M81', 'auif/action.py', 'state="COMMITTED"))', 'state="RESERVED"))', 'completion marks the reservation COMMITTED'),
 ('M82', 'auif/action.py', 'dict({k: v for k, v in old.items() if k != "intent"}, state="COMMITTED")', 'dict({k: v for k, v in old.items() if k != "zzz"}, state="COMMITTED")', 'the intent is dropped once committed'),
 ('M83', 'auif/action.py', 'if resv.get("state") != "RESERVED": continue', 'if False: continue', 'the sweep touches only RESERVED submissions'),
 ('M84', 'auif/action.py', '"created_at": resv["reserved_at"]', '"created_at": self.clock.iso()', 'recovery does not rewrite the creation time'),
 ('M85', 'auif/action.py', 'if recovered: self.ledger.event_once(', 'if False: self.ledger.event_once(', 'a recovered submission is recorded as evidence'),
 ('M86', 'auif/action.py', '"intent": {"action": action}}', '"intent": {}}', 'the reservation carries the intent needed to finish it'),
 ('M87', 'auif/action.py', 'if action["tenant_id"] != ctx.tenant_id: raise TenantContextError(', 'if False: raise TenantContextError(', "an action's tenant must equal the authenticated context before anything is written"),
 ('M88', 'auif/action.py', 'if a.get("tenant_id") != ctx.tenant_id: raise AuifError(', 'if False: raise AuifError(', "a reservation holding another tenant's action is never completed"),
 ('M89', 'auif/fabric.py', 'if action["source_module"] != module_id or action["tenant_id"] != ctx.tenant_id: raise TenantContextError(', 'if action["source_module"] != module_id: raise TenantContextError(', 'the entry point refuses an action whose tenant is not the authenticated one'),
 ('M90', 'auif/fabric.py', 'if action["source_module"] != module_id or action["tenant_id"] != ctx.tenant_id: raise TenantContextError(', 'if action["tenant_id"] != ctx.tenant_id: raise TenantContextError(', 'the entry point refuses an action not authored by the requesting module'),

 # ---- rev9: CF-1 (a failing Governor report must never let an integration escape the drift state) and CF-2 (a stale SENT record is resolved by reconciliation only, never re-sent)
 ("M91", "auif/integration.py", "        except Exception: ack = None", "        except KeyError: ack = None", "CF-1: a raising Governor report is an unacknowledged report"),
 ("M92", "auif/integration.py", 'rid = ack.get("report_id") if type(ack) is dict and ack.get("acknowledged") is True else None', 'rid = ack.get("report_id") if ack.get("acknowledged") is True else None', "CF-1: a non-dict answer is an unacknowledged report"),
 ("M93", "auif/integration.py", 'if type(ack) is dict and ack.get("acknowledged") is True else None', 'if type(ack) is dict and ack.get("acknowledged") else None', "CF-1: only acknowledged=True (not any truthy value) is an acknowledgement"),
 ("M94", "auif/integration.py", '; validate("integration#DriftEvidence", cand); return cand', "; return cand", "CF-1: an acknowledgement whose report id yields invalid evidence is not an acknowledgement"),
 ("M95", "auif/integration.py", "            except Exception: pass                                      # an acknowledgement that does not yield valid evidence is not an acknowledgement", "            except KeyError: pass", "CF-1: invalid acknowledgement evidence never escapes as an exception"),
 ("M96", "auif/integration.py", 'self.d.tel.inc(self.ctx.tenant_id, self.integration_id, "governor_report_unacknowledged"); return ev', "return ev", "CF-1: an unacknowledged report is counted"),
 ("M97", "auif/integration.py", 'self.d.tel.inc(self.ctx.tenant_id, self.integration_id, "governor_report_unacknowledged"); return ev', 'self.d.tel.inc(self.ctx.tenant_id, self.integration_id, "governor_report_unacknowledged"); return None', "CF-1: the drift evidence is still returned and stored after an unacknowledged report"),
 ("M98", "auif/integration.py", '"status": "REPORTED", "report_ref"', '"status": "PENDING", "report_ref"', "CF-1: a valid acknowledgement makes the consequence REPORTED"),
 ("M99", "auif/integration.py", "            ev = self._report_drift(ev, ", "            ev = (lambda e, c: e)(ev, ", "CF-1: the drift condition is reported to the Governor"),
 ("M100", "auif/action.py", "if isinstance(stale_after_seconds, bool) or not isinstance(stale_after_seconds, (int, float)) or not 0 < stale_after_seconds < float(\"inf\"): "+V2, "if not isinstance(stale_after_seconds, (int, float)) or not 0 < stale_after_seconds < float(\"inf\"): "+V2, "CF-2: a boolean is not an acceptable staleness threshold"),
 ("M101", "auif/action.py", "or not 0 < stale_after_seconds < float(\"inf\"): "+V2, "or not 0 <= stale_after_seconds < float(\"inf\"): "+V2, "CF-2: a zero threshold would treat every in-flight record as stale"),
 ("M102", "auif/action.py", "or not 0 < stale_after_seconds < float(\"inf\"): "+V2, "or not 0 < stale_after_seconds: "+V2, "CF-2: an infinite threshold is refused"),
 ("M103", "auif/action.py", '            if rec.get("execution_state") != "SENT": continue\n            if rec.get("sent_at", "") > cutoff:', '            if False: continue\n            if rec.get("sent_at", "") > cutoff:', "CF-2: only SENT records are considered"),
 ("M104", "auif/action.py", 'if rec.get("sent_at", "") > cutoff: out["not_stale"] += 1; continue', 'if rec.get("sent_at", "") >= cutoff: out["not_stale"] += 1; continue', "CF-2: a record exactly at the threshold is stale"),
 ("M105", "auif/action.py", 'if rec.get("sent_at", "") > cutoff: out["not_stale"] += 1; continue', 'if False: out["not_stale"] += 1; continue', "CF-2: a live in-flight record is never recovered"),
 ("M106", "auif/action.py", "cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {\"recovered\"", "cutoff, out = self.clock.iso(self.clock.now + stale_after_seconds), {\"recovered\"", "CF-2: the cutoff lies in the past"),
 ("M107", "auif/action.py", 'strat = "QUERY_EXTERNAL_BY_IDEMPOTENCY_KEY" if h.runtime.descriptor()["idempotency"]["outcome_reconciliation_supported"] else "OPERATOR_REVIEW"\n                self.ledger.transition(ctx, aid, "UNKNOWN_OUTCOME"', 'strat = "QUERY_EXTERNAL_BY_IDEMPOTENCY_KEY"\n                self.ledger.transition(ctx, aid, "UNKNOWN_OUTCOME"', "CF-2: a target that cannot be queried goes to operator review"),
 ("M108", "auif/action.py", '"next_check_at": self.clock.iso(self.clock.now), "blind_retry_permitted": False})\n                self.ledger.event(ctx, aid, "STALE_SENT_RECOVERED"', '"next_check_at": self.clock.iso(self.clock.now), "blind_retry_permitted": True})\n                self.ledger.event(ctx, aid, "STALE_SENT_RECOVERED"', "CF-2: a blind retry is never permitted"),
 ("M109", "auif/action.py", 'self.ledger.transition(ctx, aid, "UNKNOWN_OUTCOME", error={"code": "UNKNOWN_EXTERNAL_ERROR"', 'self.ledger.transition(ctx, aid, "FAILED", error={"code": "UNKNOWN_EXTERNAL_ERROR"', "CF-2: a stale record is never simply failed without reconciliation (the write may have applied)"),
 ("M110", "auif/action.py", 'self.ledger.event(ctx, aid, "STALE_SENT_RECOVERED", sent_at=rec["sent_at"], stale_after_seconds=stale_after_seconds); self.tel.inc(ctx.tenant_id, h.integration_id, "stale_sent_recovery"); out["recovered"].append(aid)', 'self.tel.inc(ctx.tenant_id, h.integration_id, "stale_sent_recovery"); out["recovered"].append(aid)', "CF-2: the recovery is recorded in the event trail"),
 ("M111", "auif/action.py", 'self.tel.inc(ctx.tenant_id, h.integration_id, "stale_sent_recovery"); out["recovered"].append(aid)', 'out["recovered"].append(aid)', "CF-2: the recovery is counted"),
 ("M112", "auif/action.py", 'out["reconciled"][aid] = self.reconcile(ctx, aid)["execution_state"]', 'out["reconciled"][aid] = "UNKNOWN_OUTCOME"', "CF-2: a recovered record is reconciled"),
 ("M113", "auif/action.py", 'self.reconcile(ctx, aid)["execution_state"]\n            except IllegalTransition: out["skipped"].append(aid)', 'self.reconcile(ctx, aid)["execution_state"]\n            except IllegalTransition: pass', "CF-2: a record that moved on is reported as skipped"),
 ("M114", "auif/action.py", 'except Exception as e: out["problems"].append({"action_id": aid, "problem": "%s: %s"', 'except KeyError as e: out["problems"].append({"action_id": aid, "problem": "%s: %s"', "CF-2: an unrecoverable record is reported, not raised"),

 # ---- rev10: CF-4 (a record stranded in ACKNOWLEDGED after the target confirmed the effect is completed from what is on the record, never re-sent and never re-authorised)
 ('M115', 'auif/action.py', 'if isinstance(stale_after_seconds, bool) or not isinstance(stale_after_seconds, (int, float)) or not 0 < stale_after_seconds < float("inf"): raise AuifError("stale_after_seconds must be a positive, finite number of seconds")\n        cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"completed"', 'if not isinstance(stale_after_seconds, (int, float)) or not 0 < stale_after_seconds < float("inf"): raise AuifError("stale_after_seconds must be a positive, finite number of seconds")\n        cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"completed"', 'CF-4: a boolean is not an acceptable staleness threshold'),
 ('M116', 'auif/action.py', 'or not 0 < stale_after_seconds < float("inf"): raise AuifError("stale_after_seconds must be a positive, finite number of seconds")\n        cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"completed"', 'or not 0 <= stale_after_seconds < float("inf"): raise AuifError("stale_after_seconds must be a positive, finite number of seconds")\n        cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"completed"', 'CF-4: a zero threshold would treat every in-flight record as stale'),
 ('M117', 'auif/action.py', 'or not 0 < stale_after_seconds < float("inf"): raise AuifError("stale_after_seconds must be a positive, finite number of seconds")\n        cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"completed"', 'or not 0 < stale_after_seconds: raise AuifError("stale_after_seconds must be a positive, finite number of seconds")\n        cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"completed"', 'CF-4: an infinite threshold is refused'),
 ('M118', 'auif/action.py', '            if rec.get("execution_state") != "ACKNOWLEDGED": continue', '            if False: continue', 'CF-4: only ACKNOWLEDGED records are considered'),
 ('M119', 'auif/action.py', 'if at > cutoff: out["not_stale"] += 1; continue', 'if at >= cutoff: out["not_stale"] += 1; continue', 'CF-4: a record exactly at the threshold is stale'),
 ('M120', 'auif/action.py', 'if at > cutoff: out["not_stale"] += 1; continue', 'if False: out["not_stale"] += 1; continue', 'CF-4: a live in-flight record is never completed by the sweep'),
 ('M121', 'auif/action.py', 'cutoff, out = self.clock.iso(self.clock.now - stale_after_seconds), {"completed"', 'cutoff, out = self.clock.iso(self.clock.now + stale_after_seconds), {"completed"', 'CF-4: the cutoff lies in the past'),
 ('M122', 'auif/action.py', 'isinstance(ref, str) and ref and isinstance(at, str) and at): out["problems"]', 'isinstance(at, str) and at): out["problems"]', "CF-4: a record without the target's external reference is never completed"),
 ('M123', 'auif/action.py', 'isinstance(ref, str) and ref and isinstance(at, str) and at): out["problems"]', 'isinstance(ref, str) and ref): out["problems"]', 'CF-4: a record without the acknowledgement timestamp is never completed'),
 ('M124', 'auif/action.py', 'so it is left for an operator"}); continue', 'so it is left for an operator"})', 'CF-4: an unconfirmed record is left alone, never completed'),
 ('M125', 'auif/action.py', 'result={"outcome": "APPLIED"})\n                self.ledger.event(ctx, aid, "STRANDED', 'result={"outcome": "APPLIED_CONFIRMED_BY_RECONCILIATION"})\n                self.ledger.event(ctx, aid, "STRANDED', 'CF-4: the confirmed effect is recorded as APPLIED'),
 ('M126', 'auif/action.py', 'self.ledger.transition(ctx, aid, "COMPLETED", completed_at=self.clock.iso(), result={"outcome": "APPLIED"})\n                self.ledger.event(ctx, aid, "STRANDED', 'self.ledger.transition(ctx, aid, "FAILED", completed_at=self.clock.iso(), result={"outcome": "APPLIED"})\n                self.ledger.event(ctx, aid, "STRANDED', 'CF-4: a confirmed action is completed, never failed'),
 ('M127', 'auif/action.py', 'self.ledger.event(ctx, aid, "STRANDED_ACKNOWLEDGED_COMPLETED", acknowledged_at=at, stale_after_seconds=stale_after_seconds); out["completed"].append(aid)', 'out["completed"].append(aid)', 'CF-4: the completion is recorded in the event trail'),
 ('M128', 'auif/action.py', 'try: self.tel.inc(ctx.tenant_id, self.integrations.resolve(ctx, self.store.get(ctx, "action_manifest_ref", aid)).integration_id, "stale_acknowledged_recovery")', 'try: pass', 'CF-4: the completion is counted'),
 ('M129', 'auif/action.py', 'except Exception: pass                                                       # telemetry only', 'except KeyError: pass                                                       # telemetry only', 'CF-4: a telemetry failure never turns a durable completion into a problem'),
 ('M130', 'auif/action.py', '            except IllegalTransition: out["skipped"].append(aid)                  # the record moved on (a live dispatch finished): there is nothing to recover\n            except Exception as e: out["problems"].append({"action_id": aid, "problem": "completion failed', '            except IllegalTransition: pass                  # the record moved on (a live dispatch finished): there is nothing to recover\n            except Exception as e: out["problems"].append({"action_id": aid, "problem": "completion failed', 'CF-4: a record that moved on is reported as skipped'),
 ('M131', 'auif/action.py', 'except Exception as e: out["problems"].append({"action_id": aid, "problem": "completion failed', 'except KeyError as e: out["problems"].append({"action_id": aid, "problem": "completion failed', 'CF-4: a failed completion is reported, not raised'),
 ('M132', 'auif/action.py', 'self.ledger.event(ctx, aid, "STRANDED_ACKNOWLEDGED_COMPLETED", acknowledged_at=at, stale_after_seconds=stale_after_seconds); out["completed"].append(aid)', 'self.ledger.event(ctx, aid, "STRANDED_ACKNOWLEDGED_COMPLETED", acknowledged_at=at, stale_after_seconds=stale_after_seconds); pass', 'CF-4: a completed record is reported as completed'),
 ('M133', 'auif/action.py', 'self.ledger.transition(ctx, aid, "COMPLETED", completed_at=self.clock.iso(), result={"outcome": "APPLIED"})\n                self.ledger.event(ctx, aid, "STRANDED', 'self.ledger.transition(ctx, aid, "COMPLETED", result={"outcome": "APPLIED"})\n                self.ledger.event(ctx, aid, "STRANDED', 'CF-4: the completion time is recorded'),
 # ---- rev14: the six defects found while building APG-M8 (M8-F1 to M8-F6)
 ("M134", "auif/canonical.py", 'concept, dot, attr = str(ref).rpartition(".")', 'concept, dot, attr = str(ref).partition(".")', "M8-F1: the attribute is after the LAST dot"),
 ("M135", "auif/canonical.py", 'return (concept, attr) if dot else ("", str(ref))', 'return (concept, attr) if dot else (str(ref), "")', "M8-F1: a reference without a dot has no concept"),
 ("M136", "auif/translation.py", 'if not ATTR.match(attr) or (ent is not None and concept != ent): raise PackError(', 'if False: raise PackError(', "M8-F1: a malformed field reference is refused at registration"),
 ("M137", "auif/translation.py", 'if not ATTR.match(attr) or (ent is not None and concept != ent): raise', 'if (ent is not None and concept != ent): raise', "M8-F1: the attribute part must be an attribute name"),
 ("M138", "auif/translation.py", 'if not ATTR.match(attr) or (ent is not None and concept != ent): raise', 'if not ATTR.match(attr): raise', "M8-F1: a field must map into its entity's concept"),
 ("M139", "auif/translation.py", 'if m["kind"] != "FIELD": continue\n            concept, attr', 'if m["kind"] != "FIELD" or m["mapping_state"] not in ("VALIDATED", "TRUSTED"): continue\n            concept, attr', "M8-F1: a malformed reference is refused even in a mapping that does not run"),
 ("M140", "auif/translation.py", 'if concept != ctype: outcomes.append({"source_field": path, "outcome": "REJECTED"})', 'if False: outcomes.append({"source_field": path, "outcome": "REJECTED"})', "M8-F1: translation refuses a field into another concept (defence in depth)"),
 ("M141", "auif/translation.py", 'if m["kind"] != "FIELD" or split_ref(m["canonical_ref"])[0] != canonical_type: continue', 'if m["kind"] != "FIELD": continue', "M8-F1: outbound takes only the requested concept's fields"),
 ("M142", "auif/translation.py", 'attr = split_ref(m["canonical_ref"])[1]', 'attr = m["canonical_ref"].split(".", 1)[1]', "M8-F1: outbound reads the attribute after the concept's full name"),
 ("M143", "auif/ai_boundary.py", 'ctype, attr = split_ref(canonical_ref)', 'ctype, _, attr = canonical_ref.partition(".")', "M8-F1: the AI validator reads the attribute after the concept's full name"),
 ("M144", "auif/fabric.py", 'if spec == IDENTITY_CONTENT_HASH: return sha(record)[:12], None', 'if False: return sha(record)[:12], None', "M8-F2: a declared content-hash identity works"),
 ("M145", "auif/fabric.py", 'if v is None or isinstance(v, (dict, list, bool)) or (isinstance(v, str) and not v.strip()): return None', 'if v is None or isinstance(v, (dict, list, bool)): return None', "M8-F2/F6: a blank identity value is missing"),
 ("M146", "auif/fabric.py", 'if v is None or isinstance(v, (dict, list, bool)) or (isinstance(v, str)', 'if v is None or (isinstance(v, str)', "M8-F2: a structured identity value is refused"),
 ("M147", "auif/fabric.py", 'if v is None or isinstance(v, (dict, list, bool)) or', 'if isinstance(v, (dict, list, bool)) or', "M8-F2: an absent identity is missing"),
 ("M148", "auif/fabric.py", '.replace("|", "\\\\|") for x in vals)', ' for x in vals)', "M8-F2: a composite identity is unambiguous (separator escaped)"),
 ("M149", "auif/fabric.py", 'x.replace("\\\\", "\\\\\\\\").replace', 'x.replace', "M8-F2: a composite identity is unambiguous (escape character escaped)"),
 ("M150", "auif/fabric.py", 'if not fields or not all(isinstance(f, str) and f for f in fields): return None', 'if not all(isinstance(f, str) and f for f in fields): return None', "M8-F2: an empty identity declaration is refused"),
 ("M151", "auif/fabric.py", 'if sid is None: self._error(ctx, c.anchor_module, "IDENTITY_MISSING"', 'if sid is None: sid = sha(record)[:12]\n        if False: self._error(ctx, c.anchor_module, "IDENTITY_MISSING"', "M8-F2: a missing identity is never replaced by a hash"),
 ("M152", "auif/fabric.py", 'if st in NOT_APPLIED or st == "IN_ORDER":', 'if False:', "M8-F3: the module is told about an event not applied"),
 ("M153", "auif/fabric.py", 'if st in NOT_APPLIED or st == "IN_ORDER":', 'if st in NOT_APPLIED:', "M8-F3: an in-order event with no entity mapping is told"),
 ("M154", "auif/fabric.py", 'NOT_APPLIED = ("QUEUED_AWAITING_PREDECESSOR", "DEFERRED",', 'NOT_APPLIED = ("QUEUED_AWAITING_PREDECESSOR",', "M8-F3: a deferred event is told"),
 ("M155", "auif/fabric.py", '"RECONCILIATION_PENDING", "REJECTED_BY_POLICY")', '"RECONCILIATION_PENDING")', "M8-F3: a rejected event is told"),
 ("M156", "auif/fabric.py", 'waiting_on=list(d.get("waiting_on", []))', 'waiting_on=[]', "M8-F3: the module is told what the event waits on"),
 ("M157", "auif/fabric.py", 'self._tell(ctx, c.anchor_module, "EVENT_NOT_APPLIED"', 'self._error(ctx, c.anchor_module, "EVENT_NOT_APPLIED"', "M8-F3: a waiting event is not counted as a failure"),
 ("M158", "auif/fabric.py", 'except Exception: failed = True\n        if failed: self._module_failed(ctx, c.integration_id', 'except Exception: failed = False\n        if failed: self._module_failed(ctx, c.integration_id', "M8-F4: a raising entity handler is a failed delivery"),
 ("M159", "auif/fabric.py", 'failed = self._failed(r1) or self._failed(r2)', 'failed = self._failed(r1)', "M8-F4: a failed observation delivery counts"),
 ("M160", "auif/fabric.py", 'def _failed(result): return isinstance(result, dict) and bool(result.get("handler_failures"))', 'def _failed(result): return False', "M8-F4: a module's failure marker is read"),
 ("M161", "auif/fabric.py", 'self.tel.inc(ctx.tenant_id, integration_id, "module_failures")', 'pass', "M8-F4: a module failure is counted"),
 ("M162", "auif/fabric.py", 'self.store.put(ctx, "module_delivery_failures"', '(lambda *a: None)(ctx, "module_delivery_failures"', "M8-F4: a module failure is recorded"),
 ("M163", "auif/fabric.py", 'self._tell(ctx, c.anchor_module, "MODULE_DELIVERY_FAILED"', '(lambda *a, **k: None)(ctx, c.anchor_module, "MODULE_DELIVERY_FAILED"', "M8-F4: the module is told its delivery failed"),
 ("M164", "auif/fabric.py", 'return obj, "module_failed"', 'return obj, "delivered"', "M8-F4: a failed delivery is not reported as delivered"),
 ("M165", "auif/fabric.py", 'except Exception: failed = True\n        if failed: self._module_failed(ctx, state.get(', 'except Exception: failed = False\n        if failed: self._module_failed(ctx, state.get(', "M8-F4: a raising state handler is counted"),
 ("M166", "auif/fabric.py", 'except NotFound: failed = False\n        except Exception: failed = True\n        if failed: self._module_failed(ctx, state.get(', 'except NotFound: failed = False\n        if failed: self._module_failed(ctx, state.get(', "M8-F4: a raising state handler never stops the transition"),
 ("M167", "auif/fabric.py", 'except Exception: failed = True\n        if failed: self._module_failed(ctx, d.get(', 'except Exception: failed = False\n        if failed: self._module_failed(ctx, d.get(', "M8-F4: a raising error handler is counted"),
 ("M168", "auif/fabric.py", 'else: rep["stopped_at_page_limit"] = True', 'else: pass', "M8-F5: a read cut short by the page limit says so"),
 ("M169", "auif/fabric.py", 'if cursor is None: rep["complete"] = True; break', 'if cursor is None: break', "M8-F5: a read that reached the end says so"),
 ("M170", "auif/fabric.py", 'if k == "NO_DATA": rep["empty"] = True; rep["complete"] = True; break', 'if k == "NO_DATA": rep["empty"] = True; break', "M8-F5: an empty source is a complete read"),
 ("M171", "auif/fabric.py", 'if k != "DATA_OBTAINED": rep["failed"] = out.error["code"]; self._error(', 'if k != "DATA_OBTAINED": rep["failed"] = out.error["code"]; rep["complete"] = True; self._error(', "M8-F5: a failed read is never complete"),
 ("M172", "auif/fabric.py", '_, status = self._ingest_record(ctx, c, entity, item); rep[status] += 1', '_, status = self._ingest_record(ctx, c, entity, item); rep["delivered"] += 1', "M8-F5: only what the module took is counted as delivered"),
 ("M173", "auif/integration.py", 'if base is None: return False', 'pass', "M8-F6: drift before the first validation is reported, not raised"),
 ("M174", "auif/fabric.py", 'except ContractViolation as e: self._error(ctx, c.anchor_module, "RECORD_REFUSED"', 'except KeyError as e: self._error(ctx, c.anchor_module, "RECORD_REFUSED"', "M8-F6: a record the observation contract refuses is reported, not raised"),
]
def run(m):
    mid, f, old, new, what = m; d = tempfile.mkdtemp(prefix="mut_")
    try:
        for sub in ("auif", "auif_ref", "synthetic", "port_contracts", "tests", "tools", "contracts", "evidence"): shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub), ignore=shutil.ignore_patterns("__pycache__"))
        for fn in ("AMIR_ENGINE_DEPENDENCY_TODO.json",): shutil.copy(os.path.join(ROOT, fn), d)
        p = os.path.join(d, f); s = open(p).read()
        if s.count(old) != 1: return {"id": mid, "guard": what, "file": f, "result": "INVALID (target matched %d times)" % s.count(old)}
        open(p, "w").write(s.replace(old, new)); r = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "tests", "-t", "."], cwd=d, capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), timeout=240)
        tail = (r.stderr.strip().splitlines() or [""])[-1]; failing = failing_classes(r.stderr)
        return {"id": mid, "guard": what, "file": f, "result": "KILLED" if r.returncode != 0 else "SURVIVED", "detected_by": failing, "suite": tail}
    except subprocess.TimeoutExpired: return {"id": mid, "guard": what, "file": f, "result": "KILLED", "detected_by": ["timeout (hang)"]}
    finally: shutil.rmtree(d, ignore_errors=True)
if __name__ == "__main__":
    arg = lambda n: next((x.split("=", 1)[1] for x in sys.argv if x.startswith("--%s=" % n)), None)
    only, merge, save = arg("only"), arg("merge"), arg("save"); only = only.split(",") if only else None; sel = [m for m in M if only is None or m[0] in only]
    if only and "--write" in sys.argv: sys.exit("--write requires the full mutant list (no --only); use --save per chunk, then --merge")
    if merge:       # assemble chunked runs; accepted ONLY if the chunks cover every defined mutant exactly once
        res = [r for f in merge.split(",") for r in json.load(open(f))]; ids = [r["id"] for r in res]
        if sorted(ids) != sorted(m[0] for m in M): sys.exit("merge refused: chunks do not cover every defined mutant exactly once (%d results for %d mutants)" % (len(ids), len(M)))
        res.sort(key=lambda r: r["id"]); sel = M
    else:
        with concurrent.futures.ThreadPoolExecutor(6) as ex: res = list(ex.map(run, sel))
    if save: json.dump(res, open(save, "w"))
    k = sum(r["result"] == "KILLED" for r in res); sv = [r for r in res if r["result"] == "SURVIVED"]; inv = [r for r in res if r["result"].startswith("INVALID")]
    out = {"mutants": len(sel), "killed": k, "survived": len(sv), "invalid": len(inv), "results": res}
    if "--write" in sys.argv and (sv or inv): sys.exit("refusing to write evidence: %d survived, %d invalid" % (len(sv), len(inv)))      # a bad result is never recorded as the evidence
    if "--write" in sys.argv: json.dump(out, open(os.path.join(ROOT, "evidence", "mutation_results.json"), "w"), indent=1)      # tracked evidence is rewritten only on request
    for r in res: print("%-4s %-9s %-60s %s" % (r["id"], r["result"][:9], r["guard"][:60], ",".join(r.get("detected_by", []))[:70]))
    print("\nmutants=%d killed=%d survived=%d invalid=%d" % (len(sel), k, len(sv), len(inv)))

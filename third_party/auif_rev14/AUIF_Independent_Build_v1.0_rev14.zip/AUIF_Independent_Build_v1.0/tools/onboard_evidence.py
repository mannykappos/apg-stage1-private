"""Produces evidence/onboard_verification.json for the onboarding accelerator (auif_onboard): the accelerator's test counts, per-spec evidence for the three materially different synthetic OpenAPI specs (draft, unknowns, synthetic loopback validation, human-approval flow with test reviewers, secrets canary), static checks, reverse contamination, and core/extension/frozen-file integrity against the untouched rev13 package (rev14: the core was revised; until rev13 the baseline was rev10). Run by the builder, not by the verifier.
Usage: python3 tools/onboard_evidence.py <out.json> --pristine=<untouched rev13 extraction> [--mutation=<mutation_onboard --out file>]"""
import ast, hashlib, json, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); sys.path.insert(0, os.path.join(ROOT, "tools"))
PINNED_CORE = "923de5100f95debbbf63d5ab6e960cee2091ee57abce403792403ff049ac7839"; REV10_TO_REV13_CORE = "74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d"; FROZEN_DIRS = ("auif", "auif_ext", "auif_ref", "synthetic", "contracts", "tests", "port_contracts")
EXPECTED_CHANGED = ["auif/ai_boundary.py", "auif/canonical.py", "auif/fabric.py", "auif/integration.py", "auif/translation.py", "auif_ext/module_client/client.py", "auif_ext/tests/test_extension_boundary.py"]
EXPECTED_ADDED = ["auif_ext/tests/test_rev14_module_client.py", "tests/test_rev14_fixes.py"]           # rev14: the ONLY differences from the untouched rev13 layers (the M8-F1 to M8-F6 fixes, their tests, and the pinned core hash). rev11 to rev13 compared with rev10 and expected only auif_ext/connectors/rest.py and auif_ext/tests/test_rest_tenant.py.
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def walk(root, top):
    out = {}
    for d, ds, fs in os.walk(os.path.join(root, top)):
        ds[:] = [x for x in ds if x != "__pycache__"]
        for f in fs:
            if not f.endswith(".pyc"): p = os.path.join(d, f); out[os.path.relpath(p, root)] = sha(p)
    return out
def integrity(pristine):
    """Every file of the frozen layers must be byte-identical to the untouched rev13 extraction, with nothing added, removed or changed, EXCEPT the rev14 differences named in EXPECTED_CHANGED and EXPECTED_ADDED (and nothing else). The reference implementations, the synthetic world, the contracts and the port contracts must be wholly identical."""
    changed, added, removed, same = [], [], [], 0
    for top in FROZEN_DIRS:
        a, b = walk(pristine, top), walk(ROOT, top); removed += sorted(set(a) - set(b)); added += sorted(set(b) - set(a))
        for k in sorted(set(a) & set(b)):
            if a[k] == b[k]: same += 1
            else: changed.append(k)
    outside_ext = sorted(x for x in changed + added + removed if not x.startswith("auif_ext/"))
    return {"frozen_dirs": list(FROZEN_DIRS), "identical_files": same, "changed": changed, "added": added, "removed": removed, "expected_changed": EXPECTED_CHANGED, "expected_added": EXPECTED_ADDED, "outside_extension_layer_differences": outside_ext, "ok": changed == EXPECTED_CHANGED and added == EXPECTED_ADDED and not removed}
def unittests(sub):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1"); env.pop("AUIF_GOVERNOR_R14_ZIP", None)
    r = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", sub, "-t", "."], cwd=ROOT, capture_output=True, text=True, env=env); out = r.stdout + r.stderr
    n = int(re.search(r"Ran (\d+) tests", out).group(1)); k = re.search(r"skipped=(\d+)", out); return {"tests_run": n, "skipped": int(k.group(1)) if k else 0, "ok": r.returncode == 0 and out.strip().splitlines()[-1].startswith("OK")}
def per_spec():
    from auif_onboard import validate, secrets_scan
    from auif_onboard.tests.support import NAMES, CANARY, spec_bytes, drafts
    from auif_onboard.tests.test_e2e_onboard import onboard
    from auif_onboard.tests.vendors import VENDORS
    from synthetic.packs import MODEL_DEF
    out = {}
    for name in NAMES:
        cd, pd = drafts(name); rep = validate.validate_synthetic(cd, pd, VENDORS[name], MODEL_DEF); s, cd2, pd2, ac, asm = onboard(name); body = json.dumps([cd, pd, rep, ac, asm, s.ledger], default=str)
        unresolved = [i for i in s.items.values() if s.status[i["item_id"]] == "PENDING"]
        out[name] = {"spec_sha256": hashlib.sha256(spec_bytes(name)).hexdigest(), "config_draft_hash": cd["draft_hash"], "pack_draft_hash": pd["draft_hash"], "draft_state": cd["draft_state"], "authority": cd["authority"], "credential_ref_in_draft": cd["config"]["credential_ref"], "auth": cd["config"]["auth"],
                     "entities": sorted(cd["config"]["entities"]), "undetermined_reported": len(cd["undetermined"]), "mappings_in_draft_pack": len(pd["pack"]["mappings"]) if pd["pack"] else 0, "validated_or_trusted_in_draft": sum(m["mapping_state"] in ("VALIDATED", "TRUSTED") for m in (pd["pack"]["mappings"] if pd["pack"] else [])),
                     "validation": {"report_hash": rep["report_hash"], "synthetic_only": rep["synthetic_only"], "real_system_validated": rep["real_system_validated"], "summary": rep["summary"], "all_checks_passed": rep["all_checks_passed"], "vendor": rep["vendor"]},
                     "review_flow": {"approved_config_hash": ac["approved_hash"], "assembled_pack_hash": asm["pack"]["artifact_hash"], "approved_mappings": len(asm["pack"]["mappings"]), "left_out_pending": len(asm["left_out"]), "pending_items_after_review": len(unresolved), "ledger_entries": len(s.ledger)},
                     "secrets": {"canary_planted_in_spec": CANARY.encode() in spec_bytes(name), "canary_in_any_artifact_or_report": CANARY in body, "scan_findings_in_artifacts": len(secrets_scan.scan([cd, pd, rep, ac, asm], "evidence", extra_literals=(CANARY,)))}}
    return out
def main():
    argv = sys.argv[1:]; out = next(a for a in argv if not a.startswith("--")); pr = next((a.split("=", 1)[1] for a in argv if a.startswith("--pristine=")), None); mu = next((a.split("=", 1)[1] for a in argv if a.startswith("--mutation=")), None)
    if not pr: raise SystemExit("--pristine=<untouched rev13 extraction> is required")
    import static_checks_onboard; st = static_checks_onboard.run(); core = unittests("tests"); ext = unittests("auif_ext/tests"); ob = unittests("auif_onboard/tests")
    rc = subprocess.run([sys.executable, "tools/onboard_reverse_contamination.py", str(core["tests_run"]), str(ext["tests_run"]), str(ext["skipped"]), PINNED_CORE], cwd=ROOT, capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1")); rcd = ast.literal_eval(rc.stdout.strip().splitlines()[-1])
    ev = {"onboard_tests": ob, "core_tests": core, "ext_tests": ext, "static": st, "reverse_contamination": rcd, "pinned_core_tree_sha256": PINNED_CORE, "rev10_to_rev13_core_tree_sha256": REV10_TO_REV13_CORE, "core_tree_sha256": st["core_tree_sha256"], "frozen_layers_vs_rev13": integrity(pr), "specs": per_spec()}
    if mu: m = json.load(open(mu)); ev["mutation"] = {k: m[k] for k in ("mutants", "killed", "survived", "invalid", "defined")}; ev["mutation"]["equivalent_not_run"] = m["equivalent_not_run"]
    json.dump(ev, open(out, "w"), indent=1, default=str); sp = ev["specs"]
    good = (ob["ok"] and core["ok"] and ext["ok"] and rcd["ok"] and ev["core_tree_sha256"] == PINNED_CORE and ev["frozen_layers_vs_rev13"]["ok"] and not any(v for v in st.values() if isinstance(v, list)) and len(sp) == 3
            and all(s["validation"]["all_checks_passed"] and s["validation"]["synthetic_only"] and not s["validation"]["real_system_validated"] and s["credential_ref_in_draft"] is None and s["validated_or_trusted_in_draft"] == 0 and not s["secrets"]["canary_in_any_artifact_or_report"] and s["secrets"]["scan_findings_in_artifacts"] == 0 and s["secrets"]["canary_planted_in_spec"] in (True, False) for s in sp.values())
            and (mu is None or (ev["mutation"]["survived"] == 0 and ev["mutation"]["invalid"] == 0)))
    print(json.dumps({"onboard_tests": ob, "core_tests": core, "ext_tests": ext, "reverse_contamination": rcd, "frozen_layers_ok": ev["frozen_layers_vs_rev13"]["ok"], "specs": {k: v["validation"]["summary"] for k, v in sp.items()}, "mutation": ev.get("mutation", "not supplied")}, default=str))
    print("ONBOARD EVIDENCE: %s" % ("ALL OK" if good else "NOT OK (see the file)")); return 0 if good else 1
if __name__ == "__main__": sys.exit(main())

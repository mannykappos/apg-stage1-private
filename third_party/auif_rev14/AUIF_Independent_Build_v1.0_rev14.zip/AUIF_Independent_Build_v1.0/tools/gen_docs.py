"""Generates the Amir register, handoff, port templates and the derived documents. Quoted register text is copied verbatim from the audited package; nothing here asserts a fact about the Anchor Engine."""
import ast, glob, hashlib, inspect, json, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT)
from tools.amir_items import ITEMS, REQUIRED_FIELDS, FULL, tmpl
AUDITED = os.path.join(ROOT, "evidence", "audited_inputs")
def W(path, text): os.makedirs(os.path.dirname(os.path.join(ROOT, path)) or ROOT, exist_ok=True); open(os.path.join(ROOT, path), "w").write(text)
reg = json.load(open(AUDITED + "/03_AUIF_Open_Decisions_and_Dependency_Register.json")); _sp = json.load(open(AUDITED + "/07_AUIF_Acceptance_Test_Specification.json")); _sp = _sp if isinstance(_sp, list) else [v for v in _sp.values() if isinstance(v, list)][0]; spec = {t["id"]: t for t in _sp}
by_id = {x["id"]: x for k in ("engine_dependencies", "external_dependencies", "infrastructure_requirements", "db_dependent_closure_register", "governor_review_points", "open_decisions") for x in reg[k]}
def extracts(refs):
    out = []
    for r in refs:
        for i in ([r] if ".." not in r else ["DB-%02d" % n for n in range(int(r[3:5]), int(r[-2:]) + 1)] if r.startswith("DB-") else []):
            x = by_id.get(i)
            if not x: continue
            if i.startswith("DB-"): out.append({"register_id": i, "title": x["item"], "exact_amir_instruction": x["exact_amir_instruction"], "required_database_environment": x["required_database_environment"], "validation_procedure": x["validation_procedure"], "required_closure_evidence": x["required_closure_evidence"]})
            elif i.startswith("ED-"): out.append({"register_id": i, "title": x["title"], "requirement": x["requirement"], "closure_evidence": x.get("closure_evidence", "")})
            elif i[:2] in ("XD", "GD", "ID"): out.append({"register_id": i, "title": x["title"], "detail": x.get("issue") or x.get("requirement", "")})
    if "AUIF-AT-15" in refs: a = spec["AUIF-AT-15"]; out.append({"register_id": "AUIF-AT-15", "title": a["title"], "steps": a["steps"], "expected": a["expected"], "evidence": a["evidence"]})
    return out
TEMPLATES = {"module": ("ModulePortContract", "port_contracts.other_contracts", "make_module", "from <your_binding_module> import <YourModuleBinding>", "<YourModuleBinding>(...)"), "tenant": ("TenantAuthorityContract", "port_contracts.other_contracts", "make_authority", "from <your_binding_module> import <YourTenantAuthority>", "<YourTenantAuthority>(...)"),
             "persistence": ("PersistenceContract", "port_contracts.persistence_contract", "make_store", "from <your_binding_module> import <YourPersistence>", "<YourPersistence>(...)"), "secret": ("SecretPortContract", "port_contracts.other_contracts", "make_secrets", "from <your_binding_module> import <YourSecretPort>", "(<YourSecretPort>(...), <function(tenant_id, ref, value) that stores a secret out of band>)"),
             "governor": ("GovernorPortContract", "port_contracts.other_contracts", "make_governor", "from <your_binding_module> import <YourGovernorPort>", "<YourGovernorPort>(...)  # a NON-PRODUCTION Governor"), "policy": ("PolicyPortContract", "port_contracts.other_contracts", "make_policy", "from <your_binding_module> import <YourPolicyPort>", "<YourPolicyPort>(...)")}
for port, (cls, mod, fac, imp, ctor) in TEMPLATES.items():
    W("port_contracts/templates/test_%s_binding.py.template" % port, "# Copy to tests/binding/test_%s_binding.py, fill the <placeholders>, then run:\n#   python3 -W ignore -m unittest tests.binding.test_%s_binding -v\nimport unittest\nfrom %s import %s\n%s\nclass TestEngine%sBinding(%s, unittest.TestCase):\n    def %s(self): return %s\n" % (port, port, mod, cls, imp, port.capitalize(), cls, fac, ctor))
W("tests/binding/__init__.py", "# Engine binding tests live here (created from port_contracts/templates/*.template by whoever writes the binding).\n")
items = []
for it in ITEMS:
    port = it.get("port"); step = it["step"].replace("{T}", tmpl(port) if port else "")
    items.append({"id": it["id"], "component": it["component"], "register_refs": it["refs"], "why_blocked": it["why_blocked"], "engine_information_required": it["info"], "question_for_amir": it["question"], "evidence_required": it["evidence"], "implementation_step": step, "amir_must_modify_engine_code": it["modify"], "db_access_required": it["db"],
                  "staging_sufficient": it["staging"], "validation_procedure": it["validation"], "expected_result": it["expected"], "evidence_to_return": it["returns"], "unblocks": it["unblocks"], "dependencies": it["deps"], "status": "OPEN", "register_extracts_verbatim": extracts(it["refs"])})
doc = {"title": "AUIF Engine / live-environment dependency register (blocked items only)", "generated_from": "tools/amir_items.py + audited register 03 (verbatim extracts)", "rule": "Nothing in this register states a fact about the Anchor Engine. Each item is a question, a required artefact or a procedure whose output is evidence.", "required_fields": REQUIRED_FIELDS, "count": len(items), "items": items}
W("AMIR_ENGINE_DEPENDENCY_TODO.json", json.dumps(doc, indent=1))
md = ["# AMIR_ENGINE_DEPENDENCY_TODO", "", "Blocked items only. %d open items. Every item states: component, why blocked, exact Engine information, exact question, exact evidence, exact implementation step, whether Engine code changes, whether DB access is needed, whether staging suffices, exact validation command, expected result, evidence to return, what it unblocks, dependencies, status." % len(items), "",
      "Rule: nothing here states a fact about the Anchor Engine. Order of work: AMIR-TODO-01 first; the dependency column gives the rest.", "", "Run any suite from the build directory. Reference run: `%s`" % FULL, ""]
label = [("component", "Component"), ("register_refs", "Register references"), ("why_blocked", "Why it cannot be completed"), ("engine_information_required", "Engine information required"), ("question_for_amir", "Question for Amir"), ("evidence_required", "Source / file / config / DB evidence required"), ("implementation_step", "Implementation step Amir performs"), ("amir_must_modify_engine_code", "Amir must modify Engine code?"),
         ("db_access_required", "DB access required?"), ("staging_sufficient", "Staging / non-production sufficient?"), ("validation_procedure", "Validation command / procedure"), ("expected_result", "Expected result"), ("evidence_to_return", "Evidence to return"), ("unblocks", "Unblocks"), ("dependencies", "Dependencies / blockers"), ("status", "Status")]
for i in items:
    md += ["## %s: %s" % (i["id"], i["component"]), ""]
    for k, l in label[1:]: md.append("- **%s:** %s" % (l, ", ".join(i[k]) if isinstance(i[k], list) else i[k]))
    if i["register_extracts_verbatim"]:
        md += ["", "Verbatim extracts from the audited register:", ""]
        for e in i["register_extracts_verbatim"]: md.append("- `%s` %s" % (e["register_id"], json.dumps({k: v for k, v in e.items() if k != "register_id"}, ensure_ascii=False)[:1400]))
    md.append("")
W("AMIR_ENGINE_DEPENDENCY_TODO.md", "\n".join(md))
# persistence collections and sequences (scanned from the core; key prefixes inside a collection are NOT collections)
cols, seqs = set(), set()
for p in glob.glob(ROOT + "/auif/*.py"):
    src = open(p).read()
    for m in re.finditer(r'\.(?:put|get|update|list)\(\s*(?:self\.)?ctx,\s*"([a-z_\-]+:?)"', src): cols.add(m.group(1) + ("<integration_id>" if m.group(1).endswith(":") else ""))
    for m in re.finditer(r'next_sequence\(\s*(?:self\.)?ctx,\s*"([a-z_\-]+:?)"', src): seqs.add(m.group(1) + ("<id>" if m.group(1).endswith(":") else ""))
W("docs/PERSISTENCE_COLLECTIONS.md", "# Collections and sequences the AUIF core uses through PersistencePort\n\nGenerated by scanning auif/*.py. Each collection is keyed (tenant, collection, key); values are JSON documents. `if_absent` writes need a per-key unique constraint; `update` must be an atomic read-modify-write; `next_sequence(ctx, name)` must be strictly increasing per (tenant, name). Collections ending in `<integration_id>` are one logical collection per integration.\n\n## Collections\n\n" + "\n".join("- `%s`" % c for c in sorted(cols)) + "\n\n## Sequence names (counters, not collections)\n\n" + "\n".join("- `%s`" % c for c in sorted(seqs)) + "\n")
# port conformance cases
import importlib; from port_contracts import persistence_contract as pc, other_contracts as oc
lines = ["# Port conformance cases (language-neutral)\n\nA binding of a port passes when every case below holds. In Python, subclass the mixin (see port_contracts/templates). In another language, implement these cases in your framework.\n"]
for cls in (pc.PersistenceContract, oc.SecretPortContract, oc.TenantAuthorityContract, oc.GovernorPortContract, oc.PolicyPortContract, oc.ModulePortContract):
    lines += ["## %s" % cls.__name__, "", (inspect.getdoc(cls) or ""), ""]
    for n in sorted(x for x in dir(cls) if x.startswith("test_")): lines.append("- `%s`" % n.replace("test_", "", 1).replace("_", " "))
    lines.append("")
W("docs/PORT_CONFORMANCE_CASES.md", "\n".join(lines))
# Governor decisions
gd = ["# UNRESOLVED_GOVERNOR_DECISIONS", "", "These Governor-side decisions are OPEN and are NOT resolved by this build. AUIF isolates the interface and implements the audited DRAFT position only. Governor is unmodified.", ""]
where = {"GD-01": ("auif/canonical.py (framework only)", "AUIF keeps its own canonical model framework; it does not map into the Governor Neutral Model and defines no Governor-side translation."),
         "GD-02": ("auif/integration.py::_validate_phase; contracts/integration.schema.json (manifest_scope and governance_authority are constants)", "The manifest is INTEGRATION_CONFIGURATION with governance_authority NONE; the schema rejects anything else."),
         "GD-03": ("auif/action.py::ActionService.dispatch / submit; auif/ports.py::GovernorPort", "An action whose governance requirement is UNKNOWN is held and never sent; a decision reference supplied by a module is ignored and logged; decisions are obtained only from GovernorPort; AUIF carries ref and hash and never verifies or issues them."),
         "GD-04": ("auif/ports.py::PolicyPort; auif/classification.py::BoundaryEnforcer", "Policy is an input port. Undeterminable policy for a datum means the whole payload is rejected; AUIF never authors policy."),
         "GD-05": ("auif/ports.py::GovernorPort", "Only request_decision and report_condition exist. No authentication, signing or transport is implemented because none has been decided.")}
for g in reg["governor_review_points"]:
    w = where[g["id"]]; gd += ["## %s: %s" % (g["id"], g["title"]), "", "- **Audited issue:** %s" % g["issue"], "- **Audited open decisions:** %s" % json.dumps(g["open_decisions"], ensure_ascii=False), "- **Isolated in code at:** %s" % w[0], "- **What AUIF does meanwhile:** %s" % w[1], "- **Status:** OPEN (decision belongs to the owner / Governor side; not Amir)", ""]
W("UNRESOLVED_GOVERNOR_DECISIONS.md", "\n".join(gd))
print("generated: %d register items, %d port templates" % (len(items), len(TEMPLATES)))

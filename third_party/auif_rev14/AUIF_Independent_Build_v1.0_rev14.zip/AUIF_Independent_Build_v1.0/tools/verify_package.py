"""Manifest verification. Every file in FILE_MANIFEST.json must be present with the exact size and sha256; no unlisted file may exist (ignoring __pycache__ and *.pyc); the manifest's tree hash is recomputed.
Usage: python3 tools/verify_package.py [package_root]     |     python3 tools/verify_package.py --selftest"""
import hashlib, json, os, shutil, sys, tempfile
def tree_hash(files): return hashlib.sha256("\n".join("%s %s" % (f["path"], f["sha256"]) for f in sorted(files, key=lambda x: x["path"])).encode()).hexdigest()
def verify(root):
    m = json.load(open(os.path.join(root, "FILE_MANIFEST.json"))); problems, listed = [], set()
    for f in m["files"]:
        listed.add(f["path"]); p = os.path.join(root, f["path"])
        if not os.path.isfile(p): problems.append({"path": f["path"], "problem": "MISSING"}); continue
        b = open(p, "rb").read()
        if len(b) != f["bytes"]: problems.append({"path": f["path"], "problem": "SIZE", "expected": f["bytes"], "found": len(b)})
        if hashlib.sha256(b).hexdigest() != f["sha256"]: problems.append({"path": f["path"], "problem": "HASH"})
    for d, ds, fs in os.walk(root):
        ds[:] = [x for x in ds if x != "__pycache__"]
        for x in fs:
            rel = os.path.relpath(os.path.join(d, x), root)
            if rel not in listed and rel != "FILE_MANIFEST.json" and not x.endswith(".pyc"): problems.append({"path": rel, "problem": "UNLISTED"})
    if tree_hash(m["files"]) != m["tree_sha256"]: problems.append({"path": "FILE_MANIFEST.json", "problem": "TREE_HASH"})
    if m["file_count"] != len(m["files"]): problems.append({"path": "FILE_MANIFEST.json", "problem": "FILE_COUNT"})
    return {"files_checked": len(m["files"]), "mismatches": problems, "ok": not problems, "tree_sha256": m["tree_sha256"]}
def selftest():
    t = tempfile.mkdtemp(); ok = []
    try:
        def build():
            shutil.rmtree(t); os.makedirs(t + "/sub"); open(t + "/a.txt", "w").write("alpha"); open(t + "/sub/b.txt", "w").write("bravo")
            fs = [{"path": p, "bytes": os.path.getsize(t + "/" + p), "sha256": hashlib.sha256(open(t + "/" + p, "rb").read()).hexdigest()} for p in ("a.txt", "sub/b.txt")]
            json.dump({"file_count": 2, "tree_sha256": tree_hash(fs), "files": fs}, open(t + "/FILE_MANIFEST.json", "w"))
        def expect(label, mutate, kind):
            build(); mutate(); r = verify(t); got = {x["problem"] for x in r["mismatches"]}; ok.append((label, (kind in got) if kind else r["ok"]))
        expect("clean tree passes", lambda: None, None)
        expect("same-size content change -> HASH", lambda: open(t + "/a.txt", "w").write("ALPHA"), "HASH")
        expect("size change -> SIZE", lambda: open(t + "/a.txt", "w").write("alpha!"), "SIZE")
        expect("deleted file -> MISSING", lambda: os.remove(t + "/sub/b.txt"), "MISSING")
        expect("extra file -> UNLISTED", lambda: open(t + "/extra.txt", "w").write("x"), "UNLISTED")
        def tamper_tree(): m = json.load(open(t + "/FILE_MANIFEST.json")); m["tree_sha256"] = "0" * 64; json.dump(m, open(t + "/FILE_MANIFEST.json", "w"))
        expect("tree hash tampered -> TREE_HASH", tamper_tree, "TREE_HASH")
        expect("pycache is ignored", lambda: (os.makedirs(t + "/__pycache__"), open(t + "/__pycache__/x.pyc", "w").write("x")), None)
    finally: shutil.rmtree(t, ignore_errors=True)
    for l, k in ok: print("%-40s %s" % (l, "PASS" if k else "FAIL"))
    return all(k for _, k in ok)
if __name__ == "__main__":
    if "--selftest" in sys.argv: sys.exit(0 if selftest() else 1)
    root = next((a for a in sys.argv[1:] if not a.startswith("-")), os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); r = verify(root); print(json.dumps(r, indent=1)); sys.exit(0 if r["ok"] else 1)

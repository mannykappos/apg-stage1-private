"""Replays the independent auditor's round-1 scenarios against the CURRENT code and prints an explicit PASS/FAIL per finding. Exit code 0 only if every finding passes. Writes nothing.
Usage: python3 tools/audit_round1_replay.py"""
import copy, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
from auif.ai_boundary import AIMappingService, MappingProposer, PromotionRefused
from auif.fabric import Fabric
from auif.translation import apply_transform
from synthetic.ai_stub import ScriptedProposer
from synthetic.connectors import SyntheticRestConnector
from synthetic.modules import module_one, module_two
from synthetic.world import World, ref
A = "tenant-a"; results = []
def T(kind, **p): return {"kind": kind, "parameters": p, "deterministic": True}
def cand(src, canon, tr, mid="ai-replay"): return {"mapping_id": mid, "kind": "FIELD", "source_ref": src, "canonical_ref": canon, "mapping_state": "CANDIDATE", "proposed_by": "AI_ASSISTED", "inbound": {"source_type": "string", "canonical_type": "STRING", "transform": tr}, "outbound": {"supported": False, "reason": "inbound only"}}
def check(finding, label, ok, detail=""): results.append(ok); print("%-4s %-9s %s%s" % ("PASS" if ok else "FAIL", finding, label, (" -> " + detail) if detail else ""))
def refused(svc, rec, src, canon, tr):
    try: m = svc.promote(cand(src, canon, tr), rec); return False, "PROMOTED %s" % m["mapping_state"]
    except PromotionRefused as e: return True, str(e)[:70]
    except Exception as e: return False, "CRASH %s" % type(e).__name__
w = World(); w.activate_all(); rec = w.integrations[(A, "rest")].last_record; svc = AIMappingService(ScriptedProposer([]), w.model, w.ids)
print("--- FINDING 1 (HIGH): deterministic validator must validate transform semantics ---")
ok, d = refused(svc, rec, "Account.balance_cents", "Party.balance", T("UNIT_CONVERT")); check("F1", "UNIT_CONVERT with parameters {} is refused (audit case)", ok, d)
ok, d = refused(svc, rec, "Account.balance_cents", "Party.balance", T("DETERMINISTIC_FUNCTION", **{"in": "no_such_fn"})); check("F1", "DETERMINISTIC_FUNCTION with an unknown name is refused (audit case)", ok, d)
for label, tr in (("UNIT_CONVERT factor 0", T("UNIT_CONVERT", factor=0)), ("UNIT_CONVERT factor NaN", T("UNIT_CONVERT", factor="NaN")), ("function used in the wrong direction", T("DETERMINISTIC_FUNCTION", **{"in": "decimal_to_cents"}))):
    ok, d = refused(svc, rec, "Account.balance_cents", "Party.balance", tr); check("F1", label + " is refused", ok, d)
try: m = svc.promote(cand("Account.balance_cents", "Party.balance", T("UNIT_CONVERT", factor="0.01", decimals=2)), rec); out = apply_transform(m["inbound"]["transform"], 12345, "in"); check("F1", "a well-formed UNIT_CONVERT is promoted and executes without error", m["mapping_state"] == "VALIDATED" and out == "123.45", "12345 -> %s" % out)
except Exception as e: check("F1", "a well-formed UNIT_CONVERT is promoted and executes", False, "%s: %s" % (type(e).__name__, e))
print("--- FINDING 2 (HIGH): malformed proposer output must not escape the boundary ---")
class Out(MappingProposer):
    def __init__(self, o): self.o = o
    def propose(self, sb): return self.o
for label, o in (('["not a dict"] (audit case)', ["not a dict"]), ("None", None), ("a dict", {"a": 1}), ("[None]", [None]), ("transform is a string", [{"source_ref": "Account.profile.name", "canonical_ref": "Party.display_name", "transform": "IDENTITY"}])):
    try: r = AIMappingService(Out(o), w.model, w.ids).propose(rec); check("F2", label + " is contained", r["candidates"] == [] and bool(r["rejected"] or r["flags"]), "rejected=%d flags=%d" % (len(r["rejected"]), len(r["flags"])))
    except Exception as e: check("F2", label + " is contained", False, "ESCAPED %s" % type(e).__name__)
try: r = AIMappingService(Out(["junk", {"source_ref": "Account.profile.name", "canonical_ref": "Party.display_name", "transform": T("IDENTITY")}]), w.model, w.ids).propose(rec); check("F2", "a good proposal survives a bad neighbour", len(r["candidates"]) == 1 and len(r["rejected"]) == 1)
except Exception as e: check("F2", "a good proposal survives a bad neighbour", False, "ESCAPED %s" % type(e).__name__)
print("--- FINDING 3 (MEDIUM): ambiguity-resolution evidence must survive promotion ---")
s3 = AIMappingService(ScriptedProposer([{"source_ref": "Account.profile.name", "canonical_ref": "Party.display_name", "transform": T("IDENTITY"), "alternatives": ["Party.contact_email"]}]), w.model, w.ids); amb = s3.propose(rec)["candidates"][0]; EV = {"evidence_id": "ticket-42", "evidence_hash": "c" * 64}
p = s3.promote(s3.resolve_ambiguity(amb, "Party.display_name", EV), rec); chain_fn = getattr(s3, "resolution_chain", None); ch = chain_fn(p) if chain_fn else {"ambiguity_resolution": None, "bound_to_validation_record": False}; res = ch["ambiguity_resolution"] or {}
check("F3", "the resolution evidence is retained in the hash-bound chain", res.get("resolution_evidence") == EV and res.get("chosen") == "Party.display_name" and ch["bound_to_validation_record"], "evidence %s, candidates %s" % (res.get("resolution_evidence", {}).get("evidence_id"), res.get("candidate_meanings")))
check("F3", "the promoted mapping verifies against that chain", s3.verify_promotion(p))
s3b = AIMappingService(ScriptedProposer([]), w.model, w.ids); s3b.proposer = ScriptedProposer([{"source_ref": "Account.profile.name", "canonical_ref": "Party.display_name", "transform": T("IDENTITY"), "alternatives": ["Party.contact_email"]}]); amb2 = s3b.propose(rec)["candidates"][0]
stripped = {k: v for k, v in amb2.items() if k != "ambiguity"}; stripped["mapping_state"] = "CANDIDATE"
try: s3b.promote(stripped, rec); check("F3", "stripping the ambiguity flag does not bypass resolution", False, "PROMOTED")
except PromotionRefused as e: check("F3", "stripping the ambiguity flag does not bypass resolution", True, str(e)[:60])
print("--- FINDING 4 (MEDIUM): restart/resume must not bypass discovery coverage ---")
sa = w.sys[A]["A"]; old = w.integrations[(A, "rest")]; old_id = old.last_record["discovery_record_id"]
def restart(): f = Fabric(store=w.store, authority=w.auth, secrets=w.secrets, governor=w.gov, policy=w.policy, clock=w.clock, telemetry=w.tel, ids=w.ids, model=w.model, packs=w.packs, throttle=w.th); f.register_module(module_one()); f.register_module(module_two()); return f.add_integration(w.ctx[A], "ia-rest", anchor_module="synthetic-module-1", connector=SyntheticRestConnector(sa, "secretref:synthetic/rest"), pack_ref=ref(w.pA), target_system_id="synthetic-system-a", environment_id="env-sandbox", governed_operations=["updateAccount"], entities=["Account", "Property"])
c2 = restart(); rec2 = getattr(c2, "last_record", None); check("F4", "process restart restores the persisted discovery record", rec2 is not None and rec2["discovery_record_id"] == old_id)
c2.suspend("audit"); st = c2.resume(); check("F4", "suspend then resume takes a fresh record and returns to ACTIVE", st["state"] == "ACTIVE" and getattr(c2, "last_record", None) is not None and c2.last_record["discovery_record_id"] != old_id, "state %s" % st["state"])
c3 = restart(); c3.suspend("audit"); orig = sa.metadata; sa.metadata = lambda: {k: v for k, v in orig().items() if k not in ("entities", "operations")}; st = c3.resume()
check("F4", "restart + suspend + resume against a target with insufficient coverage is refused", st["state"] == "TRANSLATION_INVALID" and not st["trust_basis"]["manifest_validated"], "state %s" % st["state"]); sa.metadata = orig
c4 = restart(); c4.suspend("audit"); c4._fire("RESUMED_BY_ACTOR", "rule-resume", {}); c4.raw = {"entities": [], "operations": []}; c4.last_record = None
try: c4._validate_phase()
except Exception as e: print("     (gate raised %s)" % type(e).__name__)
check("F4", "a missing discovery record fails the gate (closed), not 'nothing missing'", c4.state() == "TRANSLATION_INVALID", "state %s" % c4.state())
print("--- FINDING 5 (found by the executor while fixing F1): a hostile data VALUE must not crash a sync ---")
w2 = World(); w2.activate_all(); w2.sys[A]["A"].rows["Account"]["2"]["balance_cents"] = "abc"
try: rep = w2.fabric.sync(w2.ctx[A], "ia-rest", "Account"); check("F5", "one record with a hostile value does not abort the batch", rep["failed"] is None and rep["invalid"] == 1 and rep["delivered"] == 6, "delivered=%d invalid=%d" % (rep["delivered"], rep["invalid"]))
except Exception as e: check("F5", "one record with a hostile value does not abort the batch", False, "CRASH %s" % type(e).__name__)
print("\nRESULT: %s (%d/%d scenarios pass)" % ("ALL FINDINGS PASS" if all(results) else "FAIL", sum(results), len(results))); sys.exit(0 if all(results) else 1)

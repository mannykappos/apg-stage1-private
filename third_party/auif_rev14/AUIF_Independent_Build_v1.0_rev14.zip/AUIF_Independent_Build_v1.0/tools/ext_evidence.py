"""Produces evidence/ext_verification.json for the extension package: ext test counts (always-on, and against the real R14 Governor if AUIF_GOVERNOR_R14_ZIP is set), static checks, reverse contamination, and the core hash. Run by the builder, not by the verifier.
Usage: python3 tools/ext_evidence.py <out.json>"""
import ast, json, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(ROOT, "tools"))
def tests(env_extra):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1"); env.pop("AUIF_GOVERNOR_R14_ZIP", None); env.update(env_extra); r = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "auif_ext/tests", "-t", "."], cwd=ROOT, capture_output=True, text=True, env=env); out = r.stdout + r.stderr
    n = int(re.search(r"Ran (\d+) tests", out).group(1)); sk = re.search(r"skipped=(\d+)", out); return {"tests_run": n, "skipped": int(sk.group(1)) if sk else 0, "ok": r.returncode == 0}
def main():
    import static_checks_ext; st = static_checks_ext.run(); want = str(json.load(open(os.path.join(ROOT, "ACCEPTANCE_RESULTS.json")))["run"]["tests_run"]); rc = subprocess.run([sys.executable, "tools/ext_reverse_contamination.py", want], cwd=ROOT, capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1")); core = ast.literal_eval(rc.stdout.strip().splitlines()[-1])
    ev = {"always_on": tests({}), "static": {k: v for k, v in st.items()}, "reverse_contamination": core}; z = os.environ.get("AUIF_GOVERNOR_R14_ZIP")
    if z: import hashlib; ev["against_real_governor_r14"] = dict(tests({"AUIF_GOVERNOR_R14_ZIP": z}), governor_zip_sha256=hashlib.sha256(open(z, "rb").read()).hexdigest())
    json.dump(ev, open(sys.argv[1], "w"), indent=1, default=str); print(json.dumps({k: (v if k != "static" else "see file") for k, v in ev.items()}, default=str))
    good = ev["always_on"]["ok"] and ev["reverse_contamination"]["ok"] and not any(v for v in st.values() if isinstance(v, list)) and (not z or (ev["against_real_governor_r14"]["ok"] and ev["against_real_governor_r14"]["skipped"] == 0))
    print("EXTENSION EVIDENCE: %s" % ("ALL OK" if good else "NOT OK (see the file)")); return 0 if good else 1
if __name__ == "__main__": sys.exit(main())

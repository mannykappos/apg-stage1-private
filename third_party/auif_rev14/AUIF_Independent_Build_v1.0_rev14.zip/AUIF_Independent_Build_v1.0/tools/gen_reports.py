"""Runs the full suite under a line tracer and derives ACCEPTANCE_RESULTS, the implementation-to-test RTM (with measured coverage), the architecture-to-implementation RTM and COMPONENT_STATUS from ACTUAL outcomes and the audited spec/RTM.
Nothing here asserts a result that was not measured in this run."""
import dis, hashlib, io, json, os, platform, re, sys, unittest
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
from tools import static_checks as SC
AUD = ROOT + "/evidence/audited_inputs"
def W(p, t): open(os.path.join(ROOT, p), "w").write(t)
core = {os.path.join(ROOT, "auif", f): "auif/" + f for f in sorted(os.listdir(ROOT + "/auif")) if f.endswith(".py")}
executed, touched, cur = {r: set() for r in core.values()}, {r: set() for r in core.values()}, [None]
def tracer(frame, event, arg):
    rel = core.get(frame.f_code.co_filename)
    if rel is None: return None
    touched[rel].add(cur[0]); executed[rel].add(frame.f_lineno)
    def local(fr, ev, a):
        if ev == "line": executed[rel].add(fr.f_lineno)
        return local
    return local
def executable(path):
    out, stack = set(), [compile(open(path).read(), path, "exec")]
    while stack:
        c = stack.pop(); out |= {l for _, l in dis.findlinestarts(c) if l}; stack += [k for k in c.co_consts if hasattr(k, "co_code")]
    return out
class R(unittest.TextTestResult):
    status = {}
    def startTest(self, t): cur[0] = t.id(); super().startTest(t)
    def addSuccess(self, t): R.status[t.id()] = "pass"; super().addSuccess(t)
    def addFailure(self, t, e): R.status[t.id()] = "FAIL"; super().addFailure(t, e)
    def addError(self, t, e): R.status[t.id()] = "ERROR"; super().addError(t, e)
    def addSkip(self, t, r): R.status[t.id()] = "skip"; super().addSkip(t, r)
def run_suite():
    cur[0] = "<import>"; sys.settrace(tracer)
    try:
        os.environ["AUIF_PERF_OUT"] = ROOT + "/evidence/performance_measurement.json"      # deliberate re-measurement: this generator owns that evidence file
        suite = unittest.TestLoader().discover(os.path.join(ROOT, "tests"), top_level_dir=ROOT); res = unittest.TextTestRunner(stream=io.StringIO(), resultclass=R, verbosity=0).run(suite)
    finally: sys.settrace(None)
    return res
res = run_suite(); tests = R.status; total, passed = len(tests), sum(v == "pass" for v in tests.values())
spec = json.load(open(AUD + "/07_AUIF_Acceptance_Test_Specification.json"))["tests"]; rtm = json.load(open(AUD + "/06_AUIF_RTM.json"))["rows"]
mut = json.load(open(ROOT + "/evidence/mutation_results.json")); core_hash = SC.tree_hash(); static = {"core_import_violations": SC.core_import_violations(), "forbidden_token_hits": SC.forbidden_token_hits(), "authority_api_hits": SC.authority_api_hits()}
meta = {"python": platform.python_version(), "tests_run": total, "tests_passed": passed, "tests_failed": total - passed, "core_tree_sha256": core_hash, "mutation": {k: mut[k] for k in ("mutants", "killed", "survived", "invalid")}, "static_checks_clean": not any(static.values())}
# ---- acceptance results
at_tests = {i: [] for i in range(1, 31)}
for tid, st in tests.items():
    for m in set(re.findall(r"AT_(\d\d)", tid.split(".")[-1])): at_tests[int(m)].append((tid, st))
rows = []
for a in spec:
    n = int(a["id"][-2:]); ts = at_tests[n]; ok = sum(s == "pass" for _, s in ts); dep = a["engine_dependency"]
    cat = "BLOCKED - AMIR REQUIRED" if dep.startswith("ENGINE-DEPENDENT") else ("BUILT BUT ENVIRONMENT-DEPENDENT" if dep.startswith("PARTLY") else "BUILT AND VERIFIED")
    if n == 15: result = "NOT EXECUTED: cannot run without McGrath access (XD-01) and the Anchor Real Estate module (ED-14). A guard test asserts it is not claimed." if ok else "NOT EXECUTED; guard test missing or failing"
    elif not ts: result = "NO TEST"
    elif ok == len(ts): result = "PASS on the synthetic world" + ("; real-platform run is environment-dependent" if cat.startswith("BUILT BUT") else "")
    else: result = "FAIL"
    rows.append({"id": a["id"], "title": a["title"], "layer": a["layer"], "category": cat, "engine_dependency_per_audited_spec": dep, "result": result, "tests_passed": ok, "tests_total": len(ts), "tests": [t for t, _ in ts]})
cats = {}
for r in rows: cats.setdefault(r["category"], []).append(r["id"][-2:])
acc = {"title": "AUIF Independent Build: acceptance results (synthetic world; audited spec 07)", "run": meta, "category_counts": {k: len(v) for k, v in cats.items()}, "categories": cats, "results": rows}
json.dump(acc, open(ROOT + "/ACCEPTANCE_RESULTS.json", "w"), indent=1)
L = ["# ACCEPTANCE_RESULTS", "", "Executed against the SYNTHETIC world through the real AUIF runtime. Not a result on the Anchor Engine. Categories follow the audited spec's `engine_dependency` field.", "",
     "Run: Python %s | %d tests run, %d passed, %d failed | core tree sha256 `%s` | mutation: %d/%d killed (%d survived, %d invalid) | static checks clean: %s" % (meta["python"], total, passed, total - passed, core_hash, mut["killed"], mut["mutants"], mut["survived"], mut["invalid"], meta["static_checks_clean"]), "",
     "| Category | Count | Tests |", "|---|---|---|"] + ["| %s | %d | %s |" % (k, len(v), ", ".join("AT-" + x for x in v)) for k, v in cats.items()] + ["", "| AT | Title | Category | Result | Tests passed |", "|---|---|---|---|---|"]
L += ["| %s | %s | %s | %s | %d/%d |" % (r["id"][-5:], r["title"], r["category"], r["result"], r["tests_passed"], r["tests_total"]) for r in rows]; W("ACCEPTANCE_RESULTS.md", "\n".join(L) + "\n")
# ---- coverage and implementation -> test RTM
cov = {}
for p, rel in core.items():
    ex = executable(p); hit = executed[rel] & ex; cls = sorted({t.rsplit(".", 1)[0].split(".")[-1] for t in touched[rel] if t and t != "<import>"}); ats = sorted({"AT-" + m for t in touched[rel] if t for m in re.findall(r"AT_(\d\d)", t.split(".")[-1])})
    cov[rel] = {"executable_lines": len(ex), "executed_lines": len(hit), "percent": round(100.0 * len(hit) / max(1, len(ex)), 1), "uncovered_lines": sorted(ex - hit), "test_classes": cls, "test_count": len({t for t in touched[rel] if t and t != "<import>"}), "acceptance_tests": ats,
                "mutants_killed": [m["id"] for m in mut["results"] if m["file"] == rel and m["result"] == "KILLED"]}
json.dump(cov, open(ROOT + "/evidence/coverage_by_core_file.json", "w"), indent=1)
tot_ex, tot_hit = sum(c["executable_lines"] for c in cov.values()), sum(c["executed_lines"] for c in cov.values())
L = ["# RTM_IMPL_TO_TEST: implementation to test traceability (measured)", "", "Line execution was MEASURED by tracing the full suite (`tools/gen_reports.py`). Percent = executable lines executed at least once by some test. It shows code was exercised, not that every behaviour was asserted: mutation results are listed beside it.", "",
     "Overall: %d/%d executable core lines executed (%.1f%%)." % (tot_hit, tot_ex, 100.0 * tot_hit / tot_ex), "", "| Core file | Lines run | % | Tests touching | Acceptance tests touching | Mutants killed |", "|---|---|---|---|---|---|"]
L += ["| %s | %d/%d | %s | %d | %s | %s |" % (f, c["executed_lines"], c["executable_lines"], c["percent"], c["test_count"], ", ".join(c["acceptance_tests"]) or "-", ", ".join(c["mutants_killed"]) or "-") for f, c in cov.items()]
L += ["", "## Test classes per core file", ""] + ["- **%s**: %s" % (f, ", ".join(c["test_classes"])) for f, c in cov.items()]; W("RTM_IMPL_TO_TEST.md", "\n".join(L) + "\n"); json.dump(cov, open(ROOT + "/RTM_IMPL_TO_TEST.json", "w"), indent=1)
# ---- architecture -> implementation RTM
AR = {  # id: (title, implementation, verified scope, environment-dependent scope, blocked scope, Amir items)
 "AR-0": ("Reading rules and tagging", ["evidence/audited_inputs/", "contracts/"], "Audited inputs copied byte-identically (verified)", "", "", []),
 "AR-1": ("Purpose and commercial shape", [], "Document only", "", "", []),
 "AR-2": ("Separation of concerns", ["auif/ports.py", "tools/static_checks.py"], "Core depends only on stdlib and itself; ports are the only boundary (static check, AT-17/28)", "", "", []),
 "AR-3": ("Governor boundary", ["auif/ports.py", "auif/action.py", "auif/integration.py", "tools/static_checks.py"], "AUIF requests and reports only; no authority API exists (static scan); governed action never sent without a decision (AT-13, M11/M25/M28)", "Real Governor wiring (EP-07); GD-03/GD-05 open", "", ["AMIR-TODO-07"]),
 "AR-4": ("Component model and isolation", ["auif/", "synthetic/", "tools/static_checks.py"], "Core/synthetic separation; core tree hash unchanged when a 4th system is added (AT-01/02/16)", "", "", []),
 "AR-5": ("Connection Layer / Connector contract", ["auif/connector.py", "synthetic/connectors.py"], "Contract enforcement, retry/Retry-After, idempotency-gated writes, failure principle, cancellation, credential boundary (AT-08/11/14/18/20)", "Real transports and credentials", "", ["AMIR-TODO-05", "AMIR-TODO-09"]),
 "AR-6": ("Discovery, fingerprint, drift", ["auif/discovery.py", "auif/integration.py"], "Records, deterministic fingerprints, scoped drift (AT-05)", "Materiality policy (OD-05) is a draft position", "", []),
 "AR-7": ("Canonical Anchor Model boundary", ["auif/canonical.py"], "Framework, typed validation, classification, provenance chain (AT-19/22)", "", "The REAL Anchor canonical attribute sets (OD-08)", ["AMIR-TODO-11"]),
 "AR-8": ("Translation Packs", ["auif/translation.py", "synthetic/packs.py"], "Immutable hashed registry, pinning, bidirectional translation, explicit outcomes, outbound validation (AT-03/04/06/19/23); ONE shared transform validator for the registry, runtime and AI validator, and hostile data values are explicit per-field failures (audit round 1: F1, F5)", "", "Real target packs (McGrath)", ["AMIR-TODO-13"]),
 "AR-9": ("Ambiguity and AI boundary", ["auif/ai_boundary.py", "synthetic/ai_stub.py"], "AI proposes only; deterministic promotion with full transform validation; sandbox; proposer OUTPUT treated as untrusted input; ambiguity-resolution evidence hash-bound into the validation record; untrusted text (AT-07/25; audit round 1: F1, F2, F3); promotion evidence binds the complete mapping and the registry recognises AI promotion by its evidence (audit round 2: F6)", "Real AI service binding", "", ["AMIR-TODO-17"]),
 "AR-10": ("Observations, provenance, ordering", ["auif/observation.py", "auif/fabric.py"], "Envelopes, causal ordering, bounded wait then reconcile, dedupe (AT-09/10/22)", "", "", []),
 "AR-11": ("Backpressure and throttling", ["auif/throttle.py", "auif/connector.py"], "Token bucket, Retry-After, circuit breaker, bounded queues, tenant-fair scheduling (AT-08/30)", "Fairness on the platform's real workers", "", ["AMIR-TODO-06"]),
 "AR-12": ("Classification and boundary enforcement", ["auif/classification.py", "synthetic/policy.py"], "Policy-driven allow/transform/reject; undeterminable means reject (AT-21)", "The real policy source (GD-04/OD-09)", "", ["AMIR-TODO-18"]),
 "AR-13": ("Actions, ledger, idempotency", ["auif/action.py"], "Ledger transition table, durable before send, idempotency, no blind retry, reconciliation (AT-11/13); submission is a resumable write-ahead intent: a failure at any single write cannot strand an action or a key (audit round 2: F7); an action's tenant must equal the authenticated context before any record is written (audit round 3: F9)", "Durable ledger on real storage", "", ["AMIR-TODO-04"]),
 "AR-14": ("Integration state machine and manifest", ["auif/integration.py", "contracts/integration_state_machine.json"], "ACTIVE only via validation; failure distinctions; manifests carry no authority; discovery record persisted, restored on restart and re-taken on resume, and the pack gate fails closed without one (AT-05/06; audit round 1: F4)", "", "", []),
 "AR-15": ("Tenant isolation, credentials, security", ["auif/tenancy.py", "auif/security.py", "auif/observability.py", "auif_ref/secrets.py"], "Forged/missing context refused; hostile input; no secret in outputs (AT-12/14/20/24); a caller-supplied action tenant is verified against the authenticated context (audit round 3: F9)", "Isolation on real data layer, secrets and infrastructure", "", ["AMIR-TODO-03", "AMIR-TODO-05", "AMIR-TODO-16"]),
 "AR-16": ("Versioning", ["auif/translation.py", "auif/integration.py"], "Pack/model/contract compatibility checks; manifest versions", "", "", []),
 "AR-17": ("Observability and performance", ["auif/observability.py", "evidence/performance_measurement.json"], "15 required signals, redaction (AT-24); synthetic performance measured (AT-29)", "Real sink and real performance", "", ["AMIR-TODO-08", "AMIR-TODO-14"]),
 "AR-18": ("Anchor module contract", ["auif/modules.py", "auif/ports.py", "synthetic/modules.py"], "Module Port against reference modules; module isolation", "Real module binding; descriptor format OD-22 is reference-only", "Anchor Real Estate specifics", ["AMIR-TODO-02", "AMIR-TODO-12"]),
 "AR-19": ("Proving ground and testing strategy", ["tests/", "synthetic/world.py", "tools/mutation_test.py", "tools/static_checks.py"], "Synthetic world, acceptance, mutation testing (see evidence/mutation_results.json), static checks", "", "McGrath proof (AT-15)", ["AMIR-TODO-13"]),
 "AR-20": ("Engine boundary (ED-01..14)", ["auif/ports.py", "port_contracts/", "AMIR_ENGINE_DEPENDENCY_TODO.md"], "Ports and conformance suites exist; every Engine fact recorded as UNKNOWN", "All bindings", "Reconnaissance", ["AMIR-TODO-01", "AMIR-TODO-02", "AMIR-TODO-03", "AMIR-TODO-04", "AMIR-TODO-05", "AMIR-TODO-06", "AMIR-TODO-07", "AMIR-TODO-08", "AMIR-TODO-09", "AMIR-TODO-10", "AMIR-TODO-15"]),
 "AR-21": ("Reference vs production; DB-dependent closure", ["auif_ref/", "docs/PERSISTENCE_COLLECTIONS.md"], "Two reference stores pass the persistence conformance suite", "DB-dependent closure items (DB-01..DB-10)", "", ["AMIR-TODO-04", "AMIR-TODO-18"]),
 "AR-22": ("Order, gates, evidence, change control", ["tools/", "evidence/", "FILE_MANIFEST.json"], "Evidence, manifest and hashes", "Architecture LOCK remains gated on reconnaissance review", "", ["AMIR-TODO-01"]),
 "AR-23": ("What remains open", ["UNRESOLVED_GOVERNOR_DECISIONS.md", "KNOWN_LIMITATIONS.md"], "Open items recorded; none resolved here", "", "", [])}
atres = {r["id"][-2:]: r for r in rows}; arrows = []
for k, (t, impl, v, e, b, am) in AR.items():
    ats = sorted({a[-2:] for r in rtm if k in r.get("architecture_primary", []) for a in r.get("tests", [])}); arrows.append({"ar": k, "title": t, "implementation": impl, "verified_scope": v, "environment_dependent_scope": e, "blocked_scope": b, "amir_items": am, "acceptance_tests": ["AT-" + a for a in ats], "at_results": {("AT-" + a): atres[a]["result"][:60] for a in ats if a in atres}})
json.dump(arrows, open(ROOT + "/RTM_ARCH_TO_IMPL.json", "w"), indent=1)
L = ["# RTM_ARCH_TO_IMPL: architecture (AR-0..AR-23) to implementation", "", "Source: audited Architecture v1.0-DRAFT Revision 2. Scope columns say exactly what is verified on the synthetic world, what still needs the real environment, and what is blocked.", "",
     "| AR | Title | Implementation | Verified (synthetic) | Environment-dependent | Blocked | Amir items |", "|---|---|---|---|---|---|---|"]
L += ["| %s | %s | %s | %s | %s | %s | %s |" % (r["ar"], r["title"], "; ".join(r["implementation"]) or "-", r["verified_scope"] or "-", r["environment_dependent_scope"] or "-", r["blocked_scope"] or "-", ", ".join(x[-2:] for x in r["amir_items"]) or "-") for r in arrows]
L += ["", "## Handoff headings (67) to architecture, implementation and acceptance evidence", "", "| Handoff | Heading | Architecture | Implementation | Acceptance tests (result) | Dependencies |", "|---|---|---|---|---|---|"]; hrows = []
for r in rtm:
    prim = r.get("architecture_primary", []); impl = sorted({f for a in prim for f in AR.get(a, ("", [], "", "", "", []))[1]}); ats = [a[-2:] for a in r.get("tests", [])]
    stat = "DOCUMENT/GOVERNANCE (no code)" if not impl else ("PARTLY BLOCKED (AT-15)" if "15" in ats else ("VERIFIED on synthetic; real-platform run env-dependent" if any(atres[a]["category"].startswith("BUILT BUT") for a in ats if a in atres) else "VERIFIED on synthetic" if ats else "IMPLEMENTED; verified by unit/contract tests"))
    hrows.append({"handoff_id": r["handoff_id"], "heading": r["heading"], "architecture": prim, "implementation": impl, "acceptance_tests": ["AT-" + a for a in ats], "dependencies": r.get("dependencies", []), "status": stat})
    L.append("| %s | %s | %s | %s | %s | %s |" % (r["handoff_id"], r["heading"][:60], ", ".join(prim), "; ".join(impl)[:90] or "-", ", ".join("AT-%s" % a for a in ats) or "-", ", ".join(r.get("dependencies", [])) or "-"))
L += ["", "Handoff-row status is in `RTM_ARCH_TO_IMPL.json` (`handoff_rows`)."]; W("RTM_ARCH_TO_IMPL.md", "\n".join(L) + "\n"); json.dump({"architecture": arrows, "handoff_rows": hrows}, open(ROOT + "/RTM_ARCH_TO_IMPL.json", "w"), indent=1)
print(json.dumps(meta)); print("categories:", acc["category_counts"]); print("coverage: %d/%d = %.1f%%" % (tot_hit, tot_ex, 100.0 * tot_hit / tot_ex)); print("failing:", [t for t, s in tests.items() if s != "pass"][:5]); print("AT without tests:", [r["id"] for r in rows if r["result"] == "NO TEST"])
sys.exit(0 if passed == total and not [r for r in rows if r["result"] in ("FAIL", "NO TEST")] else 1)

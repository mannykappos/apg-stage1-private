"""Replays the independent audit's round-3 scenario (F9: a CanonicalAction whose tenant_id differs from the authenticated TenantContext) against the CURRENT code; prints PASS/FAIL per scenario; exit 0 only if all pass. Writes nothing.
Usage: python3 tools/audit_round3_replay.py"""
import copy, dataclasses, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
from auif.errors import TenantContextError
from auif.util import sha
from synthetic.world import World
from tests.acceptance_support import act
results = []
def check(label, ok, detail=""): results.append(ok); print("%-4s %s%s" % ("PASS" if ok else "FAIL", label, (" -> " + detail) if detail else ""))
class Boom(Exception): pass
COLLS = ("action_idem", "action_ledger", "action_payloads", "action_manifest_ref", "action_events")
def world():
    w = World(); w.activate_all(); return w
def instrument(w, fail_at=None):
    st = {"n": 0, "writes": []}; s = w.store; op, ou, nq = s.put, s.update, s.next_sequence
    def tick(kind, c, coll):
        st["n"] += 1; st["writes"].append("%s:%s:%s" % (kind, c.tenant_id, coll))
        if st["n"] == fail_at: raise Boom("injected")
    s.put = lambda c, coll, k, v, **kw: (tick("put", c, coll), op(c, coll, k, v, **kw))[1]; s.update = lambda c, coll, k, fn: (tick("update", c, coll), ou(c, coll, k, fn))[1]; s.next_sequence = lambda c, name: (tick("seq", c, name), nq(c, name))[1]; return st
def records(w): return {t: {c: len(w.store.list(w.ctx[t], c)) for c in COLLS} for t in ("tenant-a", "tenant-b")}
def empty(w): return all(n == 0 for per in records(w).values() for n in per.values())
def outcome(fn):
    try: r = fn(); return "ACCEPTED (%s)" % r.get("execution_state", "?") if isinstance(r, dict) else "ACCEPTED"
    except TenantContextError as e: return "TenantContextError"
    except Exception as e: return type(e).__name__
print("--- F9 (HIGH): a CanonicalAction's tenant_id must equal the authenticated TenantContext, checked before any record is written ---")
w = world(); a = act(w, "tenant-a", 1, {"display_name": "Zed"}); r = w.fabric.actions.submit(w.ctx["tenant-a"], a); check("a matching tenant is accepted and queued", r["execution_state"] == "QUEUED" and r["tenant_id"] == "tenant-a")
for label, tid in (("a different existing tenant (audit case)", "tenant-b"), ("a non-existent tenant", "tenant-zzz"), ("the right tenant in other case", "TENANT-A")):
    w = world(); st = instrument(w); a = act(w, "tenant-a", 1, {"display_name": "Zed"}); a["tenant_id"] = tid; o = outcome(lambda: w.fabric.actions.submit(w.ctx["tenant-a"], a))
    check("mismatch (%s) is rejected" % label, o in ("TenantContextError", "ContractViolation"), o); check("   ... with ZERO store writes of any kind", st["writes"] == [], "%d writes: %s" % (len(st["writes"]), st["writes"][:2])); check("   ... and no idempotency/ledger/payload/manifest/event record in EITHER tenant", empty(w), str(records(w)) if not empty(w) else "")
w = world(); a = act(w, "tenant-b", 1, {"display_name": "Zed"}); st = instrument(w, fail_at=2)
try: w.fabric.actions.submit(w.ctx["tenant-a"], a)
except Exception: pass
idem = w.store.get(w.ctx["tenant-a"], "action_idem", a["idempotency_key"]); held = ((idem or {}).get("intent") or {}).get("action", {}).get("tenant_id")
check("the durable intent never holds a tenant other than the authenticated one (audit's mid-flight observation)", idem is None or held in (None, "tenant-a"), "reservation exists, its intent carries tenant_id=%s" % held if idem is not None and held not in (None, "tenant-a") else "")
w = world(); a = act(w, "tenant-b", 1, {"display_name": "Zed"})
try: w.fabric.actions.submit(w.ctx["tenant-a"], a)
except Exception: pass
rp = [getattr(w.fabric.actions, "recover_pending")(w.ctx[t]) for t in ("tenant-a", "tenant-b")]; check("a rejected mismatched submission cannot be recovered by recover_pending() in either tenant", all(x["completed"] == [] for x in rp) and empty(w), str(rp)[:100] if not empty(w) else "")
w = world(); a1 = act(w, "tenant-a", 1, {"display_name": "Zed"}); st = instrument(w, fail_at=2)
try: w.fabric.actions.submit(w.ctx["tenant-a"], a1)
except Boom: pass
w.store.put, w.store.update = w.store.put, w.store.update
o = outcome(lambda: w.fabric.actions.submit(w.ctx["tenant-b"], a1)); check("a retry of tenant-a's action under tenant-b's context is rejected", o == "TenantContextError", o)
check("   ... tenant-b gets no records and tenant-a's reservation is untouched", records(w)["tenant-b"] == {c: 0 for c in COLLS} and (w.store.get(w.ctx["tenant-a"], "action_idem", a1["idempotency_key"]) or {}).get("state") == "RESERVED", str(records(w)["tenant-b"]))
w = world(); a = act(w, "tenant-b", 1, {"display_name": "Zed"}); ctxa = w.ctx["tenant-a"]
w.store.put(ctxa, "action_idem", a["idempotency_key"], {"action_id": a["action_id"], "content_hash": sha(a["canonical_action"]), "state": "RESERVED", "reserved_at": "2026-10-02T00:00:00Z", "intent": {"action": a}}, if_absent=True)
out = w.fabric.actions.recover_pending(ctxa); check("a reservation planted with another tenant's action cannot be completed by recover_pending()", out["completed"] == [] and w.store.get(ctxa, "action_ledger", a["action_id"]) is None, "completed %s; ledger %s" % (out["completed"], "CREATED under tenant-a" if w.store.get(ctxa, "action_ledger", a["action_id"]) else "none"))
w = world(); a = act(w, "tenant-b", 1, {"display_name": "Zed"}); forged = dataclasses.replace(w.ctx["tenant-a"], tenant_id="tenant-b"); st = instrument(w); o = outcome(lambda: w.fabric.actions.submit(forged, a)); check("a FORGED context that claims the action's tenant cannot satisfy the check", o not in ("ACCEPTED (QUEUED)",) and empty(w), o)
w = world(); o = outcome(lambda: w.fabric.request_action(w.ctx["tenant-a"], "synthetic-module-1", act(w, "tenant-b", 1, {"display_name": "Y"}))); check("control: the public Fabric.request_action entry point still refuses it", o == "TenantContextError", o)
print("\nRESULT: %s (%d/%d scenarios pass)" % ("ALL FINDINGS PASS" if all(results) else "FAIL", sum(results), len(results))); sys.exit(0 if all(results) else 1)

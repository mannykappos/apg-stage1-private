"""Static checks for the extension package (auif_ext), complementing tools/static_checks.py (which covers the core). Checks, by syntax tree and not by text: imports are standard library / auif / auif_ext only; no Governor, synthetic, reference or test code is imported by
production extension code; only the HTTP transport imports network modules; no real external system is named; no logging, printing, deserialisation or process execution; no authority operation exists; the core never mentions the extensions; and the core tree hash is reported.
Prints one dict and exits 0 only if every list is empty."""
import ast, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(ROOT, "tools"))
NET = {"socket", "ssl", "http", "urllib", "ftplib", "smtplib", "telnetlib", "poplib", "imaplib", "xmlrpc", "socketserver", "asyncio", "select", "selectors"}; HTTP_FILE = os.path.join("auif_ext", "connectors", "http_client.py")
NAMES = ("xero", "myob", "salesforce", "hubspot", "mcgrath", "reapit", "vaultre", "ndis", "quickbooks", "stripe", "netsuite", "sap", "dynamics", "zoho", "pipedrive", "freshbooks", "mindbody", "westlab", "tasso")
BAD_CALLS = {"print", "eval", "exec", "compile", "__import__", "breakpoint"}; BAD_MODULES = {"logging", "pickle", "cPickle", "marshal", "subprocess", "shelve", "yaml", "ctypes", "multiprocessing", "importlib"}; BAD_OS = {"system", "popen", "execv", "execl", "spawnl", "fork"}
AUTH = {"evaluate_policy", "issue_promotion_token", "mutate_governor_state", "assert_compliant", "determine_materiality", "resolve_conflict", "issue_cpt", "authorize", "grant_decision", "decide"}
def files():
    out = []
    for r, ds, fs in os.walk(os.path.join(ROOT, "auif_ext")):
        ds[:] = [d for d in ds if d not in ("tests", "__pycache__")]; out += [os.path.join(r, f) for f in fs if f.endswith(".py")]
    return sorted(out)
def imports(tree): return [(a.name, 0, n.lineno) for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names] + [((n.module or ""), n.level, n.lineno) for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
def run():
    r = {"ext_import_violations": [], "ext_governor_or_test_imports": [], "ext_network_import_violations": [], "ext_real_system_names": [], "ext_forbidden_constructs": [], "ext_authority_names": [], "core_mentions_ext": [], "ext_files_checked": 0}
    for p in files():
        rel = os.path.relpath(p, ROOT); src = open(p).read(); tree = ast.parse(src); r["ext_files_checked"] += 1
        for mod, lvl, line in imports(tree):
            if lvl: continue
            top = mod.split(".")[0]
            if top not in sys.stdlib_module_names and top not in ("auif", "auif_ext"): r["ext_import_violations"].append((rel, line, mod))
            if top in ("governor_core", "adapters", "synthetic", "auif_ref", "tests", "port_contracts", "tools"): r["ext_governor_or_test_imports"].append((rel, line, mod))
            if rel != HTTP_FILE and (mod in ("http.client", "http.server", "urllib.request") or (top in NET and top not in ("http", "urllib"))): r["ext_network_import_violations"].append((rel, line, mod))
            if top in BAD_MODULES: r["ext_forbidden_constructs"].append((rel, line, mod))
        for i, line in enumerate(src.split("\n"), 1):
            for n in NAMES:
                if re.search(r"\b%s\b" % n, line, re.I): r["ext_real_system_names"].append((rel, i, n))
        for n in ast.walk(tree):
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in BAD_CALLS: r["ext_forbidden_constructs"].append((rel, n.lineno, n.func.id))
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id == "os" and n.func.attr in BAD_OS: r["ext_forbidden_constructs"].append((rel, n.lineno, "os." + n.func.attr))
            name = n.name if isinstance(n, (ast.FunctionDef, ast.ClassDef)) else n.id if isinstance(n, ast.Name) else n.attr if isinstance(n, ast.Attribute) else None
            if name in AUTH: r["ext_authority_names"].append((rel, getattr(n, "lineno", 0), name))
    for d, _, fs in os.walk(os.path.join(ROOT, "auif")):
        for f in fs:
            if f.endswith(".py") and "auif_ext" in open(os.path.join(d, f)).read(): r["core_mentions_ext"].append(f)
    import static_checks; cwd = os.getcwd(); os.chdir(ROOT)
    try: r["core_tree_sha256"] = static_checks.tree_hash()
    finally: os.chdir(cwd)
    return r
if __name__ == "__main__":
    res = run(); print(res); sys.exit(0 if not any(res[k] for k in res if isinstance(res[k], list)) else 1)

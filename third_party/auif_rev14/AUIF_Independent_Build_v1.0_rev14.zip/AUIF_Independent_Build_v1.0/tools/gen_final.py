"""Generates README, COMPONENT_STATUS, AMIR_HANDOFF, BUILD_REPORT and FILE_MANIFEST from MEASURED outputs (ACCEPTANCE_RESULTS.json, RTM, coverage, mutation results) and the audited register.
Never overwrites an existing file unless --force. Asserts nothing about the Anchor Engine."""
import hashlib, json, os, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); FORCE = "--force" in sys.argv; wrote, skipped = [], []
def J(p): return json.load(open(os.path.join(ROOT, p)))
def W(p, t):
    full = os.path.join(ROOT, p)
    if os.path.exists(full) and not FORCE: skipped.append(p); return
    open(full, "w").write(t); wrote.append(p)
def fmt(v):
    if isinstance(v, bool): return "Yes" if v else "No"
    if isinstance(v, list): return "\n".join("  - " + str(x) for x in v)
    return str(v)
acc, rtm, amir, cov, mut = J("ACCEPTANCE_RESULTS.json"), J("RTM_ARCH_TO_IMPL.json"), J("AMIR_ENGINE_DEPENDENCY_TODO.json"), J("evidence/coverage_by_core_file.json"), J("evidence/mutation_results.json")
reg = J("evidence/audited_inputs/03_AUIF_Open_Decisions_and_Dependency_Register.json"); items = amir["items"]; run = acc["run"]; cats = acc["categories"]; arch_zip = open(os.path.join(ROOT, "contracts/SOURCE.sha256")).read() and "31cb5f988d1b04cf4c6edf37a6f53fe4e4ef3a0221d6e60c1d6bee4db7658f20"
tot = sum(v.get("total", v.get("lines", 0)) if isinstance(v, dict) else 0 for v in cov.values()); 
def levels():
    deps = {i["id"]: [d for d in (x.strip() for x in str(i["dependencies"]).replace(";", ",").split(",")) if d.startswith("AMIR-TODO-")] for i in items}; done, out = set(), []
    while len(done) < len(deps):
        lvl = sorted(k for k, d in deps.items() if k not in done and set(d) <= done)
        if not lvl: lvl = sorted(k for k in deps if k not in done)
        out.append(lvl); done |= set(lvl)
    return out, deps
lv, deps = levels(); byid = {i["id"]: i for i in items}
# ---- COMPONENT_STATUS
rows = rtm["architecture"]; V = [r for r in rows if r["verified_scope"].strip()]; E = [r for r in rows if r["environment_dependent_scope"].strip()]; B = [r for r in rows if r["blocked_scope"].strip()]
cs = ["# COMPONENT_STATUS", "", "Per architecture section (AR-n), derived from `RTM_ARCH_TO_IMPL.json`. Three categories, as required by the build authorization. All evidence is on the SYNTHETIC world; nothing here is an Engine result.", "",
      "- **BUILT AND VERIFIED**: implemented and tested here. Sections with a non-empty verified scope: %d of %d." % (len(V), len(rows)), "- **BUILT BUT ENVIRONMENT-DEPENDENT**: implemented here; final validation needs Amir / live infrastructure. Sections: %d." % len(E), "- **BLOCKED - AMIR REQUIRED**: cannot be implemented without Engine facts. Sections with a blocked part: %d." % len(B), "",
      "| AR | Title | Verified scope | Environment-dependent scope | Blocked scope | Amir items | AT |", "|---|---|---|---|---|---|---|"]
for r in rows: cs.append("| %s | %s | %s | %s | %s | %s | %s |" % (r["ar"], r["title"], r["verified_scope"] or "-", r["environment_dependent_scope"] or "-", r["blocked_scope"] or "-", ", ".join(r["amir_items"]) or "-", ", ".join(r["acceptance_tests"]) or "-"))
cs += ["", "## Acceptance tests by category", ""] + ["- **%s** (%d): %s" % (k, len(v), ", ".join(v)) for k, v in cats.items()]
W("COMPONENT_STATUS.md", "\n".join(cs) + "\n"); W("COMPONENT_STATUS.json", json.dumps({"categories_by_acceptance_test": cats, "architecture": rows}, indent=1))
# ---- AMIR_HANDOFF
h = ["# AMIR_HANDOFF", "", "**STATUS: RELEASED FOR HANDOFF. The implementation was independently audited in three rounds (rev6 was accepted as the current reference candidate; it is not frozen). The accompanying document AUIF_Amir_Full_Handoff_rev6.pdf is the overview; this file and AMIR_ENGINE_DEPENDENCY_TODO.md are the detailed per-item instructions.**", "", "Everything Amir needs to close the Engine-dependent work, in order. You do not need to reverse-engineer anything: each item states what to find, what to build, how to prove it and what to send back.", "",
     "## Ground rules", "", "1. **Nothing in this package states a fact about the Anchor Engine.** Every Engine detail is UNKNOWN until you supply it with evidence. If an item's answer is not what a placeholder implies, say so; do not make the Engine fit the placeholder.",
     "2. **Do not modify `auif/` (the core) to fit the Engine.** Bind to the ports in `auif/ports.py` from outside, or report the mismatch as a finding. Governor is out of scope and must not be modified.", "3. **Staging or non-production first**, wherever an item says staging is sufficient.",
     "4. **Return evidence exactly as each item lists it.** Put it in `evidence_from_amir/<ITEM-ID>/` with a `SHA256SUMS` file (sha256 of every file you return).", "", "## Setup (about 5 minutes)", "",
     "Python 3.12, standard library only. From the package root:", "", "```", "export PYTHONDONTWRITEBYTECODE=1", "python3 -W ignore -m unittest discover -s tests -t .", "python3 tools/static_checks.py", "```", "",
     "Expected: all tests pass (%d at packaging), static checks report no violations. If this baseline fails on your machine, stop and report that first." % run["tests_run"], "",
     "## How to prove a port binding", "", "Each port has a conformance suite in `port_contracts/`. Templates are in `port_contracts/templates/`: copy one to `tests/binding/`, fill the placeholders with your binding, run it with `python3 -W ignore -m unittest tests.binding.<name> -v`. A binding passes when every case passes. `docs/PORT_CONFORMANCE_CASES.md` lists the cases language-neutrally if the platform is not Python.",
     "To run the whole synthetic world on a real persistence binding, set `AUIF_BINDINGS_MODULE` (test-world hook in `synthetic/world.py`; see `KNOWN_LIMITATIONS.md` item 17).", "", "## Order of work", "", "Items are grouped by dependency. Items in the same group can run in parallel.", ""]
for n, lvl in enumerate(lv, 1): h.append("- **Group %d:** %s" % (n, ", ".join(lvl)))
h.append("")
for lvl in lv:
    for iid in lvl:
        i = byid[iid]; h += ["## %s: %s" % (iid, i["component"]), "", "- **Depends on:** %s" % i["dependencies"], "- **Why it is blocked:** %s" % fmt(i["why_blocked"]), "- **Engine information required:**", fmt(i["engine_information_required"]), "- **Question for Amir:** %s" % fmt(i["question_for_amir"]), "- **Evidence to find (source / file / config / DB):**", fmt(i["evidence_required"]),
              "- **Implementation step:**", fmt(i["implementation_step"]), "- **Must Amir modify Engine code?** %s" % fmt(i["amir_must_modify_engine_code"]), "- **DB access required?** %s" % fmt(i["db_access_required"]), "- **Staging sufficient?** %s" % fmt(i["staging_sufficient"]), "- **Validation procedure:**", fmt(i["validation_procedure"]), "- **Expected result:** %s" % fmt(i["expected_result"]),
              "- **Evidence to return:**", fmt(i["evidence_to_return"]), "- **Unblocks:** %s" % fmt(i["unblocks"]), "- **Status:** %s" % i["status"], ""]
h += ["## When you finish", "", "Return `evidence_from_amir/` and a one-line status per item (CLOSED / PARTIAL / BLOCKED, with the reason). Nothing is CLOSED without its evidence. Closure of an item does not change the Architecture's lock status: that is a separate gate."]
W("AMIR_HANDOFF.md", "\n".join(h) + "\n")
# ---- README
W("README.md", """# AUIF Independent Build v1.0 (reference implementation)

A reference implementation of the Anchor Universal Integration Fabric, built from the independently audited **Architecture v1.0-DRAFT Revision 2** (audited package sha256 `%s`). It is proven on a **synthetic** world. It is **not** integrated with the Anchor Engine, **not** production-ready, and **no** Engine-dependent item is closed. The architecture's lock status is unchanged: it remains the audited DRAFT.

## Layout
| Path | What it is |
|---|---|
| `auif/` | The core (rev14 revises it in five files: findings M8-F1 to M8-F6, section 17 of the report). Python standard library only; imports nothing but itself (checked by `tools/static_checks.py`). |
| `auif_ref/` | Reference implementations of ports (in-memory and SQLite persistence, secret store). Not the Engine's. |
| `synthetic/` | Test doubles: three external systems, three connectors, packs, modules, Governor and policy doubles, AI stubs, the world. Never imported by the core. |
| `port_contracts/` | Conformance suites any port binding must pass, plus templates for a real binding. |
| `contracts/` | Byte copies of the audited schemas and state machine. |
| `tests/` | The test suite, including `test_acceptance.py` (AT-01..AT-30). |
| `auif_ext/` | **extensions, carried from rev8; rev12 adds one optional tenant-header setting to the REST connector; rev14 makes `BaseModule` report a handler failure to the fabric (M8-F4)** (a separate package; the core does not import it): connector kit, module client, Governor adapter. See `AUIF_EXTENSIONS.md`. |
| `auif_onboard/` | **the onboarding accelerator (rev11; rev12 adds wrapped-list, tenant-header and entity-exclusion handling; rev14 reads module-concept field references correctly)**: a drafting and review accelerator, not an onboarding authority. It sits above `auif/` and `auif_ext/`; nothing in them imports it. See `AUIF_ONBOARDING.md`. |
| `tools/` | Static checks, mutation testing (core and extensions), generators. |
| `evidence/` | Mutation, coverage and performance results; byte-identical audited inputs; the record on unexplained files. |

## Run
```
export PYTHONDONTWRITEBYTECODE=1
python3 -W ignore -m unittest discover -s tests -t .      # full suite (seconds)
python3 tools/static_checks.py                            # import graph, forbidden tokens, authority-API names
python3 tools/mutation_test.py                            # %d guard mutants in temp copies (roughly 16 to 18 minutes on the reference machine; the shipped verifier waits for it); read-only unless --write is given
python3 -W ignore -m unittest discover -s auif_ext/tests -t .   # the extension tests (set AUIF_GOVERNOR_R14_ZIP to also run against the real R14 Governor)
python3 tools/static_checks_ext.py                        # extension imports, names, constructs, sockets, core hash
python3 tools/ext_reverse_contamination.py                # the core passes with auif_ext removed
python3 tools/mutation_ext.py                             # mutation testing of the extension guards
python3 -W ignore -m unittest discover -s auif_onboard/tests -t .   # the onboarding accelerator's tests
python3 tools/static_checks_onboard.py                    # accelerator imports, authority names, approval capability confined to review.py, secrets, core hash
python3 tools/onboard_reverse_contamination.py <core> <ext> <ext_skipped> <pinned_core_hash>   # core and extensions pass, unchanged, with auif_onboard removed
python3 tools/mutation_onboard.py                         # mutation testing of the accelerator's guards
python3 -m auif_onboard draft --spec API.json --canonical-model MODEL.json --out DIR   # draft a connector config and a candidate pack (approves nothing)
```
No network and no third-party packages are needed. The Amir handoff was prepared from rev6.1; rev10 (a core revision: CF-4, section 13 of the report; it carries rev9's CF-1 and CF-2 fixes, section 12) was independently audited and closed (as relayed by the owner; the builder does not certify closure). rev11 to rev13 changed no core file; rev11 added the onboarding accelerator `auif_onboard/` (section 14 of the report). **rev14 revises the core again** (five files, the six defects found while building APG-M8; section 17 of the report and `CHANGES_rev14.md`): it is a builder revision awaiting independent audit, not accepted.

## Regenerate derived documents (in this order)
```
python3 tools/gen_docs.py          # Amir register and port templates
python3 tools/mutation_test.py --write   # refreshes evidence/mutation_results.json
python3 tools/gen_reports.py       # ACCEPTANCE_RESULTS, both RTMs, coverage (runs the whole suite)
python3 tools/gen_final.py --force # this README, COMPONENT_STATUS, AMIR_HANDOFF, BUILD_REPORT, FILE_MANIFEST
```

## Verify a package (fresh ZIP, exactly this order)
```
python3 tools/verify_fresh_zip.py AUIF_Independent_Build_v1.0_rev14.zip
```
Checks the zip against its sidecar hash, extracts it, verifies the manifest (hash, size, missing and unlisted files, tree hash), runs the tests and static checks (and, when `auif_ext/` is present, the extension tests, extension static checks and reverse contamination, with their evidence required), (and, when `auif_onboard/` is present, the accelerator's tests, static checks, reverse contamination and recorded evidence, all required), re-verifies the manifest, runs mutation testing (core, then extensions, then the accelerator), re-verifies the manifest. Set `AUIF_GOVERNOR_R14_ZIP` to also re-run the extension tests against the real R14 Governor. Passes only if there are zero mismatches after every step. Running the tests or mutation testing never modifies a tracked file; evidence is rewritten only by `gen_reports.py` and `mutation_test.py --write`. `python3 tools/verify_package.py [root]` verifies one extracted tree.\n\nReplay the independent audit's scenarios (each writes nothing): `python3 tools/audit_round1_replay.py`, `python3 tools/audit_round2_replay.py` and `python3 tools/audit_round3_replay.py`.

## Read first
`BUILD_REPORT.md` (result and three-category status; section 11 for the carried extensions, section 12 for the rev9 core revision, section 13 for the rev10 core revision, section 14 for the rev11 onboarding accelerator, section 15 for rev12, section 16 for rev13, section 17 for rev14), `CHANGES_rev14.md`, `AUIF_ONBOARDING.md`, `CHANGES_rev13.md`, `CHANGES_rev12.md`, `CHANGES_rev11.md`, `AUIF_EXTENSIONS.md`, `KNOWN_LIMITATIONS.md`, `AMIR_ENGINE_DEPENDENCY_TODO.md` and `AMIR_HANDOFF.md` (%d Engine-dependent items), `UNRESOLVED_GOVERNOR_DECISIONS.md`, `DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md`, `evidence/UNEXPLAINED_ARTEFACTS_STATUS.md`.
""" % (arch_zip, mut["mutants"], len(items)))
# ---- BUILD_REPORT
od = reg["open_decisions"]; gd = reg["governor_review_points"]; ng = sum(len(v) for v in cats.values())
r = ["# BUILD_REPORT: AUIF Independent Build v1.0", "", "**Status: reference implementation proven on a synthetic world. Not integrated with the Anchor Engine. Not production-ready. No Engine-dependent item is closed. Governor integration is not complete. Architecture lock status is unchanged (audited DRAFT).**", "",
     "## 1. Measured results", "", "| Measure | Result |", "|---|---|", "| Tests | %d run, %d passed, %d failed |" % (run["tests_run"], run["tests_passed"], run["tests_failed"]), "| Mutation testing | %d mutants, %d killed, %d survived, %d invalid |" % (mut["mutants"], mut["killed"], mut["survived"], mut["invalid"]),
     "| Static checks | clean: %s |" % run["static_checks_clean"], "| Core tree sha256 | `%s` |" % run["core_tree_sha256"], "| Python | %s (standard library only) |" % run["python"], "| Audited architecture package | sha256 `%s` |" % arch_zip, "",
     "Line coverage of the core is in `RTM_IMPL_TO_TEST.md` and `evidence/coverage_by_core_file.json`. Coverage shows lines were executed, not that every behaviour was asserted; mutation results show the chosen safety-critical guards (see `evidence/mutation_results.json`) are tested, not that no defect exists elsewhere.", "",
     "## 2. The three categories", ""] + ["- **%s** (%d of %d acceptance tests): %s" % (k, len(v), ng, ", ".join(v)) for k, v in cats.items()] + ["",
     "Component-level status by architecture section is in `COMPONENT_STATUS.md`. AT-15 (the McGrath proof) is **not executed and not claimed**; a guard test asserts that.", "",
     "## 3. Engine-dependent work (BLOCKED - AMIR REQUIRED)", "", "**%d items**, each with the full set of required fields, in `AMIR_ENGINE_DEPENDENCY_TODO.md` / `.json` and in dependency order in `AMIR_HANDOFF.md`." % len(items), ""] + ["- Group %d: %s" % (n, ", ".join(lvl)) for n, lvl in enumerate(lv, 1)] + ["",
     "The first item (the Engine reconnaissance gate) gates the others, as the audited sequencing requires.", "", "## 4. Remaining architectural decisions", "",
     "- **Governor-side GD-01..GD-%02d** (%d): open, isolated in code, not resolved. See `UNRESOLVED_GOVERNOR_DECISIONS.md`. These belong to the owner and the Governor side, not Amir." % (len(gd), len(gd)), "- **Audited open decisions OD-01..OD-%02d** (%d): remain open in the audited register. Draft positions were implemented where the audited draft gave one." % (len(od), len(od)),
     "- **Design decisions D-1..D-19** made where the draft is silent: need ratification (`DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md`).", "- **Findings F-1..F-4** against the audited draft (error-code gap, missing may-have-reached-target field, no `from_state` for creation, no field for ambiguity-resolution evidence): for the auditor. The audited package was not changed.", "",
     "## 5. Provenance and verification caveat", "", "Part of the tree was written by a process other than the executor of this report; this was observed, preserved, reviewed and recorded in `evidence/UNEXPLAINED_ARTEFACTS_STATUS.md`. The owner states they started one executor. Authorship of that part is still unestablished. The implementation has since been independently audited in three rounds (sections 6 to 8): the auditor re-ran the tests, static checks and replays, reviewed the code, and checked the preserved foreign-origin material for dangerous patterns. A complete line-by-line manual review of every foreign-origin file has not been done. Before packaging, the tree was copied to a private directory and the tests, static checks, mutation run and byte-comparison of the audited inputs and contracts were re-run there, with the results reported above. **The audit does not establish who wrote that part of the tree.**", "",
     "## 6. Audit round 1 (independent audit of rev2): resolved and confirmed by the round-2 audit", "", "| Finding | Class | Severity | Status |", "|---|---|---|---|",
     "| F1 The AI validator promoted malformed transforms (e.g. `UNIT_CONVERT` with `{}`, unknown function names) to VALIDATED | DEFECT | HIGH | Fixed: one shared, strict transform validator |", "| F2 Malformed proposer output (e.g. `[\"not a dict\"]`) escaped the AI boundary | DEFECT | HIGH | Fixed: proposer output is untrusted input at every level |",
     "| F3 Ambiguity-resolution evidence was required, then discarded | DEFECT | MEDIUM | Fixed: hash-bound chain (the audited contract has no field for it: DESIGN GAP F-4) |", "| F4 Restart/resume did not restore or rebuild the discovery record; the gate treated its absence as no missing coverage | DEFECT | MEDIUM | Fixed: persisted, restored and re-taken; the gate fails closed |",
     "| F5 A hostile data VALUE crashed a whole sync (found by the executor while fixing F1) | DEFECT | HIGH | Fixed: explicit per-field failure |", "",
     "Evidence: 51 new regression tests (F1: 12, F2: 10, F3: 10, F4: 13, F5: 6); 26 new mutants M43-M68, all killed; `tools/audit_round1_replay.py` passes 20/20 (the pre-fix code passes 2/20). Details, the exact production diff and the reasoning are in `AUDIT_ROUND1_RESOLUTION.md`. **The core tree hash changed INTENTIONALLY** (`089afcbd2579c16e75f53be942f99471399820bbaa0d53b71e028d2fa36a8357` to the value in section 1); three core files changed.", "",
     "## 7. Audit round 2 (re-audit of rev3): resolved and confirmed by the round-3 audit", "", "| Finding | Class | Severity | Status |", "|---|---|---|---|",
     "| F6 AI promotion evidence did not bind the complete mapping (author, kind, outbound, validation flag and state could change and still verify); the registry's AI check depended on the declared author | DEFECT | HIGH | Fixed: evidence binds the whole mapping and the registry recognises AI promotion by its evidence |",
     "| F7 A persistence failure between the idempotency reservation and ledger creation stranded the action; failure at any of the writes left it stranded or silently stalled in CREATED | DEFECT | HIGH | Fixed: resumable write-ahead intent (`docs/ACTION_SUBMISSION_STATE_MACHINE.md`) |",
     "| F8 AI evidence ledgers are in memory (known limitation 18) | DESIGN GAP | n/a | **OPEN, unchanged:** owner/Amir-dependent |", "",
     "Evidence: 32 new regression tests in `tests/test_audit_round2.py`; 18 new mutants M69-M86, all 86 killed; `tools/audit_round2_replay.py` passes 17/17 (rev3 passes 5/17). Details: `AUDIT_ROUND2_RESOLUTION.md`. The core tree hash changed INTENTIONALLY again (see section 1); three core files changed.", "",
     "## 8. Audit round 3 (final audit of rev5): F9 resolved; rev6 independently accepted (not frozen)", "", "| Finding | Class | Severity | Status |", "|---|---|---|---|",
     "| F9 A CanonicalAction's `tenant_id` was not bound to the authenticated TenantContext: a mismatched action was accepted, the ledger was stamped with the context's tenant while the durable intent kept the submitted one, and tenant-a's action retried under tenant-b's context was accepted | DEFECT | HIGH | Fixed: checked before any write; defence in depth on recovery |", "",
     "Evidence: 12 new regression tests in `tests/test_audit_round3.py`; 2 new mutants M87-M88; `tools/audit_round3_replay.py` passes 17/17 (rev5 passes 3/17). Production change: `auif/action.py` only (the core tree hash changed INTENTIONALLY, see section 1). Details: `AUDIT_ROUND3_RESOLUTION.md`.", "",
     "## 9. Package integrity and revisions", "", "**rev1** (superseded, zip sha256 `e88b50542dd8bcf687365c98892626ec2b248a37abcb71ffc8e9fee606ac3a8e`) had a package-integrity defect: running the test suite rewrote `evidence/performance_measurement.json`, so the manifest failed after a test run. **rev2** (superseded by rev3; zip sha256 `45c0df434384de5ec54521c0355dcbe38035a536e988c986c9dbf317cebd2f63`) fixed it (AT-29 and `mutation_test.py` write evidence only when asked; `tools/verify_fresh_zip.py` verifies the manifest after every step). **rev3** (superseded, preserved untouched) was the round-1 candidate; the round-2 audit found F6 and F7 in it. **rev4** (superseded; the clean rev4 candidate, zip sha256 `ffc2aeafa7a463af3fb6116f5c7ab8576df425d095741898787bd1061867531f`) carried the round-1 and round-2 fixes and passed the independent audit of F1-F7, but its shipped verifier's fixed 900 s mutation limit was shorter than the 86-mutant run, so it could not complete its own fresh-ZIP verification (a verification-tool limitation, not an implementation defect). **rev5** (preserved unchanged; zip sha256 `146cdfb6173c4245006f4050ba13633f831ad2dd366964d848b337696fdaa226`) is a TOOLING-ONLY correction of rev4 (the shipped verifier waits for the mutation run to finish; see `REV5_TOOLING_CORRECTION.md`); the independent audit accepted it. The same audit found F9, so rev5 is superseded by rev6, which has since been independently audited. **rev6** (zip sha256 `b7956f0094150cd49cf177a970f24a37bbe56e51b30bea425c7591e5111b5332`) carries the F9 fix (production change in `auif/action.py` only) and was accepted as the current reference implementation candidate; it is not frozen. **rev6.1** (this package) is a DOCUMENTATION-ONLY correction of rev6 made before handoff: no file under `auif/`, `contracts/`, `synthetic/`, `auif_ref/`, `port_contracts/` or `tests/` changed, and the core tree hash is identical to rev6's (see `DOCUMENTATION_CORRECTIONS_rev6.1.md`).", "",
     "## 10. Exact next actions", "", "1. **Released for handoff to Amir** after the independent audit (owner decision). Start with `AMIR_ENGINE_DEPENDENCY_TODO.md` and the accompanying full handoff document.", "2. Done: rev6 was independently audited and accepted as the current reference candidate (not frozen); rev6.1 differs from it only in documentation (`DOCUMENTATION_CORRECTIONS_rev6.1.md`). rev7 adds the separate extension package of section 11 and changes no core file; it needs its own independent audit. rev9 REVISED the core in two files (section 12; independently audited and closed, as relayed to the builder by the owner) and rev10 REVISES it in one more file (section 13) and needs its own independent audit. Any further change to AUIF needs a new audit round.",
     "3. Executor: any further finding is corrected in a new audited revision; none is open against F1 to F7 and F9.", "4. Owner: ratify or amend D-1..D-19; route F-1..F-4 to the auditor; decide GD-01..GD-05 on the Governor side; rule on the in-memory AI evidence ledger (known limitations 18 and 25) and on the unattested human/tool validation claims (limitation 23).", "5. The %d-item handoff to Amir contains only genuinely Engine-dependent work." % len(items),
     "6. Confirm or stop any second executor still writing into the shared build folder.", "7. Do not describe AUIF as integrated, production-ready or Governor-integrated until the evidence for those claims exists.", ""]
def ext_section():
    ev, mu = os.path.join(ROOT, "evidence", "ext_verification.json"), os.path.join(ROOT, "evidence", "mutation_ext_results.json")
    if not os.path.isdir(os.path.join(ROOT, "auif_ext")): return []
    if not (os.path.exists(ev) and os.path.exists(mu)): raise SystemExit("auif_ext/ is present but its evidence (evidence/ext_verification.json, evidence/mutation_ext_results.json) is missing: refusing to write a report without it")
    e, m = J("evidence/ext_verification.json"), J("evidence/mutation_ext_results.json"); a, g, rc, st = e["always_on"], e.get("against_real_governor_r14"), e["reverse_contamination"], e["static"]
    out = ["", "## 11. Extension package (carried from rev8; rev12 adds one optional tenant-header setting, section 15)", "", "**rev10** carries rev8's extension package unchanged (it builds on the rev7 extension candidate, zip sha256 `62f5441934fea206a4c7f653a4a0608d0d5b5359678c26f233db9902a688d8d2`, whose independent audit results were relayed to the builder by the owner) on top of a core REVISED in three files across rev9 and rev10 (sections 12 and 13; `contracts/`, `synthetic/`, `auif_ref/` and `port_contracts/` are byte-identical to rev8's), plus a separate `auif_ext/` package (connector kit, module client, Governor adapter; see `AUIF_EXTENSIONS.md`), extension tools under `tools/`, and documentation additions (this section, the README rows, the extension sections of `KNOWN_LIMITATIONS.md` and `DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md`, and `evidence/EXT_PROVENANCE.md`). The extensions operationalise the existing core contracts; they do not mean the core was incomplete, and the REST / OAuth2, webhook and CSV / JSON implementations are the first extension implementations, not locked architecture requirements. **rev7 is a candidate awaiting independent audit; it is not frozen.**", "",
           "| Evidence | Result |", "|---|---|", "| Core tree hash | `%s` (%s the audited core hash recorded in section 1) |" % (st["core_tree_sha256"], "equal to" if st["core_tree_sha256"] == run["core_tree_sha256"] else "DIFFERENT FROM"), "| Extension tests (always on) | **%d run, %d skipped, ok=%s** |" % (a["tests_run"], a["skipped"], a["ok"])]
    if g: out.append("| Extension tests against the REAL Governor R14 (zip sha256 `%s`) | **%d run, %d skipped, ok=%s** |" % (g["governor_zip_sha256"], g["tests_run"], g["skipped"], g["ok"]))
    out += ["| Extension static checks | %d files checked; import, Governor, network, real-system-name, forbidden-construct and authority-name violations: %s |" % (st["ext_files_checked"], "none" if not any(st[k] for k in st if isinstance(st[k], list)) else "SEE evidence/ext_verification.json"), "| Reverse contamination | core tests with `auif_ext` removed: %d run, ok=%s |" % (rc["core_tests"], rc["ok"]),
            "| Extension mutation | **%d mutants run: %d killed, %d survived, %d invalid**; %d defined, of which %s documented as equivalent and not run (`tools/mutation_ext.py`; one guard sabotaged per mutant; the always-on extension tests only) |" % (m["mutants"], m["killed"], m["survived"], m["invalid"], m.get("defined", m["mutants"]), ", ".join(x["id"] for x in m.get("equivalent_not_run", [])) or "none"), "",
            "Not claimed: **no real external system is integrated** and every extension test ran against local loopback servers, so no connector is verified against a real system (AT-15 cannot be claimed); GD-05 / ED-11 is open, so the Governor adapter's decision delivery fails closed; R14 is a verified candidate, not a closed Governor, and the adapter is not Governor-integrated: it implements the contract and passes the AT-27 boundary checks against the R14 code only. See `KNOWN_LIMITATIONS.md` (Extension limitations E-1 to E-14) and `DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md` (D-20 to D-31), and the provenance record `evidence/EXT_PROVENANCE.md`.", ""]
    return out
r += ext_section()
def core_revision_section():
    cr = os.path.join(ROOT, "CHANGES_rev9.md")
    if not os.path.exists(cr): return []
    return ["", "## 12. rev9: core revision (CF-1 and CF-2)", "",
            "rev9 revises the audited core in exactly two files, `auif/integration.py` (CF-1) and `auif/action.py` (CF-2), and adds two regression test files (`tests/test_cf1_report_condition_failure.py`, `tests/test_cf2_stale_sent_recovery.py`). `auif_ext/` is byte-identical to rev8's apart from one pinned core-hash literal in `auif_ext/tests/test_extension_boundary.py`. Details, what was NOT changed (CF-3 is accepted behaviour; CF-4 was recorded, not fixed, in rev9; rev10 fixes it, section 13) and how to read the evidence: `CHANGES_rev9.md`.", "",
            "| Evidence | Result |", "|---|---|", "| rev9 core tree hash | `a18fd7aa98fdbb4a7ca28fa25b4b98275e2d2c3f3b100629a6300c46128e7146` (rev8's was `5f27396249ea4f036fbc51bc9dad69134389d667a46a9962e8948d819bdb84d9`); rev9 zip sha256 `5b8a15fc2a83b3860a0b4afa4ae6ee7932bd45c60716c5dad551981ef9d4617e` |",
            "| Core tests (rev9, as audited) | **389 run, all passing** (rev8: 363) |",
            "| Core mutation (rev9, as audited) | **114 mutants: 114 killed, 0 survived, 0 invalid** (rev8: 90; 24 new mutants guard the CF-1 and CF-2 code) |", "",
            "rev9 was independently audited and closed as a core revision (the auditor's result was relayed to the builder by the owner; the builder does not certify closure). This section records its audited numbers; the current build's measured numbers are in section 13. Not claimed: production readiness, Engine integration, Governor integration, Layer 2 or any real-system behaviour. `KNOWN_LIMITATIONS.md` limitations 28 to 31 record the scope and the caveats.", ""]
r += core_revision_section()
def frozen_rev13_sections():
    """rev14: sections 13 to 16 are rev13's own text, copied byte for byte into docs/BUILD_REPORT_rev13_sections_13_to_16.md and NOT regenerated: their figures (core hash, test and
    mutant counts) describe rev10 to rev13 when those revisions were built, and regenerating them from rev14's evidence would misstate them."""
    t = open(os.path.join(ROOT, "docs", "BUILD_REPORT_rev13_sections_13_to_16.md")).read().split("\n---\n\n", 1)[1]
    return ["", "_Sections 13 to 16 are reproduced from rev13's report and describe rev10 to rev13 as built (`docs/BUILD_REPORT_rev13_sections_13_to_16.md`). rev14's measured figures are in section 1 and section 17._"] + t.rstrip("\n").split("\n")
r += frozen_rev13_sections()
def rev14_section():
    ev, mu, mx = os.path.join(ROOT, "evidence/onboard_verification.json"), os.path.join(ROOT, "evidence/mutation_onboard_results.json"), os.path.join(ROOT, "evidence/mutation_ext_results.json")
    if not (os.path.exists(ev) and os.path.exists(mu) and os.path.exists(mx) and os.path.exists(os.path.join(ROOT, "CHANGES_rev14.md"))): return []
    e, m, x = json.load(open(ev)), json.load(open(mu)), json.load(open(mx)); fz = e["frozen_layers_vs_rev13"]; xe = J("evidence/ext_verification.json")["always_on"]
    return ["", "## 17. rev14: core revision (the six defects found while building APG-M8)", "",
            "Building APG-M8 on the frozen rev13 found six defects in this build (M8-F1 to M8-F6). rev14 fixes them, on the owner's authorisation: a field reference into a MODULE concept is read as `<concept>.<attribute>` with the attribute after the LAST dot (inbound, outbound, the AI validator and the accelerator), and a malformed reference is refused when the pack is registered (F1); a source identity may be several fields, a content-hash identity must be declared, and a missing identity is a per-record error (F2); the module is told about every event that was not applied to it (F3); a module's failure to take a delivery is counted, recorded and told, never swallowed (F4); the sync report says whether the read reached the end (F5); sync reports instead of raising (F6). Details, the one changed existing test (an owner decision) and what was NOT changed: `CHANGES_rev14.md`. rev13 is preserved unchanged.", "",
            "| Evidence | Result |", "|---|---|", "| rev14 core tree hash | `%s` (rev10 to rev13: `%s`) |" % (run["core_tree_sha256"], e["rev10_to_rev13_core_tree_sha256"]),
            "| Layers against the untouched rev13 extraction | %d files identical; changed: %s; added: %s; removed: %d |" % (fz["identical_files"], ", ".join("`%s`" % c for c in fz["changed"]) or "none", ", ".join("`%s`" % c for c in fz["added"]) or "none", len(fz["removed"])),
            "| Core tests | **%d run, all passing** (rev13: 410) |" % run["tests_run"], "| Extension tests | **%d run, %d skipped, all passing** (rev13: 343, 20 skipped) |" % (xe["tests_run"], xe["skipped"]), "| Accelerator tests | **%d run, all passing** (rev13: 418) |" % e["onboard_tests"]["tests_run"],
            "| Core mutation | **%d mutants: %d killed, %d survived, %d invalid** (rev13: 133) |" % (mut["mutants"], mut["killed"], mut["survived"], mut["invalid"]),
            "| Extension mutation | **%d mutants run: %d killed, %d survived, %d invalid** (%d defined) |" % (x["mutants"], x["killed"], x["survived"], x["invalid"], x["defined"]),
            "| Accelerator mutation | **%d mutants run: %d killed, %d survived, %d invalid**; %d documented equivalents not run |" % (m["mutants"], m["killed"], m["survived"], m["invalid"], len(m["equivalent_not_run"])),
            "| Reverse contamination | with `auif_onboard` removed, %d core and %d extension tests still pass, core hash unchanged: %s |" % (e["reverse_contamination"]["core_tests"], e["reverse_contamination"]["ext_tests"], e["reverse_contamination"]["ok"]), "",
            "Not claimed: acceptance (this revision awaits independent audit), production readiness, Engine, Governor or Layer 2 integration, or any real-system behaviour. APG-M8's deviation DEV-M8-01 is not ended by this revision; moving APG onto rev14 is separate work. `KNOWN_LIMITATIONS.md` items 32 to 40 record the limits.", ""]
r += rev14_section()
W("BUILD_REPORT.md", "\n".join(r))
# ---- FILE_MANIFEST (always last; includes everything above)
files = []
for d, ds, fs in os.walk(ROOT):
    ds[:] = [x for x in ds if x != "__pycache__"]
    for f in fs:
        p = os.path.join(d, f); rel = os.path.relpath(p, ROOT)
        if f.endswith(".pyc") or rel == "FILE_MANIFEST.json": continue
        b = open(p, "rb").read(); files.append({"path": rel, "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()})
files.sort(key=lambda x: x["path"]); tree = hashlib.sha256("\n".join("%s %s" % (f["path"], f["sha256"]) for f in files).encode()).hexdigest()
FORCE_M = True; full = os.path.join(ROOT, "FILE_MANIFEST.json")
if os.path.exists(full) and not FORCE: skipped.append("FILE_MANIFEST.json")
else: open(full, "w").write(json.dumps({"package": "AUIF_Independent_Build_v1.0", "file_count": len(files), "tree_sha256": tree, "audited_architecture_zip_sha256": arch_zip, "files": files}, indent=1)); wrote.append("FILE_MANIFEST.json")
print(json.dumps({"wrote": wrote, "skipped_existing": skipped, "files_in_manifest": len(files), "tree_sha256": tree}))

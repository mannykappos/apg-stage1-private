"""Replays the independent auditor's round-2 scenarios (F6, F7) against the CURRENT code; prints an explicit PASS/FAIL per scenario; exit 0 only if all pass. Writes nothing.
Usage: python3 tools/audit_round2_replay.py"""
import copy, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT); os.chdir(ROOT)
from auif.ai_boundary import AIMappingService
from auif.discovery import fingerprint
from auif.translation import PackRegistry, pack_hash
from synthetic.ai_stub import ScriptedProposer
from synthetic.packs import pack_a
from synthetic.world import World
from tests.acceptance_support import act
A = "tenant-a"; results = []
def T(kind, **p): return {"kind": kind, "parameters": p, "deterministic": True}
def check(f, label, ok, detail=""): results.append(ok); print("%-4s %-3s %s%s" % ("PASS" if ok else "FAIL", f, label, (" -> " + detail) if detail else ""))
print("--- F6 (HIGH): promotion evidence must bind the complete security-relevant mapping ---")
w = World(); w.activate_all(); rec = w.integrations[(A, "rest")].last_record; svc = AIMappingService(ScriptedProposer([]), w.model, w.ids)
c = {"mapping_id": "ai-t", "kind": "FIELD", "source_ref": "Account.profile.name", "canonical_ref": "Party.display_name", "mapping_state": "CANDIDATE", "proposed_by": "AI_ASSISTED", "inbound": {"source_type": "string", "canonical_type": "STRING", "transform": T("FORMAT", op="upper")}, "outbound": {"supported": False, "reason": "inbound only"}}
m = svc.promote(c, rec); check("F6", "the untouched promoted mapping verifies", svc.verify_promotion(m))
muts = {"proposed_by AI_ASSISTED -> HUMAN (audit case)": lambda x: x.update(proposed_by="HUMAN"), "kind (audit case)": lambda x: x.update(kind="ENTITY"), "outbound (audit case)": lambda x: x.update(outbound={"supported": True, "transform": T("IDENTITY")}), "deterministic_validation_performed (audit case)": lambda x: x.update(deterministic_validation_performed=False),
        "mapping_state VALIDATED -> TRUSTED": lambda x: x.update(mapping_state="TRUSTED"), "inbound.source_type": lambda x: x["inbound"].update(source_type="integer"), "inbound transform parameter": lambda x: x["inbound"]["transform"]["parameters"].update(op="lower"), "unknown field added": lambda x: x.update(extra="x")}
for label, f in muts.items(): t = copy.deepcopy(m); f(t); check("F6", "mutating %s makes verification fail" % label, not svc.verify_promotion(t))
fp = fingerprint(w.sys[A]["A"].metadata())["value"]
def pack(mapping, ver): p = pack_a([fp]); p["pack_version"] = ver; p["mappings"].append(mapping); p["artifact_hash"] = pack_hash(p); return p
def hooks(s): return s.registry_hooks() if hasattr(s, "registry_hooks") else {"ai_promotion_verifier": s.verify_promotion}
t = copy.deepcopy(m); t["proposed_by"] = "HUMAN"
try: PackRegistry(**hooks(svc)).register(pack(t, "8.1.0")); check("F6", "a mapping relabelled HUMAN cannot bypass the AI verification requirement in the registry", False, "REGISTRY ACCEPTED IT")
except Exception as e: check("F6", "a mapping relabelled HUMAN cannot bypass the AI verification requirement in the registry", True, str(e)[:70])
t = copy.deepcopy(m); t["mapping_state"] = "TRUSTED"
try: PackRegistry(**hooks(svc)).register(pack(t, "8.2.0")); check("F6", "an AI-promoted mapping cannot be raised to TRUSTED", False, "REGISTRY ACCEPTED IT")
except Exception as e: check("F6", "an AI-promoted mapping cannot be raised to TRUSTED", True, str(e)[:70])
try: PackRegistry(**hooks(svc)).register(pack(m, "8.3.0")); check("F6", "control: the untouched AI-promoted mapping is accepted", True)
except Exception as e: check("F6", "control: the untouched AI-promoted mapping is accepted", False, str(e)[:70])
print("--- F7 (HIGH): a failure at any single write must not strand an action or an idempotency key ---")
class Boom(Exception): pass
def world(): ww = World(); ww.activate_all(); return ww
def instrument(ww):
    st = {"n": 0, "fail": None, "hook_at": None, "hook": None, "on": True, "log": []}; s = ww.store; op, ou = s.put, s.update
    def tick(kind, coll):
        if not st["on"]: return
        st["n"] += 1; st["log"].append("%s:%s" % (kind, coll))
        if st["n"] == st["fail"]: raise Boom("injected")
        if st["n"] == st["hook_at"] and st["hook"]: st["on"] = False; st["hook"](); st["on"] = True
    s.put = lambda c, coll, k, v, **kw: (tick("put", coll), op(c, coll, k, v, **kw))[1]; s.update = lambda c, coll, k, fn: (tick("update", coll), ou(c, coll, k, fn))[1]; return st
def arm(st, fail=None, hook_at=None, hook=None): st.update(n=0, fail=fail, hook_at=hook_at, hook=hook, log=[])
ww = world(); st = instrument(ww); ww.fabric.actions.submit(ww.ctx[A], act(ww, A, 1, {"display_name": "Zed"})); N = len(st["log"]); print("     (a clean submission performs %d store writes: %s)" % (N, ", ".join(st["log"])))
def outcome(ww, ctx, a):
    svc = ww.fabric.actions
    try: r = svc.submit(ctx, a)
    except Exception as e: return "retry %s" % type(e).__name__
    if r["execution_state"] != "QUEUED": return "retry returned %s (silent stall: never dispatched)" % r["execution_state"]
    try: d = svc.dispatch(ctx, a["action_id"])
    except Exception as e: return "dispatch %s" % type(e).__name__
    ids = [k for k, _ in ww.store.list(ctx, "action_ledger")]
    return "ok" if d["execution_state"] == "COMPLETED" and len(ww.sys[A]["A"].effects) == 1 and ids == [a["action_id"]] else "wrong end state %s effects=%d records=%s" % (d["execution_state"], len(ww.sys[A]["A"].effects), ids)
bad = []
for k in range(1, N + 1):
    ww = world(); st = instrument(ww); ctx = ww.ctx[A]; a = act(ww, A, 1, {"display_name": "Zed"}); arm(st, fail=k)
    try: ww.fabric.actions.submit(ctx, a)
    except Boom: pass
    arm(st); o = outcome(ww, ctx, a)
    if o != "ok": bad.append("write #%d: %s" % (k, o))
check("F7", "a failure injected at EACH of the %d writes is recovered by a retry (queued, one record, sent exactly once)" % N, not bad, "; ".join(bad)[:150])
bad = []
for k in range(1, N + 1):
    ww = world(); st = instrument(ww); ctx = ww.ctx[A]; a = act(ww, A, 1, {"display_name": "Zed"}); arm(st, fail=k)
    try: ww.fabric.actions.submit(ctx, a)
    except Boom: pass
    arm(st)
    try:
        rp = getattr(ww.fabric.actions, "recover_pending"); rp(ctx); o = outcome(ww, ctx, a)
    except AttributeError: o = "no recovery sweep exists"
    except Exception as e: o = "sweep %s" % type(e).__name__
    if o != "ok": bad.append("write #%d: %s" % (k, o))
check("F7", "the recovery sweep completes every window without any retry", not bad, "; ".join(bad)[:150])
bad = []
for k in range(1, N + 1):
    ww = world(); st = instrument(ww); ctx = ww.ctx[A]; a = act(ww, A, 1, {"display_name": "Zed"}); seen = []; arm(st, hook_at=k, hook=lambda: seen.append(ww.fabric.actions.submit(ctx, a)))
    try: ww.fabric.actions.submit(ctx, a); arm(st); o = outcome(ww, ctx, a)
    except Exception as e: o = "%s" % type(e).__name__
    if o != "ok": bad.append("dup before write #%d: %s" % (k, o))
check("F7", "a duplicate submission interleaved before EACH write yields exactly one action", not bad, "; ".join(bad)[:150])
ww = world(); ctx = ww.ctx[A]; a = act(ww, A, 1, {"display_name": "Zed"}); other = copy.deepcopy(a); other["canonical_action"]["payload"]["attributes"] = {"display_name": "X"}; ww.fabric.actions.submit(ctx, a)
try: ww.fabric.actions.submit(ctx, other); check("F7", "a reused key with different content is refused", False)
except Exception as e: check("F7", "a reused key with different content is refused", "different content" in str(e))
ww = world(); ctx = ww.ctx[A]; a = act(ww, A, 1, {"display_name": "Zed"}); ww.fabric.actions.submit(ctx, a); ww.fabric.actions.dispatch(ctx, a["action_id"]); r = ww.fabric.actions.submit(ctx, a)
check("F7", "a terminal duplicate returns the terminal record and sends nothing more", r["execution_state"] == "COMPLETED" and len(ww.sys[A]["A"].effects) == 1)
print("\nRESULT: %s (%d/%d scenarios pass)" % ("ALL FINDINGS PASS" if all(results) else "FAIL", sum(results), len(results))); sys.exit(0 if all(results) else 1)

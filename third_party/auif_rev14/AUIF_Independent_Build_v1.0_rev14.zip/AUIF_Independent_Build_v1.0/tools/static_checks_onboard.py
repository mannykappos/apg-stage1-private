"""Static checks for the onboarding accelerator (auif_onboard), complementing tools/static_checks.py (core) and tools/static_checks_ext.py (extensions). By syntax tree, not by text:
  imports are standard library / auif / auif_ext / auif_onboard only; no Governor, synthetic, reference, test or tool code is imported by production code; no module imports a network module (the connector in auif_ext does the talking, and only to loopback);
  no real external system is named; no logging, printing, deserialisation, process execution, dynamic import or environment read; only cli.py opens a file; no credential-like literal;
  SEPARATION OF DRAFTING FROM APPROVAL: only auif_onboard/review.py may name an approval/promotion capability (promote, resolve_ambiguity, PromotionRefused, HumanApproval, ReviewSession, ...) or import review, and no other module may mention a VALIDATED/TRUSTED state
  except validate.py (which only CHECKS that none exists); no Governor authority operation exists anywhere; neither the core nor the extensions mention auif_onboard; the core tree hash is reported.
Prints one dict and exits 0 only if every list is empty."""
import ast, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(ROOT, "tools")); PKG = "auif_onboard"
NET = {"socket", "ssl", "http", "urllib.request", "urllib.error", "ftplib", "smtplib", "telnetlib", "poplib", "imaplib", "xmlrpc", "socketserver", "asyncio", "select", "selectors", "webbrowser", "wsgiref", "requests", "urllib3", "httpx", "aiohttp"}
NAMES = ("xero", "myob", "salesforce", "hubspot", "mcgrath", "reapit", "vaultre", "ndis", "quickbooks", "stripe", "netsuite", "sap", "dynamics", "zoho", "pipedrive", "freshbooks", "mindbody", "westlab", "tasso")
BAD_CALLS = {"print", "eval", "exec", "compile", "__import__", "breakpoint"}; BAD_MODULES = {"logging", "pickle", "cPickle", "marshal", "subprocess", "shelve", "yaml", "ctypes", "multiprocessing", "importlib", "pty", "pdb", "code", "runpy"}
BAD_OS = {"system", "popen", "execv", "execl", "spawnl", "fork", "getenv", "putenv", "environ", "environb", "remove", "unlink", "rmdir", "rename", "replace", "chmod"}
AUTH = {"evaluate_policy", "issue_promotion_token", "mutate_governor_state", "assert_compliant", "determine_materiality", "resolve_conflict", "issue_cpt", "authorize", "grant_decision"}
APPROVAL = {"promote", "resolve_ambiguity", "PromotionRefused", "HumanApproval", "ReviewSession", "check_approval", "approve_config", "assemble_pack", "verify_human_evidence", "registry_hooks", "verify_promotion", "has_issued", "resolution_chain"}
CLI_MAY = {"remove"}                       # the CLI may remove files it created itself in the same call (rollback of a partial write); nothing else may delete, rename or chmod
REVIEW = os.path.join(PKG, "review.py"); CLI = os.path.join(PKG, "cli.py"); VALIDATE = os.path.join(PKG, "validate.py"); STATE_WORDS = ("VALIDATED", "TRUSTED")
FORBIDDEN_TOP = ("governor_core", "adapters", "synthetic", "auif_ref", "tests", "port_contracts", "tools")
def files():
    out = []
    for r, ds, fs in os.walk(os.path.join(ROOT, PKG)):
        ds[:] = [d for d in ds if d not in ("tests", "__pycache__", "fixtures")]; out += [os.path.join(r, f) for f in fs if f.endswith(".py")]
    return sorted(out)
def imports(tree): return [(a.name, 0, n.lineno) for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names] + [((n.module or ""), n.level, n.lineno, [a.name for a in n.names]) for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
def empty(): return {"import_violations": [], "governor_or_test_imports": [], "network_imports": [], "real_system_names": [], "forbidden_constructs": [], "authority_names": [], "approval_capability_outside_review": [], "review_imported_outside_review": [], "state_words_outside_review": [], "file_access_outside_cli": [], "credential_like_literals": []}
def check_source(rel, src, r=None):
    """All per-file findings for one production file, given its path relative to the tree root (so tests can seed deliberate violations)."""
    r = r if r is not None else empty(); tree = ast.parse(src)
    for imp in imports(tree):
        mod, lvl, line = imp[0], imp[1], imp[2]; names = imp[3] if len(imp) > 3 else []
        if lvl:
            tail = (mod.split(".")[0] if mod else "") ; hit = tail == "review" or (not mod and "review" in names)
            if hit and rel != REVIEW: r["review_imported_outside_review"].append((rel, line, mod or ",".join(names)))
            continue
        top = mod.split(".")[0]
        if top not in sys.stdlib_module_names and top not in ("auif", "auif_ext", PKG): r["import_violations"].append((rel, line, mod))
        if top in FORBIDDEN_TOP: r["governor_or_test_imports"].append((rel, line, mod))
        if mod in NET or top in NET: r["network_imports"].append((rel, line, mod))
        if top in BAD_MODULES: r["forbidden_constructs"].append((rel, line, mod))
        if mod == PKG + ".review" or (mod == PKG and "review" in names):
            if rel != REVIEW: r["review_imported_outside_review"].append((rel, line, mod))
    for i, line in enumerate(src.split("\n"), 1):
        for n in NAMES:
            if re.search(r"\b%s\b" % n, line, re.I): r["real_system_names"].append((rel, i, n))
        if re.search(r"(?i)(password|secret|token|api[_-]?key)\s*=\s*['\"][A-Za-z0-9+/_\-]{8,}['\"]", line): r["credential_like_literals"].append((rel, i))
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in BAD_CALLS: r["forbidden_constructs"].append((rel, n.lineno, n.func.id))
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "open" and rel != CLI: r["file_access_outside_cli"].append((rel, n.lineno, "open"))
        if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id == "os" and n.attr in BAD_OS and not (rel == CLI and n.attr in CLI_MAY): r["forbidden_constructs"].append((rel, n.lineno, "os." + n.attr))
        if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in ("os", "shutil", "tempfile", "pathlib", "glob") and rel != CLI and n.attr in ("walk", "listdir", "scandir", "makedirs", "mkdir", "copy", "copyfile", "rmtree", "mkdtemp", "Path", "glob"): r["file_access_outside_cli"].append((rel, n.lineno, "%s.%s" % (n.value.id, n.attr)))
        name = n.name if isinstance(n, (ast.FunctionDef, ast.ClassDef)) else n.id if isinstance(n, ast.Name) else n.attr if isinstance(n, ast.Attribute) else n.arg if isinstance(n, ast.arg) else None
        if name in AUTH: r["authority_names"].append((rel, getattr(n, "lineno", 0), name))
        if name in APPROVAL and rel != REVIEW: r["approval_capability_outside_review"].append((rel, getattr(n, "lineno", 0), name))
        if isinstance(n, ast.alias) and n.name in APPROVAL and rel != REVIEW: r["approval_capability_outside_review"].append((rel, 0, n.name))
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and any(w in n.value for w in STATE_WORDS) and rel not in (REVIEW, VALIDATE):
            if not (n.value.count(" ") > 3): r["state_words_outside_review"].append((rel, getattr(n, "lineno", 0), n.value[:40]))      # prose (docstrings, messages) is not a state value
    return r
def run():
    r = empty(); r.update({"files_checked": 0, "core_mentions_onboard": [], "ext_mentions_onboard": [], "core_tree_sha256": None})
    for p in files():
        rel = os.path.relpath(p, ROOT); check_source(rel, open(p).read(), r); r["files_checked"] += 1
    for sub, key in (("auif", "core_mentions_onboard"), ("auif_ext", "ext_mentions_onboard")):
        for d, _, fs in os.walk(os.path.join(ROOT, sub)):
            for f in fs:
                if f.endswith(".py") and PKG in open(os.path.join(d, f)).read(): r[key].append(os.path.relpath(os.path.join(d, f), ROOT))
    import static_checks; cwd = os.getcwd(); os.chdir(ROOT)
    try: r["core_tree_sha256"] = static_checks.tree_hash()
    finally: os.chdir(cwd)
    return r
if __name__ == "__main__":
    res = run(); print(res); sys.exit(0 if res["files_checked"] and not any(res[k] for k in res if isinstance(res[k], list)) else 1)

"""Reverse contamination for the onboarding accelerator: remove auif_onboard entirely and prove that everything beneath it is unaffected -- the core test suite and the extension test suite still pass with the SAME test counts, the core and extension static checks are clean, and the core tree hash equals the audited one recorded in ACCEPTANCE_RESULTS.json (and the pinned rev10 hash, when given). Nothing in the core or the extensions may depend on, or be changed by, the accelerator.
Usage: python3 tools/onboard_reverse_contamination.py <expected_core_tests> <expected_ext_tests> <expected_ext_skipped> [pinned_core_hash]"""
import ast, json, os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def run(cmd, cwd, env):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, env=env); return r.returncode, r.stdout + r.stderr
def ok_line(out): lines = out.strip().splitlines(); return bool(lines) and lines[-1].startswith("OK")          # "OK" or "OK (skipped=N)"
def counts(out):
    m = re.search(r"Ran (\d+) tests", out); k = re.search(r"skipped=(\d+)", out); return (int(m.group(1)) if m else -1), (int(k.group(1)) if k else 0)
def main():
    a = sys.argv[1:]
    if len(a) < 3: raise SystemExit(__doc__)
    want_core, want_ext, want_skip = int(a[0]), int(a[1]), int(a[2]); pinned = a[3] if len(a) > 3 else None; t = tempfile.mkdtemp(prefix="revcont_onb_")
    try:
        p = os.path.join(t, "p"); shutil.copytree(ROOT, p, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "auif_onboard", "evidence")); assert not os.path.exists(os.path.join(p, "auif_onboard")); assert os.path.isdir(os.path.join(p, "auif_ext"))
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1"); env.pop("AUIF_GOVERNOR_R14_ZIP", None)
        rc1, o1 = run([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "tests", "-t", "."], p, env); n1, _ = counts(o1)
        rc2, o2 = run([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "auif_ext/tests", "-t", "."], p, env); n2, k2 = counts(o2)
        rc3, o3 = run([sys.executable, "tools/static_checks.py"], p, env); d = ast.literal_eval(o3.strip().splitlines()[-1])
        rc4, o4 = run([sys.executable, "tools/static_checks_ext.py"], p, env)
        try: e = ast.literal_eval(o4.strip().splitlines()[-1]); ext_clean = rc4 == 0 and e["core_tree_sha256"] == d["core_tree_sha256"]
        except (ValueError, SyntaxError, IndexError): ext_clean = False
        recorded = json.load(open(os.path.join(p, "ACCEPTANCE_RESULTS.json")))["run"]["core_tree_sha256"]
        ok = (rc1 == 0 and ok_line(o1) and n1 == want_core and rc2 == 0 and ok_line(o2) and n2 == want_ext and k2 == want_skip and rc3 == 0
              and not d["core_import_violations"] and not d["forbidden_token_hits"] and not d["authority_api_hits"] and ext_clean and d["core_tree_sha256"] == recorded and (pinned is None or d["core_tree_sha256"] == pinned))
        print("ONBOARD REVERSE CONTAMINATION: %s (with auif_onboard removed: %d core tests and %d extension tests (%d skipped) pass; static checks clean: %s; core_tree_sha256 %s)" % ("PASS" if ok else "FAIL", n1, n2, k2, ext_clean and rc3 == 0, d["core_tree_sha256"][:16] + "..."))
        print({"core_tests": n1, "ext_tests": n2, "ext_skipped": k2, "core_tree_sha256": d["core_tree_sha256"], "ok": ok}); return 0 if ok else 1
    finally: shutil.rmtree(t, ignore_errors=True)
if __name__ == "__main__": sys.exit(main())

"""Mutation testing for the ONBOARDING ACCELERATOR (auif_onboard). Each mutant sabotages ONE guard in a temporary copy of the tree; the accelerator's own suite (auif_onboard/tests) must then FAIL ("killed"). A mutant that leaves the suite green "survived" and is
a test gap. A mutant must apply to exactly one place (or to the nth of several identical guards), else it is "invalid". The mutants are data in tools/mutants_onboard.py (MUTANTS, and EQUIVALENT: mutants whose mutated code behaves identically for every input, each with its reason; they are checked for
applicability, listed in every run and in the --out JSON, and NOT run).
Usage: python3 tools/mutation_onboard.py [--check] [--workers=N] [--out=FILE] [--state=FILE] [--only=ID,ID] [--no-baseline]
  --state=FILE   append one JSON line per finished mutant and SKIP mutants already in it, so a long campaign can be stopped and resumed in chunks; the verdict is computed from the whole file.
Prints: mutants=N killed=K survived=S invalid=I (N = mutants run; the documented EQUIVALENT ones are listed and not run). Writes nothing into the package unless --out/--state is given."""
import concurrent.futures, json, os, re, shutil, subprocess, sys, tempfile, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(ROOT, "tools"))
from mutants_onboard import MUTANTS, EQUIVALENT, PRIORITY
def nth_index(s, old, nth):
    """Position of the nth (0-based) occurrence of `old`, or -1."""
    i = -1
    for _ in range(nth + 1):
        i = s.find(old, i + 1)
        if i < 0: return -1
    return i
def applicable(s, m):
    nth = m[5] if len(m) > 5 else None
    return s.count(m[2]) == 1 if nth is None else s.count(m[2]) > nth
def apply(root, m):
    mid, path, old, new, why, *rest = m; p = os.path.join(root, path); s = open(p).read()
    if not applicable(s, m): return "invalid: %d occurrences" % s.count(old)
    i = s.index(old) if not rest else nth_index(s, old, rest[0])
    open(p, "w").write(s[:i] + new + s[i + len(old):]); return None
def _run(root, args, timeout):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1"); env.pop("AUIF_GOVERNOR_R14_ZIP", None)
    cmd = ["discover", "-f"] + args[1:] if args[0] == "discover" else ["-f"] + args
    try: r = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest"] + cmd, cwd=root, capture_output=True, text=True, timeout=timeout, env=env)
    except subprocess.TimeoutExpired: return "TIMEOUT", ""
    out = r.stdout + r.stderr; first = re.search(r"^(?:FAIL|ERROR): (\S+)", out, re.M)
    if r.returncode == 0: return "pass", ""
    if not re.search(r"^FAILED \(", out, re.M): return "error", out.strip()[-160:]                       # a usage error or a crash is a HARNESS failure: it must never be mistaken for a kill
    return "fail", (first.group(1) if first else "")
def suite(root, timeout, first=()):
    if first:
        st, who = _run(root, ["auif_onboard.tests." + n for n in first], timeout)
        if st != "pass": return st, who
    return _run(root, ["discover", "-s", "auif_onboard/tests", "-t", "."], timeout)
def one(m):
    t = tempfile.mkdtemp(prefix="mutonb_")
    try:
        shutil.copytree(ROOT, os.path.join(t, "p"), ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "evidence")); root = os.path.join(t, "p"); bad = apply(root, m)
        if bad: return {"id": m[0], "status": "invalid", "detail": bad, "why": m[4]}
        st, who = suite(root, 240, PRIORITY.get(m[1], ())); return {"id": m[0], "status": "killed" if st in ("fail", "TIMEOUT") else "invalid" if st == "error" else "survived", "killed_by": who or st, "why": m[4]}
    finally: shutil.rmtree(t, ignore_errors=True)
def main():
    argv = sys.argv[1:]; workers = next((int(a.split("=")[1]) for a in argv if a.startswith("--workers=")), min(2, os.cpu_count() or 1)); out = next((a.split("=", 1)[1] for a in argv if a.startswith("--out=")), None)
    state = next((a.split("=", 1)[1] for a in argv if a.startswith("--state=")), None); only = next((a.split("=", 1)[1].split(",") for a in argv if a.startswith("--only=")), None)
    ids = [m[0] for m in MUTANTS]
    if len(set(ids)) != len(ids): raise SystemExit("duplicate mutant ids")
    unknown = set(EQUIVALENT) - set(ids)
    if unknown: raise SystemExit("EQUIVALENT names unknown mutants: %s" % sorted(unknown))
    if "--check" in argv:
        bad = 0
        for m in MUTANTS:
            src = open(os.path.join(ROOT, m[1])).read()
            if not applicable(src, m): bad += 1; print("NOT APPLICABLE %s %s: %d occurrences of %r" % (m[0], m[1], src.count(m[2]), m[2][:70]))
            elif m[2] == m[3]: bad += 1; print("NO-OP %s: old == new" % m[0])
        print("checked %d mutants, %d not applicable" % (len(MUTANTS), bad)); return 1 if bad else 0
    t0 = time.time()
    if "--no-baseline" not in argv:
        t = tempfile.mkdtemp(prefix="mutonb_base_")
        try: shutil.copytree(ROOT, os.path.join(t, "p"), ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "evidence")); st, who = suite(os.path.join(t, "p"), 600)
        finally: shutil.rmtree(t, ignore_errors=True)
        if st != "pass": print("BASELINE FAILS (%s %s): refusing to mutate a red suite" % (st, who)); return 2
    for e in sorted(EQUIVALENT): print("EQUIVALENT %s (documented, not run): %s" % (e, EQUIVALENT[e]))
    done = {}
    if state and os.path.exists(state):
        for line in open(state):
            line = line.strip()
            if line: r = json.loads(line); done[r["id"]] = r
    run = [m for m in MUTANTS if m[0] not in EQUIVALENT]; todo = [m for m in run if m[0] not in done and (only is None or m[0] in only)]
    def finish(m):
        r = one(m)
        if state:
            with open(state, "a") as f: f.write(json.dumps(r) + "\n")
        return r
    with concurrent.futures.ThreadPoolExecutor(workers) as ex: new = list(ex.map(finish, todo))
    for r in new: done[r["id"]] = r
    results = [done[m[0]] for m in run if m[0] in done]; pending = [m[0] for m in run if m[0] not in done]
    k = sum(r["status"] == "killed" for r in results); s = sum(r["status"] == "survived" for r in results); i = sum(r["status"] == "invalid" for r in results)
    for r in results:
        if r["status"] != "killed": print("%-9s %s: %s %s" % (r["status"].upper(), r["id"], r["why"], r.get("detail", "")))
    if pending and only is None: print("PENDING (not yet run): %d" % len(pending))
    print("mutants=%d killed=%d survived=%d invalid=%d in %ds (this invocation ran %d; equivalent, documented and not run: %d of %d defined)" % (len(results), k, s, i, time.time() - t0, len(new), len(EQUIVALENT), len(MUTANTS)))
    if out and not pending: json.dump({"mutants": len(results), "killed": k, "survived": s, "invalid": i, "defined": len(MUTANTS), "equivalent_not_run": [{"id": e, "reason": EQUIVALENT[e]} for e in sorted(EQUIVALENT)], "results": results}, open(out, "w"), indent=1)
    return 0 if (s == 0 and i == 0 and not pending) else 1
if __name__ == "__main__": sys.exit(main())

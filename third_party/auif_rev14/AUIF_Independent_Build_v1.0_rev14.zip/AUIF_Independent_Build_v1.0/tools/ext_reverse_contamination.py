"""Reverse contamination for the extensions: remove auif_ext entirely and prove the audited core is unaffected -- the core test suite still passes with the same test count, the core static checks are clean, and the core hash equals the audited one recorded in ACCEPTANCE_RESULTS.json. Nothing in the core may depend on the extensions.
Usage: python3 tools/ext_reverse_contamination.py [expected_core_tests]"""
import ast, json, os, re, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def main():
    want = int(sys.argv[1]) if len(sys.argv) > 1 else None; t = tempfile.mkdtemp(prefix="revcont_")
    try:
        p = os.path.join(t, "p"); shutil.copytree(ROOT, p, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "auif_ext", "evidence")); assert not os.path.exists(os.path.join(p, "auif_ext")); env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        r = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "tests", "-t", "."], cwd=p, capture_output=True, text=True, env=env); out = r.stdout + r.stderr; m = re.search(r"Ran (\d+) tests", out); n = int(m.group(1)) if m else -1
        s = subprocess.run([sys.executable, "tools/static_checks.py"], cwd=p, capture_output=True, text=True, env=env); d = ast.literal_eval(s.stdout.strip().splitlines()[-1]); ok = r.returncode == 0 and out.rstrip().endswith("OK") and (want is None or n == want) and not d["core_import_violations"] and not d["forbidden_token_hits"] and not d["authority_api_hits"] and d["core_tree_sha256"] == json.load(open(os.path.join(p, "ACCEPTANCE_RESULTS.json")))["run"]["core_tree_sha256"]
        print("REVERSE CONTAMINATION: %s (%d core tests pass with auif_ext removed; core_tree_sha256 %s)" % ("PASS" if ok else "FAIL", n, d["core_tree_sha256"][:16] + "...")); print({"core_tests": n, "core_tree_sha256": d["core_tree_sha256"], "ok": ok}); return 0 if ok else 1
    finally: shutil.rmtree(t, ignore_errors=True)
if __name__ == "__main__": sys.exit(main())

"""Fresh-ZIP verification: sidecar hash -> extract -> manifest -> tests -> static checks -> [extension tests, static checks, reverse contamination] -> [onboarding accelerator tests, static checks, reverse contamination, evidence] -> manifest -> mutation -> [extension mutation] -> manifest.
If auif_ext/ is present its evidence MUST be present and every extension step must pass (fail closed). The same holds for auif_onboard/ (steps 5i to 5l, 7c). Set AUIF_GOVERNOR_R14_ZIP to also re-run the extension tests against the real R14 Governor (step 5h). Passes only if every step passes and the manifest shows zero hash/size/missing/unlisted
mismatches after EVERY step (running the tests or mutation testing must not alter a single tracked file).   Usage: python3 tools/verify_fresh_zip.py <package.zip> [--skip-mutation] [--mutation-timeout=SECONDS]
The mutation step WAITS FOR THE RUN TO FINISH (a full run takes roughly 15-20 minutes); it has no wall-clock limit unless the caller passes --mutation-timeout."""
import ast, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time, zipfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from verify_package import verify
def sh(cmd, cwd, timeout=600, env_drop=()):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1"); env.pop("AUIF_PERF_OUT", None)
    for k in env_drop: env.pop(k, None)
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env); return r.returncode, r.stdout + r.stderr
def mutation_timeout(argv):
    """None (wait for the run to finish) unless the caller explicitly passes --mutation-timeout=SECONDS. A fixed constant here once made a correct package fail its own verification (the 86-mutant run outlasts 900 s)."""
    for a in argv:
        if a.startswith("--mutation-timeout="):
            try: v = float(a.split("=", 1)[1])
            except ValueError: raise SystemExit("--mutation-timeout needs a number of seconds")
            if not v > 0: raise SystemExit("--mutation-timeout must be positive")
            return v
    return None
def main():
    z = next(a for a in sys.argv[1:] if not a.startswith("-")); steps = []; ok = True
    def rec(name, passed, detail): 
        nonlocal ok; ok = ok and passed; steps.append({"step": name, "pass": passed, "detail": detail}); print("%-34s %s  %s" % (name, "PASS" if passed else "FAIL", detail))
    side = z + ".sha256"; got = hashlib.sha256(open(z, "rb").read()).hexdigest()
    if os.path.exists(side): want = open(side).read().split()[0]; rec("1 zip sha256 vs sidecar", got == want, got[:16] + "...")
    else: rec("1 zip sha256 (no sidecar)", True, got[:16] + "...")
    t = tempfile.mkdtemp()
    try:
        zipfile.ZipFile(z).extractall(t); root = os.path.join(t, os.listdir(t)[0]); acc = json.load(open(root + "/ACCEPTANCE_RESULTS.json"))["run"]
        def manifest(label): r = verify(root); rec(label, r["ok"], "%d files, %d mismatches %s" % (r["files_checked"], len(r["mismatches"]), r["mismatches"][:3] if r["mismatches"] else ""))
        manifest("2 manifest (fresh extraction)")
        rc, out = sh([sys.executable, "tools/verify_package.py", "--selftest"], root); rec("3 verifier self-test", rc == 0, "detects tamper/size/missing/extra/tree-hash")
        rc, out = sh([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "tests", "-t", "."], root); m = re.search(r"Ran (\d+) tests", out); n = int(m.group(1)) if m else -1
        rec("4 tests", rc == 0 and n == acc["tests_run"] and out.rstrip().endswith("OK"), "%d/%d (recorded: %d)" % (n if rc == 0 else 0, n, acc["tests_run"]))
        rc, out = sh([sys.executable, "tools/static_checks.py"], root); d = ast.literal_eval(out.strip().splitlines()[-1]); rec("5 static checks + core hash", rc == 0 and not d["core_import_violations"] and not d["forbidden_token_hits"] and not d["authority_api_hits"] and d["core_tree_sha256"] == acc["core_tree_sha256"], "core " + d["core_tree_sha256"][:16] + "...")
        rc, out = sh([sys.executable, "-W", "ignore", "tools/audit_round1_replay.py"], root); mm = re.search(r"\((\d+)/(\d+) scenarios pass\)", out); rec("5b audit round-1 replay", rc == 0 and "ALL FINDINGS PASS" in out and bool(mm), (mm.group(0) if mm else "no result"))
        rc, out = sh([sys.executable, "-W", "ignore", "tools/audit_round2_replay.py"], root); mm = re.search(r"\((\d+)/(\d+) scenarios pass\)", out); rec("5c audit round-2 replay", rc == 0 and "ALL FINDINGS PASS" in out and bool(mm), (mm.group(0) if mm else "no result"))
        rc, out = sh([sys.executable, "-W", "ignore", "tools/audit_round3_replay.py"], root); mm = re.search(r"\((\d+)/(\d+) scenarios pass\)", out); rec("5d audit round-3 replay", rc == 0 and "ALL FINDINGS PASS" in out and bool(mm), (mm.group(0) if mm else "no result"))
        extp = root + "/evidence/ext_verification.json"; has_ext = os.path.isdir(root + "/auif_ext"); ext = json.load(open(extp)) if os.path.exists(extp) else None
        if has_ext and not ext: rec("5e extension evidence", False, "auif_ext/ is present but evidence/ext_verification.json is missing (fail closed: the extension steps cannot be skipped)")
        if ext and not has_ext: rec("5e extension evidence", False, "extension evidence is present but auif_ext/ is missing")
        if has_ext and ext:                                                                                  # the rev7 extension package (auif_ext): tests, static checks, reverse contamination
            rc, out = sh([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "auif_ext/tests", "-t", "."], root, env_drop=("AUIF_GOVERNOR_R14_ZIP",)); m = re.search(r"Ran (\d+) tests", out); n = int(m.group(1)) if m else -1; k = re.search(r"skipped=(\d+)", out); k = int(k.group(1)) if k else 0; e = ext["always_on"]
            rec("5e extension tests", rc == 0 and n == e["tests_run"] and k == e["skipped"], "%d run, %d skipped (recorded: %d, %d)" % (n, k, e["tests_run"], e["skipped"]))
            rc, out = sh([sys.executable, "tools/static_checks_ext.py"], root)
            try: d = ast.literal_eval(out.strip().splitlines()[-1]); good = rc == 0 and d["core_tree_sha256"] == acc["core_tree_sha256"]; det = "%d files, core %s" % (d["ext_files_checked"], d["core_tree_sha256"][:16] + "...")
            except (ValueError, SyntaxError, IndexError): good, det = False, "no result"
            rec("5f extension static checks", good, det)
            rc, out = sh([sys.executable, "tools/ext_reverse_contamination.py", str(acc["tests_run"])], root); first = out.strip().splitlines()[0][:120] if out.strip() else "no result"; rec("5g reverse contamination", rc == 0 and "REVERSE CONTAMINATION: PASS" in out, first)
            gz = os.environ.get("AUIF_GOVERNOR_R14_ZIP"); g = ext.get("against_real_governor_r14")
            if gz and os.path.isfile(gz):                                                                    # optional: only when the caller supplies the read-only R14 Governor zip
                rc, out = sh([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "auif_ext/tests", "-t", "."], root); m = re.search(r"Ran (\d+) tests", out); n = int(m.group(1)) if m else -1; k = re.search(r"skipped=(\d+)", out); k = int(k.group(1)) if k else 0
                rec("5h extension tests vs real R14", rc == 0 and k == 0 and bool(g) and n == g["tests_run"] and hashlib.sha256(open(gz, "rb").read()).hexdigest() == g["governor_zip_sha256"], "%d run, %d skipped (recorded: %s)" % (n, k, "%d, %d" % (g["tests_run"], g["skipped"]) if g else "none"))
            else: print("%-34s %s  %s" % ("5h extension tests vs real R14", "NOT RUN", "AUIF_GOVERNOR_R14_ZIP not supplied; the recorded R14 result is in evidence/ext_verification.json (not a pass or a fail of this run)"))
        obp = root + "/evidence/onboard_verification.json"; has_ob = os.path.isdir(root + "/auif_onboard"); ob = json.load(open(obp)) if os.path.exists(obp) else None; PINNED = "923de5100f95debbbf63d5ab6e960cee2091ee57abce403792403ff049ac7839"; X_CHANGED, X_ADDED = ["auif/ai_boundary.py", "auif/canonical.py", "auif/fabric.py", "auif/integration.py", "auif/translation.py", "auif_ext/module_client/client.py", "auif_ext/tests/test_extension_boundary.py"], ["auif_ext/tests/test_rev14_module_client.py", "tests/test_rev14_fixes.py"]      # rev14: the core was revised (rev10 to rev13 pinned 74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d) and the layers are compared with the untouched rev13 package
        if has_ob and not ob: rec("5i onboarding evidence", False, "auif_onboard/ is present but evidence/onboard_verification.json is missing (fail closed: the onboarding steps cannot be skipped)")
        if ob and not has_ob: rec("5i onboarding evidence", False, "onboarding evidence is present but auif_onboard/ is missing")
        if has_ob and ob:                                                                                    # the onboarding accelerator (auif_onboard): tests, static checks, reverse contamination, recorded evidence
            rc, out = sh([sys.executable, "-W", "ignore", "-m", "unittest", "discover", "-s", "auif_onboard/tests", "-t", "."], root, env_drop=("AUIF_GOVERNOR_R14_ZIP",)); m = re.search(r"Ran (\d+) tests", out); n = int(m.group(1)) if m else -1; e = ob["onboard_tests"]
            rec("5i onboarding tests", rc == 0 and out.strip().splitlines()[-1].startswith("OK") and n == e["tests_run"] and e["ok"], "%d run (recorded: %d)" % (n, e["tests_run"]))
            rc, out = sh([sys.executable, "tools/static_checks_onboard.py"], root)
            try: d = ast.literal_eval(out.strip().splitlines()[-1]); good = rc == 0 and not any(v for v in d.values() if isinstance(v, list)) and d["core_tree_sha256"] == acc["core_tree_sha256"] == PINNED; det = "%d files, core %s" % (d["files_checked"], d["core_tree_sha256"][:16] + "...")
            except (ValueError, SyntaxError, IndexError): good, det = False, "no result"
            rec("5j onboarding static checks", good, det)
            rc, out = sh([sys.executable, "tools/onboard_reverse_contamination.py", str(acc["tests_run"]), str(ext["always_on"]["tests_run"]), str(ext["always_on"]["skipped"]), PINNED], root); first = out.strip().splitlines()[0][:150] if out.strip() else "no result"; rec("5k onboarding reverse contamination", rc == 0 and "ONBOARD REVERSE CONTAMINATION: PASS" in out, first)
            sp = ob.get("specs", {}); fz = ob.get("frozen_layers_vs_rev13", {})
            good = (len(sp) == 3 and ob["pinned_core_tree_sha256"] == PINNED == ob["core_tree_sha256"] == acc["core_tree_sha256"] and fz.get("ok") is True and fz.get("changed") == X_CHANGED and fz.get("added") == X_ADDED and not fz.get("removed") and ob["reverse_contamination"]["ok"] is True and ob["core_tests"]["tests_run"] == acc["tests_run"]
                    and all(v["validation"]["all_checks_passed"] is True and v["validation"]["synthetic_only"] is True and v["validation"]["real_system_validated"] is False and v["credential_ref_in_draft"] is None and v["validated_or_trusted_in_draft"] == 0 and v["secrets"]["canary_in_any_artifact_or_report"] is False and v["secrets"]["scan_findings_in_artifacts"] == 0 for v in sp.values()))
            rec("5l onboarding evidence consistent", good, "%d specs, frozen layers identical to rev13 apart from the named rev14 files: %s, core pinned" % (len(sp), fz.get("ok")))
        manifest("6 manifest (after tests)")
        if "--skip-mutation" not in sys.argv:
            limit = mutation_timeout(sys.argv); t0 = time.monotonic()
            try: rc, out = sh([sys.executable, "tools/mutation_test.py"], root, limit)
            except subprocess.TimeoutExpired: rec("7 mutation", False, "stopped by the caller's explicit --mutation-timeout=%gs (not a verdict on the package)" % limit)
            else:
                m = re.search(r"mutants=(\d+) killed=(\d+) survived=(\d+) invalid=(\d+)", out); mu = acc["mutation"]
                rec("7 mutation", bool(m) and tuple(map(int, m.groups())) == (mu["mutants"], mu["killed"], 0, 0) and mu["survived"] == 0, (m.group(0) if m else "no summary") + " in %ds" % (time.monotonic() - t0))
            mxp = root + "/evidence/mutation_ext_results.json"
            if has_ext and not os.path.exists(mxp): rec("7b extension mutation", False, "auif_ext/ is present but evidence/mutation_ext_results.json is missing (fail closed)")
            if has_ext and ext and os.path.exists(mxp):
                mx = json.load(open(mxp)); t1 = time.monotonic()
                try: rc, out = sh([sys.executable, "tools/mutation_ext.py"], root, limit)
                except subprocess.TimeoutExpired: rec("7b extension mutation", False, "stopped by the caller's explicit --mutation-timeout=%gs (not a verdict on the package)" % limit)
                else:
                    m = re.search(r"mutants=(\d+) killed=(\d+) survived=(\d+) invalid=(\d+)", out); rec("7b extension mutation", bool(m) and tuple(map(int, m.groups())) == (mx["mutants"], mx["killed"], 0, 0) and mx["survived"] == 0, (m.group(0) if m else "no summary") + " in %ds" % (time.monotonic() - t1))
            mop = root + "/evidence/mutation_onboard_results.json"
            if has_ob and not os.path.exists(mop): rec("7c onboarding mutation", False, "auif_onboard/ is present but evidence/mutation_onboard_results.json is missing (fail closed)")
            if has_ob and ob and os.path.exists(mop):
                mo = json.load(open(mop)); t2 = time.monotonic()
                try: rc, out = sh([sys.executable, "tools/mutation_onboard.py"], root, limit)
                except subprocess.TimeoutExpired: rec("7c onboarding mutation", False, "stopped by the caller's explicit --mutation-timeout=%gs (not a verdict on the package)" % limit)
                else:
                    m = re.search(r"mutants=(\d+) killed=(\d+) survived=(\d+) invalid=(\d+)", out); rec("7c onboarding mutation", rc == 0 and bool(m) and tuple(map(int, m.groups())) == (mo["mutants"], mo["killed"], 0, 0) and mo["survived"] == 0 and mo["invalid"] == 0 and ob.get("mutation", {}).get("mutants") == mo["mutants"], (m.group(0) if m else "no summary") + " in %ds" % (time.monotonic() - t2))
            manifest("8 manifest (after mutation)")
    finally: shutil.rmtree(t, ignore_errors=True)
    print("\nRESULT: %s" % ("PASS - zero hash/size mismatches after every step" if ok else "FAIL")); return 0 if ok else 1
if __name__ == "__main__": sys.exit(main())

"""Mutation testing for the EXTENSION package (auif_ext). Each mutant sabotages ONE guard in a temporary copy of the tree; the extension suite must then FAIL ("killed"). A mutant that leaves the suite green "survived" and is a test gap.
Only the always-on extension tests run (not the R14 conformance, which needs the Governor zip). A mutant must apply to exactly one place, else it is "invalid". Usage: python3 tools/mutation_ext.py [--check] [--workers=N] [--out=FILE]
Prints: mutants=N killed=K survived=S invalid=I (N = mutants run; the documented EQUIVALENT ones are listed and not run). Writes nothing into the package unless --out is given (so verifying a fresh ZIP never alters a tracked file)."""
import concurrent.futures, json, os, re, shutil, subprocess, sys, tempfile, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
C, H, O, R, W, F, G, M = "auif_ext/common.py", "auif_ext/connectors/http_client.py", "auif_ext/connectors/oauth2.py", "auif_ext/connectors/rest.py", "auif_ext/connectors/webhook.py", "auif_ext/connectors/file_import.py", "auif_ext/governor_adapter/adapter.py", "auif_ext/module_client/client.py"
MUTANTS = [
 # --- common: credential wrapper, header hygiene, Retry-After
 ("E01", C, 'return "Secret(<redacted>)"', 'return "Secret(" + self._v + ")"', "a Secret leaks through repr"),
 ("E02", C, 'def __format__(self, spec): return "<redacted>"', 'def __format__(self, spec): return self._v', "a Secret leaks through format()"),
 ("E03", C, 'def __reduce__(self): raise TypeError("a Secret cannot be pickled")', 'def __reduce__(self): return (str, (self._v,))', "a Secret can be pickled"),
 ("E04", C, '_BAD_VALUE = re.compile(r"[\\r\\n\\x00]")', '_BAD_VALUE = re.compile(r"[\\r\\x00]")', "LF no longer refused in a header value"),
 ("E05", C, "not _TOKEN.match(name) or ", "", "header names are not validated"),
 ("E06", C, "return min(float(v), cap)", "return float(v)", "Retry-After seconds are not clamped"),
 ("E07", C, "max(0.0, min(dt.timestamp() - (time.time() if now is None else now), cap))", "max(0.0, dt.timestamp() - (time.time() if now is None else now))", "Retry-After dates are not clamped"),
 # --- http transport
 ("E10", H, "if p.netloc.lower() not in self.hosts and host not in self.hosts:", "if False:", "the host allow-list is not enforced"),
 ("E11", H, 'if p.scheme == "http" and not (self.insecure_ok and host in LOOPBACK):', "if False:", "plain http is accepted"),
 ("E12", H, "not (self.insecure_ok and host in LOOPBACK)", "not self.insecure_ok", "insecure http is accepted for non-loopback hosts"),
 ("E13", H, 'or "@" in p.netloc ', "", "userinfo in a URL is accepted"),
 ("E14", H, "or p.fragment ", "", "a URL fragment is accepted"),
 ("E15", H, "k, v = common.clean_header(k, v); hdrs[k.lower()] = v", "hdrs[k.lower()] = v", "header injection is not refused"),
 ("E16", H, "if len(data) > self.max_bytes:", "if False:", "the response size cap is not enforced"),
 ("E17", H, 'raise TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", message="request timed out")', 'raise TransportError("TIMEOUT", applied="NOT_APPLIED", message="request timed out")', "a write that times out is not MAYBE applied"),
 ("E18", H, 'applied="MAYBE" if (write and sent) else "NOT_APPLIED", message="connection lost")', 'applied="NOT_APPLIED", message="connection lost")', "a write whose connection drops is not MAYBE applied"),
 ("E19", H, 'raise TransportError("CONNECTION_FAILED", applied="NOT_APPLIED", message="connection failed")', 'raise TransportError("CONNECTION_FAILED", applied="MAYBE", message="connection failed")', "a refused connection is reported as maybe applied"),
 ("E20", H, "ssl.create_default_context()", "ssl._create_unverified_context()", "TLS verification is off by default"),
 ("E21", H, '"accept-encoding": "identity"', '"accept-encoding": "gzip"', "compression is requested"),
 ("E22", H, 'WRITE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})', 'WRITE_METHODS = frozenset({"POST", "PUT", "DELETE"})', "PATCH is not treated as a write"),
 ("E23", H, 'if not hosts: raise ValueError("an explicit host allow-list is required")', "pass", "an empty allow-list is accepted"),
 # --- oauth2
 ("E30", O, "return c[1] if c and c[0] == key and c[2] > now else None", "return c[1] if c and c[2] > now else None", "a cached token is reused for different credentials"),
 ("E31", O, "now + max(0.0, life - self.skew)", "now + max(0.0, life)", "the expiry skew is ignored"),
 ("E32", O, "life = min(max(life, 0.0), self.maxlife)", "life = max(life, 0.0)", "the token lifetime is not clamped"),
 ("E33", O, 'str(body.get("token_type", "bearer")).lower() != "bearer"', "False", "a non-bearer token type is accepted"),
 ("E34", O, "if r.status == 429:", "if r.status == 0:", "token endpoint rate limiting is not recognised"),
 ("E35", O, "if r.status >= 500:", "if r.status >= 600:", "token endpoint outages are not recognised"),
 ("E36", O, "parse_constant=lambda c: (_ for _ in ()).throw(ValueError(c))", "parse_constant=float", "NaN is accepted in a token response"),
 ("E37", O, 'if self.style == "basic": hdrs["Authorization"]', 'if self.style == "body": hdrs["Authorization"]', "the credential style is swapped"),
 ("E38", O, "if not cid or not csec:", "if False:", "an empty client id or secret is accepted"),
 ("E39", O, 'cid, _, csec = secret.partition(":")', 'cid, _, csec = secret.rpartition(":")', "the credential is split on the last colon"),
 # --- rest connector
 ("E40", R, 'return TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", status=s, message="authentication failed")', 'return TransportError("UNAVAILABLE", applied="NOT_APPLIED", status=s, message="authentication failed")', "401 is not mapped to AUTHENTICATION_FAILED"),
 ("E41", R, '"AUTHORIZATION_DENIED_BY_TARGET", applied="NOT_APPLIED", status=s', '"TARGET_REJECTED_REQUEST", applied="NOT_APPLIED", status=s', "403 is not mapped to AUTHORIZATION_DENIED_BY_TARGET"),
 ("E42", R, 'TransportError("RATE_LIMITED", applied="NOT_APPLIED", retry_after=ra, status=s', 'TransportError("RATE_LIMITED", applied="NOT_APPLIED", status=s', "Retry-After is dropped on 429"),
 ("E43", R, 'applied="MAYBE" if write else "NOT_APPLIED", retry_after=ra, status=s, message="target unavailable")', 'applied="NOT_APPLIED", retry_after=ra, status=s, message="target unavailable")', "a write answered by a 5xx is not MAYBE applied"),
 ("E44", R, 'TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", status=s, message="target timed out")', 'TransportError("TIMEOUT", applied="NOT_APPLIED", status=s, message="target timed out")', "a write answered by a 408 is not MAYBE applied"),
 ("E45", R, "if 300 <= s <= 499: return", "if 400 <= s <= 499: return", "a redirect is not rejected"),
 ("E46", R, "if not (200 <= r.status <= 299): raise error_for_status(r, write)", "if not (200 <= r.status <= 399): raise error_for_status(r, write)", "a redirect is treated as success"),
 ("E47", R, "extra={c.idempotency_header: key} if c.idempotency_header else None", "extra=None", "the idempotency key is not sent"),
 ("E48", R, 'urllib.parse.quote(v, safe="")', 'urllib.parse.quote(v, safe="/")', "path parameters are not fully percent-encoded"),
 ("E49", R, 'not v or v in (".", "..") or len(v) > 200', "not v or len(v) > 200", "dot segments are accepted as path parameters"),
 ("E50", R, 'max(1, min(int(request.get("page_size") or 50), c.max_page_size))', 'max(1, int(request.get("page_size") or 50))', "the page size is not clamped"),
 ("E51", R, "(not isinstance(cur, str) or not cur or len(cur) > 512)", "False", "an unacceptable cursor is accepted"),
 ("E52", R, "or len(items) > c.max_page_size or ", "or ", "an oversized page is accepted"),
 ("E53", R, "or any(not isinstance(i, dict) for i in items)", "", "non-object page items are accepted"),
 ("E54", R, 'if "json" not in r.headers.get("content-type", "").lower(): raise MalformedResponse("response is not JSON")', "pass", "a non-JSON response is parsed"),
 ("E55", R, "return json.loads(r.body.decode(\"utf-8\"), parse_constant=_plain)", "return json.loads(r.body.decode(\"utf-8\"))", "NaN is accepted in a response"),
 ("E56", R, "if not isinstance(fields, dict) or (c.idempotency_header and (not isinstance(key, str) or not IDEM.match(key))):", "if not isinstance(fields, dict):", "an unacceptable idempotency key is accepted"),
 ("E57", R, "if r.status == 404: return None", "if r.status == 404: raise error_for_status(r, w)", "a 404 lookup is not 'not applied'"),
 ("E58", R, 'if ref in (None, ""): raise MalformedResponse("lookup response has no reference")', "pass", "a lookup without a reference is accepted"),
 ("E59", R, 'raise ValueError("base_url must be https")', "pass", "a plain http base_url is accepted"),
 ("E60", R, 'or set(PLACE.findall(ep.path)) - {"{id}", "{key}"}', "", "unknown path placeholders are accepted"),
 ("E61", R, 'if c.auth != "NONE" and not c.credential_ref: raise ValueError("authentication needs a credential_ref (a secret reference)")', "pass", "authentication without a credential reference is accepted"),
 ("E62", R, 'if not isinstance(sec, str) or not sec: raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", message="no credential")', "pass", "connecting without a credential is accepted"),
 ("E63", R, 'if self._secret is None: raise TransportError("AUTHENTICATION_FAILED", applied="NOT_APPLIED", message="not connected")', "pass", "an unconnected connector makes authenticated requests"),
 ("E64", R, "if r.status == 401 and self.oauth: self.oauth.invalidate()", "pass", "a 401 does not invalidate the cached token"),
 ("E65", R, "self.oauth.invalidate(); self.oauth.token(self._cid, csec)", "self.oauth.invalidate()", "an OAuth2 credential is not verified at connect"),
 ("E66", R, 'if isinstance(nxt, bool) or nxt in (None, "", 0): return None', 'if nxt in (None, ""): return None', "a false-like next cursor continues paging"),
 ("E67", R, 'if not e or not e.get("list"): raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED", message="entity is not readable")', "pass", "an undeclared entity is readable"),
 ("E68", R, "c.auth_header: c.auth_prefix + self._secret.reveal()", "c.auth_header: self._secret.reveal()", "the API-key prefix is dropped"),
 ("E69", R, "idempotent_writes=bool(c.idempotency_header)", "idempotent_writes=True", "the descriptor claims idempotency it does not have"),
 # --- webhook
 ("E80", W, "ok |= hmac.compare_digest(mac.encode(), cand.encode())", "ok |= (mac == cand)", "the signature is not compared in constant time"),
 ("E81", W, "ok |= hmac.compare_digest(mac.encode(), cand.encode())", "ok = ok or hmac.compare_digest(mac.encode(), cand.encode())", "the comparison short-circuits"),
 ("E82", W, "fresh = abs(self.clock() - t) <= c.tolerance_seconds", "fresh = True", "the timestamp tolerance is not enforced"),
 ("E83", W, "fresh = abs(self.clock() - t) <= c.tolerance_seconds", "fresh = (self.clock() - t) <= c.tolerance_seconds", "future timestamps are accepted"),
 ("E84", W, "except (TypeError, ValueError): fresh = False", "except (TypeError, ValueError): fresh = True", "a missing or invalid timestamp is accepted"),
 ("E85", W, "or len(body) > c.max_body_bytes", "", "the body size limit is not enforced"),
 ("E86", W, 'if not secrets: return WebhookResult(503, {"status": "verification_unavailable"})', "pass", "a delivery is accepted when no secret can be resolved"),
 ("E87", W, "if not self._verified(secrets, headers, bytes(body), ts): return WebhookResult(401", "if False: return WebhookResult(401", "the signature is not checked"),
 ("E88", W, "if s.strip().startswith(self.c.signature_prefix)", "if True", "the signature prefix is not enforced"),
 ("E89", W, "or not str(eid) or", "or", "an empty event id is accepted"),
 ("E90", W, "or len(str(eid)) > 128 or", "or", "an oversized event id is accepted"),
 ("E91", W, "isinstance(eid, bool) or ", "", "a boolean event id is accepted"),
 ("E92", W, "or not isinstance(payload, dict)", "", "a non-object payload is accepted"),
 ("E93", W, 'WebhookResult(409, {"status": "conflict"})', 'WebhookResult(200, {"status": "conflict"})', "an event-id conflict is acknowledged as success"),
 ("E94", W, 'WebhookResult(200, {"status": "duplicate"})', 'WebhookResult(409, {"status": "duplicate"})', "a duplicate is reported as a conflict"),
 ("E95", W, 'except Exception: return WebhookResult(503, {"status": "unavailable"})', 'except Exception: return WebhookResult(200, {"status": "unavailable"})', "a failure in the core is acknowledged as success"),
 ("E96", W, "except TenantContextError: return WebhookResult(401", "except TenantContextError: return WebhookResult(503", "a tenant context failure is not unauthorised"),
 ("E97", W, '{"{timestamp}": (ts or "").encode(), "{body}": body}', '{"{timestamp}": b"", "{body}": body}', "the timestamp is not part of the signed message"),
 ("E98", W, "if not isinstance(dep, list) or any(not isinstance(d, (str, int)) or isinstance(d, bool) for d in dep): return WebhookResult(400", "if False: return WebhookResult(400", "depends_on is not validated"),
 # --- file import
 ("E110", F, "if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode)", "if not stat.S_ISREG(st.st_mode)", "symlinks are followed"),
 ("E111", F, "or not stat.S_ISREG(st.st_mode) or os.path.dirname", "or os.path.dirname", "non-regular files are accepted"),
 ("E112", F, 'if i >= sp.max_rows: raise MalformedResponse("file exceeds the row limit")', "pass", "the row limit is not enforced"),
 ("E113", F, 'if len(r) != len(head): raise MalformedResponse("a row does not match the header")', "pass", "ragged rows are accepted"),
 ("E114", F, "or len(set(head)) != len(head)", "", "duplicate header names are accepted"),
 ("E115", F, 'if "\\x00" in text: raise MalformedResponse("file contains NUL bytes")', "pass", "NUL bytes are accepted"),
 ("E116", F, 'data.decode("utf-8-sig")', 'data.decode("utf-8")', "a BOM is not stripped"),
 ("E117", F, 'elif t == "integer" and INT.match(v): out[k] = int(v)', 'elif t == "integer": out[k] = int(v)', "an integer column is not validated"),
 ("E118", F, 'NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")', 'NAME = re.compile(r"^[A-Za-z0-9._][A-Za-z0-9._-]{0,127}$")', "a leading dot is accepted in file names"),
 ("E119", F, "if start < 0:", "if False:", "a negative cursor is accepted"),
 ("E120", F, 'size = max(1, min(int(request.get("page_size") or 50), 200))', 'size = max(1, int(request.get("page_size") or 50))', "the file page size is not clamped"),
 ("E121", F, 'raise TransportError("UNSUPPORTED_OPERATION", applied="NOT_APPLIED", message="file import is read-only")', 'return {"external_reference": "x", "result": {}}', "a read-only connector accepts a write"),
 ("E122", F, "parse_constant=_refuse", "parse_constant=float", "NaN is accepted in a JSON file"),
 ("E123", F, 'raise TransportError("UNAVAILABLE", applied="NOT_APPLIED", message="file is not present")', 'raise TransportError("UNAVAILABLE", applied="MAYBE", message="file is not present")', "a missing file is reported as maybe applied"),
 # --- governor adapter
 ("E140", G, "if not callable(self._verify) or not callable(self._sink) or not isinstance(decision, dict): return False", "if not isinstance(decision, dict): return False", "decision delivery does not require a verifier and a sink"),
 ("E141", G, "if self._verify(decision) is not True: return False", "if not self._verify(decision): return False", "a truthy verifier result delivers a decision"),
 ("E142", G, "self._sink(decision); return True\n            except Exception: return False", "self._sink(decision); return True\n            except Exception: return True", "a failing delivery reports success"),
 ("E143", G, "self._sink(decision); return True", "return True", "a verified decision is never actually delivered"),
 ("E144", G, 'except TimeoutError: return bad("timeout")', 'except TimeoutError: return bad("crash")', "a timeout is not reported as a timeout"),
 ("E145", G, "if not isinstance(native, list) or any(not isinstance(n, dict) for n in native): return bad(\"malformed\")", "if not isinstance(native, list): return bad(\"malformed\")", "non-object observations are accepted"),
 ("E146", G, 'if k not in ("tenant_id", "target_system_id")', "if True", "a declared proposal can override the tenant"),
 ("E147", G, '_SAFE = re.compile(r"[^a-z0-9_-]+")', '_SAFE = re.compile(r"[^a-z0-9_.-]+")', "neutral ids are not sanitised"),
 ("E148", G, 'if getattr(observation, "failure", None) or not isinstance(n, dict) or not n: return None', "if not isinstance(n, dict) or not n: return None", "a failed observation is normalised"),
 ("E149", G, "declared_metadata=dict(n), classification=cls if isinstance(cls, str) else None)", "declared_metadata=dict(n), classification=cls)", "a non-string classification is passed through"),
 ("E150", G, "signature=None)", 'signature="forged")', "an attestation carries a signature AUIF cannot make"),
 ("E151", G, "Cap.DECISION_DELIVERY: callable(self._verify) and callable(self._sink)", "Cap.DECISION_DELIVERY: True", "decision delivery is declared without being wired"),
 ("E152", G, "Cap.ATTESTATION: self._attester is not None", "Cap.ATTESTATION: True", "attestation is declared without being wired"),
 ("E153", G, 'canonical_event_type=t if isinstance(t, str) and t else "unknown"', "canonical_event_type=t", "a non-string event type is passed through"),
 ("E154", G, "tenant_id=self._t, target_system_id=self._s, environment_id=self._e, declared_metadata", "tenant_id=n.get(\"tenant_id\", self._t), target_system_id=self._s, environment_id=self._e, declared_metadata", "a target can override the tenant"),
 ("E155", G, 'if o.get("target_system_id") != tsid: continue', "if False: continue", "observations of other integrations are forwarded"),
 ("E156", G, '"schema_fingerprint": o.get("schema_fingerprint")})', '"schema_fingerprint": o.get("schema_fingerprint"), "payload": o})', "business payloads are forwarded"),
 ("E157", G, "if missing: raise ValueError", "if False: raise ValueError", "an incomplete Governor binding is accepted"),
 ("E158", G, 'if id_namespace.count(".") < 1 or concept not in gov.NeutralConcept.__members__: raise ValueError("unacceptable namespace or concept")', "pass", "an unacceptable namespace or concept is accepted"),
 # --- module client
 ("E170", M, "json.dumps([ctx.tenant_id, intent_id, canonical_type, canonical_id, attributes]", "json.dumps([intent_id, canonical_type, canonical_id, attributes]", "the idempotency key is not tenant-specific"),
 ("E171", M, "sort_keys=True", "sort_keys=False", "the idempotency key depends on key order"),
 ("E172", M, '"governor_decision_ref": None}}', '"governor_decision_ref": "forged-ref"}}', "a module asserts a Governor decision"),
 ("E173", M, "except Exception as e: self.handler_errors.append", "except ZeroDivisionError as e: self.handler_errors.append", "a failing handler stops delivery"),
 ("E174", M, '{"kind": kind, "error": type(e).__name__}', '{"kind": kind, "error": str(e)}', "a handler error message (which may hold data) is kept"),
 ("E175", M, "json.loads(json.dumps(requirements))", "requirements", "a module's declared requirements can be changed by the caller"),
 ("E176", M, 'if not isinstance(module_id, str) or not module_id: raise ValueError("a module must declare a module_id")', "pass", "a module without an id is accepted"),
 # --- rev8 extensions (transport deadline and TLS floor, single-flight OAuth2, ingest serialisation, REST pagination)
 ('E200', H, 'and 0 < total_deadline < float("inf")', 'and True', 'a non-positive or infinite total deadline is accepted'),
 ('E201', H, 'held[0] if held else conn.sock', 'conn.sock', 'the deadline cannot cut a socket that http.client has handed to the response'),
 ('E202', H, 'threading.Timer(self.dl, _expire)', 'threading.Timer(self.dl * 1000, _expire)', 'the total deadline never fires'),
 ('E203', H, 'if expired.is_set(): raise TransportError("TIMEOUT", applied="NOT_APPLIED", message="request exceeded the total deadline")      # the deadline passed while connecting', 'if False: raise TransportError("TIMEOUT", applied="NOT_APPLIED", message="request exceeded the total deadline")      # the deadline passed while connecting', 'a deadline that passes while connecting is ignored'),
 ('E204', H, 'applied="MAYBE" if write else "NOT_APPLIED", message="request exceeded the total deadline"', 'applied="NOT_APPLIED", message="request exceeded the total deadline"', 'a write cut off by the deadline during the request is not maybe applied', 0),
 ('E205', H, 'applied="MAYBE" if write else "NOT_APPLIED", message="request exceeded the total deadline"', 'applied="NOT_APPLIED", message="request exceeded the total deadline"', 'a write cut off by the deadline while reading is not maybe applied', 1),
 ('E206', H, 'applied="MAYBE" if write else "NOT_APPLIED", message="request exceeded the total deadline"', 'applied="NOT_APPLIED", message="request exceeded the total deadline"', 'a write whose body was cut short silently is not maybe applied', 2),
 ('E207', H, '        if expired.is_set(): raise TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", message="request exceeded the total deadline")          # a read cut short', '        if False: raise TransportError("TIMEOUT", applied="MAYBE" if write else "NOT_APPLIED", message="request exceeded the total deadline")          # a read cut short', 'a body cut short by the deadline is accepted as complete'),
 ('E208', H, 'c.minimum_version = ssl.TLSVersion.TLSv1_2', 'c.minimum_version = ssl.TLSVersion.TLSv1', 'the TLS floor is lowered to 1.0'),
 ('E210', O, 'leader = fl is None', 'leader = True', 'every concurrent caller fetches its own token'),
 ('E211', O, 'if self._gen == gen:', 'if True:', 'an invalidate during a fetch is undone by that fetch'),
 ('E212', O, 'self._flights.pop(key, None)', 'None', 'a finished flight is never removed'),
 ('E213', O, 'fl = self._flights.get(key); leader', 'fl = next(iter(self._flights.values()), None); leader', "a different credential joins another credential's flight"),
 ('E214', O, 'if fl["err"] is not None: raise fl["err"]', 'if False: raise fl["err"]', 'a failed fetch is not reported to the callers waiting on it'),
 ('E220', W, 'with self._ingest_lock: decisions = self.ingest(ctx, integration_id, [ev])', 'if True: decisions = self.ingest(ctx, integration_id, [ev])', 'calls into the core overlap'),
 ('E230', R, 'total_deadline=c.total_deadline)', 'total_deadline=60.0)', 'the configured total deadline is not passed to the transport'),
 ('E231', R, 'n = self._position(cur, 0 if ep.pagination == "offset" else 1)', 'n = self._position(cur, 1)', 'the first offset is 1, not 0'),
 ('E232', R, 'or int(cur) < first or', 'or', 'page 0 is accepted'),
 ('E233', R, 'or int(cur) > 10 ** 9:', 'or False:', 'an enormous offset is accepted'),
 ('E234', R, 'cur.isascii() and cur.isdigit()', 'cur.isdigit()', 'non-ASCII digits are accepted in a position'),
 ('E235', R, 'if not items: return None', 'if False: return None', 'an empty page does not end offset or page paging'),
 ('E236', R, 'if (here + len(items) >= total) if offset else (here >= total): return None', 'if False: return None', 'a known total does not end paging'),
 ('E237', R, 'if isinstance(total, bool) or not isinstance(total, int) or total < 0: raise MalformedResponse', 'if False: raise MalformedResponse', 'a malformed total is accepted'),
 ('E238', R, 'return str(here + len(items) if offset else here + 1)', 'return str(here + 1)', 'the offset advances by one instead of by the page'),
 ('E239', R, '(ep.offset_param if ep.pagination == "offset" else ep.page_param)', 'ep.offset_param', 'the page parameter name is ignored'),
 ('E240', R, 'else (here >= total)', 'else False', 'a known total page count does not end page paging'),
 ('E241', R, '(u.scheme, u.netloc.lower(), u.path) != (base.scheme, base.netloc.lower(), base.path) or u.fragment', 'False or u.fragment', 'a next link may leave the origin or the endpoint'),
 ('E242', R, 'or u.fragment or', 'or', 'a next link with a fragment is accepted'),
 ('E243', R, 'strict_parsing=True', 'strict_parsing=False', 'a query with a bare key is accepted in a next link', 1),
 ('E244', R, 'max_num_fields=20', 'max_num_fields=None', 'an unbounded number of query fields is accepted in a next link', 1),
 ('E245', R, 'or len(cursor) > 512:', 'or False:', 'an oversized link cursor is accepted'),
 ('E246', R, 'if NEXTISH.search(header): raise MalformedResponse(', 'if False: raise MalformedResponse(', 'an unreadable next link silently ends paging'),
 ('E247', R, 'if len(header) > 4096: raise MalformedResponse("link header is too long")', 'pass', 'an oversized link header is accepted'),
 ('E248', R, '"next" not in (rel.group(1) or rel.group(2) or "").lower().split()', 'False', 'any link is treated as the next page'),
 ('E249', R, 'urllib.parse.urljoin(self._url(ep.path), m.group(1))', 'm.group(1)', 'a relative next link is not resolved'),
 ('E250', R, 'if cur is None: return {ep.page_size_param: size}\n            try:', 'if cur is None: return {}\n            try:', 'the first link-mode request omits the page size'),
 ('E251', R, 'if not pairs or urllib.parse.urlencode(pairs) != cur:', 'if not pairs:', 'a non-canonical link cursor is accepted'),
 ('E252', R, 'ep.pagination not in PAGINATIONS', 'False', 'an unknown pagination style is accepted'),
 ('E253', R, 'all(isinstance(x, str) and x for x in (ep.cursor_param, ep.page_size_param, ep.offset_param, ep.page_param))', 'True', 'an empty or non-string paging parameter name is accepted'),
 # --- rev12: tenant-scoped connections
 ("E254", R, 'if (c.tenant_header is None) != (c.tenant_id is None): raise ValueError(', 'if False: raise ValueError(', 'a tenant header without a value, or a value without a header, is accepted'),
 ("E255", R, ' or h in RESERVED_HEADERS: raise ValueError("tenant_header is not an acceptable header name")', ': raise ValueError("tenant_header is not an acceptable header name")', 'a reserved header can be the tenant header'),
 ("E256", R, 'HEADER_NAME = re.compile(r"^[A-Za-z0-9-]{1,64}\\Z")', 'HEADER_NAME = re.compile(r"^[A-Za-z0-9-]{1,640}\\Z")', 'the tenant header name length is not limited'),
 ("E257", R, 'HEADER_NAME = re.compile(r"^[A-Za-z0-9-]{1,64}\\Z")', 'HEADER_NAME = re.compile(r"^[A-Za-z0-9_-]{1,64}\\Z")', 'an underscore is accepted in the tenant header name'),
 ("E258", R, 'HEADER_NAME = re.compile(r"^[A-Za-z0-9-]{1,64}\\Z")', 'HEADER_NAME = re.compile(r"^[A-Za-z0-9-]{1,64}$")', 'a trailing newline is tolerated in the tenant header name'),
 ("E259", R, 'TENANT_ID = re.compile(r"^[A-Za-z0-9._:-]{1,100}\\Z")', 'TENANT_ID = re.compile(r"^[A-Za-z0-9._:-]{1,100}$")', 'a trailing newline is tolerated in the tenant value'),
 ("E260", R, 'TENANT_ID = re.compile(r"^[A-Za-z0-9._:-]{1,100}\\Z")', 'TENANT_ID = re.compile(r"^[A-Za-z0-9._:-]{1,1000}\\Z")', 'the tenant value length is not limited'),
 ("E261", R, 'TENANT_ID = re.compile(r"^[A-Za-z0-9._:-]{1,100}\\Z")', 'TENANT_ID = re.compile(r"^[A-Za-z0-9._: -]{1,100}\\Z")', 'a space is accepted in the tenant value'),
 ("E262", R, 'TENANT_ID = re.compile(r"^[A-Za-z0-9._:-]{1,100}\\Z")', 'TENANT_ID = re.compile(r"^[A-Za-z0-9._:;,-]{1,100}\\Z")', 'separator characters are accepted in the tenant value'),
 ("E263", R, 'if not (isinstance(c.tenant_id, str) and TENANT_ID.match(c.tenant_id)): raise', 'if not TENANT_ID.match(c.tenant_id): raise', 'a non-text tenant value is not refused as such'),
 ("E264", R, 'if not (isinstance(c.tenant_header, str) and HEADER_NAME.match(c.tenant_header)) or', 'if not HEADER_NAME.match(c.tenant_header) or', 'a non-text tenant header is not refused as such'),
 ("E265", R, 'if h in {(c.auth_header or "").lower() if c.auth == "API_KEY" else None,', 'if h in {None,', 'the tenant header may collide with the API-key header'),
 ("E266", R, 'if c.auth == "API_KEY" else None, (c.idempotency_header', 'if True else None, (c.idempotency_header', 'the tenant header is refused for a name only another authentication mode would use'),
 ("E267", R, '(c.idempotency_header or "").lower() or None}', 'None}', 'the tenant header may collide with the idempotency header'),
 ("E268", R, 'if self.cfg.tenant_header: hdrs[self.cfg.tenant_header] = self.cfg.tenant_id', 'if False: hdrs[self.cfg.tenant_header] = self.cfg.tenant_id', 'the tenant header is never sent'),
 ("E269", R, 'hdrs[self.cfg.tenant_header] = self.cfg.tenant_id', 'hdrs[self.cfg.tenant_header] = self.cfg.tenant_header', 'the tenant header carries its own name as the value'),
 ("E270", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', "the reserved header 'authorization' is allowed as a tenant header"),
 ("E271", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', "the reserved header 'proxy-authorization' is allowed as a tenant header"),
 ("E272", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', "the reserved header 'host' is allowed as a tenant header"),
 ("E273", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', "the reserved header 'content-type' is allowed as a tenant header"),
 ("E274", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', "the reserved header 'content-length' is allowed as a tenant header"),
 ("E275", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', "the reserved header 'accept' is allowed as a tenant header"),
 ("E276", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', "the reserved header 'cookie' is allowed as a tenant header"),
 ("E277", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', "the reserved header 'connection' is allowed as a tenant header"),
 ("E278", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "upgrade", "expect", "te", "trailer"})', "the reserved header 'transfer-encoding' is allowed as a tenant header"),
 ("E279", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "expect", "te", "trailer"})', "the reserved header 'upgrade' is allowed as a tenant header"),
 ("E280", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "te", "trailer"})', "the reserved header 'expect' is allowed as a tenant header"),
 ("E281", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "trailer"})', "the reserved header 'te' is allowed as a tenant header"),
 ("E282", R, 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te", "trailer"})', 'RESERVED_HEADERS = frozenset({"authorization", "proxy-authorization", "host", "content-type", "content-length", "accept", "cookie", "connection", "transfer-encoding", "upgrade", "expect", "te"})', "the reserved header 'trailer' is allowed as a tenant header"),
 # ---- rev14 (M8-F4): a handler failure is returned to the fabric, never swallowed
 ("E177", M, 'return {"handler_failures": failed} if failed else None', 'return None', "a handler failure is not reported to the fabric"),
 ("E178", M, 'type(e).__name__}); failed += 1', 'type(e).__name__})', "a handler failure is not counted"),
 ("E179", M, 'def ingest_canonical_entity(self, ctx, obj): return self._dispatch(', 'def ingest_canonical_entity(self, ctx, obj): self._dispatch(', "an entity delivery's failure is dropped"),
 ("E180", M, 'def ingest_canonical_observation(self, ctx, observation): return self._dispatch(', 'def ingest_canonical_observation(self, ctx, observation): self._dispatch(', "an observation delivery's failure is dropped"),
 ("E181", M, 'def ingest_canonical_event(self, ctx, observation): return self._dispatch(', 'def ingest_canonical_event(self, ctx, observation): self._dispatch(', "an event delivery's failure is dropped"),
 ("E182", M, 'def receive_integration_state(self, ctx, state): return self._dispatch(', 'def receive_integration_state(self, ctx, state): self._dispatch(', "a state delivery's failure is dropped"),
 ("E183", M, 'def receive_integration_error(self, ctx, error): return self._dispatch(', 'def receive_integration_error(self, ctx, error): self._dispatch(', "an error delivery's failure is dropped"),
]
# Equivalent mutants: the mutated code behaves identically to the original for EVERY input, so no test can kill them. Each is documented with its reason,
# still checked for applicability by --check, listed in every run and in the --out JSON, and NOT run. Nothing is hidden: the line it would change stays in MUTANTS.
EQUIVALENT = {
 "E110": "st comes from os.lstat(), which never follows a link, and a file's type bits are mutually exclusive, so S_ISLNK(m) implies not S_ISREG(m): the "
         "regular-file check alone already refuses a symlink. Both checks are kept as defence in depth. (A test that a symlink is refused exists and passes either way.)",
}
# Note: E140 was proposed as equivalent in the handoff; it is NOT (without the guard a missing sink still returns False, but only after the verifier has been
# called, which is observable). It is run like any other mutant and killed by test_incomplete_delivery_wiring_consults_nothing.
def nth_index(s, old, nth):
    """Position of the nth (0-based) occurrence of `old`, or -1. A mutant defined without nth must match EXACTLY one place; with nth it targets one of several identical guards."""
    i = -1
    for _ in range(nth + 1):
        i = s.find(old, i + 1)
        if i < 0: return -1
    return i
def applicable(s, m):
    nth = m[5] if len(m) > 5 else None
    return s.count(m[2]) == 1 if nth is None else s.count(m[2]) > nth
def apply(root, m):
    mid, path, old, new, why, *rest = m; p = os.path.join(root, path); s = open(p).read()
    if not applicable(s, m): return "invalid: %d occurrences" % s.count(old)
    i = s.index(old) if not rest else nth_index(s, old, rest[0])
    open(p, "w").write(s[:i] + new + s[i + len(old):]); return None
# The module(s) most likely to kill a mutant of each file run FIRST. The verdict is unchanged (a mutant is killed iff ANY test fails, and a mutant these do not kill still faces the whole suite); only the time to a kill drops.
PRIORITY = {C: ("test_common",), H: ("test_http_transport", "test_tls_e2e", "test_rest_connector"), O: ("test_oauth2",), R: ("test_rest_connector", "test_rest_pagination", "test_rest_tenant"), W: ("test_webhook",), F: ("test_file_import",), G: ("test_governor_adapter",), M: ("test_module_client",)}
def _run(root, args, timeout):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1"); env.pop("AUIF_GOVERNOR_R14_ZIP", None)
    cmd = ["discover", "-f"] + args[1:] if args[0] == "discover" else ["-f"] + args                     # -f belongs AFTER the discover sub-command
    try: r = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest"] + cmd, cwd=root, capture_output=True, text=True, timeout=timeout, env=env)
    except subprocess.TimeoutExpired: return "TIMEOUT", ""
    out = r.stdout + r.stderr; first = re.search(r"^(?:FAIL|ERROR): (\S+)", out, re.M)
    if r.returncode == 0: return "pass", ""
    if not re.search(r"^FAILED \(", out, re.M): return "error", out.strip()[-160:]                       # a usage error or a crash is a HARNESS failure: it must never be mistaken for a kill
    return "fail", (first.group(1) if first else "")
def suite(root, timeout, first=()):
    if first:
        st, who = _run(root, ["auif_ext.tests." + n for n in first], timeout)
        if st != "pass": return st, who
    return _run(root, ["discover", "-s", "auif_ext/tests", "-t", "."], timeout)
def one(m):
    t = tempfile.mkdtemp(prefix="mutext_")
    try:
        shutil.copytree(ROOT, os.path.join(t, "p"), ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "evidence")); root = os.path.join(t, "p"); bad = apply(root, m)
        if bad: return {"id": m[0], "status": "invalid", "detail": bad, "why": m[4]}
        st, who = suite(root, 180, PRIORITY.get(m[1], ())); return {"id": m[0], "status": "killed" if st in ("fail", "TIMEOUT") else "invalid" if st == "error" else "survived", "killed_by": who or st, "why": m[4]}
    finally: shutil.rmtree(t, ignore_errors=True)
def main():
    argv = sys.argv[1:]; workers = next((int(a.split("=")[1]) for a in argv if a.startswith("--workers=")), min(6, os.cpu_count() or 1)); out = next((a.split("=", 1)[1] for a in argv if a.startswith("--out=")), None)
    ids = [m[0] for m in MUTANTS]
    if len(set(ids)) != len(ids): raise SystemExit("duplicate mutant ids")
    if "--check" in argv:
        bad = 0
        for m in MUTANTS:
            src = open(os.path.join(ROOT, m[1])).read()
            if not applicable(src, m): bad += 1; print("NOT APPLICABLE %s %s: %d occurrences of %r" % (m[0], m[1], src.count(m[2]), m[2][:70]))
        print("checked %d mutants, %d not applicable" % (len(MUTANTS), bad)); return 1 if bad else 0
    t0 = time.time(); t = tempfile.mkdtemp(prefix="mutext_base_")
    try:
        shutil.copytree(ROOT, os.path.join(t, "p"), ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "evidence")); st, who = suite(os.path.join(t, "p"), 300)
    finally: shutil.rmtree(t, ignore_errors=True)
    if st != "pass": print("BASELINE FAILS (%s %s): refusing to mutate a red suite" % (st, who)); return 2
    unknown = set(EQUIVALENT) - set(ids)
    if unknown: raise SystemExit("EQUIVALENT names unknown mutants: %s" % sorted(unknown))
    for e in sorted(EQUIVALENT): print("EQUIVALENT %s (documented, not run): %s" % (e, EQUIVALENT[e]))
    run = [m for m in MUTANTS if m[0] not in EQUIVALENT]
    with concurrent.futures.ThreadPoolExecutor(workers) as ex: results = list(ex.map(one, run))
    k = sum(r["status"] == "killed" for r in results); s = sum(r["status"] == "survived" for r in results); i = sum(r["status"] == "invalid" for r in results)
    for r in results:
        if r["status"] != "killed": print("%-9s %s: %s %s" % (r["status"].upper(), r["id"], r["why"], r.get("detail", "")))
    print("mutants=%d killed=%d survived=%d invalid=%d in %ds (equivalent, documented and not run: %d of %d defined)" % (len(run), k, s, i, time.time() - t0, len(EQUIVALENT), len(MUTANTS)))
    if out: json.dump({"mutants": len(run), "killed": k, "survived": s, "invalid": i, "defined": len(MUTANTS), "equivalent_not_run": [{"id": e, "reason": EQUIVALENT[e]} for e in sorted(EQUIVALENT)], "results": results}, open(out, "w"), indent=1)
    return 0 if (s == 0 and i == 0) else 1
if __name__ == "__main__": sys.exit(main())

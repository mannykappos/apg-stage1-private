"""Static evidence for AT-16 (universality), AT-17 (reverse contamination) and AT-28 (engine independence): what the CORE (auif/) imports, names and contains."""
import ast, hashlib, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STDLIB = set(sys.stdlib_module_names)
FORBIDDEN_TOKENS = ["mcgrath", "salesforce", "hubspot", "xero", "domain.com.au", "realestate.com", "django", "sqlalchemy", "flask", "fastapi", "psycopg", "boto3", "pydantic", "anchor_real_estate", "shield"]
GOVERNOR_AUTHORITY_NAMES = re.compile(r"(issue_?cpt|issue_?decision|grant_?decision|approve_?action|authori[sz]e_?action|sign_?decision|mint_?cpt)", re.I)
def py_files(sub="auif"):
    for dp, dn, fn in os.walk(os.path.join(ROOT, sub)):
        dn[:] = [d for d in dn if d != "__pycache__"]
        for f in sorted(fn):
            if f.endswith(".py"): yield os.path.join(dp, f)
def tree_hash(sub="auif"):
    h = hashlib.sha256()
    for p in sorted(py_files(sub)): h.update(os.path.relpath(p, ROOT).encode()); h.update(open(p, "rb").read())
    return h.hexdigest()
def core_import_violations():
    out = []
    for p in py_files():
        t = ast.parse(open(p).read())
        for n in ast.walk(t):
            mods = [a.name for a in n.names] if isinstance(n, ast.Import) else ([n.module or ""] if isinstance(n, ast.ImportFrom) and n.level == 0 else [])
            for m in mods:
                top = m.split(".")[0]
                if top not in STDLIB and top != "auif": out.append((os.path.relpath(p, ROOT), m))
    return out
def forbidden_token_hits():
    hits = []
    for p in py_files():
        src = open(p).read().lower()
        for tok in FORBIDDEN_TOKENS:
            if tok in src: hits.append((os.path.relpath(p, ROOT), tok))
    return hits
def authority_api_hits():
    out = []
    for p in py_files():
        for n in ast.walk(ast.parse(open(p).read())):
            if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and GOVERNOR_AUTHORITY_NAMES.search(n.name): out.append((os.path.relpath(p, ROOT), n.name))
    return out
if __name__ == "__main__":
    r = {"core_import_violations": core_import_violations(), "forbidden_token_hits": forbidden_token_hits(), "authority_api_hits": authority_api_hits(), "core_tree_sha256": tree_hash()}; print(r); sys.exit(1 if (r["core_import_violations"] or r["forbidden_token_hits"] or r["authority_api_hits"]) else 0)

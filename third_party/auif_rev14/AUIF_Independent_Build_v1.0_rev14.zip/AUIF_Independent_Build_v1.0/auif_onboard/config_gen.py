"""Connector-configuration generator: API model (openapi.parse) -> ConfigDraft. A DRAFT: `draft_state` is DRAFT_NOT_APPROVED and nothing here can change that.
Every setting is classified honestly as one of
  determined          the API description states it (with the part of the description it came from),
  assumed_defaults    the description is silent and the connector's default (or a stated conservative choice) is used, with the reason,
  undetermined        the description is silent, ambiguous or uses something the generic connector does not support; `blocking` items must be settled by an explicit human override before the draft can be approved.
No secret is generated, inferred or emitted: `credential_ref` is always None here (a human supplies a `secretref:` NAME at approval); the output is screened by secrets_scan before it is returned."""
import copy, re
from auif.util import sha
from . import AUTHORITY, DRAFT_STATE, VERSION
from .secrets_scan import assert_clean
import urllib.parse
def norm(n): return re.sub(r"[^a-z0-9]", "", str(n).lower())
CURSOR_P = {"cursor", "after", "pagetoken", "nextcursor", "startingafter", "continuation", "continuationtoken", "marker", "nextpagetoken"}; LIMIT_P = {"limit", "pagesize", "perpage", "size", "count", "maxresults", "pagelimit"}
OFFSET_P = {"offset", "skip", "start"}; PAGE_P = {"page", "pagenumber", "pageno", "pageindex"}
NEXT_PROPS = {"nextcursor", "next", "nextpagetoken", "cursor", "continuation", "nexttoken", "after"}; TOTAL_ITEMS = {"total", "count", "totalcount", "totalitems", "totalresults"}; TOTAL_PAGES = {"totalpages", "pagecount", "pages", "numpages"}
ID_PROPS = {"id", "externalreference", "uuid", "guid"}; WRAPPERS = {"data", "result", "item", "record", "resource", "results", "items", "content"}; LOOKUP_PARAMS = {"key", "idempotencykey", "requestkey", "idempotencyid"}; HEALTH = {"/health", "/healthz", "/status", "/ping", "/_health", "/healthcheck"}
ENVELOPE = {"warnings", "errors", "messages", "validationerrors", "validationwarnings", "links", "problems", "meta"}; HANDLED_HEADERS = {"accept", "contenttype", "authorization"}
def _is_tenant_header(h):
    """A header that scopes a call to one tenant/organisation (by name only: nothing is read from the description)."""
    n = norm(h); return n.endswith("tenantid") or n in {"tenant", "xtenant", "organizationid", "organisationid", "xorganizationid", "xorganisationid"}
def _plurals(n): return {n, n + "s", n + "es"} | ({n[:-1] + "ies"} if n.endswith("y") else set())
def _pick_array(arrs, path):
    """Which of several arrays of objects in a response is the record list: (choice, rule) or (None, None). Rule 1: arrays whose name is a known envelope (warnings, errors, messages, ...) are not record lists; if exactly one array is left it is the list.
    Rule 2: if several are left, the one whose name is the last segment of the path (ignoring case and punctuation). Anything else is not decidable."""
    if len(arrs) == 1: return arrs[0], None
    rest = [a for a in arrs if not (a[0] and norm(a[0][-1]) in ENVELOPE)]
    if len(rest) == 1: return rest[0], "envelope"
    seg = norm(path.rstrip("/").rsplit("/", 1)[-1]); named = [a for a in rest if a[0] and norm(a[0][-1]) == seg]
    return (named[0], "name") if len(named) == 1 else (None, None)
ENTITY_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,63}$"); MAX_FIELD_DEPTH = 4; DEFAULT_MAX_PAGE = 200; SUPPORTED_KINDS = ("API_KEY_HEADER", "HTTP_BEARER", "OAUTH2_CC")
def _scalar_props(s, names, types, depth=2, prefix=()):
    """Paths (tuples) of properties whose normalised name is in `names` and whose type is in `types`, searching `depth` levels of objects."""
    found = []
    for k, v in sorted(s["properties"].items()):
        if norm(k) in names and v["type"] in types: found.append(prefix + (k,))
        elif v["type"] == "object" and depth > 1: found += _scalar_props(v, names, types, depth - 1, prefix + (k,))
    return found
def _arrays(s, depth=2, prefix=()):
    """Paths of properties holding an array of objects (or the schema itself if it is one)."""
    if s["type"] == "array": return [((), s["items"])] if s["items"] and s["items"]["type"] == "object" else []
    out = []
    for k, v in sorted(s["properties"].items()):
        if v["type"] == "array" and v["items"] and v["items"]["type"] == "object": out.append((prefix + (k,), v["items"]))
        elif v["type"] == "object" and depth > 1: out += _arrays(v, depth - 1, prefix + (k,))
    return out
def flatten(item, prefix="", depth=0, ancestors_required=True, notes=None):
    """Leaf fields of an object schema as dotted paths. Objects are flattened; arrays are kept as `array` leaves (the proposer will not map them)."""
    out, notes = [], notes if notes is not None else []
    for name, p in sorted(item["properties"].items()):
        path = prefix + name; req = ancestors_required and name in item["required"]
        if p["variants"]: notes.append("%s uses oneOf/anyOf and was skipped" % path); continue
        if p["type"] == "object" and p["properties"]:
            if depth + 1 >= MAX_FIELD_DEPTH: notes.append("%s is nested deeper than %d levels and was skipped" % (path, MAX_FIELD_DEPTH)); continue
            out += flatten(p, path + ".", depth + 1, req, notes); continue
        if p["type"] == "unknown": notes.append("%s has no usable type and was skipped" % path); continue
        f = {"name": path, "type": p["type"]}
        for k_out, k_in in (("enum", "enum"), ("format", "format"), ("max_length", "max_length"), ("minimum", "minimum"), ("maximum", "maximum")):
            if p[k_in] is not None: f[k_out] = p[k_in]
        f.update(required=bool(req), read_only=p["read_only"], write_only=p["write_only"], nullable=p["nullable"]); out.append(f)
    return out
class _Report:
    def __init__(self): self.determined, self.assumed, self.undetermined, self.warnings = [], [], [], []
    def det(self, field, value, source): self.determined.append({"field": field, "value": value, "source": source})
    def asm(self, field, value, reason): self.assumed.append({"field": field, "value": value, "reason": reason})
    def und(self, field, reason, blocking=True, candidates=None): self.undetermined.append({"field": field, "blocking": bool(blocking), "reason": reason, "candidates": list(candidates or [])})
def ep_dict(**kw):
    d = {"method": "GET", "path": "/", "items_path": [], "next_cursor_path": ["next_cursor"], "cursor_param": "cursor", "page_size_param": "limit", "record_path": [], "id_field": "id", "pagination": "cursor", "offset_param": "offset", "page_param": "page", "total_items_path": None, "total_pages_path": None}
    d.update(kw); return d
def _slug(title, sha8):
    s = re.sub(r"[^a-z0-9]+", "-", (title or "api").lower()).strip("-")[:30] or "api"; return "onb-%s-%s" % (s, sha8)
def _id_info(schema, entity, rep, where):
    """(record_path, id_field) of a response schema; reports what it could not decide."""
    if schema is None: rep.asm(where + ".id_field", "id", "the description declares no response body: 'id' is the connector default"); return [], "id"
    def ids(s): return _scalar_props(s, ID_PROPS | {norm(entity) + "id"}, ("string", "integer"), depth=1)
    top = ids(schema)
    if top: path, cands = [], [p[0] for p in top]
    else:
        wr = [k for k, v in sorted(schema["properties"].items()) if v["type"] == "object" and ids(v)]
        path, cands = ([wr[0]], [p[0] for p in ids(schema["properties"][wr[0]])]) if len(wr) == 1 else ([], [])
    if len(cands) == 1: rep.det(where + ".id_field", cands[0], "response schema property"); return path, cands[0]
    if "id" in cands: rep.det(where + ".id_field", "id", "response schema property 'id' (of %d candidates)" % len(cands)); return path, "id"
    rep.und(where + ".id_field", "the response schema has no single identifier property" if not cands else "several identifier properties; the connector reads one", False, cands); return path, "id"
def _pagination(op, entity, rep, where):
    """The Endpoint settings for a list operation."""
    q = op["query_params"]; hit = lambda names: sorted(n for n in q if norm(n) in names)
    cur, off, pg, lim = hit(CURSOR_P), hit(OFFSET_P), hit(PAGE_P), hit(LIMIT_P); link = "link" in op["success"]["headers"]
    styles = [s for s, present in (("cursor", cur), ("offset", off), ("page", pg), ("link", link)) if present]
    ep = {}
    if lim: ep["page_size_param"] = lim[0]; rep.det(where + ".page_size_param", lim[0], "query parameter")
    else: rep.asm(where + ".page_size_param", "limit", "no page-size parameter is declared; the connector always sends one and 'limit' is its default")
    if len(styles) != 1:
        rep.und(where + ".pagination", "no pagination style could be determined (a single page would silently truncate larger data)" if not styles else "several pagination styles are indicated", True, styles or ["single_page"]); ep["pagination"] = "cursor"; return ep, lim
    style = styles[0]; ep["pagination"] = style; rep.det(where + ".pagination", style, "query parameters" if style != "link" else "Link response header")
    body = op["success"]["schema"] or {"properties": {}, "type": "unknown"}
    if style == "cursor":
        ep["cursor_param"] = cur[0]; rep.det(where + ".cursor_param", cur[0], "query parameter")
        nxt = _scalar_props(body, NEXT_PROPS, ("string", "integer"))
        if len(nxt) == 1: ep["next_cursor_path"] = list(nxt[0]); rep.det(where + ".next_cursor_path", list(nxt[0]), "response schema property")
        else: rep.und(where + ".next_cursor_path", "no single next-cursor property in the response schema" if not nxt else "several possible next-cursor properties", True, ["/".join(p) for p in nxt])
    elif style == "offset":
        ep["offset_param"] = off[0]; rep.det(where + ".offset_param", off[0], "query parameter"); tot = _scalar_props(body, TOTAL_ITEMS, ("integer",))
        if len(tot) == 1: ep["total_items_path"] = list(tot[0]); rep.det(where + ".total_items_path", list(tot[0]), "response schema property")
        else: rep.asm(where + ".total_items_path", None, "no single total-count property: paging continues until an empty page")
    elif style == "page":
        ep["page_param"] = pg[0]; rep.det(where + ".page_param", pg[0], "query parameter"); tot = _scalar_props(body, TOTAL_PAGES, ("integer",))
        if len(tot) == 1: ep["total_pages_path"] = list(tot[0]); rep.det(where + ".total_pages_path", list(tot[0]), "response schema property")
        else: rep.asm(where + ".total_pages_path", None, "no single total-pages property: paging continues until an empty page")
    return ep, lim
def _auth(api, used_ops, base_url, rep):
    reqs = []
    for op in used_ops: reqs.append(op["security"] if op["security"] is not None else api["default_security"])
    distinct = {repr(r) for r in reqs}
    if len(distinct) > 1: rep.und("auth", "the operations used declare different security requirements", True, sorted(distinct)); return {"auth": "NONE"}
    r = reqs[0] if reqs else None
    if r is None: rep.asm("auth", "NONE", "the description declares no security requirement anywhere: confirm that the API really needs none"); rep.warnings.append("no security requirement is declared; auth defaults to NONE"); return {"auth": "NONE"}
    if not any(alt for alt in r): rep.det("auth", "NONE", "an empty security requirement"); return {"auth": "NONE"}
    seen = []
    for alt in r:
        kinds = [api["security_schemes"].get(n, {}).get("kind", "UNDEFINED") for n in alt]; seen.append("+".join(kinds))
        if len(alt) != 1 or kinds[0] not in SUPPORTED_KINDS: continue
        s = api["security_schemes"][alt[0]]
        if kinds[0] == "API_KEY_HEADER":
            if not s["header"]: continue
            rep.det("auth", "API_KEY", "apiKey security scheme in a header"); rep.det("auth_header", s["header"], "security scheme"); rep.det("auth_prefix", "", "apiKey values carry no prefix"); out = {"auth": "API_KEY", "auth_header": s["header"], "auth_prefix": ""}
        elif kinds[0] == "HTTP_BEARER": rep.det("auth", "API_KEY", "http bearer security scheme (the connector sends the secret as a bearer value)"); rep.det("auth_header", "Authorization", "bearer scheme"); rep.det("auth_prefix", "Bearer ", "bearer scheme"); out = {"auth": "API_KEY", "auth_header": "Authorization", "auth_prefix": "Bearer "}
        else:
            tu = s["token_url"]
            if tu and tu.startswith("/") and base_url: tu = urllib.parse.urlsplit(base_url)._replace(path=tu, query="", fragment="").geturl(); rep.asm("token_url", tu, "the description gives a relative token URL: resolved against the API server")
            if not tu or not tu.startswith("https://"): rep.und("token_url", "the OAuth2 token URL is missing, not https, or not resolvable", True); continue
            rep.det("auth", "OAUTH2_CLIENT_CREDENTIALS", "oauth2 clientCredentials flow"); rep.det("token_url", tu, "security scheme") if tu == s["token_url"] else None; rep.asm("token_auth_style", "basic", "the description does not say how the client authenticates to the token endpoint; RFC 6749 recommends HTTP Basic")
            rep.asm("scope", None, "scopes are not chosen automatically; declared scopes: %s" % (", ".join(s["scopes"]) or "none")); out = {"auth": "OAUTH2_CLIENT_CREDENTIALS", "token_url": tu, "scope": None, "token_auth_style": "basic"}
        if len(r) > 1: rep.warnings.append("%d alternative security requirement(s) were not used" % (len(r) - 1))
        return out
    rep.und("auth", "none of the declared security requirements is supported by the generic connector (supported: apiKey in a header, http bearer, OAuth2 client credentials)", True, seen); return {"auth": "NONE"}
def _tenant(used, idempotency, cfg_auth, rep):
    """The tenant-scoping header, if every operation the connector will use requires one. The tenant IDENTIFIER is never drafted: it is not a credential, but it names a customer's organisation, so a human supplies it at approval. Other required headers the connector does not send are reported."""
    if not used: return None
    req = [set(op["required_header_params"]) for op in used]; common = sorted(h for h in set.intersection(*req) if _is_tenant_header(h)); anyop = sorted({h for r in req for h in r if _is_tenant_header(h)}); out = None
    if len(common) == 1:
        out = common[0]; rep.det("tenant_header", out, "a required header parameter of every operation the connector uses"); rep.und("tenant_id", "a human supplies the tenant identifier at approval (it names an organisation; it is not a credential and must not be placed in the credential)", True)
    elif len(common) > 1: rep.und("tenant_header", "several tenant-scoping headers are required by every operation; the connector sends one", True, common)
    elif anyop: rep.und("tenant_header", "only some operations require a tenant-scoping header; the connector would send one on every call or on none", True, anyop)
    handled = HANDLED_HEADERS | {norm(h) for h in (out, idempotency, cfg_auth.get("auth_header")) if h}; other = sorted({h for r in req for h in r if norm(h) not in handled and not _is_tenant_header(h)})
    if other: rep.und("required_headers", "operations require header(s) the connector does not send: calls to them may be refused", False, other)
    return out
def draft_config(api, openapi_sha256):
    rep = _Report(); ops = api["operations"]; notes = []; unsupported = []
    # --- base url ---------------------------------------------------------------------------------------------------------------------------------------------------------------
    base = None; srv = api["servers"]
    if not srv: rep.und("base_url", "the description declares no server URL", True)
    else:
        s = srv[0]
        if s["relative"] or s.get("unresolved_variables"): rep.und("base_url", "the first server URL is relative or has a variable without a default", True)
        elif not s["url"].startswith("https://"): rep.und("base_url", "the first server URL is not https and the connector refuses plain http", True, [urllib.parse.urlsplit(s["url"]).scheme])
        else: base = s["url"]; rep.det("base_url", base, "servers[0]" if api["dialect"] != "swagger-2.0" else "host/basePath/schemes")
        if len(srv) > 1: rep.warnings.append("%d server URLs are declared; the first was used" % len(srv))
    for r in api["rejected"]: rep.warnings.append("%s: %s" % (r["where"], r["reason"]))
    # --- list endpoints -> entities --------------------------------------------------------------------------------------------------------------------------------------------
    entities, fields_by_entity, list_ops, max_pages, groups = {}, {}, {}, [], {}
    for op in ops:
        if op["method"] != "GET": continue
        if op["path_params"]: continue
        sch = op["success"]["schema"]; arrs = _arrays(sch) if sch else []
        if op["path"] in HEALTH: continue
        if not arrs: unsupported.append({"operation": "GET " + op["path"], "reason": "no response schema holding an array of objects was found"}); continue
        pick, rule = _pick_array(arrs, op["path"])
        if pick is None: rep.und("entities", "GET %s returns several arrays of objects; which one is the record list is not decidable" % op["path"], False, ["/".join(p) or "(root)" for p, _ in arrs]); continue
        items_path, item = pick; name = item["ref_name"] or re.sub(r"[^A-Za-z0-9_-]", "_", op["path"].rstrip("/").rsplit("/", 1)[-1])
        if not ENTITY_NAME.match(name): rep.und("entities", "the entity name for GET %s is not acceptable to the connector" % op["path"], False); continue
        groups.setdefault(name, []).append((op, items_path, item, rule, [("/".join(p) or "(root)") for p, _ in arrs]))
    for name, grp in groups.items():
        if len(grp) > 1:
            named = [g for g in grp if norm(g[0]["path"].rstrip("/").rsplit("/", 1)[-1]) in _plurals(norm(name))]; paths = sorted("GET " + g[0]["path"] for g in grp)
            if len(named) == 1:
                grp = named; rep.und("entities.%s" % name, "%d list endpoints resolve to the same entity name; GET %s was used (its path names the entity) and the others were not" % (len(paths), named[0][0]["path"]), False, paths)
            else:
                rep.und("entities.%s" % name, "%d list endpoints resolve to the same entity name and none of them is identifiable as the collection of that entity: none was used" % len(paths), False, paths)
                unsupported += [{"operation": p, "reason": "shares its record type with other list endpoints; not drafted as an entity"} for p in paths]; continue
        op, items_path, item, rule, found = grp[0]
        where = "entities.%s.list" % name; pag, lim = _pagination(op, name, rep, where)
        ep = ep_dict(path=op["path"], items_path=list(items_path), **pag)
        if items_path and rule: rep.asm(where + ".items_path", list(items_path), "the response holds %d arrays of objects (%s); %s" % (len(found), ", ".join(sorted(found)), "the others are known envelope arrays (warnings, errors, ...), not records" if rule == "envelope" else "this is the one named like the path"))
        elif items_path: rep.det(where + ".items_path", list(items_path), "response schema")
        entities[name] = {"list": ep, "write": None}; list_ops[name] = op; rep.det(where + ".path", op["path"], "path"); fnotes = []
        fields_by_entity[name] = flatten(item, notes=fnotes); notes += ["%s: %s" % (name, n) for n in fnotes]
        if not _scalar_props(item, ID_PROPS | {norm(name) + "id"}, ("string", "integer"), depth=1): rep.und("entities.%s" % name, "the record schema has no identifier property: its records cannot be keyed or reconciled by id (possibly not a record collection, e.g. a report or a setting)", False)
        for q in (op["query_params"].get(l) for l in lim):
            if q and q["schema"]["maximum"] is not None: max_pages.append(int(q["schema"]["maximum"]))
    # --- write endpoints -------------------------------------------------------------------------------------------------------------------------------------------------------
    write_ops = {}
    for op in ops:
        if op["method"] in ("POST", "PUT", "PATCH"):
            if len(op["path_params"]) > 1: unsupported.append({"operation": "%s %s" % (op["method"], op["path"]), "reason": "more than one path parameter is not supported by the generic connector"}); continue
            base_path = re.sub(r"/\{[^{}]+\}$", "", op["path"]) if op["path_params"] else op["path"]
            linked = [n for n, lo in sorted(list_ops.items()) if lo["path"] == base_path]
            if not linked: unsupported.append({"operation": "%s %s" % (op["method"], op["path"]), "reason": "no list endpoint for this resource was found, so it belongs to no entity"}); continue
            if op["request"] is None: unsupported.append({"operation": "%s %s" % (op["method"], op["path"]), "reason": "no JSON request body schema"}); continue
            write_ops.setdefault(linked[0], []).append(op)
        elif op["method"] == "DELETE": unsupported.append({"operation": "DELETE " + op["path"], "reason": "DELETE is not mapped by this draft"})
    idem, write_fields = set(), {}
    for name, cands in sorted(write_ops.items()):
        where = "entities.%s.write" % name
        if len(cands) > 1: rep.und(where, "several write operations exist for this entity; the connector uses one", False, ["%s %s" % (c["method"], c["path"]) for c in cands]); continue
        op = cands[0]; path = re.sub(r"\{[^{}]+\}", "{id}", op["path"]); rp, idf = _id_info(op["success"]["schema"], name, rep, where)
        entities[name]["write"] = ep_dict(method=op["method"], path=path, record_path=rp, id_field=idf); rep.det(where + ".method_path", "%s %s" % (op["method"], path), "operation"); wn = []
        write_fields[name] = [{k: v for k, v in f.items() if k in ("name", "type", "required", "read_only")} for f in flatten(op["request"], notes=wn)]; notes += ["%s (write body): %s" % (name, n) for n in wn]
        hit = sorted(h for h in op["header_params"] if "idempotency" in norm(h))
        if hit: idem.add(hit[0])
    if len(idem) == 1: idempotency = next(iter(idem)); rep.det("idempotency_header", idempotency, "header parameter of a write operation")
    elif len(idem) > 1: idempotency = None; rep.und("idempotency_header", "write operations declare different idempotency headers; the connector uses one", True, sorted(idem))
    else:
        idempotency = None
        if any(e["write"] for e in entities.values()): rep.und("idempotency_header", "no write operation declares an idempotency header: the draft does not claim idempotent writes, so a lost answer to a write cannot be reconciled by key", False)
    # --- lookup and health ---------------------------------------------------------------------------------------------------------------------------------------------------
    lk = [op for op in ops if op["method"] == "GET" and len(op["path_params"]) == 1 and norm(op["path_params"][0]) in LOOKUP_PARAMS]; lookup = None
    if len(lk) == 1:
        op = lk[0]; rp, idf = _id_info(op["success"]["schema"], "", rep, "lookup"); lookup = ep_dict(path=re.sub(r"\{[^{}]+\}", "{key}", op["path"]), record_path=rp, id_field=idf); rep.det("lookup.path", lookup["path"], "operation with a key path parameter")
    elif len(lk) > 1: rep.und("lookup", "several operations look like a lookup by key", False, ["GET " + o["path"] for o in lk])
    elif any(e["write"] for e in entities.values()): rep.und("lookup", "no lookup-by-key operation is declared: the connector will not claim reconciliation", False)
    health = sorted(o["path"] for o in ops if o["method"] == "GET" and o["path"] in HEALTH and not o["path_params"]); health_path = health[0] if health else None
    if health_path: rep.det("health_path", health_path, "path")
    # --- authentication ---------------------------------------------------------------------------------------------------------------------------------------------------------------
    used = list(list_ops.values()) + [c[0] for c in write_ops.values() if len(c) == 1] + (lk if len(lk) == 1 else [])
    cfg_auth = _auth(api, used, base, rep) if used else {"auth": "NONE"}; tenant_header = _tenant(used, idempotency, cfg_auth, rep)
    if cfg_auth["auth"] != "NONE": rep.und("credential_ref", "a human supplies a secret REFERENCE name (never the secret) at approval", True)
    if not entities: rep.und("entities", "no usable list endpoint was found: a connector needs at least one readable entity", True)
    hosts = sorted({urllib.parse.urlsplit(u).netloc.lower() for u in (base, cfg_auth.get("token_url")) if u})
    mp = min(max_pages + [DEFAULT_MAX_PAGE]) if max_pages else DEFAULT_MAX_PAGE
    if max_pages: rep.det("max_page_size", mp, "declared maximum of a page-size parameter (capped at %d)" % DEFAULT_MAX_PAGE)
    else: rep.asm("max_page_size", DEFAULT_MAX_PAGE, "no maximum page size is declared")
    rep.asm("discover_path", "/metadata", "an API description cannot say where a target serves discovery metadata; the discovery document below is derived offline from the description")
    cfg = {"connector_id": _slug(api["title"], openapi_sha256[:8]), "version": VERSION, "base_url": base, "allowed_hosts": hosts, "credential_ref": None, "auth": "NONE", "auth_header": "Authorization", "auth_prefix": "Bearer ", "token_url": None, "scope": None, "token_auth_style": "basic",
           "discover_path": "/metadata", "health_path": health_path, "entities": entities, "idempotency_header": idempotency, "lookup": lookup, "max_page_size": mp, "tenant_header": tenant_header, "tenant_id": None}
    cfg.update(cfg_auth)
    draft = {"artifact_kind": "ConnectorConfigDraft", "draft_state": DRAFT_STATE, "authority": AUTHORITY, "config": cfg, "determined": rep.determined, "assumed_defaults": rep.assumed, "undetermined": rep.undetermined, "warnings": rep.warnings + notes,
             "unsupported_operations": unsupported, "write_fields": write_fields, "discovery_document": discovery_document(api, cfg, fields_by_entity, list_ops, write_ops), "source": {"openapi_sha256": openapi_sha256, "dialect": api["dialect"]}}
    assert_clean(draft, "config draft"); draft["draft_hash"] = sha(draft); return draft
def discovery_document(api, cfg, fields_by_entity, list_ops, write_ops):
    """The DISCOVERY raw format (see auif.discovery) derived OFFLINE from the API description: entities with their fields, read and write operations. It is information, not truth: the core marks every element DISCOVERED, never VALIDATED."""
    ents, operations = [], []
    for name in sorted(fields_by_entity):
        ents.append({"name": name, "fields": [{k: v for k, v in f.items() if k != "name"} | {"name": f["name"]} for f in fields_by_entity[name]]})
        lo = list_ops[name]; operations.append({"name": lo["operation_id"] or "list_%s" % name, "kind": "read", "entities": [name]})
        w = cfg["entities"][name]["write"]
        for op in write_ops.get(name, []):
            if w and w["method"] == op["method"] and w["path"] == re.sub(r"\{[^{}]+\}", "{id}", op["path"]): operations.append({"name": op["operation_id"] or "%s_%s" % (op["method"].lower(), name), "kind": "write", "entities": [name]})
    doc = {"entities": ents, "operations": operations, "pagination": {"styles": sorted({e["list"]["pagination"] for e in cfg["entities"].values()})}, "auth_requirements": {"scheme": cfg["auth"]}}
    if api["api_version"]: doc["system_version"] = api["api_version"]
    return doc

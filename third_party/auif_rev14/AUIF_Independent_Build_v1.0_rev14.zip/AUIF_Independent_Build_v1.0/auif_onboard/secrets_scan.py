"""Secret-material screen applied to EVERY artifact auif_onboard produces (config draft, pack draft, review records, validation report, files written by the CLI).
It is the backstop behind a design in which secrets are never read in the first place (examples, defaults, descriptions and x- extensions of an API description are never copied, a credential is only ever a `secretref:` NAME).
A finding names the PATH and the RULE; it never repeats the matched text, so the finding itself cannot leak."""
import math, re
from .errors import SecretLeak
SAFE_KEYS = frozenset({"credential_ref", "token_url", "auth_header", "auth_prefix", "token_auth_style", "secrets_in_descriptor", "contains_secrets"})
SECRET_KEYS = frozenset({"password", "passwd", "secret", "client_secret", "api_key", "apikey", "access_token", "refresh_token", "private_key", "bearer_token", "token", "authorization_value", "credential", "credentials"})
REFERENCE = re.compile(r"^secretref:[A-Za-z0-9._:-]{1,100}$")
RULES = (("private-key-block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")), ("bearer-token", re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{8,}")), ("basic-credentials", re.compile(r"\bBasic\s+[A-Za-z0-9+/=]{8,}")),
         ("provider-key", re.compile(r"\b(?:sk|pk|rk)[-_](?:live|test)?[-_]?[A-Za-z0-9]{16,}|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{20,}|xox[abp]-[A-Za-z0-9-]{10,}")), ("jwt", re.compile(r"eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{4,}")),
         ("url-userinfo", re.compile(r"://[^/\s:@]+:[^/\s@]+@")), ("secret-in-query", re.compile(r"[?&](?:api_?key|access_?token|token|secret|client_secret|password|key|sig|signature)=[^&\s]{4,}", re.I)),
         ("assignment", re.compile(r"(?:secret|password|passwd|token|api[_-]?key)\s*[:=]\s*\S{6,}", re.I)))
HEX = re.compile(r"^[0-9a-f]{32,128}$"); WORD = re.compile(r"^[a-z]{2,16}$"); DIGEST = re.compile(r"^(?:[0-9a-f]{1,16}|[0-9]{1,8})$")
B64ISH = re.compile(r"^[A-Za-z0-9+/=_-]{28,}$"); MAX_NODES = 200_000
def _identifier_like(s):
    """How this package names things: lower-case words joined by - or _, optionally with short hex or decimal segments (onb-synthetic-ledger-vendor-1a2b3c4d-draft). A credential is not made of words."""
    segs = re.split(r"[-_]", s); return len(segs) >= 3 and sum(bool(WORD.match(x)) for x in segs) >= 2 and all(WORD.match(x) or DIGEST.match(x) for x in segs)
def _entropy(s):
    n = len(s); return -sum(c / n * math.log2(c / n) for c in (s.count(ch) for ch in set(s)))
def _string_findings(s, extra):
    out = [name for name, rx in RULES if rx.search(s)]
    if B64ISH.match(s) and not HEX.match(s) and not _identifier_like(s) and any(c.isdigit() for c in s) and any(c.isalpha() for c in s) and _entropy(s) >= 4.2: out.append("high-entropy-token")
    if any(lit and lit in s for lit in extra): out.append("known-secret-literal")
    return out
def scan(obj, where="artifact", extra_literals=()):
    """Return a list of (path, rule). Walks keys and values; never returns matched text."""
    found, stack, seen = [], [(obj, where)], 0
    while stack:
        o, p = stack.pop(); seen += 1
        if seen > MAX_NODES: found.append((p, "too-large-to-scan")); break
        if isinstance(o, dict):
            for k, v in o.items():
                kp = "%s.%s" % (p, k if len(str(k)) < 60 else "<long key>")
                if isinstance(k, str):
                    for r in _string_findings(k, extra_literals): found.append((kp + "#key", r))
                    nk = k.lower().replace("-", "_")
                    if nk in SECRET_KEYS and nk not in SAFE_KEYS and isinstance(v, str) and v and not REFERENCE.match(v): found.append((kp, "secret-named-field"))
                stack.append((v, kp))
        elif isinstance(o, (list, tuple)): stack.extend((v, "%s[%d]" % (p, i)) for i, v in enumerate(o))
        elif isinstance(o, str): found += [(p, r) for r in _string_findings(o, extra_literals)]
    return sorted(set(found))
def assert_clean(obj, where="artifact", extra_literals=()):
    f = scan(obj, where, extra_literals)
    if f: raise SecretLeak("secret-like material found in %s: %s" % (where, "; ".join("%s (%s)" % x for x in f[:5])))
    return obj

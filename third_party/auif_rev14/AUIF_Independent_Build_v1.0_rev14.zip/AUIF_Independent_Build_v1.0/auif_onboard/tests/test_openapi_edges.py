"""Edge cases of the untrusted-input reader: limits at their exact boundary, reference decoding, schema merging, and what is deliberately not read."""
import json, unittest
from auif_onboard import openapi
from auif_onboard.errors import SpecRejected
from auif_onboard.tests.support import arr, get_list, mini, q
BASE = {"openapi": "3.0.0", "info": {"title": "t", "version": "1"}, "paths": {}}
def sch(components, node, **kw):
    doc = {"openapi": "3.0.0", "info": {}, "paths": {}, "components": {"schemas": components}}; return openapi.schema(doc, node, **kw)
class Limits(unittest.TestCase):
    def test_a_document_of_exactly_the_size_limit_is_read_and_one_byte_more_is_refused(self):
        raw = json.dumps(BASE).encode(); doc, h = openapi.load(raw + b" " * (openapi.MAX_BYTES - len(raw))); self.assertEqual(doc, BASE)
        with self.assertRaises(SpecRejected): openapi.load(raw + b" " * (openapi.MAX_BYTES - len(raw) + 1))
    def test_an_oversized_python_document_is_refused_too(self):
        with self.assertRaises(SpecRejected) as cm: openapi.load({"x": "a" * (openapi.MAX_BYTES + 1)})
        self.assertIn("larger", str(cm.exception))
    def test_non_json_input_is_refused_cleanly(self):
        for bad in (b"{nope", b"[1]", b"\xff\xfe", "NaN", b'{"a": NaN}', b'{"a": Infinity}', 5, None, [1]):
            with self.subTest(msg=repr(bad)[:20]), self.assertRaises(SpecRejected): openapi.load(bad)
    def test_a_value_that_is_not_plain_json_is_refused(self):
        with self.assertRaises(SpecRejected): openapi.load({"a": {1, 2}})
    def test_only_the_three_supported_dialects_are_read(self):
        for v in ("3.0", "3.0.3", "3.1.0", "3.1"): self.assertEqual(openapi.parse(dict(BASE, openapi=v))["dialect"], "openapi-" + v[:3])
        self.assertEqual(openapi.parse({"swagger": "2.0", "info": {}, "paths": {}})["dialect"], "swagger-2.0")
        for bad in ({"openapi": "3.2.0"}, {"openapi": "3.10"}, {"openapi": "4.0.0"}, {"openapi": "3"}, {"openapi": "3.0.x"}, {"openapi": 3.0}, {"swagger": "1.2"}, {"swagger": "2.1"}, {}):
            with self.subTest(msg=str(bad)), self.assertRaises(SpecRejected): openapi.parse(dict(BASE, **bad) if "openapi" in bad else dict({"info": {}, "paths": {}}, **bad))
    def test_enumerations_are_read_only_within_their_limits(self):
        ok = sch({}, {"type": "string", "enum": ["v%d" % i for i in range(200)]}); self.assertEqual(len(ok["enum"]), 200)
        self.assertIsNone(sch({}, {"type": "string", "enum": ["v%d" % i for i in range(201)]})["enum"]); self.assertIsNone(sch({}, {"type": "string", "enum": ["x" * 101]})["enum"]); self.assertEqual(sch({}, {"type": "string", "enum": ["x" * 100]})["enum"], ["x" * 100])
        self.assertIsNone(sch({}, {"type": "integer", "enum": [1, True]})["enum"]); self.assertIsNone(sch({}, {"type": "string", "enum": []})["enum"]); self.assertIsNone(sch({}, {"type": "number", "enum": [1.5]})["enum"]); self.assertEqual(sch({}, {"type": "integer", "enum": [0, 1, 2]})["enum"], [0, 1, 2])
    def test_limits_are_read_only_where_they_make_sense(self):
        self.assertIsNone(sch({}, {"type": "integer", "maxLength": 5})["max_length"]); self.assertEqual(sch({}, {"type": "string", "maxLength": 5})["max_length"], 5); self.assertIsNone(sch({}, {"type": "string", "maxLength": -1})["max_length"]); self.assertIsNone(sch({}, {"type": "string", "maxLength": True})["max_length"])
        s = sch({}, {"type": "string", "minimum": 3, "maximum": 9}); self.assertEqual((s["minimum"], s["maximum"]), (None, None)); s = sch({}, {"type": "integer", "minimum": 0, "maximum": 9}); self.assertEqual((s["minimum"], s["maximum"]), (0, 9))
        s = sch({}, {"type": "integer", "minimum": True, "maximum": "9"}); self.assertEqual((s["minimum"], s["maximum"]), (None, None)); s = sch({}, {"type": "number", "minimum": 0.5}); self.assertEqual(s["minimum"], 0.5)
    def test_a_schema_with_too_many_properties_is_not_read(self):
        s = sch({}, {"type": "object", "properties": {"p%d" % i: {"type": "string"} for i in range(openapi.MAX_PROPERTIES + 1)}}); self.assertEqual(s["properties"], {}); self.assertTrue([p for p in s["problems"] if "too many" in p])
        self.assertEqual(len(sch({}, {"type": "object", "properties": {"p%d" % i: {"type": "string"} for i in range(openapi.MAX_PROPERTIES)}})["properties"]), openapi.MAX_PROPERTIES)
    def test_a_property_name_that_cannot_be_represented_is_skipped_with_a_note(self):
        s = sch({}, {"type": "object", "properties": {"ok_name": {"type": "string"}, "bad name": {"type": "string"}, "1st": {"type": "string"}, "x" * 65: {"type": "string"}}}); self.assertEqual(sorted(s["properties"]), ["ok_name"]); self.assertEqual(len(s["problems"]), 3)
    def test_the_operation_limit_is_enforced(self):
        paths = {"/p%d" % i: {"get": {"responses": {}}} for i in range(openapi.MAX_OPERATIONS + 5)}; m = openapi.parse(dict(BASE, paths=paths)); self.assertEqual(len(m["operations"]), openapi.MAX_OPERATIONS); self.assertTrue([r for r in m["rejected"] if "more than" in r["reason"]])
        m = openapi.parse(dict(BASE, paths={"/p%d" % i: {"get": {"responses": {}}} for i in range(openapi.MAX_OPERATIONS)})); self.assertEqual((len(m["operations"]), m["rejected"]), (openapi.MAX_OPERATIONS, []))
    def test_paths_that_do_not_start_with_a_slash_or_are_overlong_are_rejected(self):
        m = openapi.parse(dict(BASE, paths={"nope": {"get": {"responses": {}}}, "/" + "x" * 300: {"get": {"responses": {}}}, "/ok": {"get": {"responses": {}}}})); self.assertEqual([o["path"] for o in m["operations"]], ["/ok"]); self.assertEqual(len(m["rejected"]), 2)
    def test_an_overlong_version_string_is_dropped(self):
        self.assertEqual(openapi.parse(dict(BASE, info={"title": "t", "version": "v" * 64}))["api_version"], "v" * 64); self.assertIsNone(openapi.parse(dict(BASE, info={"title": "t", "version": "v" * 65}))["api_version"])
class References(unittest.TestCase):
    def test_pointer_escapes_are_decoded_in_the_right_order(self):
        comps = {"a/b": {"type": "string"}, "m~n": {"type": "integer"}, "a~1b": {"type": "boolean"}}
        self.assertEqual(sch(comps, {"$ref": "#/components/schemas/a~1b"})["type"], "string"); self.assertEqual(sch(comps, {"$ref": "#/components/schemas/m~0n"})["type"], "integer"); self.assertEqual(sch(comps, {"$ref": "#/components/schemas/a~01b"})["type"], "boolean")
    def test_only_a_reference_starting_with_hash_slash_is_followed(self):
        for ref in ("#_components/schemas/Thing", "#", "#/", "#x", "http://x.invalid/s.json#/a", "other.json#/a", 5, None):
            with self.subTest(msg=str(ref)): s = sch({"Thing": {"type": "string"}}, {"$ref": ref}); self.assertEqual(s["type"], "unknown"); self.assertTrue(s["problems"])
    def test_cycles_and_deep_chains_are_reported_not_followed(self):
        comps = {"A": {"$ref": "#/components/schemas/B"}, "B": {"$ref": "#/components/schemas/A"}}; self.assertEqual(sch(comps, {"$ref": "#/components/schemas/A"})["problems"], ["circular reference"])
        chain = {"C%d" % i: {"$ref": "#/components/schemas/C%d" % (i + 1)} for i in range(20)}; chain["C20"] = {"type": "string"}; self.assertEqual(sch(chain, {"$ref": "#/components/schemas/C0"})["problems"], ["reference chain is too deep"])
        short = {"C%d" % i: {"$ref": "#/components/schemas/C%d" % (i + 1)} for i in range(openapi.MAX_REF_DEPTH - 2)}; short["C%d" % (openapi.MAX_REF_DEPTH - 2)] = {"type": "string"}; self.assertEqual(sch(short, {"$ref": "#/components/schemas/C0"})["type"], "string")
    def test_a_self_referential_object_is_cut_off_without_recursion_errors(self):
        s = sch({"Node": {"type": "object", "properties": {"child": {"$ref": "#/components/schemas/Node"}}}}, {"$ref": "#/components/schemas/Node"}); self.assertEqual(s["ref_name"], "Node"); self.assertIn("circular reference", json.dumps(s))
    def test_schema_nesting_is_bounded(self):
        node = {"type": "string"}
        for _ in range(openapi.MAX_SCHEMA_DEPTH + 3): node = {"type": "object", "properties": {"n": node}}
        self.assertIn("schema nesting is too deep", json.dumps(sch({}, node)))
class Merging(unittest.TestCase):
    BASEC = {"Base": {"type": "object", "properties": {"id": {"type": "string"}}, "required": ["id"]}, "Enumed": {"type": "string", "enum": ["a", "b"], "format": "tag", "maxLength": 9}, "Numbered": {"type": "integer", "minimum": 1, "maximum": 5}, "Listed": {"type": "array", "items": {"type": "string"}}, "Choice": {"oneOf": [{"type": "string"}, {"type": "integer"}]}}
    def test_allof_merges_properties_and_required_lists_and_the_type(self):
        s = sch(self.BASEC, {"allOf": [{"$ref": "#/components/schemas/Base"}, {"properties": {"x": {"type": "string"}}, "required": ["x"]}]}); self.assertEqual(sorted(s["properties"]), ["id", "x"]); self.assertEqual(s["required"], ["id", "x"]); self.assertEqual(s["type"], "object")
    def test_allof_inherits_enum_format_limits_and_items(self):
        s = sch(self.BASEC, {"allOf": [{"$ref": "#/components/schemas/Enumed"}]}); self.assertEqual((s["type"], s["enum"], s["format"], s["max_length"]), ("string", ["a", "b"], "tag", 9))
        s = sch(self.BASEC, {"allOf": [{"$ref": "#/components/schemas/Numbered"}]}); self.assertEqual((s["minimum"], s["maximum"]), (1, 5)); s = sch(self.BASEC, {"allOf": [{"$ref": "#/components/schemas/Listed"}]}); self.assertEqual((s["type"], s["items"]["type"]), ("array", "string"))
    def test_allof_keeps_the_outer_value_when_it_has_one(self):
        s = sch(self.BASEC, {"allOf": [{"$ref": "#/components/schemas/Enumed"}], "enum": ["z"], "format": "other"}); self.assertEqual((s["enum"], s["format"]), (["z"], "other"))
    def test_oneof_anyof_is_flagged_not_interpreted_even_inside_allof(self):
        for node in ({"$ref": "#/components/schemas/Choice"}, {"anyOf": [{"type": "string"}]}, {"allOf": [{"$ref": "#/components/schemas/Choice"}]}):
            with self.subTest(msg=str(node)[:30]): s = sch(self.BASEC, node); self.assertTrue(s["variants"]); self.assertTrue([p for p in s["problems"] if "oneOf" in p])
        self.assertFalse(sch(self.BASEC, {"type": "string", "oneOf": []})["variants"])
    def test_a_type_list_gives_the_non_null_type_and_nullability(self):
        s = sch({}, {"type": ["null", "string"]}); self.assertEqual((s["type"], s["nullable"]), ("string", True)); s = sch({}, {"type": ["string", "null"]}); self.assertEqual((s["type"], s["nullable"]), ("string", True)); s = sch({}, {"type": ["string"]}); self.assertEqual((s["type"], s["nullable"]), ("string", False))
        s = sch({}, {"type": "string", "nullable": True}); self.assertTrue(s["nullable"]); self.assertFalse(sch({}, {"type": "string", "nullable": "yes"})["nullable"])
    def test_an_object_without_a_type_is_an_object_and_an_unknown_type_stays_unknown(self):
        self.assertEqual(sch({}, {"properties": {"a": {"type": "string"}}})["type"], "object"); self.assertEqual(sch({}, {"type": "file"})["type"], "unknown"); self.assertEqual(sch({}, {"items": {"type": "string"}})["type"], "array"); self.assertEqual(sch({}, 5)["type"], "unknown")
    def test_read_only_and_write_only_are_true_only_when_true(self):
        for key, field in (("readOnly", "read_only"), ("writeOnly", "write_only")):
            self.assertTrue(sch({}, {"type": "string", key: True})[field]); self.assertFalse(sch({}, {"type": "string", key: False})[field]); self.assertFalse(sch({}, {"type": "string", key: "true"})[field]); self.assertFalse(sch({}, {"type": "string"})[field])
    def test_a_format_must_look_like_a_format(self):
        self.assertEqual(sch({}, {"type": "string", "format": "date-time"})["format"], "date-time"); self.assertIsNone(sch({}, {"type": "string", "format": "has space"})["format"]); self.assertIsNone(sch({}, {"type": "string", "format": "x" * 41})["format"]); self.assertIsNone(sch({}, {"type": "string", "format": 5})["format"])
class ServersAndSecurity(unittest.TestCase):
    def servers(self, *servers, **kw): return openapi.parse(dict(BASE, servers=list(servers), **kw))["servers"]
    def test_a_variable_default_is_substituted_only_when_it_is_a_plain_token(self):
        ok = self.servers({"url": "https://{h}.x.invalid/v1", "variables": {"h": {"default": "demo-1"}}})[0]; self.assertEqual((ok["url"], ok["unresolved_variables"]), ("https://demo-1.x.invalid/v1", False))
        for bad in ("a/b", "a b", "x" * 64, "", 5, None):
            with self.subTest(msg=str(bad)): s = self.servers({"url": "https://{h}.x.invalid/v1", "variables": {"h": {"default": bad}}})[0]; self.assertTrue(s["unresolved_variables"]); self.assertIn("{h}", s["url"])
    def test_a_variable_with_no_declaration_is_unresolved(self): self.assertTrue(self.servers({"url": "https://{h}.x.invalid"})[0]["unresolved_variables"]); self.assertTrue(self.servers({"url": "https://{h}.x.invalid", "variables": {"h": 5}})[0]["unresolved_variables"])
    def test_a_trailing_slash_is_dropped_and_a_relative_url_is_marked(self):
        s = self.servers({"url": "https://x.invalid/v1/"})[0]; self.assertEqual((s["url"], s["relative"]), ("https://x.invalid/v1", False)); s = self.servers({"url": "/api/v1"})[0]; self.assertTrue(s["relative"])
    def test_server_urls_with_credentials_queries_fragments_or_excess_length_are_dropped(self):
        m = openapi.parse(dict(BASE, servers=[{"url": "https://u:p@x.invalid"}, {"url": "https://x.invalid/?a=1"}, {"url": "https://x.invalid/#f"}, {"url": "https://x.invalid/" + "a" * 2050}, {"url": 5}, "junk", {"url": "https://ok.invalid"}])); self.assertEqual([s["url"] for s in m["servers"]], ["https://ok.invalid"]); self.assertEqual(len(m["rejected"]), 3)
    def test_swagger_two_builds_urls_from_host_base_path_and_schemes_https_first(self):
        m = openapi.parse({"swagger": "2.0", "info": {}, "paths": {}, "host": "h.invalid", "basePath": "/v1/", "schemes": ["http", "https"]}); self.assertEqual([s["url"] for s in m["servers"]], ["https://h.invalid/v1", "http://h.invalid/v1"])
        self.assertEqual(openapi.parse({"swagger": "2.0", "info": {}, "paths": {}, "host": "h.invalid"})["servers"][0]["url"], "https://h.invalid"); self.assertEqual(openapi.parse({"swagger": "2.0", "info": {}, "paths": {}})["servers"], [])
    def schemes(self, **s): return openapi.parse(dict(BASE, components={"securitySchemes": s}))["security_schemes"]
    def test_no_declared_schemes_means_none_not_a_made_up_one(self): self.assertEqual(openapi.parse(BASE)["security_schemes"], {}); self.assertEqual(openapi.parse(dict(BASE, components={"securitySchemes": 5}))["security_schemes"], {})
    def test_an_api_key_is_a_header_scheme_only_when_in_a_header_with_a_plain_name(self):
        s = self.schemes(h={"type": "apiKey", "in": "header", "name": "X-Api-Key"}, q={"type": "apiKey", "in": "query", "name": "api_key"}, bad={"type": "apiKey", "in": "header", "name": "bad name!"}, num={"type": "apiKey", "in": "header", "name": 5})
        self.assertEqual((s["h"]["kind"], s["h"]["header"]), ("API_KEY_HEADER", "X-Api-Key")); self.assertEqual((s["q"]["kind"], s["q"]["header"]), ("API_KEY_OTHER", None)); self.assertIsNone(s["bad"]["header"]); self.assertIsNone(s["num"]["header"])
    def test_http_schemes_are_case_insensitive(self):
        s = self.schemes(a={"type": "http", "scheme": "Bearer"}, b={"type": "http", "scheme": "BASIC"}, c={"type": "http", "scheme": "digest"}, d={"type": "openIdConnect"}, e={"type": "mutualTLS"}); self.assertEqual([s[k]["kind"] for k in "abcde"], ["HTTP_BEARER", "HTTP_BASIC", "UNKNOWN", "OIDC", "UNKNOWN"])
    def test_oauth2_client_credentials_gives_a_token_url_and_a_bounded_scope_list(self):
        scopes = {"s%d" % i: "d" for i in range(60)}; scopes["bad scope!"] = "d"; s = self.schemes(o={"type": "oauth2", "flows": {"clientCredentials": {"tokenUrl": "https://t.invalid/token", "scopes": scopes}}})["o"]; self.assertEqual((s["kind"], s["token_url"], len(s["scopes"])), ("OAUTH2_CC", "https://t.invalid/token", 50)); self.assertNotIn("bad scope!", s["scopes"])
        s = self.schemes(o={"type": "oauth2", "flows": {"clientCredentials": {"tokenUrl": "https://u:p@t.invalid/t", "scopes": {}}}})["o"]; self.assertIsNone(s["token_url"]); s = self.schemes(o={"type": "oauth2", "flows": {"clientCredentials": {"tokenUrl": "https://t.invalid/t?a=1", "scopes": {}}}})["o"]; self.assertIsNone(s["token_url"])
        s = self.schemes(o={"type": "oauth2", "flows": {"authorizationCode": {"scopes": {}}}})["o"]; self.assertEqual(s["kind"], "OAUTH2_OTHER"); s = self.schemes(o={"type": "oauth2", "flows": {}})["o"]; self.assertEqual(s["kind"], "UNKNOWN")
        s = openapi.parse({"swagger": "2.0", "info": {}, "paths": {}, "securityDefinitions": {"o": {"type": "oauth2", "flow": "application", "tokenUrl": "https://t.invalid/t", "scopes": {"a": "b"}}, "p": {"type": "oauth2", "flow": "implicit"}}})["security_schemes"]; self.assertEqual((s["o"]["kind"], s["p"]["kind"]), ("OAUTH2_CC", "OAUTH2_OTHER"))
class Operations(unittest.TestCase):
    def op(self, path_item, schemas=None, **kw): return openapi.parse(mini({"/things": path_item}, schemas or {}, **kw))["operations"][0]
    def test_query_parameters_record_whether_they_are_required(self):
        o = self.op(get_list({"type": "object"}, [q("a"), dict(q("b"), required=True), dict(q("c"), required="yes")])); self.assertEqual({k: v["required"] for k, v in o["query_params"].items()}, {"a": False, "b": True, "c": False})
    def test_a_vendor_json_media_type_and_any_case_are_read_but_other_types_are_not(self):
        sc = {"type": "object", "properties": {"x": {"type": "string"}}}
        for mt, expect in (("application/json", True), ("Application/JSON", True), ("application/vnd.api+json", True), ("APPLICATION/HAL+JSON", True), ("text/json", False), ("application/xml", False), ("application/jsonx", False)):
            with self.subTest(msg=mt): o = self.op({"get": {"responses": {"200": {"description": "ok", "content": {mt: {"schema": sc}}}}}}); self.assertEqual(o["success"]["schema"] is not None, expect)
    def test_the_lowest_two_hundred_response_with_a_schema_is_the_success_response(self):
        sc = lambda n: {"description": "ok", "content": {"application/json": {"schema": {"type": "object", "properties": {n: {"type": "string"}}}}}}
        o = self.op({"get": {"responses": {"201": sc("created"), "200": {"description": "no body"}, "default": sc("dflt"), "404": sc("nf")}}}); self.assertEqual((o["success"]["status"], sorted(o["success"]["schema"]["properties"])), ("201", ["created"]))
        o = self.op({"get": {"responses": {"200": {"description": "no body"}, "204": {"description": "none"}}}}); self.assertEqual((o["success"]["status"], o["success"]["schema"]), ("200", None)); o = self.op({"get": {"responses": {"404": sc("x")}}}); self.assertEqual(o["success"], {"status": None, "schema": None, "headers": []})
        o = self.op({"get": {"responses": {"2XX": sc("range"), "300": sc("redir")}}}); self.assertEqual(o["success"]["status"], "2XX")
    def test_path_parameters_come_from_the_template_not_from_declarations(self):
        o = openapi.parse(mini({"/things/{id}/parts/{part}": {"get": {"parameters": [{"name": "decoy", "in": "path", "required": True, "schema": {"type": "string"}}], "responses": {}}}}))["operations"][0]; self.assertEqual(o["path_params"], ["id", "part"])
    def test_operation_ids_must_look_like_identifiers(self):
        for oid, expect in (("listThings", "listThings"), ("a.b-c_d", "a.b-c_d"), ("1bad", None), ("has space", None), ("x" * 65, None), (5, None)):
            with self.subTest(msg=str(oid)): self.assertEqual(self.op({"get": {"operationId": oid, "responses": {}}})["operation_id"], expect)
    def test_header_parameters_and_declared_operation_security_are_read(self):
        o = self.op({"get": {"parameters": [{"name": "X-B", "in": "header", "schema": {"type": "string"}}, {"name": "X-A", "in": "header", "schema": {"type": "string"}}, {"name": "sid", "in": "cookie", "schema": {"type": "string"}}], "security": [{"k": []}, {}], "responses": {}}}); self.assertEqual(o["header_params"], ["X-A", "X-B"]); self.assertEqual(o["security"], [["k"], []])
        self.assertIsNone(self.op({"get": {"responses": {}}})["security"]); self.assertEqual(self.op({"get": {"security": [], "responses": {}}})["security"], [])
    def test_a_path_level_parameter_is_merged_and_the_operation_overrides_it(self):
        o = self.op({"parameters": [dict(q("limit"), required=True), q("shared")], "get": {"parameters": [q("limit")], "responses": {}}}); self.assertEqual({k: v["required"] for k, v in o["query_params"].items()}, {"limit": False, "shared": False})
    def test_swagger_two_reads_its_body_parameter_as_the_request_schema(self):
        m = openapi.parse({"swagger": "2.0", "info": {}, "paths": {"/t": {"post": {"parameters": [{"name": "b", "in": "body", "schema": {"type": "object", "properties": {"x": {"type": "string"}}}}], "responses": {}}}}}); self.assertEqual(sorted(m["operations"][0]["request"]["properties"]), ["x"])
    def test_an_unreadable_path_item_is_listed_not_fatal(self):
        m = openapi.parse(dict(BASE, paths={"/a": {"$ref": "#/nowhere"}, "/b": 5, "/c": {"get": {"responses": {}}}})); self.assertEqual([o["path"] for o in m["operations"]], ["/c"]); self.assertEqual(len(m["rejected"]), 2)
if __name__ == "__main__": unittest.main()

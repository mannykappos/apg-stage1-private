"""rev13 (finding REV12-AUD-01): a configuration may not remove the write endpoint of an entity for which an outbound mapping (ENTITY, FIELD or ACTION) is already approved. The same invariant holds in the other order (no outbound mapping can be approved for an entity without a write endpoint), so the pair of approved artefacts can never disagree about whether an entity is writable, whatever order the human decisions are taken in.
Synthetic fixture only (the CRM fixture: Account is writable, Property is not)."""
import unittest
from auif_onboard.errors import ApprovalRefused
from auif_onboard.review import ReviewSession
from auif_onboard.tests.support import approval
from auif_onboard.tests.test_review import decide, session
CREF = "secretref:crm.api-key"; NO_WRITE = {"entities.Account.write": None}
def cfg(s, cd, **ov): return s.approve_config(approval(cd["draft_hash"], credential_ref=CREF, overrides=ov))
class TestWriteRemovedAfterOutboundApproval(unittest.TestCase):
    def refused(self, s, cd):
        with self.assertRaises(ApprovalRefused) as cm: cfg(s, cd, **NO_WRITE)
        self.assertIn("unwritable", str(cm.exception)); self.assertIn("Account", str(cm.exception)); self.assertIsNone(s.config_decision)
        return cm.exception
    def test_an_approved_entity_outbound_blocks_removal_of_the_write_endpoint(self):
        s, cd, _ = session(); decide(s, "ENTITY", "Account", outbound="ENABLE"); self.refused(s, cd)
    def test_an_approved_field_outbound_alone_blocks_it(self):
        s, cd, _ = session(); decide(s, "ENTITY", "Account"); decide(s, "FIELD", "Account.balance_cents", route="HUMAN", outbound="PROPOSED"); self.refused(s, cd)
    def test_an_approved_action_alone_blocks_it(self):
        s, cd, _ = session(); decide(s, "ACTION", None, canonical_action="crm.update_party"); self.refused(s, cd)
    def test_the_refusal_changes_nothing_and_the_reviewer_can_resolve_it_explicitly(self):
        s, cd, _ = session(); decide(s, "ENTITY", "Account", outbound="ENABLE"); before = (dict(s.approved), len(s.ledger)); self.refused(s, cd); self.assertEqual((dict(s.approved), len(s.ledger)), before)
        out = cfg(s, cd); self.assertTrue(out["config"]["entities"]["Account"]["write"])       # keeping the endpoint is fine
        self.assertTrue(any(m["outbound"]["supported"] for m in s.assemble_pack()["pack"]["mappings"]))
    def test_the_conflict_is_resolved_by_the_reviewer_not_by_silently_stripping_the_mapping(self):
        s, cd, _ = session(); decide(s, "ENTITY", "Account", outbound="ENABLE"); self.refused(s, cd)
        m = next(m for m in s.approved.values() if m["kind"] == "ENTITY"); self.assertTrue(m["outbound"]["supported"])
class TestOtherOrder(unittest.TestCase):
    def removed(self):
        s, cd, _ = session(); out = cfg(s, cd, **NO_WRITE); self.assertIsNone(out["config"]["entities"]["Account"]["write"]); return s
    def test_with_the_write_endpoint_already_removed_no_outbound_mapping_can_be_approved(self):
        for kind, src, kw in (("ENTITY", "Account", {"outbound": "ENABLE"}), ("ACTION", None, {"canonical_action": "crm.update_party"})):
            with self.subTest(kind):
                s = self.removed()
                with self.assertRaises(ApprovalRefused): decide(s, kind, src, **kw)
        s = self.removed(); decide(s, "ENTITY", "Account")
        with self.assertRaises(ApprovalRefused): decide(s, "FIELD", "Account.balance_cents", route="HUMAN", outbound="PROPOSED")
    def test_both_orders_end_with_a_pack_and_a_configuration_that_agree(self):
        s = self.removed(); decide(s, "ENTITY", "Account"); decide(s, "FIELD", "Account.profile.name")        # inbound only
        ms = s.assemble_pack()["pack"]["mappings"]; self.assertFalse(any(m["outbound"]["supported"] for m in ms)); self.assertIsNone(s.config_decision["config"]["entities"]["Account"]["write"])
class TestInboundOnlyApprovalsDoNotBlock(unittest.TestCase):
    def test_removing_the_write_endpoint_is_allowed_when_nothing_outbound_was_approved(self):
        s, cd, _ = session(); decide(s, "ENTITY", "Account"); decide(s, "FIELD", "Account.profile.name"); out = cfg(s, cd, **NO_WRITE); self.assertIsNone(out["config"]["entities"]["Account"]["write"])
    def test_an_outbound_mapping_on_another_entity_is_unaffected_and_an_unrelated_approved_entity_is_not_reported(self):
        s, cd, _ = session(); decide(s, "ENTITY", "Property"); decide(s, "ENTITY", "Account"); out = cfg(s, cd); self.assertEqual(sorted(out["config"]["entities"]), ["Account", "Property"])
    def test_approving_with_no_mappings_at_all_is_unaffected(self):
        s, cd, _ = session(); out = cfg(s, cd, **NO_WRITE); self.assertIsNone(out["config"]["entities"]["Account"]["write"])
    def test_a_rejected_outbound_decision_does_not_count_as_approved(self):
        s, cd, _ = session(); decide(s, "ENTITY", "Account", decision="REJECT"); out = cfg(s, cd, **NO_WRITE); self.assertIsNone(out["config"]["entities"]["Account"]["write"])
if __name__ == "__main__": unittest.main()

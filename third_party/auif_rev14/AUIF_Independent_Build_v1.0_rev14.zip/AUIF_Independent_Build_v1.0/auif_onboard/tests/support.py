"""Shared test helpers (TEST-ONLY)."""
import copy, json, os
from auif_onboard import config_gen, openapi, pack_draft
from auif_onboard.review import HumanApproval
from synthetic.packs import MODEL_DEF
FIX = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures"); NAMES = ("crm_cursor_apikey", "ledger_offset_oauth2", "helpdesk_link_swagger2"); CANARY = "CANARY-s3cr3t-7731"
REVIEWER = "Rowan Test-Reviewer"; STATEMENT = "I reviewed exactly this item and approve it for the synthetic test."; WHEN = "2026-10-07T01:00:00Z"
def spec_bytes(name):
    with open(os.path.join(FIX, name + ".openapi.json"), "rb") as f: return f.read()
def spec_doc(name): return json.loads(spec_bytes(name))
_CACHE = {}
def drafts(name):
    """(config_draft, pack_draft) of a fixture, deep-copied from a cache (generation is deterministic, so this is only a speed-up)."""
    if name not in _CACHE:
        doc, h = openapi.load(spec_bytes(name)); cd = config_gen.draft_config(openapi.parse(doc), h); _CACHE[name] = (cd, pack_draft.draft_pack(cd, MODEL_DEF))
    return copy.deepcopy(_CACHE[name])
def drafts_for_doc(doc):
    d, h = openapi.load(doc); cd = config_gen.draft_config(openapi.parse(d), h); return cd, pack_draft.draft_pack(cd, MODEL_DEF)
def approval(subject_hash, decision="APPROVE", reviewer=REVIEWER, statement=STATEMENT, when=WHEN, **params): return HumanApproval(reviewer=reviewer, statement=statement, subject_hash=subject_hash, decided_at=when, decision=decision, parameters=params)
def mini(paths, schemas=None, security=None, schemes=None, servers=None, openapi_version="3.0.3"):
    """A small inline OpenAPI document for edge-case tests."""
    d = {"openapi": openapi_version, "info": {"title": "Mini", "version": "1"}, "servers": servers if servers is not None else [{"url": "https://mini.synthetic-vendor.invalid/v1"}], "paths": paths, "components": {"schemas": schemas or {}}}
    if schemes: d["components"]["securitySchemes"] = schemes
    if security is not None: d["security"] = security
    return d
def arr(ref): return {"type": "array", "items": {"$ref": "#/components/schemas/" + ref}}
def get_list(schema, params=None, headers=None):
    r = {"description": "ok", "content": {"application/json": {"schema": schema}}}
    if headers: r["headers"] = headers
    return {"get": {"parameters": params or [], "responses": {"200": r}}}
def q(name, **schema): return {"name": name, "in": "query", "schema": dict({"type": "string"}, **schema)}
THING = {"Thing": {"type": "object", "properties": {"id": {"type": "string"}, "title": {"type": "string"}, "state": {"type": "string", "enum": ["open", "closed"]}}}}

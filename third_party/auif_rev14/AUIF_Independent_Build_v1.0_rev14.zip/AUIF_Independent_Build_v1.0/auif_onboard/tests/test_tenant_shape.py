"""rev12: APIs whose lists are WRAPPED with a warnings array and a page-count object, that are scoped to a tenant by a required header, and whose only declared OAuth2 flow is not client credentials.
Everything here is synthetic (no real system is named or contacted); the shapes are those a real accounting API presents, which the first real-system proof showed the rev11 generator could not draft."""
import copy, json, unittest
from auif.util import sha
from auif_onboard import config_gen, openapi, validate
from auif_onboard.errors import ApprovalRefused
from auif_onboard.review import ReviewSession
from auif_onboard.rest_adapter import to_rest_config
from auif_onboard.tests.support import MODEL_DEF, approval, drafts_for_doc, get_list
from auif_onboard.tests.vendors import CANARY, Vendor
from auif_ext.connectors.rest import RestConnector
from auif_ext.tests.loopback import jresp
TENANT = "11111111-2222-3333-4444-555555555555"
def prop(t, **kw): return dict({"type": t}, **kw)
THING = {"type": "object", "properties": {"ThingID": prop("string"), "Title": prop("string", maxLength=50), "Kind": prop("string", enum=["a", "b"])}}
PAGINATION = {"type": "object", "properties": {"page": prop("integer"), "pageSize": prop("integer"), "pageCount": prop("integer"), "itemCount": prop("integer")}}
def wrapped(name="Things", extra=None, item="Thing", pagination=True):
    props = {name: {"type": "array", "items": {"$ref": "#/components/schemas/" + item}}, "Warnings": {"type": "array", "items": {"$ref": "#/components/schemas/Warning"}}}
    if pagination: props["pagination"] = {"$ref": "#/components/schemas/Pagination"}
    props.update(extra or {}); return {"type": "object", "properties": props}
def hdr(name="X-Tenant-Id", required=True): return {"name": name, "in": "header", "required": required, "schema": prop("string")}
def lst(schema, params=(), headers=None): return get_list(schema, list(params), headers)
def doc(paths, schemes=None, security=None, schemas=None):
    s = {"Thing": THING, "Pagination": PAGINATION, "Warning": {"type": "object", "properties": {"Message": prop("string")}}}; s.update(schemas or {})
    d = {"openapi": "3.0.3", "info": {"title": "Tenant Ledger", "version": "1"}, "servers": [{"url": "https://tenant.synthetic-vendor.invalid/api"}], "paths": paths, "components": {"schemas": s, "securitySchemes": schemes or {"Key": {"type": "apiKey", "in": "header", "name": "X-Api-Key"}}}}
    d["security"] = security if security is not None else [{"Key": []}]; return d
PAGED = lambda **kw: lst(wrapped(**kw), [{"name": "page", "in": "query", "schema": prop("integer")}, {"name": "pageSize", "in": "query", "schema": prop("integer", maximum=25)}, hdr()])
def draft(d): dd, h = openapi.load(d); return config_gen.draft_config(openapi.parse(dd), h)
def und(d): return {u["field"]: u for u in d["undetermined"]}
class TestWrappedLists(unittest.TestCase):
    def test_a_warnings_array_beside_the_records_does_not_make_the_record_list_undecidable(self):
        d = draft(doc({"/Things": PAGED()})); e = d["config"]["entities"]["Thing"]["list"]
        self.assertEqual((e["items_path"], e["pagination"], e["page_param"], e["page_size_param"], e["total_pages_path"], d["config"]["max_page_size"]), (["Things"], "page", "page", "pageSize", ["pagination", "pageCount"], 25))
        a = {x["field"]: x for x in d["assumed_defaults"]}["entities.Thing.list.items_path"]; self.assertEqual(a["value"], ["Things"]); self.assertIn("Warnings", a["reason"]); self.assertIn("envelope", a["reason"])
        self.assertNotIn("entities", und(d)); self.assertNotIn("entities.Thing.list.pagination", und(d))
    def test_every_known_envelope_name_is_set_aside_whatever_its_case(self):
        for env in ("Warnings", "errors", "MESSAGES", "ValidationErrors", "validation_warnings", "Links", "problems", "meta"):
            with self.subTest(env):
                s = {"type": "object", "properties": {"Records": {"type": "array", "items": {"$ref": "#/components/schemas/Thing"}}, env: {"type": "array", "items": {"$ref": "#/components/schemas/Warning"}}}}                  # the path does NOT name the record array: only the envelope rule can decide
                d = draft(doc({"/Things": lst(s, [hdr()])})); self.assertEqual(d["config"]["entities"]["Thing"]["list"]["items_path"], ["Records"])
    def test_with_two_real_record_arrays_the_one_named_like_the_path_is_used_else_nothing_is_guessed(self):
        two = lambda a, b: {"type": "object", "properties": {a: {"type": "array", "items": {"$ref": "#/components/schemas/Thing"}}, b: {"type": "array", "items": {"$ref": "#/components/schemas/Other"}}}}
        S = {"Other": {"type": "object", "properties": {"OtherID": prop("string")}}}
        d = draft(doc({"/Things": lst(two("Things", "Extras"), [hdr()])}, schemas=S)); self.assertEqual(d["config"]["entities"]["Thing"]["list"]["items_path"], ["Things"]); self.assertIn("named like the path", {x["field"]: x for x in d["assumed_defaults"]}["entities.Thing.list.items_path"]["reason"])
        d = draft(doc({"/v1/Things": lst(two("Things", "Extras"), [hdr()])}, schemas=S)); self.assertEqual(d["config"]["entities"]["Thing"]["list"]["items_path"], ["Things"])                   # the LAST path segment names the array
        d = draft(doc({"/Things": lst(two("Alpha", "Beta"), [hdr()])}, schemas=S)); self.assertEqual(d["config"]["entities"], {}); u = [x for x in d["undetermined"] if x["field"] == "entities" and x["candidates"]][0]; self.assertFalse(u["blocking"]); self.assertEqual(sorted(u["candidates"]), ["Alpha", "Beta"])
        d = draft(doc({"/Things": lst(two("Things", "things"), [hdr()])}, schemas=S)); self.assertNotIn("Thing", d["config"]["entities"])                 # two arrays that both match: still not decidable
    def test_a_response_whose_only_arrays_are_envelopes_has_no_record_list(self):
        s = {"type": "object", "properties": {"Warnings": {"type": "array", "items": {"$ref": "#/components/schemas/Warning"}}, "Errors": {"type": "array", "items": {"$ref": "#/components/schemas/Warning"}}}}
        d = draft(doc({"/Things": lst(s, [hdr()])})); self.assertEqual(d["config"]["entities"], {}); self.assertIn("entities", und(d))
    def test_a_single_array_is_still_a_determined_setting_not_an_assumption(self):
        d = draft(doc({"/Things": lst({"type": "object", "properties": {"Things": {"type": "array", "items": {"$ref": "#/components/schemas/Thing"}}}}, [hdr()])})); self.assertIn("entities.Thing.list.items_path", {x["field"] for x in d["determined"]}); self.assertNotIn("entities.Thing.list.items_path", {x["field"] for x in d["assumed_defaults"]})
    def test_without_a_page_count_in_the_response_description_the_page_walk_is_assumed_to_end_on_an_empty_page(self):
        d = draft(doc({"/Things": PAGED(pagination=False)})); e = d["config"]["entities"]["Thing"]["list"]; self.assertEqual((e["pagination"], e["total_pages_path"]), ("page", None)); self.assertIn("entities.Thing.list.total_pages_path", {x["field"] for x in d["assumed_defaults"]})
class TestSameNameCollisions(unittest.TestCase):
    def test_the_path_names_the_entity_in_the_singular_the_plural_or_the_irregular_plural(self):
        for name, plural in (("Thing", "things"), ("Thing", "thing"), ("Box", "boxes"), ("Category", "categories"), ("Category", "category")):
            with self.subTest(plural):
                S = {name: {"type": "object", "properties": {name + "ID": prop("string")}}}; d = draft(doc({"/" + plural: lst(wrapped(plural.title(), item=name, pagination=False), [hdr()]), "/" + plural + "/archived": lst(wrapped("Archived", item=name, pagination=False), [hdr()])}, schemas=S))
                self.assertEqual(d["config"]["entities"][name]["list"]["path"], "/" + plural)
    def test_a_path_that_only_resembles_the_entity_does_not_win(self):
        S = {"Box": {"type": "object", "properties": {"BoxID": prop("string")}}}; d = draft(doc({"/boxz": lst(wrapped("Boxz", item="Box", pagination=False), [hdr()]), "/boxx/archived": lst(wrapped("A", item="Box", pagination=False), [hdr()])}, schemas=S)); self.assertNotIn("Box", d["config"]["entities"])
class TestUnpagedAndKeyless(unittest.TestCase):
    def test_an_endpoint_with_no_paging_signal_stays_blocking_and_names_single_page_as_the_candidate_a_human_may_choose(self):
        d = draft(doc({"/Things": lst(wrapped(pagination=False), [hdr()])})); u = und(d)["entities.Thing.list.pagination"]; self.assertEqual((u["blocking"], u["candidates"]), (True, ["single_page"]))
    def test_the_human_choice_single_page_ends_the_walk_after_one_request(self):
        d = doc({"/Things": lst(wrapped(pagination=False), [hdr()])}); cd, pd = drafts_for_doc(d); s = ReviewSession(cd, pd, MODEL_DEF)
        out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key", overrides={"tenant_id": TENANT, "entities.Thing.list.pagination": "single_page"})); e = out["config"]["entities"]["Thing"]["list"]; self.assertEqual((e["pagination"], e["next_cursor_path"]), ("cursor", ["__no_next_cursor__"]))
    def test_a_record_schema_with_no_identifier_is_reported_not_removed(self):
        S = {"Setting": {"type": "object", "properties": {"Name": prop("string"), "Value": prop("string")}}}
        d = draft(doc({"/Settings": lst(wrapped("Settings", item="Setting"), [{"name": "page", "in": "query", "schema": prop("integer")}, hdr()]), "/Things": PAGED()}, schemas=S)); self.assertIn("Setting", d["config"]["entities"]); u = und(d)["entities.Setting"]; self.assertFalse(u["blocking"]); self.assertIn("identifier", u["reason"]); self.assertNotIn("entities.Thing", und(d))
class TestTenantHeader(unittest.TestCase):
    def test_a_header_required_by_every_used_operation_is_the_tenant_header_and_its_value_is_left_to_a_human(self):
        d = draft(doc({"/Things": PAGED()})); c = d["config"]; self.assertEqual((c["tenant_header"], c["tenant_id"]), ("X-Tenant-Id", None)); self.assertEqual(sorted(x["field"] for x in d["determined"] if x["field"] == "tenant_header"), ["tenant_header"])
        u = und(d)["tenant_id"]; self.assertTrue(u["blocking"]); self.assertIn("not a credential", u["reason"]); self.assertEqual(c["credential_ref"], None)
    def test_the_name_alone_decides_what_looks_like_a_tenant_header(self):
        for name, expect in (("xero-tenant-id", True), ("X-Tenant-ID", True), ("TenantId", True), ("Tenant", True), ("X-Organization-Id", True), ("Organisation-ID", True), ("X-Request-Id", False), ("X-Account", False), ("X-Region", False), ("tenants", False)):
            with self.subTest(name):
                d = draft(doc({"/Things": lst(wrapped(), [{"name": "page", "in": "query", "schema": prop("integer")}, hdr(name)])})); self.assertEqual(d["config"]["tenant_header"], name if expect else None)
    def test_a_required_query_parameter_is_not_a_header_whatever_its_name(self):
        d = draft(doc({"/Things": lst(wrapped(), [{"name": "page", "in": "query", "schema": prop("integer")}, {"name": "tenantId", "in": "query", "required": True, "schema": prop("string")}])})); self.assertIsNone(d["config"]["tenant_header"]); self.assertNotIn("tenant_id", und(d)); self.assertNotIn("required_headers", und(d))
    def test_an_optional_tenant_header_is_not_drafted(self):
        d = draft(doc({"/Things": lst(wrapped(), [{"name": "page", "in": "query", "schema": prop("integer")}, hdr(required=False)])})); self.assertIsNone(d["config"]["tenant_header"]); self.assertNotIn("tenant_id", und(d))
    def test_a_tenant_header_required_by_only_some_operations_is_blocking_and_not_drafted(self):
        d = draft(doc({"/Things": PAGED(), "/Others": lst(wrapped("Others", item="Other"), [{"name": "page", "in": "query", "schema": prop("integer")}])}, schemas={"Other": {"type": "object", "properties": {"OtherID": prop("string")}}})); u = und(d)["tenant_header"]; self.assertTrue(u["blocking"]); self.assertEqual(u["candidates"], ["X-Tenant-Id"]); self.assertIn("only some", u["reason"]); self.assertIsNone(d["config"]["tenant_header"]); self.assertNotIn("required_headers", und(d))
    def test_two_different_tenant_headers_on_every_operation_are_blocking(self):
        d = draft(doc({"/Things": lst(wrapped(), [{"name": "page", "in": "query", "schema": prop("integer")}, hdr("X-Tenant-Id"), hdr("X-Org-Tenant-Id")])})); u = und(d)["tenant_header"]; self.assertEqual(u["candidates"], ["X-Org-Tenant-Id", "X-Tenant-Id"]); self.assertIn("several", u["reason"]); self.assertTrue(u["blocking"]); self.assertIsNone(d["config"]["tenant_header"]); self.assertNotIn("required_headers", und(d))
    def test_other_required_headers_the_connector_cannot_send_are_reported(self):
        d = draft(doc({"/Things": lst(wrapped(), [{"name": "page", "in": "query", "schema": prop("integer")}, hdr(), hdr("X-Api-Version")])})); u = und(d)["required_headers"]; self.assertFalse(u["blocking"]); self.assertEqual(u["candidates"], ["X-Api-Version"])
        d = draft(doc({"/Things": lst(wrapped(), [{"name": "page", "in": "query", "schema": prop("integer")}, hdr(), hdr("Accept"), hdr("Authorization"), hdr("X-Api-Key")])})); self.assertNotIn("required_headers", und(d))                 # headers the connector sets itself are not reported
    def test_the_draft_holds_the_header_name_but_never_an_identifier_and_still_contains_no_secret(self):
        d = draft(doc({"/Things": PAGED()})); self.assertNotIn(TENANT, json.dumps(d)); self.assertIsNone(d["config"]["tenant_id"])
class TestApprovalOfATenantConnector(unittest.TestCase):
    def sess(self, d=None):
        cd, pd = drafts_for_doc(d or doc({"/Things": PAGED()})); return ReviewSession(cd, pd, MODEL_DEF), cd
    def test_approval_needs_the_tenant_id_as_an_explicit_override_and_records_it_apart_from_the_credential(self):
        s, cd = self.sess()
        with self.assertRaises(ApprovalRefused) as cm: s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key"))
        self.assertIn("tenant_id", str(cm.exception))
        out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key", overrides={"tenant_id": TENANT})); c = out["config"]
        self.assertEqual((c["tenant_header"], c["tenant_id"], c["credential_ref"]), ("X-Tenant-Id", TENANT, "secretref:tenant-key")); self.assertNotEqual(c["tenant_id"], c["credential_ref"]); self.assertIn("tenant_id", out["overrides_applied"])
        rc = to_rest_config(c); self.assertEqual((rc.tenant_header, rc.tenant_id), ("X-Tenant-Id", TENANT)); RestConnector(rc)
    def test_a_tenant_id_the_connector_would_refuse_is_refused_at_approval(self):
        for bad in ("a b", "a\r\nb", "", "x" * 101, 5, "a/b"):
            with self.subTest(bad):
                s, cd = self.sess()
                with self.assertRaises(ApprovalRefused): s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key", overrides={"tenant_id": bad}))
    def test_a_human_may_remove_the_tenant_header_but_not_leave_half_of_it(self):
        s, cd = self.sess(); out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key", overrides={"tenant_id": None, "tenant_header": None})); self.assertEqual((out["config"]["tenant_header"], out["config"]["tenant_id"]), (None, None))
        s, cd = self.sess()
        with self.assertRaises(ApprovalRefused): s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key", overrides={"tenant_id": None, "tenant_header": "X-Tenant-Id"}))
    def test_a_reserved_header_name_cannot_be_chosen_as_the_tenant_header(self):
        s, cd = self.sess()
        with self.assertRaises(ApprovalRefused): s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key", overrides={"tenant_id": TENANT, "tenant_header": "Authorization"}))
    def test_a_secret_is_still_refused_even_if_pasted_as_the_tenant_value(self):
        s, cd = self.sess()
        from auif_onboard.errors import SecretLeak
        with self.assertRaises((ApprovalRefused, SecretLeak)): s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key", overrides={"tenant_id": "Bearer abcdefgh12345678"}))
    def test_a_client_credentials_connection_can_be_approved_over_a_description_that_only_declares_an_authorization_code_flow(self):
        schemes = {"OAuth": {"type": "oauth2", "flows": {"authorizationCode": {"authorizationUrl": "https://login.synthetic-vendor.invalid/authorize", "tokenUrl": "https://identity.synthetic-vendor.invalid/connect/token", "scopes": {"things.read": "read things"}}}}}
        cd, pd = drafts_for_doc(doc({"/Things": PAGED()}, schemes=schemes, security=[{"OAuth": ["things.read"]}])); u = {x["field"]: x for x in cd["undetermined"]}; self.assertEqual((cd["config"]["auth"], u["auth"]["blocking"], u["auth"]["candidates"]), ("NONE", True, ["OAUTH2_OTHER"]))
        s = ReviewSession(cd, pd, MODEL_DEF)
        with self.assertRaises(ApprovalRefused): s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key", overrides={"tenant_id": TENANT}))                                  # auth has no explicit override
        out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:tenant-key", overrides={"tenant_id": TENANT, "auth": "OAUTH2_CLIENT_CREDENTIALS", "token_url": "https://identity.synthetic-vendor.invalid/connect/token", "scope": "things.read"})); c = out["config"]
        self.assertEqual((c["auth"], c["scope"], c["allowed_hosts"]), ("OAUTH2_CLIENT_CREDENTIALS", "things.read", ["identity.synthetic-vendor.invalid", "tenant.synthetic-vendor.invalid"]))
class TestExcludingEntities(unittest.TestCase):
    def two(self): return doc({"/Things": PAGED(), "/Others": lst(wrapped("Others", item="Other", pagination=False), [hdr()])}, schemas={"Other": {"type": "object", "properties": {"OtherID": prop("string")}}})
    def sess(self): cd, pd = drafts_for_doc(self.two()); return ReviewSession(cd, pd, MODEL_DEF), cd
    def test_without_a_decision_about_the_unpaged_entity_the_config_cannot_be_approved(self):
        s, cd = self.sess()
        with self.assertRaises(ApprovalRefused) as cm: s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides={"tenant_id": TENANT}))
        self.assertIn("entities.Other.list.pagination", str(cm.exception))
    def test_a_reviewer_may_exclude_an_entity_and_its_blocking_questions_fall_away(self):
        s, cd = self.sess(); out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides={"tenant_id": TENANT, "entities.Other.list": None})); self.assertEqual(list(out["config"]["entities"]), ["Thing"]); self.assertIn("entities.Other.list", out["overrides_applied"])
    def test_excluding_an_entity_does_not_excuse_other_blocking_questions(self):
        s, cd = self.sess()
        with self.assertRaises(ApprovalRefused) as cm: s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides={"entities.Other.list": None}))
        self.assertIn("tenant_id", str(cm.exception)); self.assertNotIn("Other", str(cm.exception))
    def test_a_list_endpoint_cannot_be_replaced_only_removed_and_the_last_entity_cannot_be_removed(self):
        for val in ({"path": "/x"}, "single_page", [], 0, False):
            with self.subTest(val):
                s, cd = self.sess()
                with self.assertRaises(ApprovalRefused): s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides={"tenant_id": TENANT, "entities.Other.list": val}))
        s, cd = self.sess()
        with self.assertRaises(ApprovalRefused): s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides={"tenant_id": TENANT, "entities.Other.list": None, "entities.Thing.list": None}))
    def test_an_excluded_entity_cannot_be_approved_in_the_pack(self):
        s, cd = self.sess(); s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides={"tenant_id": TENANT, "entities.Other.list": None}))
        item = next(i for i in s.items.values() if i["kind"] == "ENTITY_MANUAL" and i["source_ref"] == "Other")
        with self.assertRaises(ApprovalRefused): s.decide(item["item_id"], approval(item["item_hash"], canonical_ref="Property"))
        self.assertEqual(s.status[item["item_id"]], "PENDING")
class TestExclusionAfterMappingsWereApproved(unittest.TestCase):
    def test_a_configuration_that_excludes_an_entity_is_refused_while_a_mapping_for_it_is_approved(self):
        cd, pd = drafts_for_doc(doc({"/Things": PAGED(), "/Others": lst(wrapped("Others", item="Other", pagination=False), [hdr()])}, schemas={"Other": {"type": "object", "properties": {"OtherID": prop("string")}}})); s = ReviewSession(cd, pd, MODEL_DEF)
        item = next(i for i in s.items.values() if i["kind"] == "ENTITY_MANUAL" and i["source_ref"] == "Other"); s.decide(item["item_id"], approval(item["item_hash"], canonical_ref="Property"))
        with self.assertRaises(ApprovalRefused) as cm: s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides={"tenant_id": TENANT, "entities.Other.list": None}))
        self.assertIn("Other", str(cm.exception)); self.assertIsNone(s.config_decision)
        out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides={"tenant_id": TENANT, "entities.Other.list.pagination": "single_page"})); self.assertIn("Other", out["config"]["entities"])        # keeping the entity is fine
    def test_the_same_holds_for_an_approved_field_mapping_alone(self):
        from auif_onboard import planner
        cd, pd = drafts_for_doc(doc({"/Things": PAGED(), "/Others": lst(wrapped("Others", item="Other", pagination=False), [hdr()])}, schemas={"Other": {"type": "object", "properties": {"OtherID": prop("string")}}})); s = ReviewSession(cd, pd, MODEL_DEF)
        item = next(i for i in s.items.values() if i["kind"] == "FIELD_MANUAL" and i["source_ref"] == "Other.OtherID"); s.decide(item["item_id"], approval(item["item_hash"], route="HUMAN", canonical_ref="Property.street", transform=planner.ID_T))
        with self.assertRaises(ApprovalRefused) as cm: s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides={"tenant_id": TENANT, "entities.Other.list": None}))
        self.assertIn("Other", str(cm.exception))
    def test_the_entity_of_every_kind_of_mapping_is_found(self):
        from auif_onboard.review import _entity_of
        self.assertEqual(_entity_of({"kind": "ENTITY", "source_ref": "A"}), "A"); self.assertEqual(_entity_of({"kind": "FIELD", "source_ref": "A.b.c"}), "A"); self.assertEqual(_entity_of({"kind": "ACTION", "source_ref": "POST /a", "outbound": {"target_type": "A"}}), "A")
class TenantVendor(Vendor):
    """A synthetic vendor that refuses any call without the right tenant header and serves a wrapped, page-numbered list with a warnings array and a page-count object."""
    profile, ENTITY, ID_FIELD, base_path, entities = "tenantpaged", "Thing", "ThingID", "/api", ("Thing",); WRITE = {"entity": "Thing", "id": "t1", "fields": {}}; TENANT = "synthetic-tenant"
    def authorized(self, h): return h.get("x-api-key") == CANARY and h.get("x-tenant-id") == self.TENANT
    def record(self, entity, i): return {"ThingID": "t%d" % i, "Title": "Thing %d" % i, "Kind": "a" if i % 2 else "b"}
    def route(self, method, path, q, h, body, fault):
        if method == "GET" and path == "/Things":
            page, size = int(q["page"]), int(q["pageSize"])
            if size > 25: return jresp({"error": "pageSize too large"}, 400)
            recs = self.records("Thing"); a = (page - 1) * size; return jresp({"Things": recs[a:a + size], "Warnings": [{"Message": "w"}], "pagination": {"page": page, "pageSize": size, "pageCount": -(-len(recs) // size), "itemCount": len(recs)}})
        return jresp({"error": "not found"}, 404)
class WrongTenantVendor(TenantVendor): TENANT = "some-other-tenant"
class TestSyntheticValidation(unittest.TestCase):
    def run_validation(self, vendor, conformance=False):
        cd, pd = drafts_for_doc(doc({"/Things": PAGED()})); return validate.validate_synthetic(cd, pd, vendor, MODEL_DEF, run_conformance_suite=conformance), cd
    def test_the_draft_reads_every_record_through_the_wrapped_page_walk_with_the_tenant_header_sent(self):
        rep, cd = self.run_validation(TenantVendor); r = {c["id"]: c for c in rep["checks"]}; self.assertEqual(r["connector_constructs"]["result"], "PASS"); self.assertEqual(r["read_all:Thing"]["result"], "PASS", r["read_all:Thing"]); self.assertEqual(r["read_all:Thing"]["detail"]["read"], validate.SAMPLE)
        self.assertTrue(any("tenant_id set to a stand-in" in n for n in rep["harness_overrides"])); self.assertEqual(rep["real_system_validated"], False)
    def test_the_stand_in_tenant_is_really_checked_by_the_vendor(self):
        rep, _ = self.run_validation(WrongTenantVendor); self.assertEqual({c["id"]: c for c in rep["checks"]}["read_all:Thing"]["result"], "FAIL")
    def test_the_conformance_kit_passes_for_a_tenant_scoped_wrapped_list(self):
        rep, _ = self.run_validation(TenantVendor, conformance=True); k = {c["id"]: c for c in rep["checks"]}["conformance_kit"]; self.assertEqual(k["result"], "PASS", k["detail"]); self.assertGreaterEqual(k["detail"]["ran"], 5)
    def test_the_report_and_drafts_never_carry_a_tenant_identifier_or_a_credential(self):
        rep, cd = self.run_validation(TenantVendor); self.assertNotIn(TENANT, json.dumps([rep, cd])); self.assertNotIn(CANARY, json.dumps([rep, cd]))
if __name__ == "__main__": unittest.main()

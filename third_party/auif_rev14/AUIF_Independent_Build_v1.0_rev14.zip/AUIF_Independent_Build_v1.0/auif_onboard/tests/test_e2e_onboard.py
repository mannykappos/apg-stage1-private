"""End to end, on synthetic loopback vendors only: draft -> named human approvals (test reviewers) -> approved config and pack -> real HTTP through the generic connector -> the unchanged core's Translator and fabric -> a write that takes effect exactly once."""
import json, unittest
from decimal import Decimal
from auif.canonical import CanonicalModel
from auif.clock import FakeClock
from auif.errors import AuifError
from auif.translation import PackRegistry, Translator
from auif.util import Ids
from auif_ext.connectors.rest import RestConnector
from auif_onboard import validate
from auif_onboard.rest_adapter import to_rest_config
from auif_onboard.tests.support import CANARY, NAMES, approval, drafts
from auif_onboard.tests.vendors import VENDORS
from auif_onboard.review import ReviewSession
from synthetic.packs import MODEL_DEF
from synthetic.world import World
CRED = "secretref:test.onboarding-cred"
def approve_all(s):
    """What a diligent test reviewer does: approve what the generator could propose, adopt the proposed outbound where there is one, name the actions, and leave the rest (ambiguities, unmapped fields) pending."""
    for it in list(s.items.values()):
        k = it["kind"]; p = {}
        if k == "ENTITY": p = {"outbound": "ENABLE"} if it["writable"] else {}
        elif k == "FIELD":
            if it["mapping"]["mapping_state"] == "AMBIGUOUS": continue
            if it["outbound_proposal"]["supported"]: p = {"route": "HUMAN", "outbound": "PROPOSED"}
        elif k == "ACTION": p = {"canonical_action": "test.update_" + it["operation"].lower()}
        else: continue
        s.decide(it["item_id"], approval(it["item_hash"], **p))
def onboard(name):
    cd, pd = drafts(name); s = ReviewSession(cd, pd, MODEL_DEF); approve_all(s); ac = s.approve_config(approval(cd["draft_hash"], credential_ref=CRED)); out = s.assemble_pack(approval(s.assemble_pack()["assembly_hash"])); return s, cd, pd, ac, out
def connector(ac, vendor, cls=RestConnector):
    extra, _ = validate.harness_overrides(ac["config"], vendor); extra.pop("credential_ref"); conn = cls(to_rest_config(ac["config"], **extra)); conn.connect(vendor.credentials()); return conn
def ref(pack): return {"id": pack["pack_id"], "version": pack["pack_version"], "hash": pack["artifact_hash"]}
def translator(s, pack): reg = PackRegistry(**s.service.registry_hooks()); reg.register(pack); return Translator(CanonicalModel(MODEL_DEF), reg, Ids(), FakeClock())
CTX = type("C", (), {"tenant_id": "t"})()
def read_all(conn, entity, size=4):
    out, cur = [], None
    while True:
        r = conn.read({"entity": entity, "page_size": size, "cursor": cur}); out += r["items"]
        if r["next_cursor"] is None: return out
        cur = r["next_cursor"]
class Vend:
    def __init__(self, name): self.v = VENDORS[name](); self.name = name
    def __enter__(self): self.v.start(); return self.v
    def __exit__(self, *a): self.v.stop()
EXPECT = {"crm_cursor_apikey": ("Account", "display_name", lambda r: r["profile"]["name"]), "ledger_offset_oauth2": ("Customer", "display_name", lambda r: r["full_name"]), "helpdesk_link_swagger2": ("Ticket", "title", lambda r: r["title"])}
class TheWholeFlow(unittest.TestCase):
    def test_every_approved_pack_translates_every_record_of_every_page_to_valid_canonical_objects(self):
        for name in NAMES:
            with self.subTest(msg=name), Vend(name) as v:
                s, cd, pd, ac, out = onboard(name); pack = out["pack"]; ent, attr, get = EXPECT[name]; v.seed(11, ent); recs = read_all(connector(ac, v), ent); self.assertEqual(len(recs), 11); tr = translator(s, pack); seen = set()
                for r in recs:
                    sid = str(r[v.ID_FIELD]); o = tr.translate_inbound(CTX, ref(pack), ent, r, source_system="onb", observation_id="o-" + sid, schema_fingerprint="0" * 64, source_id=sid)
                    self.assertEqual(o["validation_state"], "VALID"); self.assertEqual(o["attributes"][attr], get(r)); seen.add(o["canonical_id"])
                self.assertEqual(len(seen), 11)
    def test_only_what_a_human_approved_is_translated(self):
        for name in NAMES:
            with self.subTest(msg=name), Vend(name) as v:
                s, cd, pd, ac, out = onboard(name); pack = out["pack"]; ent = EXPECT[name][0]; v.seed(2, ent); r = read_all(connector(ac, v), ent)[0]; o = translator(s, pack).translate_inbound(CTX, ref(pack), ent, r, source_system="onb", observation_id="o", schema_fingerprint="0" * 64, source_id=str(r[v.ID_FIELD]))
                approved = {m["canonical_ref"].split(".", 1)[1] for m in pack["mappings"] if m["kind"] == "FIELD" and m["source_ref"].startswith(ent + ".")}; self.assertEqual(set(o["attributes"]), approved); self.assertTrue(len(out["left_out"]) > 0)
    def test_the_secret_is_only_ever_a_reference_in_everything_that_was_approved_and_assembled(self):
        for name in NAMES:
            with self.subTest(msg=name): s, cd, pd, ac, out = onboard(name); self.assertEqual(ac["config"]["credential_ref"], CRED); self.assertNotIn(CANARY, json.dumps([ac, out, s.ledger], default=str))
    def test_the_same_approvals_assemble_the_same_pack(self):
        for name in NAMES:
            with self.subTest(msg=name): a = onboard(name); b = onboard(name); self.assertEqual(a[4]["pack"]["artifact_hash"], b[4]["pack"]["artifact_hash"]); self.assertEqual(a[3]["approved_hash"], b[3]["approved_hash"]); self.assertEqual([r["result_hash"] for r in a[0].ledger], [r["result_hash"] for r in b[0].ledger])
    def test_the_oauth2_vendor_is_reached_through_its_drafted_token_flow(self):
        with Vend(NAMES[1]) as v:
            s, cd, pd, ac, out = onboard(NAMES[1]); v.seed(3, "Customer"); read_all(connector(ac, v), "Customer"); paths = [r["path"] for r in v.requests()]; self.assertIn("/oauth/token", paths); self.assertTrue(any(p.endswith("/customers") for p in paths))
class WritesTakeEffectOnce(unittest.TestCase):
    def test_a_canonical_change_becomes_one_vendor_write_with_the_drafted_idempotency_header(self):
        with Vend(NAMES[0]) as v:
            s, cd, pd, ac, out = onboard(NAMES[0]); pack = out["pack"]; tr = translator(s, pack); body, info = tr.translate_outbound(ref(pack), "Party", {"balance": "12.34"}); self.assertEqual((body["entity"], body["fields"]), ("Account", {"balance_cents": 1234}))
            self.assertEqual(tr.action_mapping(ref(pack), "test.update_updateaccount"), {"operation": "updateAccount", "entity": "Account"}); v.seed(3, "Account"); conn = connector(ac, v); key = "onb-e2e-1"; r = conn.write({"entity": "Account", "id": "a1", "fields": body["fields"], "idempotency_key": key})
            r2 = conn.write({"entity": "Account", "id": "a1", "fields": body["fields"], "idempotency_key": key}); self.assertEqual(v.effects(key), 1); self.assertEqual(r["external_reference"], r2["external_reference"])
            patches = [q for q in v.requests() if q["method"] == "PATCH"]; self.assertTrue(patches); self.assertEqual(json.loads(patches[0]["body"]), {"balance_cents": 1234}); self.assertEqual(patches[0]["headers"]["idempotency-key"], key)
    def test_an_outbound_value_that_breaks_a_target_constraint_is_refused_before_any_request(self):
        with Vend(NAMES[0]) as v:
            s, cd, pd, ac, out = onboard(NAMES[0]); pack = out["pack"]; tr = translator(s, pack); before = len(v.requests())
            with self.assertRaises(AuifError): tr.translate_outbound(ref(pack), "Party", {"balance": "-5.00"})
            self.assertEqual(len(v.requests()), before)
    def test_a_target_the_human_left_read_only_cannot_be_written(self):
        s, cd, pd, ac, out = onboard(NAMES[2]); pack = out["pack"]; tr = translator(s, pack)
        with self.assertRaises(AuifError): tr.translate_outbound(ref(pack), "Task", {"status": "CLOSED"})
        self.assertFalse([m for m in pack["mappings"] if m["outbound"]["supported"]])
class ThroughTheUnchangedFabric(unittest.TestCase):
    def world(self, s, pack):
        w = World(); h = s.service.registry_hooks(); w.packs.ai_verifier = h["ai_promotion_verifier"]; w.packs.ai_origin = h["ai_origin"]; w.packs.register(pack); w.activate_all(); return w
    def add(self, w, v, cd, ac, pack, secret=None, iid="onb-crm"):
        class Described(RestConnector):
            def discover(self): return cd["discovery_document"]                      # the synthetic vendors serve no description of themselves: the drafted one stands in, so the schema fingerprint check is exercised but is NOT independent evidence
        ctx = w.ctx["tenant-a"]; w.secrets.put("tenant-a", CRED, secret if secret is not None else v.credentials()["secret"]); extra, _ = validate.harness_overrides(ac["config"], v); extra.pop("credential_ref")
        return ctx, w.fabric.add_integration(ctx, integration_id=iid, anchor_module="synthetic-module-1", connector=Described(to_rest_config(ac["config"], **extra)), pack_ref=ref(pack), target_system_id="synthetic-onb", environment_id="env-sandbox", entities=["Account", "Property"])
    def test_an_approved_onboarding_syncs_through_the_fabric_with_no_invalid_objects(self):
        with Vend(NAMES[0]) as v:
            s, cd, pd, ac, out = onboard(NAMES[0]); pack = out["pack"]; w = self.world(s, pack); v.seed(7, "Account"); ctx, integ = self.add(w, v, cd, ac, pack); st = integ.activate()
            self.assertEqual((st["state"], st["trust_basis"]["fingerprint_matches_manifest"], st["trust_basis"]["translation_pack_pinned"]), ("ACTIVE", True, True)); r = w.fabric.sync(ctx, "onb-crm", "Account"); self.assertEqual((r["delivered"], r["invalid"], r["ambiguous"], r["failed"]), (7, 0, 0, None)); self.assertGreaterEqual(r["pages"], 3)
    def test_a_wrong_secret_fails_closed_and_delivers_nothing(self):
        with Vend(NAMES[0]) as v:
            s, cd, pd, ac, out = onboard(NAMES[0]); pack = out["pack"]; w = self.world(s, pack); v.seed(7, "Account"); ctx, integ = self.add(w, v, cd, ac, pack, secret="not-the-vendor-secret"); integ.activate(); r = w.fabric.sync(ctx, "onb-crm", "Account")
            self.assertEqual((r["delivered"], r["failed"]), (0, "AUTHENTICATION_FAILED"))
    def test_the_draft_pack_itself_is_not_trusted_by_the_fabric_because_nothing_in_it_is_approved(self):
        with Vend(NAMES[0]) as v:
            s, cd, pd, ac, out = onboard(NAMES[0]); w = World(); w.packs.register(pd["pack"]); w.activate_all(); v.seed(7, "Account"); ctx, integ = self.add(w, v, cd, ac, pd["pack"]); self.assertEqual(integ.activate()["state"], "TRANSLATION_INVALID"); r = w.fabric.sync(ctx, "onb-crm", "Account"); self.assertEqual((r["delivered"], r["not_allowed"]), (0, True))
if __name__ == "__main__": unittest.main()

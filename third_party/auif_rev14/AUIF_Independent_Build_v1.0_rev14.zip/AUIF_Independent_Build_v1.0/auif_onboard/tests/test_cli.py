import io, json, os, subprocess, sys, tempfile, unittest
from unittest import mock
from auif.util import sha
from auif_onboard import cli
from auif_onboard.tests.support import NAMES, drafts, spec_bytes
from synthetic.packs import MODEL_DEF
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
class Base(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory(); self.d = self.t.name; self.addCleanup(self.t.cleanup); self.model = os.path.join(self.d, "m.json"); json.dump(MODEL_DEF, open(self.model, "w"))
    def spec(self, name=NAMES[0]):
        p = os.path.join(self.d, name + ".json"); open(p, "wb").write(spec_bytes(name)); return p
    def run_cli(self, *args):
        o = io.StringIO()
        try: code = cli.main(list(args), o)
        except SystemExit as e: code = e.code
        return code, o.getvalue()
    def draft(self, spec, out, model=None): return self.run_cli("draft", "--spec", spec, "--canonical-model", model or self.model, "--out", out)
class Drafting(Base):
    def test_a_draft_is_written_for_each_spec_as_three_files_that_say_nothing_is_approved(self):
        for name in NAMES:
            with self.subTest(msg=name):
                out = os.path.join(self.d, "o-" + name); code, text = self.draft(self.spec(name), out); self.assertEqual(code, 0); self.assertEqual(sorted(os.listdir(out)), ["SUMMARY.txt", "config_draft.json", "pack_draft.json"])
                cd = json.load(open(os.path.join(out, "config_draft.json"))); pd = json.load(open(os.path.join(out, "pack_draft.json"))); self.assertEqual(open(os.path.join(out, "SUMMARY.txt")).read(), text); self.assertIn("nothing here is approved", text)
                self.assertEqual((cd["draft_state"], pd["draft_state"], cd["authority"], pd["authority"]), ("DRAFT_NOT_APPROVED",) * 2 + ("NONE",) * 2); self.assertEqual(cd["draft_hash"], drafts(name)[0]["draft_hash"]); self.assertIn(cd["draft_hash"], text); self.assertIsNone(cd["config"]["credential_ref"])
                body = {k: v for k, v in cd.items() if k != "draft_hash"}; self.assertEqual(sha(body), cd["draft_hash"])
    def test_the_same_inputs_give_byte_identical_files(self):
        sp = self.spec(); a, b = os.path.join(self.d, "a"), os.path.join(self.d, "b"); self.assertEqual((self.draft(sp, a)[0], self.draft(sp, b)[0]), (0, 0))
        for f in os.listdir(a): self.assertEqual(open(os.path.join(a, f), "rb").read(), open(os.path.join(b, f), "rb").read())
    def test_the_summary_lists_what_remains_for_a_human(self):
        _, text = self.draft(self.spec(), os.path.join(self.d, "o")); self.assertIn("human work remaining:", text); self.assertIn("undetermined:", text); self.assertIn("mappings by state: ", text); self.assertIn("CANDIDATE=", text)
    def test_the_out_directory_is_created_including_parents(self): out = os.path.join(self.d, "x", "y", "z"); self.assertEqual(self.draft(self.spec(), out)[0], 0); self.assertEqual(len(os.listdir(out)), 3)
    def test_a_draft_can_go_into_an_existing_empty_directory(self): out = os.path.join(self.d, "empty"); os.makedirs(out); self.assertEqual(self.draft(self.spec(), out)[0], 0)
    def test_running_it_as_a_module_works_and_makes_no_network_call(self):
        out = os.path.join(self.d, "m"); sp = self.spec(); env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=ROOT, HTTP_PROXY="http://127.0.0.1:9", HTTPS_PROXY="http://127.0.0.1:9")
        r = subprocess.run([sys.executable, "-W", "ignore", "-m", "auif_onboard", "draft", "--spec", sp, "--canonical-model", self.model, "--out", out], cwd=self.d, capture_output=True, text=True, env=env); self.assertEqual((r.returncode, r.stderr), (0, "")); self.assertIn("nothing here is approved", r.stdout)
    def test_importing_the_cli_never_opens_a_socket(self):
        code = "import socket; socket.socket = None; import auif_onboard.cli as c; print('ok')"; r = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1")); self.assertEqual((r.returncode, r.stdout.strip()), (0, "ok"))
class Refusals(Base):
    def assertRefused(self, code_text, out=None):
        code, text = code_text; self.assertEqual(code, 2); self.assertTrue(text.startswith("refused:")); self.assertNotIn("Traceback", text)
        if out: self.assertFalse(os.path.exists(out), "nothing may be written when a draft is refused")
    def test_a_missing_or_unreadable_input_is_refused_cleanly(self):
        out = os.path.join(self.d, "o"); self.assertRefused(self.draft(os.path.join(self.d, "none.json"), out), out); self.assertRefused(self.draft(self.spec(), out, os.path.join(self.d, "none.json")), out); self.assertRefused(self.draft(self.d, out), out)
    def test_a_description_that_is_not_json_is_refused_with_the_yaml_hint(self):
        p = os.path.join(self.d, "y.yaml"); open(p, "w").write("openapi: 3.0.0\ninfo:\n  title: x\n"); out = os.path.join(self.d, "o"); r = self.draft(p, out); self.assertRefused(r, out); self.assertIn("YAML is not supported", r[1])
    def test_a_description_that_is_not_an_api_description_is_refused(self):
        for label, content in (("array", "[1]"), ("empty object", "{}"), ("wrong version", json.dumps({"openapi": "9.9", "info": {}, "paths": {}}))):
            with self.subTest(msg=label): p = os.path.join(self.d, "d.json"); open(p, "w").write(content); out = os.path.join(self.d, "o-" + label.replace(" ", "")); self.assertRefused(self.draft(p, out), out)
    def test_a_description_with_no_operations_gives_an_honest_empty_draft_not_a_crash(self):
        p = os.path.join(self.d, "e.json"); open(p, "w").write(json.dumps({"openapi": "3.0.0", "info": {"title": "t", "version": "1"}, "paths": {}})); out = os.path.join(self.d, "o"); code, text = self.draft(p, out); self.assertEqual(code, 0); self.assertIn("entities: none", text); self.assertIn("mappings by state: none", text); pd = json.load(open(os.path.join(out, "pack_draft.json"))); self.assertIsNone(pd["pack"])
    def test_an_oversized_description_is_refused(self):
        p = os.path.join(self.d, "big.json"); open(p, "w").write('{"openapi": "3.0.0", "x": "' + "a" * (5 * 1024 * 1024 + 10) + '"}'); out = os.path.join(self.d, "o"); self.assertRefused(self.draft(p, out), out)
    def test_a_bad_canonical_model_is_refused(self):
        out = os.path.join(self.d, "o")
        for label, content in (("not json", "{nope"), ("array", "[1]"), ("missing keys", json.dumps({"concepts": []}))):
            with self.subTest(msg=label): m = os.path.join(self.d, "bad.json"); open(m, "w").write(content); self.assertRefused(self.draft(self.spec(), out, m), out)
    def test_an_existing_output_file_is_never_overwritten_and_nothing_partial_is_left(self):
        sp = self.spec()
        for existing in ("config_draft.json", "pack_draft.json", "SUMMARY.txt"):
            with self.subTest(msg=existing):
                out = os.path.join(self.d, "o-" + existing); os.makedirs(out); keep = os.path.join(out, existing); open(keep, "w").write("KEEP"); code, text = self.draft(sp, out); self.assertEqual(code, 2); self.assertIn("nothing was overwritten", text)
                self.assertEqual(os.listdir(out), [existing]); self.assertEqual(open(keep).read(), "KEEP")
    def test_a_dangling_symlink_in_the_output_directory_is_also_never_followed(self):
        out = os.path.join(self.d, "o"); os.makedirs(out); target = os.path.join(self.d, "elsewhere.txt"); os.symlink(target, os.path.join(out, "SUMMARY.txt")); code, _ = self.draft(self.spec(), out); self.assertEqual(code, 2); self.assertFalse(os.path.exists(target)); self.assertEqual(os.listdir(out), ["SUMMARY.txt"])
    def test_an_unusable_output_path_is_refused_without_a_traceback(self):
        sp = self.spec(); code, text = self.draft(sp, os.path.join(sp, "sub")); self.assertEqual(code, 2); self.assertIn("not usable", text); self.assertNotIn("Traceback", text)
    def test_a_failure_part_way_through_writing_removes_only_what_this_run_wrote(self):
        out = os.path.join(self.d, "o"); sp = self.spec(); real = open; calls = []
        def flaky(path, *a, **k):
            if str(path).endswith("SUMMARY.txt") and "x" in (a[0] if a else k.get("mode", "")): raise OSError("disk full")
            f = real(path, *a, **k); calls.append(str(path)); return f
        with mock.patch("builtins.open", flaky): code, text = self.draft(sp, out)
        self.assertEqual(code, 2); self.assertIn("not usable", text); self.assertEqual(os.listdir(out), [])
    def test_usage_errors_exit_two(self):
        self.assertEqual(self.run_cli("draft")[0], 2); self.assertEqual(self.run_cli()[0], 2); self.assertEqual(self.run_cli("approve")[0], 2); self.assertEqual(self.run_cli("promote", "--all")[0], 2)
    def test_there_is_no_command_that_approves_anything(self):
        text = open(cli.__file__).read(); self.assertEqual(text.count("add_parser("), 1); self.assertIn('add_parser("draft"', text)
class Quiet(Base):
    def test_a_refusal_never_repeats_secret_like_material_from_the_input(self):
        sk = "sk_live_" + "a1B2c3D4e5F6g7H8i9J0"; d = json.loads(spec_bytes(NAMES[0])); d["info"]["title"] = "Mini " + sk; p = os.path.join(self.d, "s.json"); json.dump(d, open(p, "w")); out = os.path.join(self.d, "o"); code, text = self.draft(p, out); self.assertEqual(code, 2); self.assertNotIn(sk, text); self.assertFalse(os.path.exists(out))
if __name__ == "__main__": unittest.main()

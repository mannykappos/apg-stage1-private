"""Guards of the synthetic validator that a mutation campaign showed to be unprotected. Each test makes a (synthetic, local) vendor or a draft misbehave in exactly one way and requires the report to say so."""
import copy, unittest
from unittest import mock
from auif.errors import MalformedResponse
from auif_ext.connectors.rest import RestConnector
from auif_onboard import validate
from auif_onboard.errors import SecretLeak
from auif_onboard.tests.support import CANARY, NAMES, drafts
from auif_onboard.tests.test_validate import by_id, quick, results
from auif_onboard.tests.vendors import CrmVendor
from synthetic.packs import MODEL_DEF
class Twice(CrmVendor):
    """Applies every keyed write twice."""
    def effects(self, key): return 2 if key in self.store else 0
class Short(CrmVendor):
    def records(self, entity): return super().records(entity)[:-1]
class Dupes(CrmVendor):
    def records(self, entity): r = super().records(entity); return r[:-1] + [r[-2]]
class LongName(CrmVendor):
    def record(self, entity, i):
        r = super().record(entity, i)
        if entity == "Account": r["profile"]["name"] = "n" * 150
        return r
def run(cd, pd, vendor=CrmVendor, conformance=False): return validate.validate_synthetic(cd, pd, vendor, MODEL_DEF, run_conformance_suite=conformance)
class Conformance(unittest.TestCase):
    def test_a_vendor_that_breaks_the_kit_fails_the_conformance_check_and_the_write_roundtrip(self):
        cd, pd = drafts(NAMES[0]); rep = run(cd, pd, Twice, conformance=True); c = by_id(rep, "conformance_kit")[0]; self.assertEqual(c["result"], "FAIL"); self.assertTrue(c["detail"]["failed"]); self.assertIn("test_an_idempotent_write_takes_effect_once_and_sends_its_key", [f["test"] for f in c["detail"]["failed"]])
        self.assertEqual(by_id(rep, "write_roundtrip:Account")[0]["result"], "FAIL"); self.assertFalse(rep["all_checks_passed"]); self.assertEqual(by_id(rep, "write_roundtrip:Account")[0]["detail"]["effects"], 2)
    def test_a_kit_that_ran_nothing_proves_nothing(self):
        cd, pd = drafts(NAMES[0]); empty = {"ran": 0, "failed": [], "not_applicable": [], "passed": 0, "skipped_by_suite": 0}
        with mock.patch.object(validate, "run_conformance", return_value=empty): rep = validate.validate_synthetic(cd, pd, CrmVendor, MODEL_DEF)
        self.assertEqual(by_id(rep, "conformance_kit")[0]["result"], "FAIL")
class Reading(unittest.TestCase):
    def test_a_partial_read_fails(self):
        cd, pd = drafts(NAMES[0]); c = by_id(run(cd, pd, Short), "read_all:Account")[0]; self.assertEqual(c["result"], "FAIL"); self.assertEqual((c["detail"]["seeded"], c["detail"]["read"]), (23, 22))
    def test_duplicate_records_fail(self):
        cd, pd = drafts(NAMES[0]); c = by_id(run(cd, pd, Dupes), "read_all:Account")[0]; self.assertEqual(c["result"], "FAIL"); self.assertEqual(c["detail"]["read"], 23)
    def test_a_paging_loop_that_never_ends_is_an_error_after_a_hundred_pages(self):
        class Endless:
            calls = 0
            def read(self, req): Endless.calls += 1; return {"items": [{"id": Endless.calls}], "next_cursor": "again"}
        with self.assertRaises(MalformedResponse): validate._read_all(Endless(), "X")
        self.assertEqual(Endless.calls, 100)
    def test_a_loop_that_ends_returns_everything_it_read(self):
        class Two:
            def read(self, req): return {"items": [1, 2], "next_cursor": None if req["cursor"] == "b" else "b"}
        self.assertEqual(validate._read_all(Two(), "X"), [1, 2, 1, 2])
class DraftChecks(unittest.TestCase):
    def tampered(self, fn):
        cd, pd = drafts(NAMES[0]); pd = copy.deepcopy(pd); cd = copy.deepcopy(cd); fn(cd, pd); return cd, pd
    def test_a_trusted_or_validated_mapping_in_a_draft_fails_the_unapproved_check(self):
        for state in ("TRUSTED", "VALIDATED"):
            with self.subTest(state):
                cd, pd = self.tampered(lambda c, p: p["pack"]["mappings"][0].update(mapping_state=state)); c = by_id(quick(cd, pd), "draft_is_unapproved")[0]; self.assertEqual(c["result"], "FAIL"); self.assertEqual(len(c["detail"]["validated_or_trusted_mappings"]), 1)
    def test_an_incomplete_discovery_record_fails(self):
        for label, fn in (("no kinds", lambda c, p: p["discovery_record"]["coverage"].update(obtained_kinds=[])), ("no operations", lambda c, p: p["discovery_record"]["coverage"].update(obtained_kinds=["ENTITY", "FIELD"])), ("short fingerprint", lambda c, p: p["discovery_record"]["schema_fingerprint"].update(value="abc"))):
            with self.subTest(label): cd, pd = self.tampered(fn); self.assertEqual(by_id(quick(cd, pd), "discovery_record")[0]["result"], "FAIL")
        cd, pd = drafts(NAMES[0]); self.assertEqual(by_id(quick(cd, pd), "discovery_record")[0]["result"], "PASS")
    def test_a_report_that_would_carry_the_vendors_secret_is_refused(self):
        def plant(c, p): next(m for m in p["pack"]["mappings"] if m["kind"] == "FIELD")["source_ref"] = "Account." + CANARY
        cd, pd = self.tampered(plant)
        with self.assertRaises(SecretLeak) as cm: quick(cd, pd)
        self.assertIn("validation report", str(cm.exception)); self.assertNotIn(CANARY, str(cm.exception))
class WriteRoundtrip(unittest.TestCase):
    def tampered(self, fn):
        cd, pd = drafts(NAMES[0]); pd = copy.deepcopy(pd); cd = copy.deepcopy(cd); fn(cd, pd); return cd, pd
    def test_a_value_that_breaks_a_generated_target_constraint_is_not_written(self):
        cd, pd = drafts(NAMES[0]); v = LongName(); rep = run(cd, pd, LongName); c = by_id(rep, "write_roundtrip:Account")[0]; self.assertEqual(c["result"], "FAIL"); self.assertIn("target constraint", c["detail"]["reason"]); self.assertEqual(c["detail"]["field"], "profile.name")
    def test_nothing_is_sent_to_the_vendor_when_a_constraint_rejects_the_value(self):
        sent = []; real = RestConnector.write
        def spy(self, *a, **k): sent.append(a); return real(self, *a, **k)
        cd, pd = drafts(NAMES[0])
        with mock.patch.object(RestConnector, "write", spy): rep = run(cd, pd, LongName)
        self.assertEqual(sent, []); self.assertEqual(by_id(rep, "write_roundtrip:Account")[0]["result"], "FAIL")
    def test_a_write_answer_without_an_external_reference_fails(self):
        real = RestConnector.write
        def blank(self, *a, **k): return dict(real(self, *a, **k), external_reference="")
        cd, pd = drafts(NAMES[0])
        with mock.patch.object(RestConnector, "write", blank): c = by_id(run(cd, pd), "write_roundtrip:Account")[0]
        self.assertEqual(c["result"], "FAIL"); self.assertEqual(c["detail"]["effects"], 1)
    def test_fields_of_an_entity_whose_name_merely_starts_the_same_do_not_count(self):
        def plant(c, p):
            c["write_fields"]["Account"].append({"name": "zzz", "type": "string", "required": True, "read_only": False}); other = copy.deepcopy(next(i for i in p["items"] if i["kind"] == "FIELD" and i["mapping"]["source_ref"] == "Account.profile.name")); other["mapping"]["source_ref"] = "AccountExtra.zzz"; p["items"].append(other)
        cd, pd = self.tampered(plant); c = by_id(quick(cd, pd), "write_roundtrip:Account")[0]; self.assertEqual((c["result"], c["detail"]["missing"]), ("ATTENTION", ["zzz"]))
    def test_a_read_only_field_is_never_a_required_write(self):
        def plant(c, p): c["write_fields"]["Account"].append({"name": "ro", "type": "string", "required": True, "read_only": True})
        cd, pd = self.tampered(plant); c = by_id(quick(cd, pd), "write_roundtrip:Account")[0]; self.assertEqual(c["result"], "PASS"); self.assertNotIn("ro", c["detail"]["fields_written"])
    def test_a_required_writable_field_with_no_outbound_mapping_is_for_a_human(self):
        def plant(c, p): c["write_fields"]["Account"].append({"name": "need", "type": "string", "required": True, "read_only": False})
        cd, pd = self.tampered(plant); c = by_id(quick(cd, pd), "write_roundtrip:Account")[0]; self.assertEqual((c["result"], c["detail"]["missing"]), ("ATTENTION", ["need"]))
if __name__ == "__main__": unittest.main()

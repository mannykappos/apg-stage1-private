"""Guards of the reader, matcher, secret screen, config generator, pack drafter, adapter and CLI that a mutation campaign showed to be unprotected. Each test names the behaviour it pins."""
import builtins, copy, io, json, os, tempfile, unittest
from unittest import mock
from auif.ai_boundary import MappingProposer
from auif.util import sha
from auif_onboard import cli, config_gen, matching, openapi, pack_draft
from auif_onboard.config_gen import draft_config, flatten
from auif_onboard.errors import SecretLeak
from auif_onboard.pack_draft import draft_pack
from auif_onboard.rest_adapter import to_rest_config
from auif_onboard.secrets_scan import scan
from auif_onboard.tests.support import NAMES, THING, arr, drafts, get_list, mini, q, spec_bytes
from synthetic.packs import MODEL_DEF
def draft(doc): d, h = openapi.load(doc); return draft_config(openapi.parse(d), h)
def sch(components, node): return openapi.schema({"openapi": "3.0.0", "info": {}, "paths": {}, "components": {"schemas": components}}, node)
def und(d): return {u["field"]: u for u in d["undetermined"]}
def asm(d): return {x["field"]: x for x in d["assumed_defaults"]}
LIST = lambda params=(), schema=None: get_list(schema or {"type": "object", "properties": {"items": arr("Thing"), "next_cursor": {"type": "string"}}}, list(params))
def idparam(name="id"): return [{"name": name, "in": "path", "required": True, "schema": {"type": "string"}}]
def write_body(extra_params=()): return {"parameters": list(extra_params), "requestBody": {"content": {"application/json": {"schema": {"type": "object", "properties": {"title": {"type": "string"}}}}}}, "responses": {"200": {"description": "ok", "content": {"application/json": {"schema": {"type": "object", "properties": {"id": {"type": "string"}}}}}}}}
class ReaderGuards(unittest.TestCase):
    def test_a_limit_is_kept_only_for_the_type_it_belongs_to_even_when_inherited_through_allOf(self):
        comps = {"Text": {"type": "string", "maxLength": 9}, "Num": {"type": "integer", "minimum": 1, "maximum": 5}}
        s = sch(comps, {"type": "integer", "allOf": [{"$ref": "#/components/schemas/Text"}]}); self.assertEqual((s["type"], s["max_length"]), ("integer", None))
        s = sch(comps, {"type": "string", "allOf": [{"$ref": "#/components/schemas/Num"}]}); self.assertEqual((s["type"], s["minimum"], s["maximum"]), ("string", None, None))
        s = sch(comps, {"allOf": [{"$ref": "#/components/schemas/Text"}]}); self.assertEqual(s["max_length"], 9)
    def test_an_api_key_in_a_query_with_a_perfectly_good_name_is_still_not_a_header_scheme(self):
        s = openapi.parse(dict(mini({}), components={"securitySchemes": {"q": {"type": "apiKey", "in": "query", "name": "X-Query-Key"}, "h": {"type": "apiKey", "in": "header", "name": "X-Query-Key"}}}))["security_schemes"]
        self.assertEqual((s["q"]["kind"], s["q"]["header"], s["h"]["kind"], s["h"]["header"]), ("API_KEY_OTHER", None, "API_KEY_HEADER", "X-Query-Key"))
class MatcherGuards(unittest.TestCase):
    def test_plural_entity_names_match_their_singular_concept(self):
        for entity, concept in (("Tickets", "Task"), ("accounts", "Party"), ("Customers", "Party"), ("listings", "Property")): self.assertEqual(matching.concept_name_score(entity, concept), 1.0, entity)
        self.assertEqual(matching.concept_name_score("Tickets", "Party"), 0.0)
    def test_a_plural_field_word_counts_as_a_weaker_match_for_its_singular(self):
        self.assertEqual(matching.score("tags", "tag"), 0.7); self.assertEqual(matching.score("tag", "tags"), 0.7); self.assertEqual(matching.score("tag", "tag"), 1.0); self.assertEqual(matching.score("bus", "bu"), 0.0)
class ScreenGuards(unittest.TestCase):
    def test_a_long_low_entropy_string_made_of_letters_and_digits_is_not_a_token(self):
        for s in ("xy1" * 12, "ab9" * 14, "q7" * 20 + "z"): self.assertEqual(scan([s]), [], s)
    def test_a_random_looking_one_still_is(self): self.assertEqual([r for _, r in scan(["Qz8rT2vKp9LmX4wB7nD3sF6hJ1cG5yA0eU"])], ["high-entropy-token"])
class ConfigGenGuards(unittest.TestCase):
    def test_an_item_lookup_that_returns_a_list_is_not_a_list_endpoint(self):
        comps = dict(THING, Other={"type": "object", "properties": {"id": {"type": "string"}}}); lk = {"get": {"parameters": idparam(), "responses": {"200": {"description": "ok", "content": {"application/json": {"schema": {"type": "object", "properties": {"items": arr("Other")}}}}}}}}
        d = draft(mini({"/things": LIST([q("cursor")]), "/others/{id}": lk}, comps)); self.assertEqual(sorted(d["config"]["entities"]), ["Thing"])
    def test_a_health_endpoint_is_a_health_path_and_never_an_entity(self):
        comps = dict(THING, Probe={"type": "object", "properties": {"id": {"type": "string"}}}); hp = get_list({"type": "object", "properties": {"items": arr("Probe")}})
        d = draft(mini({"/things": LIST([q("cursor")]), "/health": hp}, comps)); self.assertEqual((sorted(d["config"]["entities"]), d["config"]["health_path"]), (["Thing"], "/health"))
    def test_several_total_properties_mean_no_total_is_used(self):
        off = {"type": "object", "properties": {"items": arr("Thing"), "total": {"type": "integer"}, "count": {"type": "integer"}}}; d = draft(mini({"/things": LIST([q("offset"), q("limit")], off)}, THING)); ep = d["config"]["entities"]["Thing"]["list"]
        self.assertEqual((ep["pagination"], ep["total_items_path"]), ("offset", None)); self.assertIn("entities.Thing.list.total_items_path", asm(d))
        pg = {"type": "object", "properties": {"items": arr("Thing"), "totalPages": {"type": "integer"}, "pages": {"type": "integer"}}}; d = draft(mini({"/things": LIST([q("page"), q("limit")], pg)}, THING)); ep = d["config"]["entities"]["Thing"]["list"]
        self.assertEqual((ep["pagination"], ep["total_pages_path"]), ("page", None)); self.assertIn("entities.Thing.list.total_pages_path", asm(d))
    def test_a_single_total_property_is_used(self):
        off = {"type": "object", "properties": {"items": arr("Thing"), "total": {"type": "integer"}}}; self.assertEqual(draft(mini({"/things": LIST([q("offset")], off)}, THING))["config"]["entities"]["Thing"]["list"]["total_items_path"], ["total"])
        pg = {"type": "object", "properties": {"items": arr("Thing"), "pages": {"type": "integer"}}}; self.assertEqual(draft(mini({"/things": LIST([q("page")], pg)}, THING))["config"]["entities"]["Thing"]["list"]["total_pages_path"], ["pages"])
    def test_an_api_key_scheme_without_a_usable_header_name_is_not_drafted_as_one(self):
        d = draft(mini({"/things": LIST([q("cursor")])}, THING, security=[{"k": []}], schemes={"k": {"type": "apiKey", "in": "header", "name": "bad name!"}})); self.assertEqual(d["config"]["auth"], "NONE"); self.assertTrue(und(d)["auth"]["blocking"]); self.assertEqual(d["config"]["auth_header"], "Authorization")
    def test_only_a_header_named_for_idempotency_is_an_idempotency_header(self):
        d = draft(mini({"/things": dict(LIST([q("cursor")]), post=write_body([{"name": "X-Trace-Id", "in": "header", "schema": {"type": "string"}}]))}, THING)); self.assertIsNone(d["config"]["idempotency_header"])
    def test_a_single_parameter_get_is_a_lookup_only_when_the_parameter_names_a_key(self):
        paths = {"/things": dict(LIST([q("cursor")]), post=write_body()), "/things/{id}": {"get": {"parameters": idparam(), "responses": {"200": {"description": "ok", "content": {"application/json": {"schema": {"type": "object", "properties": {"id": {"type": "string"}}}}}}}}}}
        d = draft(mini(paths, THING)); self.assertIsNone(d["config"]["lookup"]); self.assertIn("lookup", und(d))
    def test_a_oneof_field_is_skipped_even_when_it_also_names_a_type(self):
        node = openapi.schema({}, {"type": "object", "properties": {"v": {"type": "string", "oneOf": [{"type": "string"}, {"type": "integer"}]}, "a": {"type": "string"}}}); notes = []
        self.assertEqual([f["name"] for f in flatten(node, notes=notes)], ["a"]); self.assertEqual(notes, ["v uses oneOf/anyOf and was skipped"])
    def test_the_connector_id_slug_is_bounded(self):
        doc = mini({"/things": LIST([q("cursor")])}, THING); doc["info"]["title"] = "a" * 100; d, h = openapi.load(doc); cd = draft_config(openapi.parse(d), h); self.assertEqual(cd["config"]["connector_id"], "onb-" + "a" * 30 + "-" + h[:8])
class PackDraftGuards(unittest.TestCase):
    def mk(self, props, name="Thing", model=None):
        doc = mini({"/things": LIST([q("cursor")], {"type": "object", "properties": {"items": arr(name), "next_cursor": {"type": "string"}}})}, {name: {"type": "object", "properties": props}}); d, h = openapi.load(doc); return draft_config(openapi.parse(d), h)
    def test_the_generator_enables_no_outbound_anywhere(self):
        for n in NAMES:
            _, pd = drafts(n)
            for m in pd["pack"]["mappings"]: self.assertFalse(m["outbound"]["supported"], (n, m["mapping_id"], m["kind"]))
    def test_an_entity_mapping_id_depends_on_the_concepts_it_resembles(self):
        cd = self.mk({"title": {"type": "string"}, "state": {"type": "string", "enum": ["OPEN", "CLOSED"]}}); less = copy.deepcopy(MODEL_DEF); less["concepts"] = [c for c in less["concepts"] if c["name"] != "Party"]
        a, b = draft_pack(cd, MODEL_DEF), draft_pack(cd, less); ea = [m for m in a["pack"]["mappings"] if m["kind"] == "ENTITY"][0]; eb = [m for m in b["pack"]["mappings"] if m["kind"] == "ENTITY"][0]
        self.assertEqual((ea["mapping_state"], eb["mapping_state"]), ("AMBIGUOUS", "CANDIDATE")); self.assertNotEqual(ea["mapping_id"], eb["mapping_id"])
    def test_a_rejected_proposal_is_listed_for_the_human_and_its_field_is_not_listed_twice(self):
        class Evil(MappingProposer):
            NAME = "evil"
            def propose(self, sandbox): return [{"source_ref": "Thing.title", "canonical_ref": "Task.title", "transform": {"kind": "EVIL", "parameters": {}, "deterministic": True}, "alternatives": []}]
        pd = draft_pack(self.mk({"title": {"type": "string"}, "state": {"type": "string"}}), MODEL_DEF, proposer=Evil()); kinds = [(u["kind"], u["ref"]) for u in pd["unresolved"]]
        self.assertIn(("FIELD_PROPOSAL_REJECTED", "Thing.title"), kinds); self.assertNotIn(("FIELD_UNMAPPED", "Thing.title"), kinds); self.assertIn(("FIELD_UNMAPPED", "Thing.state"), kinds)
    def test_only_required_attributes_are_reported_as_uncovered(self):
        pd = draft_pack(self.mk({"name": {"type": "string"}}, "Customer"), MODEL_DEF); self.assertEqual([u["ref"] for u in pd["unresolved"] if u["kind"] == "REQUIRED_ATTRIBUTE_UNCOVERED"], [])
        pd = draft_pack(self.mk({"nickname": {"type": "string"}}, "Customer"), MODEL_DEF); self.assertEqual([u["ref"] for u in pd["unresolved"] if u["kind"] == "REQUIRED_ATTRIBUTE_UNCOVERED"], ["Party.display_name"])
    def test_uncovered_attributes_are_checked_against_the_first_concept_only(self):
        pd = draft_pack(self.mk({"title": {"type": "string"}, "state": {"type": "string", "enum": ["OPEN", "CLOSED"]}}), MODEL_DEF); self.assertEqual([m["mapping_state"] for m in pd["pack"]["mappings"] if m["kind"] == "ENTITY"], ["AMBIGUOUS"])
        self.assertEqual([u["ref"] for u in pd["unresolved"] if u["kind"] == "REQUIRED_ATTRIBUTE_UNCOVERED"], [])
    def test_a_draft_that_somehow_carries_a_secret_is_refused_by_the_pack_drafter_itself(self):
        cd = copy.deepcopy(self.mk({"name": {"type": "string"}}, "Account")); cd["discovery_document"]["entities"][0]["fields"].append({"name": "Bearer abcdefgh12345678xx", "type": "string", "required": False, "read_only": False, "write_only": False, "nullable": False})
        with self.assertRaises(SecretLeak) as cm: draft_pack(cd, MODEL_DEF)
        self.assertIn("pack draft", str(cm.exception)); self.assertNotIn("abcdefgh12345678xx", str(cm.exception))
class AdapterGuards(unittest.TestCase):
    def test_an_incomplete_configuration_is_refused_not_converted(self):
        cd, _ = drafts(NAMES[0]); base = cd["config"]
        for label, change in (("no base_url", {"base_url": None}), ("empty base_url", {"base_url": ""}), ("no entities", {"entities": {}})):
            with self.subTest(label), self.assertRaises(ValueError) as cm: to_rest_config(dict(copy.deepcopy(base), **change))
            self.assertIn("incomplete", str(cm.exception))
    def test_absent_paths_stay_absent_and_present_ones_are_kept(self):
        cd, _ = drafts(NAMES[0]); rc = to_rest_config(cd["config"]); self.assertIsNone(rc.entities["Account"]["list"].total_items_path); self.assertIsNone(rc.entities["Account"]["list"].total_pages_path)
        led, _ = drafts(NAMES[1]); rl = to_rest_config(led["config"]); self.assertEqual(rl.entities["Customer"]["list"].total_items_path, ("total",))
    def test_the_lookup_endpoint_is_carried_over(self):
        cd, _ = drafts(NAMES[0]); rc = to_rest_config(cd["config"]); self.assertEqual(rc.lookup.path, "/idempotency/{key}"); self.assertEqual(rc.lookup.id_field, "external_reference")
        none = copy.deepcopy(cd["config"]); none["lookup"] = None; self.assertIsNone(to_rest_config(none).lookup)
class CliGuards(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.mkdtemp(); self.spec = os.path.join(self.t, "s.json"); self.model = os.path.join(self.t, "m.json"); open(self.spec, "wb").write(spec_bytes(NAMES[0])); json.dump(MODEL_DEF, open(self.model, "w")); self.out = os.path.join(self.t, "out")
    def run_cli(self, *extra, spec=None):
        buf = io.StringIO(); rc = cli.main(["draft", "--spec", spec or self.spec, "--canonical-model", self.model, "--out", self.out] + list(extra), out=buf); return rc, buf.getvalue()
    def creations(self, setup):
        """Every file the CLI tried to create inside the output directory (exclusive-create opens), in order."""
        real, seen = builtins.open, []
        def spy(path, mode="r", *a, **k):
            if isinstance(path, str) and path.startswith(self.out) and "x" in mode: seen.append(os.path.basename(path))
            return real(path, mode, *a, **k)
        setup()
        with mock.patch("builtins.open", spy): rc, text = self.run_cli()
        return rc, text, seen
    def test_an_existing_output_file_is_found_before_anything_is_created(self):
        def setup(): os.makedirs(self.out); open(os.path.join(self.out, "pack_draft.json"), "w").write("mine")
        rc, text, seen = self.creations(setup); self.assertEqual((rc, seen), (2, [])); self.assertIn("nothing was overwritten", text); self.assertEqual(os.listdir(self.out), ["pack_draft.json"]); self.assertEqual(open(os.path.join(self.out, "pack_draft.json")).read(), "mine")
    def test_a_dangling_symlink_counts_as_an_existing_output_file(self):
        def setup(): os.makedirs(self.out); os.symlink(os.path.join(self.t, "nowhere"), os.path.join(self.out, "pack_draft.json"))
        rc, text, seen = self.creations(setup); self.assertEqual((rc, seen), (2, [])); self.assertEqual(os.listdir(self.out), ["pack_draft.json"]); self.assertFalse(os.path.exists(os.path.join(self.t, "nowhere")))
    def test_the_files_are_screened_by_the_cli_itself_before_anything_is_written(self):
        cd, pd = drafts(NAMES[0]); pd = copy.deepcopy(pd); pd["items"][0]["note"] = "Bearer abcdefgh12345678xx"
        with mock.patch.object(cli.pack_draft, "draft_pack", return_value=pd): rc, text = self.run_cli()
        self.assertEqual(rc, 2); self.assertIn("refused", text); self.assertNotIn("abcdefgh12345678xx", text); self.assertFalse(os.path.exists(self.out) and os.listdir(self.out))
    def test_a_refusal_for_a_non_framework_error_names_only_the_error_type(self):
        rc, text = self.run_cli(spec=os.path.join(self.t, "missing-file.json")); self.assertEqual((rc, text), (2, "refused: FileNotFoundError\n"))
        open(self.model, "w").write("{not json"); rc, text = self.run_cli(); self.assertEqual(rc, 2); self.assertTrue(text.startswith("refused: JSONDecodeError")); self.assertNotIn("Expecting", text)
    def test_the_written_files_are_key_sorted_so_the_output_is_reproducible(self):
        self.assertEqual(self.run_cli()[0], 0)
        for name in ("config_draft.json", "pack_draft.json"):
            text = open(os.path.join(self.out, name)).read(); obj = json.loads(text); self.assertEqual(list(obj), sorted(obj), name); self.assertEqual(text, json.dumps(obj, indent=1, sort_keys=True) + "\n")
if __name__ == "__main__": unittest.main()

"""The validation report is strictly synthetic: it talks only to synthetic vendors on loopback, needs no fact about any real system, and a defect in a draft shows up as a FAIL."""
import copy, json, unittest
from unittest import mock
from auif.util import sha
from auif_onboard import validate
from auif_onboard.errors import RealSystemRefused
from auif_onboard.secrets_scan import scan
from auif_onboard.tests.support import CANARY, NAMES, drafts
from auif_onboard.tests.vendors import VENDORS, CrmVendor
from synthetic.packs import MODEL_DEF
_FULL = {}
def full(name):
    if name not in _FULL:
        cd, pd = drafts(name); _FULL[name] = (cd, pd, validate.validate_synthetic(cd, pd, VENDORS[name], MODEL_DEF))
    return copy.deepcopy(_FULL[name])
def quick(cd, pd, name=NAMES[0]): return validate.validate_synthetic(cd, pd, VENDORS[name], MODEL_DEF, run_conformance_suite=False)
def by_id(rep, cid): return [c for c in rep["checks"] if c["id"] == cid]
def results(rep): return {c["id"]: c["result"] for c in rep["checks"]}
class Stub:
    def __init__(self, url, synthetic=True): self.url, self.SYNTHETIC = url, synthetic; self.host = "x"
class TheReportOnThreeVendors(unittest.TestCase):
    def test_every_vendor_has_zero_failures_and_the_conformance_kit_ran_and_passed(self):
        for name in NAMES:
            with self.subTest(msg=name):
                cd, pd, rep = full(name); self.assertEqual(rep["summary"]["FAIL"], 0); self.assertTrue(rep["all_checks_passed"]); c = by_id(rep, "conformance_kit")[0]; self.assertEqual(c["result"], "PASS"); self.assertGreaterEqual(c["detail"]["ran"], 10); self.assertEqual(c["detail"]["failed"], [])
                self.assertEqual(sum(rep["summary"].values()), len(rep["checks"]))
    def test_the_report_states_what_it_is_and_what_it_is_not(self):
        for name in NAMES:
            with self.subTest(msg=name):
                cd, pd, rep = full(name); self.assertEqual((rep["report_kind"], rep["synthetic_only"], rep["real_system_validated"], rep["authority"], rep["status"]), ("OnboardingSyntheticValidationReport", True, False, "NONE", "PRESENTED_FOR_HUMAN_APPROVAL")); self.assertTrue(rep["vendor"]["synthetic"])
                self.assertEqual(rep["subject"], {"config_draft_hash": cd["draft_hash"], "pack_draft_hash": pd["draft_hash"]})
    def test_the_report_hash_covers_the_report_and_the_report_is_free_of_secrets_and_ports(self):
        for name in NAMES:
            with self.subTest(msg=name):
                _, _, rep = full(name); body = {k: v for k, v in rep.items() if k != "report_hash"}; self.assertEqual(rep["report_hash"], sha(body)); text = json.dumps(rep); self.assertNotIn(CANARY, text); self.assertNotIn("127.0.0.1", text); self.assertEqual(scan(rep, "report", extra_literals=(CANARY,)), [])
    def test_work_that_only_a_human_can_do_is_flagged_not_hidden(self):
        for name in NAMES:
            with self.subTest(msg=name): _, pd, rep = full(name); c = by_id(rep, "human_work_remaining")[0]; self.assertEqual(c["result"], "ATTENTION" if pd["unresolved"] else "PASS"); self.assertTrue(rep["summary"]["ATTENTION"] >= 1)
    def test_writes_are_checked_where_the_draft_has_them_and_skipped_with_a_reason_where_it_does_not(self):
        _, _, rep = full(NAMES[0]); self.assertEqual(results(rep)["write_roundtrip:Account"], "PASS"); self.assertEqual(by_id(rep, "write_roundtrip:Account")[0]["detail"]["effects"], 1); na = by_id(rep, "write_roundtrip:Property")[0]; self.assertEqual(na["result"], "NOT_APPLICABLE"); self.assertIn("no write endpoint", na["detail"]["reason"])
        _, _, rep = full(NAMES[1]); w = by_id(rep, "write_roundtrip:Customer")[0]; self.assertEqual(w["result"], "ATTENTION"); self.assertIn("missing", w["detail"])
        _, _, rep = full(NAMES[2]); c = by_id(rep, "conformance_kit")[0]["detail"]; self.assertEqual(len(c["not_applicable"]), 3); self.assertTrue(all(x["reason"] for x in c["not_applicable"]))
    def test_the_synthetic_data_is_read_completely_through_the_drafted_paging(self):
        for name in NAMES:
            with self.subTest(msg=name):
                _, _, rep = full(name)
                for c in [c for c in rep["checks"] if c["id"].startswith("read_all:")]: self.assertEqual((c["result"], c["detail"]["read"], c["detail"]["seeded"]), ("PASS", validate.SAMPLE, validate.SAMPLE))
    def test_candidate_mappings_are_measured_not_promoted(self):
        for name in NAMES:
            with self.subTest(msg=name):
                _, pd, rep = full(name); cov = rep["coverage"]["candidates"]; self.assertTrue(cov); self.assertTrue(all(c["state"] in ("CANDIDATE", "AMBIGUOUS") for c in cov)); self.assertTrue(all(c["samples"] > 0 and c["failed"] == 0 for c in cov if c["state"] == "CANDIDATE"))
    def test_two_runs_give_the_same_report(self):
        cd, pd = drafts(NAMES[0]); a = quick(cd, pd); b = quick(cd, pd); self.assertEqual(a["report_hash"], b["report_hash"]); self.assertEqual(a, b)
class OnlySyntheticLoopbackVendorsAreEverUsed(unittest.TestCase):
    def test_a_vendor_that_is_not_marked_synthetic_is_refused_before_it_is_started(self):
        class NotMarked(CrmVendor): SYNTHETIC = False
        started = mock.Mock(); cd, pd = drafts(NAMES[0])
        with mock.patch.object(NotMarked, "start", started), self.assertRaises(RealSystemRefused): validate.validate_synthetic(cd, pd, NotMarked, MODEL_DEF)
        started.assert_not_called()
    def test_loopback_only_refuses_anything_that_is_not_a_marked_vendor_on_loopback(self):
        for url in ("http://example.invalid:80", "https://api.synthetic-vendor.invalid", "http://10.0.0.5:8080", "http://192.168.1.1", "http://127.0.0.1.evil.invalid:80", "http://[2001:db8::1]:80", "http://0.0.0.0:80", "http://localhost.evil.invalid", "http://", ""):
            with self.subTest(msg=url), self.assertRaises(RealSystemRefused): validate.loopback_only(Stub(url))
        for url in ("http://127.0.0.1:1", "http://localhost:80", "http://[::1]:80"):
            with self.subTest(msg="unmarked " + url), self.assertRaises(RealSystemRefused): validate.loopback_only(Stub(url, synthetic=False))
            validate.loopback_only(Stub(url))
    def test_the_harness_changes_only_the_destination_the_credential_stand_in_and_the_timeouts(self):
        cd, _ = drafts(NAMES[1]); v = VENDORS[NAMES[1]](); v.start()
        try: extra, notes = validate.harness_overrides(cd["config"], v)
        finally: v.stop()
        self.assertEqual(set(extra), {"base_url", "allowed_hosts", "allow_insecure_loopback", "connect_timeout", "request_timeout", "total_deadline", "credential_ref", "token_url"}); self.assertEqual(extra["credential_ref"], "secretref:synthetic-validation"); self.assertTrue(extra["base_url"].startswith("http://127.0.0.1:")); self.assertTrue(extra["token_url"].startswith("http://127.0.0.1:")); self.assertEqual(len(notes), 6)
        cfg = copy.deepcopy(cd["config"]); cfg["auth"] = "NONE"; cfg["token_url"] = None
        v = VENDORS[NAMES[0]](); v.start()
        try: extra, _ = validate.harness_overrides(cfg, v)
        finally: v.stop()
        self.assertNotIn("credential_ref", extra); self.assertNotIn("token_url", extra)
    def test_the_real_vendor_credential_never_comes_from_the_draft_and_the_stand_in_is_a_reference_name(self):
        self.assertRegex(validate.SYNTHETIC_CREDENTIAL_REF, r"^secretref:"); cd, pd = drafts(NAMES[0]); self.assertIsNone(cd["config"]["credential_ref"])
    def test_the_vendor_is_stopped_even_when_validation_fails_half_way(self):
        cd, pd = drafts(NAMES[0]); made = []
        def factory(): v = CrmVendor(); made.append(v); return v
        with mock.patch.object(validate, "_validate", side_effect=RuntimeError("boom")), self.assertRaises(RuntimeError): validate.validate_synthetic(cd, pd, factory, MODEL_DEF)
        self.assertEqual(len(made), 1); import socket
        with self.assertRaises(OSError): socket.create_connection(("127.0.0.1", int(made[0].url.rsplit(":", 1)[1])), timeout=0.5).close()           # nothing listens any more
class DefectsInADraftShowUpAsFailures(unittest.TestCase):
    def test_wrong_paging_parameters_are_caught_by_reading_everything(self):
        cd, pd = drafts(NAMES[0]); cd["config"]["entities"]["Account"]["list"]["cursor_param"] = "wrong_param"; rep = quick(cd, pd); self.assertEqual(results(rep)["read_all:Account"], "FAIL"); self.assertFalse(rep["all_checks_passed"])
    def test_a_wrong_items_path_is_caught(self):
        cd, pd = drafts(NAMES[0]); cd["config"]["entities"]["Account"]["list"]["items_path"] = ["nothing_here"]; rep = quick(cd, pd); self.assertEqual(results(rep)["read_all:Account"], "FAIL")
    def test_a_candidate_transform_that_cannot_handle_the_data_is_caught_by_the_shadow_translation(self):
        cd, pd = drafts(NAMES[0]); m = [m for m in pd["pack"]["mappings"] if m["source_ref"] == "Account.profile.name"][0]; m["inbound"]["transform"] = {"kind": "DETERMINISTIC_FUNCTION", "parameters": {"in": "cents_to_decimal"}, "deterministic": True}; rep = quick(cd, pd)
        self.assertEqual(results(rep)["shadow_translate:Account.profile.name"], "FAIL"); self.assertFalse(rep["all_checks_passed"])
    def test_a_candidate_whose_values_leave_the_canonical_type_is_caught(self):
        cd, pd = drafts(NAMES[0]); m = [m for m in pd["pack"]["mappings"] if m["source_ref"] == "Account.balance_cents"][0]; m["inbound"]["transform"] = {"kind": "IDENTITY", "parameters": {}, "deterministic": True}; rep = quick(cd, pd); self.assertEqual(results(rep)["shadow_translate:Account.balance_cents"], "FAIL")
    def test_a_validated_mapping_in_a_draft_is_a_failure(self):
        cd, pd = drafts(NAMES[0]); pd["pack"]["mappings"][0]["mapping_state"] = "VALIDATED"; rep = quick(cd, pd); self.assertEqual(results(rep)["draft_is_unapproved"], "FAIL"); self.assertEqual(by_id(rep, "draft_is_unapproved")[0]["detail"]["validated_or_trusted_mappings"], [pd["pack"]["mappings"][0]["mapping_id"]])
    def test_an_approved_state_a_credential_or_a_changed_authority_in_a_draft_is_a_failure(self):
        for label, mut in (("draft_state", lambda c, p: c.update(draft_state="APPROVED")), ("credential", lambda c, p: c["config"].update(credential_ref="secretref:x")), ("authority", lambda c, p: p.update(authority="GOVERNOR")), ("pack state", lambda c, p: p.update(draft_state="APPROVED"))):
            with self.subTest(msg=label): cd, pd = drafts(NAMES[0]); mut(cd, pd); self.assertEqual(results(quick(cd, pd))["draft_is_unapproved"], "FAIL")
    def test_secret_material_in_a_draft_is_a_failure_and_never_repeated_in_the_report(self):
        cd, pd = drafts(NAMES[0]); cd["determined"].append({"field": "note", "value": "carries " + CANARY}); rep = quick(cd, pd); c = by_id(rep, "no_secret_material")[0]; self.assertEqual(c["result"], "FAIL"); self.assertNotIn(CANARY, json.dumps(rep)); self.assertTrue(c["detail"]["findings"])
        cd, pd = drafts(NAMES[0]); pd["items"][0]["note"] = "Authorization: Bearer abcdef0123456789xyz"; self.assertEqual(results(quick(cd, pd))["no_secret_material"], "FAIL")
    def test_a_configuration_the_connector_refuses_stops_the_report_early_with_a_failure(self):
        cd, pd = drafts(NAMES[0]); cd["config"]["entities"]["Account"]["list"]["pagination"] = "bogus"; rep = quick(cd, pd); self.assertEqual(results(rep)["connector_constructs"], "FAIL"); self.assertFalse(rep["all_checks_passed"]); self.assertFalse([c for c in rep["checks"] if c["id"].startswith("read_all")])
    def test_a_wrong_write_path_is_caught_by_the_write_round_trip(self):
        cd, pd = drafts(NAMES[0]); cd["config"]["entities"]["Account"]["write"]["path"] = "/nonexistent/{id}"; rep = quick(cd, pd); self.assertEqual(results(rep)["write_roundtrip:Account"], "FAIL")
    def test_a_wrong_authentication_header_is_caught_by_the_kit_and_by_every_read(self):
        cd, pd = drafts(NAMES[0]); cd["config"]["auth_header"] = "X-Wrong-Header"; rep = validate.validate_synthetic(cd, pd, VENDORS[NAMES[0]], MODEL_DEF); r = results(rep); self.assertFalse(rep["all_checks_passed"])
        self.assertEqual((r["conformance_kit"], r["read_all:Account"], r["read_all:Property"], r["write_roundtrip:Account"]), ("FAIL", "FAIL", "FAIL", "FAIL")); self.assertTrue(all(v == "NOT_APPLICABLE" for k, v in r.items() if k.startswith("shadow_translate")))
    def test_a_draft_with_no_mappings_is_still_reported(self):
        cd, pd = drafts(NAMES[0]); pd["pack"] = None; rep = quick(cd, pd); self.assertEqual(rep["status"], "PRESENTED_FOR_HUMAN_APPROVAL"); self.assertFalse([c for c in rep["checks"] if c["id"].startswith("shadow_translate")])
class TheConformanceRunner(unittest.TestCase):
    def test_a_connector_that_breaks_the_contract_fails_the_kit(self):
        cd, pd = drafts(NAMES[0]); cd["config"]["entities"]["Account"]["list"]["items_path"] = ["nothing_here"]; r = validate.run_conformance(cd, CrmVendor); self.assertTrue(r["failed"]); self.assertGreater(r["ran"], 0)
    def test_write_tests_are_listed_as_not_applicable_when_the_draft_cannot_write(self):
        cd, pd = drafts(NAMES[0]); 
        for e in cd["config"]["entities"].values(): e["write"] = None
        r = validate.run_conformance(cd, CrmVendor); self.assertEqual({x["test"] for x in r["not_applicable"]}, set(validate.WRITE_TESTS)); self.assertEqual(r["failed"], [])
    def test_the_idempotency_test_is_skipped_only_when_no_idempotency_header_is_declared(self):
        cd, pd = drafts(NAMES[0]); cd["config"]["idempotency_header"] = None; r = validate.run_conformance(cd, CrmVendor); self.assertEqual({x["test"] for x in r["not_applicable"]}, set(validate.IDEMPOTENCY_TESTS))
if __name__ == "__main__": unittest.main()

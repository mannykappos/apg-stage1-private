import unittest
from auif.ai_boundary import ProposerSandbox
from auif_onboard import matching, planner
from auif_onboard.proposer import DeterministicProposer
from synthetic.packs import MODEL_DEF
C = planner.concepts(MODEL_DEF)
class MatchingTests(unittest.TestCase):
    def test_tokens_split_snake_kebab_camel_and_dots(self):
        self.assertEqual(matching.tokens("profileEmailAddr"), ["profile", "email", "addr"]); self.assertEqual(matching.tokens("a.b-c_d"), ["a", "b", "c", "d"]); self.assertEqual(matching.tokens("HTTPServer2"), ["httpserver2"]); self.assertEqual(matching.tokens(""), [])
    def test_an_exact_word_beats_a_synonym_and_parents_count_a_quarter(self):
        self.assertEqual(matching.score("title", "title"), 1.0); self.assertEqual(matching.score("name", "title"), 0.7); self.assertGreater(matching.score("title", "title"), matching.score("name", "title"))
        self.assertEqual(matching.score("profile.name", "display_name"), 0.5); self.assertEqual(matching.score("x.owner.thing", "owner_ref"), 0.125); self.assertEqual(matching.score("unrelated", "display_name"), 0.0)
        self.assertEqual(matching.score("state", "lifecycle_state"), 1.0); self.assertEqual(matching.score("status", "lifecycle_state"), 0.7); self.assertEqual(matching.score("", "x"), 0.0); self.assertEqual(matching.score("owner_id", "owner_ref"), 1.0)
    def test_entity_names_match_by_word_or_generic_synonym(self):
        self.assertEqual(matching.concept_name_score("Ticket", "Task"), 1.0); self.assertEqual(matching.concept_name_score("customers", "Party"), 1.0); self.assertEqual(matching.concept_name_score("Property", "Property"), 1.0); self.assertEqual(matching.concept_name_score("Widget", "Party"), 0.0)
        self.assertEqual(matching.concept_name_score("Listings", "module.x.Property"), 1.0)
    def test_assignment_is_one_to_one_deterministic_and_leaves_ties_for_a_human(self):
        pairs, ties = matching.assign(["a.name", "b.name"], ["display_name"]); self.assertEqual((pairs, ties), ([], ["a.name", "b.name"]))
        pairs, ties = matching.assign(["name", "email"], ["display_name", "contact_email"]); self.assertEqual([(f, a) for f, a, _, _ in pairs], [("email", "contact_email"), ("name", "display_name")]); self.assertEqual(ties, [])
        pairs, _ = matching.assign(["title", "name"], ["title"]); self.assertEqual([(f, a) for f, a, _, _ in pairs], [("title", "title")])
        pairs, _ = matching.assign(["status"], ["lifecycle_state", "stage"]); self.assertEqual(len(pairs), 1); self.assertEqual(pairs[0][3], ["stage"] if pairs[0][1] == "lifecycle_state" else ["lifecycle_state"])
        self.assertEqual(matching.assign(["zzz"], ["display_name"]), ([], [])); self.assertEqual(matching.assign(["name"], ["display_name"], lambda f, a: False), ([], []))
    def test_enum_matching_never_guesses(self):
        self.assertEqual(matching.enum_match(["open", "closed"], ["OPEN", "CLOSED"]), ({"open": "OPEN", "closed": "CLOSED"}, [])); self.assertEqual(matching.enum_match(["act", "sus"], ["ACTIVE", "INACTIVE", "ARCHIVED"]), ({"act": "ACTIVE"}, ["sus"]))
        m, u = matching.enum_match(["a", "x"], ["AB", "AC"]); self.assertEqual((m, u), ({}, ["a", "x"])); m, u = matching.enum_match(["act", "active"], ["ACTIVE"]); self.assertEqual((m, u), ({}, ["act", "active"])); self.assertEqual(matching.enum_match([0, 1], ["ACTIVE"]), ({}, ["0", "1"]))
        self.assertEqual(matching.enum_match(["listed"], ["AVAILABLE"]), ({}, ["listed"]))
class PlannerTests(unittest.TestCase):
    def f(self, name, t="string", **kw): return dict({"name": name, "type": t}, **kw)
    def test_concepts_are_core_only_and_carry_types_values_and_required(self):
        self.assertEqual(sorted(C), ["Event", "Party", "Property", "Task"]); self.assertEqual(C["Party"]["lifecycle_state"], {"type": "ENUM", "values": ["ACTIVE", "INACTIVE", "ARCHIVED"], "required": False}); self.assertTrue(C["Party"]["display_name"]["required"])
    def test_an_entity_resembling_nothing_has_no_concept(self):
        p = planner.plan_entity("Widgets", [self.f("zork"), self.f("quux")], C); self.assertEqual((p["chosen"], p["ambiguous"]), ([], False))
    def test_a_clear_winner_is_chosen_and_a_close_second_makes_the_entity_ambiguous(self):
        p = planner.plan_entity("Thing", [self.f("title"), self.f("status", "string", enum=["open", "closed"])], C); self.assertEqual(p["chosen"], ["Task"]); self.assertFalse(p["ambiguous"])
        p = planner.plan_entity("Thing", [self.f("name"), self.f("street"), self.f("city"), self.f("email")], C); self.assertEqual(p["chosen"][0] in ("Party", "Property"), True)
        amb = planner.plan_entity("Thing", [self.f("name"), self.f("title"), self.f("state", "string", enum=["ACTIVE", "INACTIVE", "ARCHIVED"]), self.f("status")], C); self.assertTrue(set(amb["chosen"]) >= {"Party", "Task"} or not amb["ambiguous"])
    def test_unsupported_and_write_only_fields_are_not_planned(self):
        p = planner.plan_entity("Account", [self.f("name"), self.f("pw", "string", write_only=True), self.f("tags", "array")], C); self.assertEqual([f for f, *_ in p["assignments"]["Party"][0]], ["name"])
    def test_transform_choice_for_every_canonical_type(self):
        ch = lambda f, a, c: planner.choose_transform(f, a, C[c][a])
        self.assertEqual(ch(self.f("lifecycle_state", enum=["ACTIVE", "INACTIVE", "ARCHIVED"]), "lifecycle_state", "Party")[0]["kind"], "IDENTITY"); t, note = ch(self.f("state", enum=["active", "inactive", "archived"]), "lifecycle_state", "Party"); self.assertEqual((t["kind"], t["parameters"]["map"]["active"]), ("ENUM_MAP", "ACTIVE"))
        self.assertIsNone(ch(self.f("state", enum=["a"]), "lifecycle_state", "Party")[0]); self.assertIn("not an enumeration", ch(self.f("state"), "lifecycle_state", "Party")[1]); self.assertIsNone(ch(self.f("state", "integer", enum=[0, 1]), "lifecycle_state", "Party")[0])
        self.assertEqual(ch(self.f("balance_cents", "integer"), "balance", "Party")[0]["parameters"], {"in": "cents_to_decimal"}); self.assertEqual(ch(self.f("balance", "number"), "balance", "Party")[0]["parameters"], {"in": "dollars_to_decimal"}); self.assertEqual(ch(self.f("balance", "string"), "balance", "Party")[0]["parameters"], {"in": "dollars_to_decimal"})
        self.assertIn("ASSUMES", ch(self.f("balance", "integer"), "balance", "Party")[1]); self.assertIsNone(ch(self.f("balance", "boolean"), "balance", "Party")[0])
        self.assertEqual(ch(self.f("display_name"), "display_name", "Party")[0]["kind"], "IDENTITY"); self.assertEqual(ch(self.f("full_name"), "display_name", "Party")[0]["kind"], "RENAME"); self.assertEqual(ch(self.f("owner"), "owner_ref", "Property")[0]["kind"], "RENAME")
        ts = {"type": "TIMESTAMP", "values": None, "required": False}; self.assertEqual(planner.choose_transform(self.f("t", format="date-time"), "when", ts)[0]["kind"], "IDENTITY"); self.assertIsNone(planner.choose_transform(self.f("t", format="uuid"), "when", ts)[0]); self.assertIsNone(planner.choose_transform(self.f("t", "integer"), "when", ts)[0])
        b = {"type": "BOOLEAN", "values": None, "required": False}; i = {"type": "INTEGER", "values": None, "required": False}; self.assertEqual(planner.choose_transform(self.f("b", "boolean"), "b", b)[0]["kind"], "IDENTITY"); self.assertIsNone(planner.choose_transform(self.f("b", "string"), "b", b)[0]); self.assertEqual(planner.choose_transform(self.f("n", "integer"), "n", i)[0]["kind"], "IDENTITY"); self.assertIsNone(planner.choose_transform(self.f("n", "string"), "n", i)[0])
        self.assertIsNone(planner.choose_transform(self.f("o", "object"), "o", {"type": "OBJECT", "values": None, "required": False})[0])
    def test_cents_hint_reads_only_the_last_name_part(self):
        self.assertTrue(planner.name_hint_cents("a.balance_cents")); self.assertTrue(planner.name_hint_cents("minorAmount")); self.assertFalse(planner.name_hint_cents("cents.balance")); self.assertFalse(planner.name_hint_cents("balance"))
class ProposerTests(unittest.TestCase):
    def sandbox(self, fields): return ProposerSandbox([{"name": n, "detail": d} for n, d in fields], {c: sorted(a) for c, a in C.items()})
    def test_it_proposes_from_the_sandbox_alone_and_records_what_it_skipped(self):
        p = DeterministicProposer(MODEL_DEF); out = p.propose(self.sandbox([("Customer.name", {"type": "string"}), ("Customer.email", {"type": "string"}), ("Customer.secret_blob", {"type": "object"}), ("Customer.pw", {"type": "string", "write_only": True}), ("Customer.id", {"type": "string"}), ("Customer.zork", {"type": "string"})]))
        self.assertEqual(sorted((o["source_ref"], o["canonical_ref"]) for o in out), [("Customer.email", "Party.contact_email"), ("Customer.name", "Party.display_name")]); self.assertEqual(sorted(p.skipped), ["Customer.id", "Customer.pw", "Customer.secret_blob", "Customer.zork"])
        self.assertIn("write-only", p.skipped["Customer.pw"]); self.assertIn("not mappable", p.skipped["Customer.secret_blob"]); self.assertIn("identifier", p.skipped["Customer.id"]); self.assertIn("resembles", p.skipped["Customer.zork"]); self.assertEqual(set(p.notes), {("Customer.email", "Party.contact_email"), ("Customer.name", "Party.display_name")})
    def test_an_entity_that_resembles_nothing_yields_no_proposal_and_every_field_is_listed_as_skipped(self):
        p = DeterministicProposer(MODEL_DEF); self.assertEqual(p.propose(self.sandbox([("Zz.a", {"type": "string"}), ("Zz.b", {"type": "string"})])), []); self.assertEqual(sorted(p.skipped), ["Zz.a", "Zz.b"]); self.assertIn("no canonical concept", p.skipped["Zz.a"])
    def test_a_field_that_ties_is_left_to_a_human(self):
        p = DeterministicProposer(MODEL_DEF); out = p.propose(self.sandbox([("Person.name", {"type": "string"}), ("Person.owner.name", {"type": "string"}), ("Person.email", {"type": "string"})])); self.assertEqual([o["source_ref"] for o in out], ["Person.email"]); self.assertIn("tied", p.skipped["Person.name"]); self.assertIn("tied", p.skipped["Person.owner.name"])
    def test_an_ambiguous_entity_gives_alternatives_from_the_other_concept(self):
        p = DeterministicProposer(MODEL_DEF); sb = self.sandbox([("Thing.title", {"type": "string"}), ("Thing.state", {"type": "string", "enum": ["OPEN", "CLOSED"]})]); plan = planner.plan_entity("Thing", [{"name": "title", "type": "string"}, {"name": "state", "type": "string", "enum": ["OPEN", "CLOSED"]}], C)
        self.assertEqual((plan["chosen"], plan["ambiguous"]), (["Task", "Party"], True)); out = {o["source_ref"]: o for o in p.propose(sb)}; self.assertEqual(out["Thing.title"]["canonical_ref"], "Task.title"); self.assertEqual(out["Thing.title"]["alternatives"], ["Party.display_name"])
        self.assertEqual((out["Thing.state"]["canonical_ref"], out["Thing.state"]["alternatives"]), ("Task.status", ["Party.lifecycle_state"]))
    def test_the_proposer_never_sees_more_than_the_sandbox_gives_and_holds_a_copy_of_the_model(self):
        import copy; m = copy.deepcopy(MODEL_DEF); p = DeterministicProposer(m); m["concepts"].clear(); self.assertEqual(sorted(p._concepts), ["Event", "Party", "Property", "Task"])
if __name__ == "__main__": unittest.main()

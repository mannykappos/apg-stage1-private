"""The deterministic name matching, directly: thresholds, tie handling, enumerations that are never guessed."""
import unittest
from auif_onboard import matching, planner
from auif_onboard.tests.support import NAMES, drafts
from auif_onboard.proposer import DeterministicProposer
from auif_onboard import pack_draft
from synthetic.packs import MODEL_DEF
class Names(unittest.TestCase):
    def test_tokens_split_snake_kebab_camel_and_dotted_names(self):
        self.assertEqual(matching.tokens("fullName"), ["full", "name"]); self.assertEqual(matching.tokens("full_name-x.y"), ["full", "name", "x", "y"]); self.assertEqual(matching.tokens("HTTPCode2"), ["httpcode2"]); self.assertEqual(matching.tokens(""), [])
    def test_an_exact_word_beats_a_synonym_and_a_parent_counts_a_quarter(self):
        self.assertEqual(matching.score("name", "name"), 1.0); self.assertEqual(matching.score("title", "name"), 0.7); self.assertEqual(matching.score("profile.name", "name"), 1.0); self.assertEqual(matching.score("address.street", "street"), 1.0)
        self.assertEqual(matching.score("profile.name", "profile_title"), 0.475); self.assertGreater(matching.score("name", "display_name"), matching.score("title", "display_name"))
    def test_identifier_words_are_ignored_in_a_longer_name_so_they_cannot_make_a_match(self):
        self.assertEqual(matching.score("customer_id", "id_card"), 0.0); self.assertEqual(matching.score("id", "id"), 1.0)
    def test_unrelated_names_score_zero(self): self.assertEqual(matching.score("zork", "display_name"), 0.0); self.assertEqual(matching.score("", "name"), 0.0)
    def test_entity_names_match_by_synonym_group_and_plural_but_not_by_one_shared_word(self):
        self.assertEqual(matching.concept_name_score("Ticket", "Task"), 1.0); self.assertEqual(matching.concept_name_score("Customers", "Party"), 1.0); self.assertEqual(matching.concept_name_score("CustomerEvent", "Event"), 0.0); self.assertEqual(matching.concept_name_score("Gizmo", "Party"), 0.0)
        self.assertEqual(matching.concept_name_score("Account", "module.x.Listing"), 0.0)
class Assignment(unittest.TestCase):
    def test_a_weak_alternative_is_not_listed_as_a_runner_up(self):
        pairs, ties = matching.assign(["name"], ["name", "title_x"]); self.assertEqual((pairs, ties), ([("name", "name", 1.0, [])], []))
    def test_a_close_alternative_is_listed_as_a_runner_up(self):
        pairs, _ = matching.assign(["name"], ["display_name", "name_x"]); self.assertEqual(pairs, [("name", "display_name", 0.5, ["name_x"])])
    def test_two_fields_cannot_take_one_attribute_and_equal_scores_are_left_for_a_human(self):
        pairs, ties = matching.assign(["title", "label"], ["name"]); self.assertEqual(pairs, []); self.assertEqual(ties, ["label", "title"])
        pairs, ties = matching.assign(["name", "title"], ["name", "label"]); self.assertEqual(sorted((p[0], p[1]) for p in pairs), [("name", "name"), ("title", "label")]); self.assertEqual(ties, [])
    def test_the_strongest_match_is_assigned_first(self):
        pairs, _ = matching.assign(["name", "title"], ["name"]); self.assertEqual([(p[0], p[1]) for p in pairs], [("name", "name")])
    def test_matches_below_the_threshold_are_not_assigned(self): self.assertEqual(matching.assign(["x_street_y"], ["street_name_value_other_thing"]), ([], []))
    def test_compatibility_is_respected(self): self.assertEqual(matching.assign(["name"], ["name"], lambda f, a: False), ([], []))
class Enumerations(unittest.TestCase):
    def test_equality_ignoring_case_and_prefixes_in_both_directions_match(self):
        self.assertEqual(matching.enum_match(["act", "SUS"], ["ACTIVE", "SUSPENDED"]), ({"act": "ACTIVE", "SUS": "SUSPENDED"}, [])); self.assertEqual(matching.enum_match(["active_now"], ["ACTIVE", "INACTIVE"]), ({"active_now": "ACTIVE"}, []))
    def test_an_exact_match_is_preferred_to_a_prefix_match(self): self.assertEqual(matching.enum_match(["act"], ["act", "actor"]), ({"act": "act"}, []))
    def test_a_value_with_several_counterparts_is_never_guessed(self): self.assertEqual(matching.enum_match(["ac"], ["ACTIVE", "ACTOR"]), ({}, ["ac"]))
    def test_a_one_letter_value_is_never_matched_by_prefix(self): self.assertEqual(matching.enum_match(["a"], ["ACTIVE", "SOLD"]), ({}, ["a"]))
    def test_two_source_values_mapped_to_one_canonical_value_are_both_left_unmatched(self):
        m, un = matching.enum_match(["act", "active"], ["ACTIVE", "SOLD"]); self.assertEqual(m, {}); self.assertEqual(un, ["act", "active"])
    def test_integer_source_values_are_compared_as_text(self): self.assertEqual(matching.enum_match([0, 1], ["ACTIVE"]), ({}, ["0", "1"]))
class Planner(unittest.TestCase):
    D = planner.concepts(MODEL_DEF)
    def test_only_core_concepts_are_targets(self): self.assertEqual(sorted(self.D), ["Event", "Party", "Property", "Task"]); self.assertTrue(self.D["Party"]["display_name"]["required"])
    def test_a_field_of_the_wrong_type_is_not_paired_with_an_attribute(self): self.assertEqual(planner.plan_entity("Customer", [{"name": "name", "type": "integer"}], self.D)["assignments"]["Party"], ([], []))
    def test_write_only_fields_are_never_planned(self):
        plan = planner.plan_entity("Customer", [{"name": "name", "type": "string", "write_only": True}], self.D); self.assertEqual(plan["assignments"]["Party"], ([], []))
    def test_an_entity_resembling_nothing_has_no_concept(self): p = planner.plan_entity("Gizmo", [{"name": "zork", "type": "string"}], self.D); self.assertEqual((p["chosen"], p["ambiguous"]), ([], False))
    def test_the_best_scoring_concept_is_chosen_first(self):
        p = planner.plan_entity("Ticket", [{"name": "title", "type": "string"}, {"name": "state", "type": "string", "enum": ["open", "closed"]}], self.D); self.assertEqual(p["chosen"][0], "Task"); self.assertFalse(p["ambiguous"]); self.assertGreater(p["scores"]["Task"], p["scores"]["Party"])
    def test_the_entity_name_adds_to_the_score(self):
        f = [{"name": "title", "type": "string"}]; a = planner.plan_entity("Ticket", f, self.D)["scores"]["Task"]; b = planner.plan_entity("Zzz", f, self.D)["scores"]["Task"]; self.assertEqual(round(a - b, 4), 1.0)
    def test_two_concepts_within_the_margin_make_the_entity_ambiguous(self):
        p = planner.plan_entity("Thing", [{"name": "title", "type": "string"}, {"name": "state", "type": "string", "enum": ["open", "closed"]}], self.D); self.assertTrue(p["ambiguous"]); self.assertGreater(len(p["chosen"]), 1)
class ProposerStateIsPerRun(unittest.TestCase):
    def test_notes_and_skipped_reasons_of_an_earlier_run_do_not_leak_into_the_next(self):
        prop = DeterministicProposer(MODEL_DEF); cd1, _ = drafts(NAMES[0]); cd2, _ = drafts(NAMES[2]); pack_draft.draft_pack(cd1, MODEL_DEF, proposer=prop); first = set(prop.skipped) | {k[0] for k in prop.notes}; self.assertTrue(any(k.startswith("Account.") for k in first))
        pack_draft.draft_pack(cd2, MODEL_DEF, proposer=prop); second = set(prop.skipped) | {k[0] for k in prop.notes}; self.assertTrue(second); self.assertFalse([k for k in second if k.startswith("Account.") or k.startswith("Property.")])
if __name__ == "__main__": unittest.main()

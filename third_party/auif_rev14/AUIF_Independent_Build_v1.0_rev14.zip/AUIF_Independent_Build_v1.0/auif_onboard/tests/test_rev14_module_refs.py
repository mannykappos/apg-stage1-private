"""rev14 (finding M8-F1) in the accelerator: a field reference into a MODULE concept (whose name contains dots) is read as <concept>.<attribute> with the attribute after the LAST dot, both when the
accelerator shadow-translates candidate mappings and when a review assembles approved mappings.  A field mapped into another concept than its entity's is still refused.  The two module-concept
tests fail on rev13; the other two are regression guards."""
import unittest
from auif.canonical import CanonicalModel
from auif_onboard.review import ApprovalRefused, ReviewSession
from auif_onboard.validate import _shadow
from synthetic.packs import ID, MODEL_DEF, emap, fmap
L = "module.synthetic-module-2.Listing"
def shadow(canon, ent_concept):
    checks, cov = [], {"candidates": []}
    _shadow({"pack": {"mappings": [emap("e", "ENTITY", "Ticket", ent_concept, "Ticket"), fmap("f", "Ticket.title", canon, ID, None, state="CANDIDATE")]}}, CanonicalModel(MODEL_DEF), {"Ticket": [{"title": "Bright flat"}, {"title": "Garden"}]}, checks, cov)
    return cov["candidates"]
class TestShadowTranslation(unittest.TestCase):
    def test_a_module_concept_candidate_is_measured_against_its_real_attribute(self):
        cands = shadow(L + ".headline", L); self.assertEqual([(c["samples"], c["ok"], c["failed"]) for c in cands], [(2, 2, 0)])
    def test_a_core_concept_candidate_is_measured_as_before(self):
        cands = shadow("Party.display_name", "Party"); self.assertEqual([(c["samples"], c["ok"], c["failed"]) for c in cands], [(2, 2, 0)])
class TestReviewAssembly(unittest.TestCase):
    def ms(self, canon): return [emap("e", "ENTITY", "Ticket", L, "Ticket", writable=False), fmap("f", "Ticket.title", canon, ID, None)]
    def test_a_field_into_its_entitys_module_concept_is_consistent(self):
        ReviewSession._consistent(None, self.ms(L + ".headline"))
    def test_a_field_into_another_concept_is_still_refused(self):
        for bad in ("Party.display_name", "module.synthetic-module-2.headline"):
            with self.assertRaises(ApprovalRefused, msg=bad): ReviewSession._consistent(None, self.ms(bad))
if __name__ == "__main__": unittest.main()

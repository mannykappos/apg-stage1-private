"""No secret is generated, inferred, persisted or emitted: the scanner's rules, the design that never reads secret-bearing parts of an API description, and the screens on every output."""
import copy, io, json, os, tempfile, unittest
from auif_onboard import cli, config_gen, openapi, pack_draft, secrets_scan, validate
from auif_onboard.errors import ApprovalRefused, OnboardError, SecretLeak, SpecRejected
from auif_onboard.review import ReviewSession
from auif_onboard.tests.support import CANARY, NAMES, REVIEWER, approval, arr, drafts, drafts_for_doc, get_list, mini, q, spec_bytes, THING
from auif_onboard.tests.test_review import decide, item
from auif_onboard.tests.vendors import VENDORS
from synthetic.packs import MODEL_DEF
SK = "sk_live_" + "a1B2c3D4e5F6g7H8i9J0"; PW = "hunter2hunter2"; JWT = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dBjftJeZ4CVPmB92K27uhbUJU1p1r"; PEM = "-----BEGIN RSA PRIVATE KEY-----\nMIIB"
def thing_doc(**kw):
    d = mini({"/things": get_list({"type": "object", "properties": {"items": arr("Thing"), "next_cursor": {"type": "string"}}}, [q("cursor")])}, copy.deepcopy(THING), security=[], **kw); return d
def gen(doc):
    d, h = openapi.load(json.dumps(doc).encode()); cd = config_gen.draft_config(openapi.parse(d), h); return cd, pack_draft.draft_pack(cd, MODEL_DEF)
class TheScanner(unittest.TestCase):
    def rules(self, obj): return {r for _, r in secrets_scan.scan(obj)}
    def test_each_rule_fires_on_its_kind_of_material(self):
        cases = {"private-key-block": PEM, "bearer-token": "Authorization: Bearer abcdef0123456789", "basic-credentials": "Basic dXNlcjpwYXNzd29yZA==", "provider-key": SK, "jwt": JWT, "url-userinfo": "https://user:%s@host.invalid/x" % PW,
                 "secret-in-query": "https://h.invalid/p?api_key=abcd1234", "assignment": "password = " + PW, "high-entropy-token": "Zk3Qm9Xr7Lp2Vb8Nc4Ty6Hw1Js5Dg0Af"}
        for rule, sample in cases.items():
            with self.subTest(msg=rule): self.assertIn(rule, self.rules({"v": sample})); self.assertIn(rule, self.rules(["x", {"k": [sample]}]))
    def test_a_secret_named_field_with_a_value_is_flagged_unless_the_value_is_a_reference(self):
        for key in ("password", "client_secret", "api_key", "access_token", "private_key", "token", "Credential", "api-key"):
            with self.subTest(msg=key): self.assertEqual(self.rules({key: "plainvalue"}), {"secret-named-field"}); self.assertEqual(self.rules({key: "secretref:a.b-c"}), set()); self.assertEqual(self.rules({key: None}), set())
    def test_keys_are_scanned_too(self):
        self.assertIn("provider-key", self.rules({SK: 1})); self.assertTrue([p for p, _ in secrets_scan.scan({SK: 1})][0].endswith("#key"))
    def test_a_known_literal_is_found_anywhere_inside_a_string(self):
        self.assertEqual(self.rules({"v": "x"}), set()); self.assertEqual({r for _, r in secrets_scan.scan({"v": "pre-%s-post" % CANARY}, extra_literals=(CANARY,))}, {"known-secret-literal"}); self.assertEqual(secrets_scan.scan({"v": "x"}, extra_literals=("",)), [])
    def test_ordinary_material_is_not_flagged(self):
        ok = ("https://api.synthetic-vendor.invalid/v1/things", "secretref:crm.api-key", "onb-synthetic-ledger-vendor-1a2b3c4d-draft", "synthetic-rest-crm", "a" * 64, "0123456789abcdef" * 4, "Party.display_name", "cents_to_decimal", "the token endpoint is not https", "password policy applies", "2026-10-07T01:00:00Z", "customers.amount_dollars", "ACTIVE", "x" * 40, "profile.email_address.line_one")
        for s in ok:
            with self.subTest(msg=s[:30]): self.assertEqual(self.rules({"v": s}), set())
        self.assertEqual(self.rules({"token_url": "https://a.invalid/token", "credential_ref": "secretref:x", "auth_header": "X-Api-Key", "contains_secrets": False}), set())
    def test_findings_name_the_path_and_rule_but_never_repeat_the_matched_text(self):
        for sample in (SK, JWT, "password = " + PW):
            f = secrets_scan.scan({"a": {"b": [sample]}}, "doc"); self.assertTrue(f); self.assertEqual(f[0][0], "doc.a.b[0]"); self.assertNotIn(PW, json.dumps(f)); self.assertNotIn(SK, json.dumps(f)); self.assertNotIn("eyJ", json.dumps(f))
        with self.assertRaises(SecretLeak) as cm: secrets_scan.assert_clean({"a": SK}, "thing"); 
        self.assertNotIn(SK, str(cm.exception)); self.assertIn("thing.a", str(cm.exception))
    def test_a_long_low_entropy_string_is_not_a_token_but_a_random_tail_after_identifier_words_is(self):
        self.assertEqual(self.rules({"v": "ab1" * 12}), set()); self.assertIn("high-entropy-token", self.rules({"v": "onb-synthetic-ledger-Zk3Qm9Xr7Lp2Vb8Nc4Ty6Hw1Js5Dg0Af"}))
    def test_each_provider_key_shape_is_detected(self):
        for s in ("ghp_a1B2c3D4e5F6g7H8i9J0k1L2m3N4o5P6q7R8", "AKIAABCDEFGHIJKLMNOP", "xoxb-1234567890-abcdefghij", "sk_test_a1B2c3D4e5F6g7H8", "pk_live_a1B2c3D4e5F6g7H8", "rk-live-a1B2c3D4e5F6g7H8"):
            with self.subTest(msg=s[:8]): self.assertIn("provider-key", self.rules({"v": s}))
    def test_findings_come_back_sorted_by_path(self):
        r = secrets_scan.scan({"b": SK, "a": SK, "c": [SK]}, "x"); self.assertEqual(r, sorted(r)); self.assertEqual([p for p, _ in r if _ == "provider-key"], ["x.a", "x.b", "x.c[0]"])
    def test_oversized_input_is_reported_not_skipped(self):
        big = [0] * (secrets_scan.MAX_NODES + 5); self.assertEqual({r for _, r in secrets_scan.scan(big)}, {"too-large-to-scan"})
    def test_assert_clean_returns_its_input(self): o = {"a": 1}; self.assertIs(secrets_scan.assert_clean(o), o)
class SecretBearingPartsOfADescriptionAreNeverRead(unittest.TestCase):
    def test_descriptions_examples_defaults_and_extensions_never_reach_any_output(self):
        d = thing_doc(); d["info"]["description"] = "key " + SK; t = d["components"]["schemas"]["Thing"]; t["properties"]["title"].update({"example": SK, "default": SK, "description": SK}); t["x-secret"] = SK; d["x-key"] = SK; d["paths"]["/things"]["get"]["x-token"] = PW; d["paths"]["/things"]["get"]["description"] = "use " + PW
        d["components"]["securitySchemes"] = {"k": {"type": "apiKey", "in": "header", "name": "X-Key", "description": SK, "x-default": SK}}; d["security"] = [{"k": []}]; cd, pd = gen(d); text = json.dumps([cd, pd]); [self.assertNotIn(s, text) for s in (SK, PW)]
        self.assertEqual(cd["config"]["auth"], "API_KEY"); self.assertIsNone(cd["config"]["credential_ref"])
    def test_the_fixtures_plant_the_canary_in_ignored_text_and_it_never_comes_out(self):
        for name in NAMES:
            with self.subTest(msg=name):
                raw = spec_bytes(name).decode(); self.assertIn(CANARY, raw); cd, pd = drafts(name); self.assertNotIn(CANARY, json.dumps([cd, pd]))
    def test_the_canary_is_absent_from_the_validation_report_the_cli_files_and_the_review_records(self):
        for name in NAMES:
            with self.subTest(msg=name):
                cd, pd = drafts(name); rep = validate.validate_synthetic(cd, pd, VENDORS[name], MODEL_DEF, run_conformance_suite=False); s = ReviewSession(cd, pd, MODEL_DEF); first = [i for i in s.items.values() if i["kind"] == "ENTITY"][0]; s.decide(first["item_id"], approval(first["item_hash"]))
                self.assertNotIn(CANARY, json.dumps([rep, s.ledger, s.approved, s.evidence], default=str))
        with tempfile.TemporaryDirectory() as d:
            sp = os.path.join(d, "spec.json"); open(sp, "wb").write(spec_bytes(NAMES[0])); mp = os.path.join(d, "model.json"); json.dump(MODEL_DEF, open(mp, "w")); out = io.StringIO(); self.assertEqual(cli.main(["draft", "--spec", sp, "--canonical-model", mp, "--out", os.path.join(d, "o")], out), 0)
            for f in os.listdir(os.path.join(d, "o")): self.assertNotIn(CANARY, open(os.path.join(d, "o", f)).read())
            self.assertNotIn(CANARY, out.getvalue())
    def test_credentials_in_server_urls_and_token_urls_are_dropped_with_a_warning_not_copied(self):
        d = thing_doc(); d["servers"] = [{"url": "https://user:%s@mini.synthetic-vendor.invalid/v1" % PW}]; cd, pd = gen(d); self.assertNotIn(PW, json.dumps([cd, pd])); self.assertIsNone(cd["config"]["base_url"]); self.assertTrue([w for w in cd["warnings"] if "credentials" in w])
        d = thing_doc(); d["servers"] = [{"url": "https://mini.synthetic-vendor.invalid/v1?api_key=" + SK}]; cd, pd = gen(d); self.assertNotIn(SK, json.dumps([cd, pd])); self.assertIsNone(cd["config"]["base_url"])
        d = thing_doc(); d["components"]["securitySchemes"] = {"o": {"type": "oauth2", "flows": {"clientCredentials": {"tokenUrl": "https://user:%s@t.invalid/token" % PW, "scopes": {}}}}}; d["security"] = [{"o": []}]; cd, pd = gen(d); self.assertNotIn(PW, json.dumps([cd, pd])); self.assertIsNone(cd["config"]["token_url"])
    def test_secret_like_material_in_a_name_or_value_the_generator_must_copy_stops_the_draft(self):
        d = thing_doc(); d["components"]["schemas"]["Thing"]["properties"]["state"]["enum"] = ["open", SK]
        with self.assertRaises(SecretLeak): gen(d)
        d = thing_doc(); d["components"]["schemas"]["Thing"]["properties"][SK] = {"type": "string"}
        with self.assertRaises(SecretLeak): gen(d)
        d = thing_doc(); d["info"]["title"] = "Mini " + SK
        with self.assertRaises(SecretLeak): gen(d)
        d = thing_doc(); d["paths"]["/things/" + SK] = d["paths"]["/things"]
        with self.assertRaises(SecretLeak): gen(d)
    def test_the_leak_error_never_repeats_the_secret(self):
        d = thing_doc(); d["info"]["title"] = "Mini " + SK
        with self.assertRaises(SecretLeak) as cm: gen(d)
        self.assertNotIn(SK, str(cm.exception))
    def test_the_config_draft_never_carries_a_credential_reference_of_its_own(self):
        for name in NAMES: self.assertIsNone(drafts(name)[0]["config"]["credential_ref"])
class OutputsAreScreened(unittest.TestCase):
    def test_the_cli_refuses_and_writes_nothing_when_an_output_would_carry_a_secret(self):
        d = thing_doc(); d["info"]["title"] = "Mini " + SK
        with tempfile.TemporaryDirectory() as t:
            sp = os.path.join(t, "s.json"); json.dump(d, open(sp, "w")); mp = os.path.join(t, "m.json"); json.dump(MODEL_DEF, open(mp, "w")); out = io.StringIO(); code = cli.main(["draft", "--spec", sp, "--canonical-model", mp, "--out", os.path.join(t, "o")], out)
            self.assertEqual(code, 2); self.assertFalse(os.path.exists(os.path.join(t, "o"))); self.assertNotIn(SK, out.getvalue()); self.assertIn("refused", out.getvalue())
    def test_approvals_that_carry_secrets_are_refused_everywhere_a_human_can_type(self):
        s = ReviewSession(*drafts(NAMES[0]), MODEL_DEF); i = item(s, "FIELD", "Account.profile.name")
        for kw in ({"statement": "I approve this and here is the password = " + PW + " for later"}, {"parameters": {"note": SK}}, {"parameters": {"resolution_evidence": {"evidence_id": "x", "evidence_hash": "a" * 64, "token": PW}}}):
            with self.subTest(msg=str(kw)[:40]), self.assertRaises((ApprovalRefused, SecretLeak)): s.decide(i["item_id"], approval(i["item_hash"], **{k: v for k, v in kw.items() if k != "parameters"}) if "parameters" not in kw else approval(i["item_hash"], **kw["parameters"]))
        self.assertEqual(s.ledger, [])
    def test_config_approval_takes_a_reference_name_and_nothing_else_for_credentials(self):
        s = ReviewSession(*drafts(NAMES[0]), MODEL_DEF); cd = s.config_draft
        for cref in (SK, PW, CANARY, "Bearer abcdef0123456789", "secretref:" + SK[:5] + " " + PW):
            with self.subTest(msg=cref[:12]), self.assertRaises((ApprovalRefused, SecretLeak)): s.approve_config(approval(cd["draft_hash"], credential_ref=cref))
        self.assertIsNone(s.config_decision); out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:crm.api-key")); self.assertEqual(scanned(out), [])
    def test_an_override_cannot_smuggle_a_secret_into_the_approved_config(self):
        s = ReviewSession(*drafts(NAMES[0]), MODEL_DEF); cd = s.config_draft
        for ov in ({"base_url": "https://u:%s@x.invalid/v1" % PW}, {"base_url": "https://x.invalid/v1?api_key=abcd1234"}, {"scope": SK}, {"token_url": "https://x.invalid/t?client_secret=abcd1234"}):
            with self.subTest(msg=str(ov)[:40]), self.assertRaises((ApprovalRefused, SecretLeak)): s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:k", overrides=ov))
    def test_every_artifact_a_session_produces_is_clean(self):
        s = ReviewSession(*drafts(NAMES[0]), MODEL_DEF); decide(s, "ENTITY", "Account", outbound="ENABLE"); decide(s, "FIELD", "Account.profile.name"); s.approve_config(approval(s.config_draft["draft_hash"], credential_ref="secretref:crm.api-key")); out = s.assemble_pack(approval(s.assemble_pack()["assembly_hash"]))
        self.assertEqual(scanned([s.ledger, out, s.config_decision, s.evidence]), [])
def scanned(o): return secrets_scan.scan(o, "x", extra_literals=(CANARY, SK, PW))
if __name__ == "__main__": unittest.main()

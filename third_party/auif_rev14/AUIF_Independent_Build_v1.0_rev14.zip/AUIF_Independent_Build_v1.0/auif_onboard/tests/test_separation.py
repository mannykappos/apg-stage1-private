"""Drafting is separated from approval, and the accelerator is separated from the core: proven by syntax tree, by behaviour, and by seeding deliberate violations into the checker."""
import ast, copy, os, subprocess, sys, unittest
from unittest import mock
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))); sys.path.insert(0, os.path.join(ROOT, "tools"))
import static_checks_onboard as SC
from auif.ai_boundary import AIMappingService
from auif_onboard import AUTHORITY, DRAFT_STATE, config_gen, openapi, pack_draft, validate
from auif_onboard.tests.support import NAMES, drafts, spec_bytes
from auif_onboard.tests.vendors import VENDORS
from synthetic.packs import MODEL_DEF
CORE_HASH = "923de5100f95debbbf63d5ab6e960cee2091ee57abce403792403ff049ac7839"; ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
def seeded(rel, src):
    r = SC.check_source(rel, src); return {k: v for k, v in r.items() if v}
P = lambda name: os.path.join("auif_onboard", name)
class TheTreeIsClean(unittest.TestCase):
    def test_every_static_list_is_empty_and_the_core_hash_is_the_audited_one(self):
        r = SC.run(); self.assertGreaterEqual(r["files_checked"], 14); self.assertEqual({k: v for k, v in r.items() if isinstance(v, list) and v}, {}); self.assertEqual(r["core_tree_sha256"], CORE_HASH)
    def test_the_shipped_checker_exits_zero_on_the_tree(self):
        r = subprocess.run([sys.executable, "tools/static_checks_onboard.py"], cwd=ROOT, capture_output=True, text=True, env=ENV); self.assertEqual((r.returncode, r.stderr), (0, ""))
    def test_importing_the_core_or_the_extensions_never_imports_the_accelerator(self):
        code = "import sys, auif, auif.fabric, auif.ai_boundary, auif_ext, auif_ext.connectors.rest; assert not [m for m in sys.modules if m.startswith('auif_onboard')], 'accelerator imported'"
        r = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True, env=ENV); self.assertEqual((r.returncode, r.stderr), (0, ""))
    def test_importing_the_drafting_modules_does_not_import_the_review_module(self):
        code = "import sys, auif_onboard, auif_onboard.config_gen, auif_onboard.pack_draft, auif_onboard.proposer, auif_onboard.planner, auif_onboard.validate, auif_onboard.openapi, auif_onboard.cli; assert 'auif_onboard.review' not in sys.modules, 'review imported by a drafting module'"
        r = subprocess.run([sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True, env=ENV); self.assertEqual((r.returncode, r.stderr), (0, ""))
    def test_only_the_review_module_names_an_approval_capability(self):
        holders = set()
        for p in SC.files():
            rel = os.path.relpath(p, ROOT)
            for n in ast.walk(ast.parse(open(p).read())):
                name = n.name if isinstance(n, (ast.FunctionDef, ast.ClassDef)) else n.id if isinstance(n, ast.Name) else n.attr if isinstance(n, ast.Attribute) else None
                if name in SC.APPROVAL: holders.add(rel)
        self.assertEqual(holders, {P("review.py")})
    def test_no_core_or_extension_module_calls_a_name_defined_in_the_accelerator(self):
        for sub in ("auif", "auif_ext"):
            for d, _, fs in os.walk(os.path.join(ROOT, sub)):
                for f in fs:
                    if f.endswith(".py"): self.assertNotIn("auif_onboard", open(os.path.join(d, f)).read(), f)
class TheCheckerCatchesViolations(unittest.TestCase):
    def test_each_kind_of_violation_is_detected_when_seeded(self):
        cases = (("import_violations", P("x.py"), "import requests\n"), ("import_violations", P("x.py"), "import numpy\n"), ("governor_or_test_imports", P("x.py"), "from synthetic.world import World\n"), ("governor_or_test_imports", P("x.py"), "import governor_core\n"),
                 ("network_imports", P("x.py"), "import socket\n"), ("network_imports", P("x.py"), "import urllib.request\n"), ("network_imports", P("x.py"), "from http import client\nimport http.client\n"), ("network_imports", P("x.py"), "import asyncio\n"),
                 ("real_system_names", P("x.py"), "URL = 'https://api.xero.com'\n"), ("real_system_names", P("x.py"), "# talks to Salesforce\n"),
                 ("forbidden_constructs", P("x.py"), "print('x')\n"), ("forbidden_constructs", P("x.py"), "import logging\n"), ("forbidden_constructs", P("x.py"), "eval('1')\n"), ("forbidden_constructs", P("x.py"), "import subprocess\n"), ("forbidden_constructs", P("x.py"), "import os\nos.system('x')\n"),
                 ("forbidden_constructs", P("x.py"), "import os\nv = os.environ['K']\n"), ("forbidden_constructs", P("x.py"), "import os\nv = os.getenv('K')\n"), ("forbidden_constructs", P("x.py"), "import os\nos.remove('p')\n"), ("forbidden_constructs", P("cli.py"), "import os\nos.rename('a', 'b')\n"), ("forbidden_constructs", P("cli.py"), "import os\nos.chmod('a', 0)\n"), ("forbidden_constructs", P("x.py"), "import pickle\n"), ("forbidden_constructs", P("x.py"), "import importlib\n"), ("forbidden_constructs", P("x.py"), "import yaml\n"),
                 ("authority_names", P("x.py"), "def evaluate_policy(): pass\n"), ("authority_names", P("x.py"), "x.issue_cpt()\n"), ("authority_names", P("x.py"), "def f(authorize): pass\n"),
                 ("approval_capability_outside_review", P("x.py"), "svc.promote(m)\n"), ("approval_capability_outside_review", P("x.py"), "svc.resolve_ambiguity(m)\n"), ("approval_capability_outside_review", P("x.py"), "class HumanApproval: pass\n"), ("approval_capability_outside_review", P("x.py"), "from auif.ai_boundary import PromotionRefused\n"),
                 ("approval_capability_outside_review", P("x.py"), "def f(): return ReviewSession\n"), ("approval_capability_outside_review", P("x.py"), "svc.registry_hooks()\n"),
                 ("review_imported_outside_review", P("x.py"), "from . import review\n"), ("review_imported_outside_review", P("x.py"), "from .review import ReviewSession\n"), ("review_imported_outside_review", P("x.py"), "import auif_onboard.review\n"), ("review_imported_outside_review", P("x.py"), "from auif_onboard import review\n"),
                 ("state_words_outside_review", P("x.py"), "S = 'VALIDATED'\n"), ("state_words_outside_review", P("x.py"), "S = ('TRUSTED',)\n"),
                 ("file_access_outside_cli", P("x.py"), "f = open('p')\n"), ("file_access_outside_cli", P("x.py"), "import os\nos.listdir('.')\n"), ("file_access_outside_cli", P("x.py"), "import tempfile\ntempfile.mkdtemp()\n"),
                 ("credential_like_literals", P("x.py"), "api_key = 'abcdefgh12345678'\n"), ("credential_like_literals", P("x.py"), "password = \"hunter2hunter2\"\n"))
        for key, rel, src in cases:
            with self.subTest(msg="%s: %s" % (key, src.strip().splitlines()[-1])): self.assertIn(key, seeded(rel, src))
    def test_the_permitted_forms_are_not_flagged(self):
        ok = (("review may name the capability", P("review.py"), "from auif.ai_boundary import PromotionRefused\nclass HumanApproval: pass\nsvc.promote(m)\nS = 'VALIDATED'\n"), ("review may be imported by its own package tests only via the package", P("review.py"), "from . import pack_draft\n"),
              ("cli may open files", P("cli.py"), "f = open('p')\nimport os\nos.makedirs('d')\nos.remove('mine')\n"), ("validate may check the state words", P("validate.py"), "bad = [m for m in ms if m['mapping_state'] in ('VALIDATED', 'TRUSTED')]\n"),
              ("prose that names a state is not a state", P("x.py"), "MSG = 'the draft holds no VALIDATED mapping and nothing is approved'\n"), ("urllib.parse is not a network module", P("x.py"), "import urllib.parse\n"), ("re.compile is not the compile builtin", P("x.py"), "import re\nre.compile('a')\n"),
              ("auif_ext and auif imports", P("x.py"), "from auif_ext.connectors.rest import RestConfig\nfrom auif.util import sha\n"), ("relative imports of siblings", P("x.py"), "from . import matching\nfrom .errors import OnboardError\n"), ("a harmless word", P("x.py"), "x = 'safe'\nsapphire = 1\n"))
        for label, rel, src in ok:
            with self.subTest(msg=label): self.assertEqual(seeded(rel, src), {})
    def test_review_seeded_outside_the_review_file_is_the_only_difference(self):
        src = "from auif.ai_boundary import PromotionRefused\nsvc.promote(m)\n"; self.assertEqual(seeded(P("review.py"), src), {}); self.assertIn("approval_capability_outside_review", seeded(P("proposer.py"), src)); self.assertIn("approval_capability_outside_review", seeded(P("cli.py"), src))
class DraftingNeverApproves(unittest.TestCase):
    """Behaviour, not text: with the approval capabilities of the core boundary made to explode, the whole draft + validate pipeline still runs, because it never uses them; and what it produces is unapproved."""
    def run_pipeline(self, name):
        doc, h = openapi.load(spec_bytes(name)); cd = config_gen.draft_config(openapi.parse(doc), h); pd = pack_draft.draft_pack(cd, MODEL_DEF); rep = validate.validate_synthetic(cd, pd, VENDORS[name], MODEL_DEF, run_conformance_suite=False); return cd, pd, rep
    def test_the_pipeline_runs_with_promote_and_resolve_ambiguity_disabled_and_approves_nothing(self):
        boom = mock.Mock(side_effect=AssertionError("the drafting pipeline reached an approval capability"))
        with mock.patch.object(AIMappingService, "promote", boom), mock.patch.object(AIMappingService, "resolve_ambiguity", boom):
            for name in NAMES:
                with self.subTest(msg=name):
                    cd, pd, rep = self.run_pipeline(name); self.assertEqual((cd["authority"], cd["draft_state"], pd["authority"], pd["draft_state"], rep["authority"]), (AUTHORITY, DRAFT_STATE, AUTHORITY, DRAFT_STATE, AUTHORITY)); self.assertEqual(rep["status"], "PRESENTED_FOR_HUMAN_APPROVAL")
                    if pd["pack"]:
                        self.assertEqual(pd["pack"]["pack_state"], "CANDIDATE"); self.assertEqual({m["mapping_state"] for m in pd["pack"]["mappings"]} - {"CANDIDATE", "AMBIGUOUS"}, set()); self.assertTrue(all(m["proposed_by"] == "AI_ASSISTED" or m["mapping_state"] == "CANDIDATE" for m in pd["pack"]["mappings"]))
                        self.assertFalse([m for m in pd["pack"]["mappings"] if "validation_ref" in m or m.get("deterministic_validation_performed")])
                    self.assertIsNone(cd["config"]["credential_ref"]); self.assertTrue(pd["pack"]["pack_id"].endswith("-draft"))
        boom.assert_not_called()
    def test_relabelling_a_drafted_mapping_as_validated_does_not_get_it_past_the_core_registry(self):
        from auif.errors import PackError
        from auif.translation import PackRegistry, pack_hash
        from auif.util import evidence
        cd, pd = drafts(NAMES[0]); pack = copy.deepcopy(pd["pack"]); pack["pack_state"] = "VALIDATED"
        for m in pack["mappings"]: m["mapping_state"] = "VALIDATED"; m["deterministic_validation_performed"] = True; m["validation_ref"] = evidence("ai-mapping-validation", {"forged": m["mapping_id"]}, "val-ai-forged-" + m["mapping_id"])
        pack["artifact_hash"] = pack_hash(pack)
        with self.assertRaises(PackError): PackRegistry().register(pack)
    def test_a_draft_pack_is_inert_in_the_core_runtime_nothing_translates_through_a_candidate_mapping(self):
        from auif.canonical import CanonicalModel
        from auif.clock import FakeClock
        from auif.errors import TranslationFailure
        from auif.translation import PackRegistry, Translator
        from auif.util import Ids
        cd, pd = drafts(NAMES[0]); reg = PackRegistry(); pack = pd["pack"]; reg.register(pack)                    # a CANDIDATE pack may be stored ...
        tr = Translator(CanonicalModel(MODEL_DEF), reg, Ids(), FakeClock()); ref = {"id": pack["pack_id"], "version": pack["pack_version"], "hash": pack["artifact_hash"]}; ctx = type("C", (), {"tenant_id": "t"})()
        with self.assertRaises(TranslationFailure) as cm: tr.translate_inbound(ctx, ref, "Account", {"id": "a1", "profile": {"name": "Ann"}}, source_system="s", observation_id="o", schema_fingerprint="0" * 64, source_id="a1")      # ... but nothing translates through it
        self.assertIn("no validated entity mapping", str(cm.exception))
    def test_the_proposer_and_drafters_expose_no_approval_attribute(self):
        from auif_onboard import planner, proposer
        for mod in (config_gen, pack_draft, proposer, planner, openapi, validate):
            for attr in dir(mod):
                self.assertNotRegex(attr.lower(), r"promot|approv|sign_?off|certif|resolve_ambig", "%s.%s" % (mod.__name__, attr))
        for attr in dir(proposer.DeterministicProposer): self.assertNotRegex(attr.lower(), r"promot|approv|sign_?off|certif|resolve")
class TheCoreIsUntouchedByTheAccelerator(unittest.TestCase):
    def test_the_core_tree_hash_equals_the_pinned_core_hash_after_everything_has_run(self):          # rev14: renamed from ..._the_frozen_rev10_hash_... (the core was revised; rev10 to rev13 pinned 74cec87afd167601fd4f260ec02b6f3c16121355b2d5c29767b5f1d3273bf93d)
        out = subprocess.run([sys.executable, "tools/static_checks.py"], cwd=ROOT, capture_output=True, text=True, env=ENV); r = eval(out.stdout.strip().splitlines()[-1]); self.assertEqual(r["core_tree_sha256"], CORE_HASH); self.assertEqual((r["core_import_violations"], r["forbidden_token_hits"], r["authority_api_hits"]), ([], [], []))
if __name__ == "__main__": unittest.main()

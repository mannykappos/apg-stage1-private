import copy, json, unittest
from auif_onboard import config_gen, openapi
from auif_onboard.config_gen import draft_config, flatten, norm
from auif_onboard.errors import SecretLeak
from auif_onboard.tests.support import CANARY, NAMES, THING, arr, drafts, drafts_for_doc, get_list, mini, q, spec_bytes
def draft(doc): d, h = openapi.load(doc); return draft_config(openapi.parse(d), h)
def und(d, field=None): return {u["field"]: u for u in d["undetermined"] if field is None or u["field"] == field}
def det(d): return {x["field"]: x["value"] for x in d["determined"]}
def asm(d): return {x["field"]: x for x in d["assumed_defaults"]}
LISTING = lambda extra_params=(), headers=None, schema=None: get_list(schema or {"type": "object", "properties": {"items": arr("Thing"), "next_cursor": {"type": "string"}}}, list(extra_params), headers)
class FixtureTests(unittest.TestCase):
    def test_every_draft_is_marked_unapproved_and_has_no_authority_no_credential_and_a_valid_hash(self):
        from auif.util import sha
        for n in NAMES:
            cd, _ = drafts(n); self.assertEqual((cd["draft_state"], cd["authority"], cd["config"]["credential_ref"], cd["artifact_kind"]), ("DRAFT_NOT_APPROVED", "NONE", None, "ConnectorConfigDraft")); self.assertEqual(cd["draft_hash"], sha({k: v for k, v in cd.items() if k != "draft_hash"}))
    def test_generation_is_deterministic(self):
        for n in NAMES: self.assertEqual(draft(spec_bytes(n)), draft(spec_bytes(n)))
    def test_crm(self):
        cd, _ = drafts(NAMES[0]); c = cd["config"]; self.assertEqual((c["auth"], c["auth_header"], c["auth_prefix"], c["base_url"], c["idempotency_header"], c["health_path"], c["max_page_size"]), ("API_KEY", "X-Api-Key", "", "https://crm.synthetic-vendor.invalid/api/v2", "Idempotency-Key", "/health", 100))
        a, p = c["entities"]["Account"], c["entities"]["Property"]; self.assertEqual((a["list"]["pagination"], a["list"]["items_path"], a["list"]["cursor_param"], a["list"]["next_cursor_path"], a["write"]["method"], a["write"]["path"], a["write"]["id_field"], p["write"]), ("cursor", ["items"], "cursor", ["next_cursor"], "PATCH", "/accounts/{id}", "external_reference", None))
        self.assertEqual((c["lookup"]["path"], c["lookup"]["id_field"]), ("/idempotency/{key}", "external_reference")); self.assertEqual(sorted(u["field"] for u in cd["undetermined"]), ["credential_ref"]); self.assertEqual(c["allowed_hosts"], ["crm.synthetic-vendor.invalid"])
    def test_ledger(self):
        cd, _ = drafts(NAMES[1]); c = cd["config"]; self.assertEqual((c["auth"], c["token_url"], c["scope"], c["token_auth_style"], c["base_url"], c["idempotency_header"], c["lookup"], c["max_page_size"], c["health_path"]), ("OAUTH2_CLIENT_CREDENTIALS", "https://auth.ledger.synthetic-vendor.invalid/oauth/token", None, "basic", "https://demo.ledger.synthetic-vendor.invalid/rest/v1", "X-Idempotency-Key", None, 50, "/ping"))
        e = c["entities"]["Customer"]; self.assertEqual((e["list"]["pagination"], e["list"]["offset_param"], e["list"]["total_items_path"], e["list"]["items_path"], e["write"]["method"], e["write"]["record_path"], e["write"]["id_field"]), ("offset", "offset", ["total"], ["results"], "PUT", ["data"], "id"))
        self.assertEqual(c["allowed_hosts"], ["auth.ledger.synthetic-vendor.invalid", "demo.ledger.synthetic-vendor.invalid"]); self.assertFalse(und(cd, "lookup")["lookup"]["blocking"]); self.assertIn("scope", asm(cd)); self.assertIn("customers:write", asm(cd)["scope"]["reason"])
    def test_helpdesk_picks_the_supported_alternative_and_lists_what_it_cannot_do(self):
        cd, _ = drafts(NAMES[2]); c = cd["config"]; e = c["entities"]["Ticket"]; self.assertEqual((c["auth"], c["auth_header"], e["list"]["pagination"], e["list"]["items_path"], e["write"], c["idempotency_header"], c["max_page_size"]), ("API_KEY", "X-Auth-Token", "link", ["data"], None, None, 25))
        self.assertTrue(any("alternative security" in w for w in cd["warnings"])); ops = {u["operation"]: u["reason"] for u in cd["unsupported_operations"]}; self.assertIn("more than one path parameter", ops["POST /tickets/{id}/comments/{cid}"]); self.assertIn("DELETE", ops["DELETE /tickets/{id}"])
    def test_the_discovery_document_is_derived_offline_and_feeds_the_core_discovery_engine(self):
        from auif.clock import FakeClock; from auif.discovery import DiscoveryEngine; from auif.util import Ids; from types import SimpleNamespace
        for n in NAMES:
            cd, _ = drafts(n); doc = cd["discovery_document"]; rec = DiscoveryEngine(FakeClock(), Ids()).build_record(SimpleNamespace(tenant_id="t"), "i", "s", "e", {"id": cd["config"]["connector_id"], "version": "0.1.0"}, doc)
            self.assertEqual({e["name"] for e in doc["entities"]}, set(cd["config"]["entities"])); self.assertIn("FIELD", rec["coverage"]["obtained_kinds"]); self.assertEqual(rec["record_state"], "PARTIAL")
        crm = drafts(NAMES[0])[0]["discovery_document"]; self.assertEqual([(o["name"], o["kind"]) for o in crm["operations"]], [("listAccounts", "read"), ("updateAccount", "write"), ("listProperties", "read")]); self.assertEqual(crm["system_version"], "2.4.1")
    def test_nothing_from_the_untrusted_text_of_a_description_reaches_a_draft(self):
        for n in NAMES: cd, pd = drafts(n); self.assertNotIn(CANARY, json.dumps([cd, pd]))
class PaginationTests(unittest.TestCase):
    def one(self, params=(), headers=None, schema=None): return draft(mini({"/things": LISTING(params, headers, schema)}, THING))
    def test_each_style_is_detected_from_its_signals(self):
        d = self.one([q("cursor"), q("limit")]); ep = d["config"]["entities"]["Thing"]["list"]; self.assertEqual((ep["pagination"], ep["cursor_param"], ep["page_size_param"], ep["next_cursor_path"]), ("cursor", "cursor", "limit", ["next_cursor"]))
        d = self.one([q("offset"), q("page_size")], schema={"type": "object", "properties": {"items": arr("Thing"), "total_count": {"type": "integer"}}}); ep = d["config"]["entities"]["Thing"]["list"]; self.assertEqual((ep["pagination"], ep["offset_param"], ep["page_size_param"], ep["total_items_path"]), ("offset", "offset", "page_size", ["total_count"]))
        d = self.one([q("page"), q("per_page")], schema={"type": "object", "properties": {"items": arr("Thing"), "total_pages": {"type": "integer"}}}); ep = d["config"]["entities"]["Thing"]["list"]; self.assertEqual((ep["pagination"], ep["page_param"], ep["page_size_param"], ep["total_pages_path"]), ("page", "page", "per_page", ["total_pages"]))
        d = self.one([q("limit")], headers={"Link": {"schema": {"type": "string"}}}); self.assertEqual(d["config"]["entities"]["Thing"]["list"]["pagination"], "link")
    def test_names_are_matched_without_regard_to_case_or_separators(self):
        for name in ("pageToken", "Page-Token", "page_token", "PAGETOKEN"):
            with self.subTest(name): ep = self.one([q(name)])["config"]["entities"]["Thing"]["list"]; self.assertEqual((ep["pagination"], ep["cursor_param"]), ("cursor", name))
    def test_no_signal_means_blocking_undetermined_never_a_silent_single_page(self):
        d = self.one(); u = und(d, "entities.Thing.list.pagination")["entities.Thing.list.pagination"]; self.assertTrue(u["blocking"]); self.assertEqual(u["candidates"], ["single_page"])
        self.assertIn("entities.Thing.list.page_size_param", asm(d))
    def test_conflicting_signals_are_blocking_and_list_the_candidates(self):
        d = self.one([q("cursor"), q("offset")]); u = und(d, "entities.Thing.list.pagination")["entities.Thing.list.pagination"]; self.assertTrue(u["blocking"]); self.assertEqual(u["candidates"], ["cursor", "offset"])
    def test_a_cursor_style_needs_exactly_one_next_cursor_property(self):
        d = self.one([q("cursor")], schema={"type": "object", "properties": {"items": arr("Thing")}}); self.assertTrue(und(d, "entities.Thing.list.next_cursor_path")["entities.Thing.list.next_cursor_path"]["blocking"])
        d = self.one([q("cursor")], schema={"type": "object", "properties": {"items": arr("Thing"), "next": {"type": "string"}, "next_cursor": {"type": "string"}}}); u = und(d, "entities.Thing.list.next_cursor_path")["entities.Thing.list.next_cursor_path"]; self.assertEqual(u["candidates"], ["next", "next_cursor"])
    def test_a_missing_total_is_an_assumed_default_not_an_error(self):
        d = self.one([q("offset")]); self.assertIn("entities.Thing.list.total_items_path", asm(d)); self.assertEqual(d["config"]["entities"]["Thing"]["list"]["total_items_path"], None)
        d = self.one([q("page")]); self.assertIn("entities.Thing.list.total_pages_path", asm(d))
    def test_the_page_size_maximum_is_the_smallest_declared_and_capped(self):
        d = self.one([q("limit", type="integer", maximum=30)]); self.assertEqual((d["config"]["max_page_size"], det(d)["max_page_size"]), (30, 30)); d = self.one([q("limit", type="integer", maximum=5000)]); self.assertEqual(d["config"]["max_page_size"], 200)
        d = self.one([q("limit")]); self.assertEqual((d["config"]["max_page_size"], asm(d)["max_page_size"]["value"]), (200, 200))
class ShapeTests(unittest.TestCase):
    def test_array_at_the_root_nested_two_deep_and_ambiguous_arrays(self):
        d = draft(mini({"/things": get_list(arr("Thing"), [q("cursor")])}, THING)); self.assertEqual(d["config"]["entities"]["Thing"]["list"]["items_path"], [])
        d = draft(mini({"/things": get_list({"type": "object", "properties": {"data": {"type": "object", "properties": {"rows": arr("Thing")}}}}, [q("cursor")])}, THING)); self.assertEqual(d["config"]["entities"]["Thing"]["list"]["items_path"], ["data", "rows"])
        d = draft(mini({"/things": get_list({"type": "object", "properties": {"a": arr("Thing"), "b": arr("Thing")}}, [q("cursor")])}, THING)); self.assertEqual(d["config"]["entities"], {}); self.assertEqual([u["candidates"] for u in d["undetermined"] if u["field"] == "entities" and u["candidates"]], [["a", "b"]])
        self.assertTrue(any(u["field"] == "entities" and u["blocking"] for u in d["undetermined"]))
    def test_a_get_that_returns_no_array_of_objects_is_listed_as_unsupported_and_no_entity_means_blocking(self):
        d = draft(mini({"/x": get_list({"type": "object", "properties": {"a": {"type": "string"}}})}, THING)); self.assertEqual(d["unsupported_operations"][0]["operation"], "GET /x"); self.assertTrue(und(d, "entities")["entities"]["blocking"]); self.assertEqual(d["config"]["entities"], {})
    def test_entity_names_come_from_the_item_schema_or_the_path_and_must_be_acceptable(self):
        d = draft(mini({"/line-items": get_list({"type": "array", "items": {"type": "object", "properties": {"a": {"type": "string"}}}}, [q("cursor")])})); self.assertEqual(list(d["config"]["entities"]), ["line-items"])
        d = draft(mini({"/things": get_list(arr("Thing"), [q("cursor")])}, {"Thing": THING["Thing"]})); self.assertEqual(list(d["config"]["entities"]), ["Thing"])
        d = draft(mini({"/1things": get_list({"type": "array", "items": {"type": "object", "properties": {"a": {"type": "string"}}}}, [q("cursor")])})); self.assertEqual(d["config"]["entities"], {}); self.assertTrue(any("not acceptable" in u["reason"] for u in d["undetermined"] if u["field"] == "entities"))
    def test_two_list_endpoints_for_one_entity_name_use_neither_when_neither_path_names_the_entity(self):
        d = draft(mini({"/a": get_list(arr("Thing"), [q("cursor")]), "/b": get_list(arr("Thing"), [q("cursor")])}, THING)); self.assertNotIn("Thing", d["config"]["entities"]); u = und(d)["entities.Thing"]; self.assertFalse(u["blocking"]); self.assertEqual(u["candidates"], ["GET /a", "GET /b"])
        self.assertEqual({o["operation"] for o in d["unsupported_operations"]}, {"GET /a", "GET /b"})
    def test_two_list_endpoints_for_one_entity_name_use_the_one_whose_path_names_the_entity(self):
        for paths in (("/things", "/things/archived"), ("/old-things", "/things"), ("/thing/all", "/thing")):
            with self.subTest(paths):
                d = draft(mini({p: get_list(arr("Thing"), [q("cursor")]) for p in paths}, THING)); self.assertEqual(d["config"]["entities"]["Thing"]["list"]["path"], [x for x in paths if x.rsplit("/", 1)[-1] in ("things", "thing")][0]); self.assertFalse(und(d)["entities.Thing"]["blocking"])
        d = draft(mini({p: get_list(arr("Thing"), [q("cursor")]) for p in ("/a/things", "/b/things")}, THING)); self.assertNotIn("Thing", d["config"]["entities"])               # both paths name the entity: still not decidable
    def test_reads_with_path_parameters_and_health_paths_are_not_entities(self):
        d = draft(mini({"/things": get_list(arr("Thing"), [q("cursor")]), "/things/{id}": {"get": {"parameters": [{"name": "id", "in": "path", "required": True, "schema": {"type": "string"}}], "responses": {"200": {"description": "x"}}}}, "/health": get_list(arr("Thing"))}, THING)); self.assertEqual(list(d["config"]["entities"]), ["Thing"]); self.assertEqual(d["config"]["health_path"], "/health")
    def test_flatten_covers_nesting_arrays_unknowns_variants_and_depth(self):
        node = openapi.schema({}, {"type": "object", "required": ["a"], "properties": {"a": {"type": "string"}, "o": {"type": "object", "required": ["n"], "properties": {"n": {"type": "integer"}, "m": {"type": "string"}}}, "l": {"type": "array", "items": {"type": "string"}}, "u": {"description": "x"}, "v": {"oneOf": [{"type": "string"}]}}})
        notes = []; f = {x["name"]: x for x in flatten(node, notes=notes)}; self.assertEqual(sorted(f), ["a", "l", "o.m", "o.n"]); self.assertEqual((f["a"]["required"], f["o.n"]["required"], f["o.m"]["required"], f["l"]["type"]), (True, False, False, "array")); self.assertEqual(len(notes), 2)
        deep = {"type": "string"}
        for _ in range(5): deep = {"type": "object", "properties": {"n": deep}}
        notes = []; self.assertEqual(flatten(openapi.schema({}, deep), notes=notes), []); self.assertTrue(any("deeper" in n for n in notes)); n2 = []; self.assertEqual([x["name"] for x in flatten(openapi.schema({}, {"type": "object", "properties": {"a": {"type": "object", "properties": {"b": {"type": "string"}}}}}), notes=n2)], ["a.b"])
class WriteTests(unittest.TestCase):
    def body(self, extra=None):
        return {"requestBody": {"content": {"application/json": {"schema": {"type": "object", "properties": dict({"title": {"type": "string"}}, **(extra or {}))}}}}, "responses": {"200": {"description": "ok", "content": {"application/json": {"schema": {"type": "object", "properties": {"id": {"type": "string"}}}}}}}}
    def paths(self, **writes):
        p = {"/things": LISTING([q("cursor")])}; p.update(writes); return mini(p, THING)
    def test_one_write_operation_links_to_its_list_endpoint_and_gets_the_id_placeholder(self):
        w = self.body(); w["parameters"] = [{"name": "thing_id", "in": "path", "required": True, "schema": {"type": "string"}}]
        d = draft(self.paths(**{"/things/{thing_id}": {"put": w}})); e = d["config"]["entities"]["Thing"]["write"]; self.assertEqual((e["method"], e["path"], e["id_field"], e["record_path"]), ("PUT", "/things/{id}", "id", [])); self.assertEqual([f["name"] for f in d["write_fields"]["Thing"]], ["title"])
    def test_a_collection_level_post_has_no_id_placeholder(self):
        d = draft(self.paths(**{"/things": dict(LISTING([q("cursor")]), post=self.body())})); self.assertEqual(d["config"]["entities"]["Thing"]["write"]["path"], "/things")
    def test_several_write_operations_for_one_entity_leave_the_write_undetermined(self):
        d = draft(self.paths(**{"/things": dict(LISTING([q("cursor")]), post=self.body()), "/things/{id}": {"patch": dict(self.body(), parameters=[{"name": "id", "in": "path", "required": True, "schema": {"type": "string"}}])}}))
        self.assertIsNone(d["config"]["entities"]["Thing"]["write"]); u = und(d, "entities.Thing.write")["entities.Thing.write"]; self.assertFalse(u["blocking"]); self.assertEqual(sorted(u["candidates"]), ["PATCH /things/{id}", "POST /things"])
    def test_unlinked_bodyless_multi_param_and_delete_operations_are_listed_not_drafted(self):
        nob = {"responses": {"200": {"description": "x"}}}; two = dict(self.body(), parameters=[{"name": "a", "in": "path", "required": True, "schema": {"type": "string"}}, {"name": "b", "in": "path", "required": True, "schema": {"type": "string"}}])
        d = draft(self.paths(**{"/other": {"post": self.body()}, "/things/{id}": {"patch": nob, "delete": nob}, "/things/{a}/{b}": {"put": two}})); reasons = {u["operation"]: u["reason"] for u in d["unsupported_operations"]}
        self.assertIn("belongs to no entity", reasons["POST /other"]); self.assertIn("no JSON request body", reasons["PATCH /things/{id}"]); self.assertIn("DELETE", reasons["DELETE /things/{id}"]); self.assertEqual(len(reasons), 4); self.assertIsNone(d["config"]["entities"]["Thing"]["write"])
    def test_the_idempotency_header_is_taken_from_the_description_or_not_claimed(self):
        w = self.body(); w["parameters"] = [{"name": "Idempotency-Key", "in": "header", "schema": {"type": "string"}}]
        d = draft(self.paths(**{"/things": dict(LISTING([q("cursor")]), post=w)})); self.assertEqual(d["config"]["idempotency_header"], "Idempotency-Key")
        d = draft(self.paths(**{"/things": dict(LISTING([q("cursor")]), post=self.body())})); self.assertIsNone(d["config"]["idempotency_header"]); self.assertFalse(und(d, "idempotency_header")["idempotency_header"]["blocking"])
        d = draft(mini({"/things": LISTING([q("cursor")])}, THING)); self.assertNotIn("idempotency_header", und(d))
    def test_different_idempotency_headers_across_entities_are_blocking(self):
        two = {"Thing": THING["Thing"], "Other": THING["Thing"]}; w1 = dict(self.body(), parameters=[{"name": "Idempotency-Key", "in": "header", "schema": {"type": "string"}}]); w2 = dict(self.body(), parameters=[{"name": "X-Idempotency-Key", "in": "header", "schema": {"type": "string"}}])
        d = draft(mini({"/things": dict(LISTING([q("cursor")]), post=w1), "/others": dict(get_list({"type": "object", "properties": {"items": arr("Other"), "next_cursor": {"type": "string"}}}, [q("cursor")]), post=w2)}, two)); self.assertTrue(und(d, "idempotency_header")["idempotency_header"]["blocking"]); self.assertIsNone(d["config"]["idempotency_header"])
    def test_response_identifier_and_wrapper_detection(self):
        def wr(resp_schema):
            w = self.body(); w["responses"] = {"200": {"description": "ok", "content": {"application/json": {"schema": resp_schema}}}} if resp_schema is not None else {"204": {"description": "none"}}
            return draft(self.paths(**{"/things": dict(LISTING([q("cursor")]), post=w)}))
        d = wr({"type": "object", "properties": {"id": {"type": "string"}, "uuid": {"type": "string"}}}); e = d["config"]["entities"]["Thing"]["write"]; self.assertEqual((e["id_field"], e["record_path"]), ("id", [])); self.assertIn("of 2 candidates", [x["source"] for x in d["determined"] if x["field"].endswith("id_field")][0])
        d = wr({"type": "object", "properties": {"thing_id": {"type": "string"}}}); self.assertEqual(d["config"]["entities"]["Thing"]["write"]["id_field"], "thing_id")
        d = wr({"type": "object", "properties": {"data": {"type": "object", "properties": {"uuid": {"type": "string"}}}}}); e = d["config"]["entities"]["Thing"]["write"]; self.assertEqual((e["id_field"], e["record_path"]), ("uuid", ["data"]))
        d = wr({"type": "object", "properties": {"uuid": {"type": "string"}, "guid": {"type": "string"}}}); self.assertFalse(und(d, "entities.Thing.write.id_field")["entities.Thing.write.id_field"]["blocking"]); self.assertEqual(und(d, "entities.Thing.write.id_field")["entities.Thing.write.id_field"]["candidates"], ["guid", "uuid"])
        d = wr({"type": "object", "properties": {"x": {"type": "string"}}}); self.assertIn("entities.Thing.write.id_field", und(d)); self.assertEqual(d["config"]["entities"]["Thing"]["write"]["id_field"], "id")
        d = wr(None); self.assertIn("entities.Thing.write.id_field", asm(d))
    def test_lookup_health_and_ambiguity(self):
        lk = lambda path, name="key": {path: {"get": {"parameters": [{"name": name, "in": "path", "required": True, "schema": {"type": "string"}}], "responses": {"200": {"description": "ok", "content": {"application/json": {"schema": {"type": "object", "properties": {"id": {"type": "string"}}}}}}}}}}
        d = draft(self.paths(**dict(lk("/by-key/{key}"), **{"/things": dict(LISTING([q("cursor")]), post=self.body())}))); self.assertEqual((d["config"]["lookup"]["path"], d["config"]["lookup"]["id_field"]), ("/by-key/{key}", "id"))
        d = draft(self.paths(**dict(lk("/a/{idempotencyKey}", "idempotencyKey"), **lk("/b/{key}"), **{"/things": dict(LISTING([q("cursor")]), post=self.body())}))); self.assertIsNone(d["config"]["lookup"]); self.assertEqual(und(d, "lookup")["lookup"]["candidates"], ["GET /a/{idempotencyKey}", "GET /b/{key}"])
        d = draft(self.paths(**{"/things": dict(LISTING([q("cursor")]), post=self.body())})); self.assertIn("lookup", und(d))
        d = draft(mini({"/things": LISTING([q("cursor")])}, THING)); self.assertNotIn("lookup", und(d)); self.assertIsNone(d["config"]["health_path"])
class AuthTests(unittest.TestCase):
    P = {"/things": LISTING([q("cursor")])}
    def d(self, security=None, schemes=None, paths=None, servers=None): return draft(mini(paths or self.P, THING, security=security, schemes=schemes, servers=servers))
    def test_no_requirement_declared_assumes_none_and_says_so(self):
        d = self.d(); self.assertEqual(d["config"]["auth"], "NONE"); self.assertIn("auth", asm(d)); self.assertTrue(any("no security requirement" in w for w in d["warnings"])); self.assertNotIn("credential_ref", und(d))
    def test_an_explicit_empty_requirement_is_determined_none(self):
        for sec in ([], [{}]): 
            with self.subTest(sec): d = self.d(security=sec); self.assertEqual((d["config"]["auth"], det(d).get("auth")), ("NONE", "NONE")); self.assertNotIn("auth", asm(d))
    def test_bearer_apikey_and_oauth_cc_map_to_connector_auth_modes(self):
        d = self.d([{"b": []}], {"b": {"type": "http", "scheme": "bearer"}}); c = d["config"]; self.assertEqual((c["auth"], c["auth_header"], c["auth_prefix"]), ("API_KEY", "Authorization", "Bearer ")); self.assertTrue(und(d, "credential_ref")["credential_ref"]["blocking"])
        d = self.d([{"k": []}], {"k": {"type": "apiKey", "in": "header", "name": "X-Key"}}); c = d["config"]; self.assertEqual((c["auth"], c["auth_header"], c["auth_prefix"]), ("API_KEY", "X-Key", ""))
        d = self.d([{"o": []}], {"o": {"type": "oauth2", "flows": {"clientCredentials": {"tokenUrl": "/oauth/token", "scopes": {}}}}}); c = d["config"]; self.assertEqual((c["auth"], c["token_url"]), ("OAUTH2_CLIENT_CREDENTIALS", "https://mini.synthetic-vendor.invalid/oauth/token")); self.assertIn("token_url", asm(d))
    def test_unsupported_security_is_blocking_with_the_kinds_listed_and_no_secret_is_ever_involved(self):
        for scheme, kind in (({"type": "http", "scheme": "basic"}, "HTTP_BASIC"), ({"type": "apiKey", "in": "query", "name": "k"}, "API_KEY_OTHER"), ({"type": "openIdConnect", "openIdConnectUrl": "https://x.invalid"}, "OIDC"), ({"type": "oauth2", "flows": {"implicit": {"authorizationUrl": "https://a.invalid", "scopes": {}}}}, "OAUTH2_OTHER")):
            with self.subTest(kind): d = self.d([{"s": []}], {"s": scheme}); u = und(d, "auth")["auth"]; self.assertTrue(u["blocking"]); self.assertEqual(u["candidates"], [kind]); self.assertEqual(d["config"]["auth"], "NONE")
        d = self.d([{"missing": []}], {}); self.assertEqual(und(d, "auth")["auth"]["candidates"], ["UNDEFINED"])
        d = self.d([{"a": [], "b": []}], {"a": {"type": "http", "scheme": "bearer"}, "b": {"type": "apiKey", "in": "header", "name": "X"}}); self.assertEqual(und(d, "auth")["auth"]["candidates"], ["HTTP_BEARER+API_KEY_HEADER"])
    def test_oauth_with_an_unusable_token_url_is_blocking(self):
        for tu in (None, "http://t.invalid/token"):
            with self.subTest(tu): flow = {"scopes": {}}; flow.update({"tokenUrl": tu} if tu else {}); d = self.d([{"o": []}], {"o": {"type": "oauth2", "flows": {"clientCredentials": flow}}}); self.assertTrue(und(d, "token_url")["token_url"]["blocking"])
    def test_operations_with_different_requirements_are_blocking(self):
        p = {"/things": dict(LISTING([q("cursor")]), post={"security": [{"k": []}], "requestBody": {"content": {"application/json": {"schema": {"type": "object", "properties": {"title": {"type": "string"}}}}}}, "responses": {"200": {"description": "x"}}})}
        d = self.d([{"b": []}], {"b": {"type": "http", "scheme": "bearer"}, "k": {"type": "apiKey", "in": "header", "name": "X"}}, paths=p); self.assertTrue(und(d, "auth")["auth"]["blocking"])
    def test_a_second_alternative_is_noted_and_the_first_supported_one_is_used(self):
        d = self.d([{"c": []}, {"b": []}], {"c": {"type": "apiKey", "in": "cookie", "name": "s"}, "b": {"type": "http", "scheme": "bearer"}}); self.assertEqual(d["config"]["auth"], "API_KEY"); self.assertTrue(any("alternative security" in w for w in d["warnings"]))
    def test_base_url_cases(self):
        for servers, why in (([], "no server"), ([{"url": "/rel"}], "relative"), ([{"url": "http://plain.invalid/v1"}], "not https"), ([{"url": "https://{x}.invalid"}], "variable")):
            with self.subTest(why): d = self.d(servers=servers); self.assertTrue(und(d, "base_url")["base_url"]["blocking"]); self.assertIsNone(d["config"]["base_url"]); self.assertEqual(d["config"]["allowed_hosts"], [])
        d = self.d(servers=[{"url": "https://a.invalid/v1"}, {"url": "https://b.invalid"}]); self.assertEqual(d["config"]["base_url"], "https://a.invalid/v1"); self.assertTrue(any("2 server URLs" in w for w in d["warnings"]))
        d = self.d(servers=[{"url": "https://u:p@bad.invalid/v1"}]); self.assertIsNone(d["config"]["base_url"]); self.assertTrue(any("credentials" in w for w in d["warnings"])); self.assertNotIn("u:p@", json.dumps(d))
class SecretTests(unittest.TestCase):
    def test_secret_material_in_a_value_that_must_be_copied_is_refused_and_never_echoed(self):
        secret = "ghp_" + "a1B2c3D4e5F6g7H8i9J0k1L2m3"
        bad = mini({"/things": LISTING([q("cursor")])}, {"Thing": {"type": "object", "properties": {"id": {"type": "string"}, "kind": {"type": "string", "enum": ["open", secret]}}}})
        with self.assertRaises(SecretLeak) as cm: draft(bad)
        self.assertNotIn(secret, str(cm.exception)); self.assertIn("config draft", str(cm.exception))
    def test_secrets_in_the_ignored_text_fields_never_matter(self):
        doc = mini({"/things": LISTING([q("cursor", default=CANARY, example=CANARY)])}, THING); doc["info"]["description"] = "api_key=%s" % CANARY; doc["x-secret"] = CANARY; self.assertNotIn(CANARY, json.dumps(draft(doc)))
if __name__ == "__main__": unittest.main()

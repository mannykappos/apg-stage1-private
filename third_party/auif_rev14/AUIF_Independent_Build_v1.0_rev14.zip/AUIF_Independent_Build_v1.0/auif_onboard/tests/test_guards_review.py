"""Guards of the human review module that a mutation campaign showed to be unprotected. Each test names the behaviour it pins."""
import copy, unittest
from auif.util import sha
from auif_onboard import pack_draft
from auif_onboard.errors import ApprovalRefused, SecretLeak
from auif_onboard.review import HumanApproval, ReviewSession, check_approval
from auif_onboard.tests.support import NAMES, REVIEWER, STATEMENT, THING, WHEN, approval, arr, drafts, get_list, mini, q
from auif_onboard.tests.test_review import decide, item, session
from synthetic.packs import MODEL_DEF
H = "a" * 64
def ok(**kw): return check_approval(HumanApproval(**dict(dict(reviewer=REVIEWER, statement=STATEMENT, subject_hash=H, decided_at=WHEN), **kw)), H)
def first(s, kind, pred=lambda i: True): return next(i for i in s.items.values() if i["kind"] == kind and pred(i))
def refused(tc, pattern, fn, *a, **k):
    with tc.assertRaisesRegex(ApprovalRefused, pattern): fn(*a, **k)
class Approval(unittest.TestCase):
    def test_the_name_ai_is_a_placeholder_even_inside_a_longer_name(self):
        for name in ("Ai Smith", "ai", "Dr Ai"):
            with self.subTest(name), self.assertRaises(ApprovalRefused): ok(reviewer=name)
        ok(reviewer="Aiden Smith")
    def test_the_subject_hash_must_itself_be_a_lower_case_sha256_even_when_both_sides_agree(self):
        for bad in ("short", "A" * 64, "g" * 64, "a" * 63, ""):
            with self.subTest(bad), self.assertRaises(ApprovalRefused): check_approval(HumanApproval(REVIEWER, STATEMENT, bad, WHEN), bad)
    def test_an_approval_keeps_its_own_copy_of_the_parameters_it_was_made_with(self):
        p = {"k": [1], "n": {"a": 1}}; a = HumanApproval(REVIEWER, STATEMENT, H, WHEN, parameters=p); p["k"].append(2); p["n"]["a"] = 9; p["new"] = 1; self.assertEqual(a.parameters, {"k": [1], "n": {"a": 1}})
class SessionStart(unittest.TestCase):
    def test_a_draft_that_says_it_is_already_approved_is_refused_even_with_a_consistent_hash(self):
        cd, _ = drafts(NAMES[0]); cd = copy.deepcopy(cd); cd["draft_state"] = "APPROVED"; cd["draft_hash"] = sha({k: v for k, v in cd.items() if k != "draft_hash"}); pd = pack_draft.draft_pack(cd, MODEL_DEF)
        self.assertEqual(pd["draft_state"], "DRAFT_NOT_APPROVED"); refused(self, "intact, unapproved", ReviewSession, cd, pd, MODEL_DEF)
    def test_a_decided_item_is_no_longer_pending(self):
        s, cd, pd = session(); before = {p["item_id"] for p in s.pending()}; i = first(s, "ENTITY"); s.decide(i["item_id"], approval(i["item_hash"])); after = {p["item_id"] for p in s.pending()}
        self.assertEqual(before - after, {i["item_id"]}); self.assertEqual(after, before - {i["item_id"]}); j = first(s, "ENTITY", lambda x: x["item_id"] != i["item_id"]); s.decide(j["item_id"], approval(j["item_hash"], decision="REJECT")); self.assertNotIn(j["item_id"], {p["item_id"] for p in s.pending()})
    def test_the_boundary_remembers_ambiguity_so_a_stripped_flag_cannot_be_promoted(self):
        s, cd, pd = session(doc=mini({"/things": get_list({"type": "object", "properties": {"items": arr("Thing"), "next_cursor": {"type": "string"}}}, [q("cursor")])}, THING)); it = item(s, "FIELD", "Thing.title"); self.assertEqual(it["mapping"]["mapping_state"], "AMBIGUOUS")
        it["mapping"]["mapping_state"] = "CANDIDATE"; it["mapping"].pop("ambiguity"); refused(self, "ambiguous", s.decide, it["item_id"], approval(it["item_hash"]))
        self.assertEqual(s.status[it["item_id"]], "PENDING")
class HumanRoute(unittest.TestCase):
    def test_a_hand_written_mapping_needs_both_a_canonical_ref_and_a_transform(self):
        s, cd, pd = session(); it = first(s, "FIELD_MANUAL"); refused(self, "needs canonical_ref and transform", s.decide, it["item_id"], approval(it["item_hash"], route="HUMAN", canonical_ref="Party.display_name"))
        refused(self, "needs canonical_ref and transform", s.decide, it["item_id"], approval(it["item_hash"], route="HUMAN", transform={"kind": "IDENTITY", "parameters": {}, "deterministic": True}))
    def test_outbound_cannot_be_enabled_for_an_entity_without_a_write_endpoint(self):
        s, cd, pd = session(NAMES[2]); self.assertIsNone(cd["config"]["entities"]["Ticket"]["write"]); it = item(s, "FIELD", "Ticket.title")
        for spec in ("PROPOSED", {"target_type": "string", "transform": {"kind": "IDENTITY", "parameters": {}, "deterministic": True}, "target_constraints": [{"constraint_id": "c", "kind": "TYPE", "spec": {"type": "string"}}]}): refused(self, "has no write endpoint", s.decide, it["item_id"], approval(it["item_hash"], route="HUMAN", outbound=spec))
    def test_only_the_outbound_the_generator_proposed_can_be_adopted_by_name(self):
        comps = {"Customer": {"type": "object", "properties": {"id": {"type": "string"}, "name": {"type": "string"}, "email": {"type": "string", "readOnly": True}}}}
        body = {"requestBody": {"content": {"application/json": {"schema": {"type": "object", "properties": {"name": {"type": "string"}}}}}}, "responses": {"200": {"description": "ok", "content": {"application/json": {"schema": {"type": "object", "properties": {"id": {"type": "string"}}}}}}}}
        s, cd, pd = session(doc=mini({"/customers": dict(get_list({"type": "object", "properties": {"items": arr("Customer"), "next_cursor": {"type": "string"}}}, [q("cursor")]), post=body)}, comps)); self.assertTrue(cd["config"]["entities"]["Customer"]["write"])
        it = item(s, "FIELD", "Customer.email"); self.assertFalse(it["outbound_proposal"]["supported"]); self.assertTrue(item(s, "FIELD", "Customer.name")["outbound_proposal"]["supported"])
        refused(self, "no outbound proposal", s.decide, it["item_id"], approval(it["item_hash"], route="HUMAN", outbound="PROPOSED"))
    def test_an_explicit_outbound_has_exactly_the_three_parts_and_at_least_one_constraint(self):
        s, cd, pd = session(); it = item(s, "FIELD", "Account.profile.name"); ob = {k: v for k, v in it["outbound_proposal"].items() if k != "supported"}; self.assertEqual(set(ob), {"target_type", "transform", "target_constraints"})
        refused(self, "exactly", s.decide, it["item_id"], approval(it["item_hash"], route="HUMAN", outbound=dict(ob, extra=1)))
        refused(self, "exactly", s.decide, it["item_id"], approval(it["item_hash"], route="HUMAN", outbound={k: v for k, v in ob.items() if k != "transform"}))
        refused(self, "at least one target constraint", s.decide, it["item_id"], approval(it["item_hash"], route="HUMAN", outbound=dict(ob, target_constraints=[])))
        m = s.decide(it["item_id"], approval(it["item_hash"], route="HUMAN", outbound=ob)); self.assertTrue(m["outbound"]["supported"])
    def test_an_entity_item_whose_source_entity_is_not_in_the_configuration_is_refused(self):
        s, cd, pd = session(); it = first(s, "ENTITY"); it["mapping"]["source_ref"] = "NoSuchEntity"; refused(self, "does not exist in the configuration", s.decide, it["item_id"], approval(it["item_hash"]))
    def test_an_action_item_for_an_entity_without_a_write_endpoint_is_refused(self):
        s, cd, pd = session(); it = first(s, "ACTION"); self.assertIsNone(cd["config"]["entities"]["Property"]["write"]); it["entity"] = "Property"
        refused(self, "has no write endpoint", s.decide, it["item_id"], approval(it["item_hash"], canonical_action="test.update_thing"))
class Ledger(unittest.TestCase):
    def test_an_entry_that_cannot_be_written_to_the_ledger_leaves_the_item_undecided(self):
        for decision in ("APPROVE", "REJECT"):
            with self.subTest(decision):
                s, cd, pd = session(); it = first(s, "ENTITY"); bad = "Bearer abcdefgh12345678xx"; s.items[bad] = dict(it, item_id=bad); s.status[bad] = "PENDING"
                with self.assertRaises(SecretLeak) as cm: s.decide(bad, approval(it["item_hash"], decision=decision))
                self.assertIn("review ledger", str(cm.exception)); self.assertNotIn("abcdefgh12345678xx", str(cm.exception)); self.assertEqual((s.status[bad], s.approved, s.ledger), ("PENDING", {}, []))
    def test_every_decision_is_one_ledger_entry_in_order_and_the_entry_carries_the_result_hash(self):
        s, cd, pd = session(); a, b = [i for i in s.items.values() if i["kind"] == "ENTITY"][:2]; m = s.decide(a["item_id"], approval(a["item_hash"])); s.decide(b["item_id"], approval(b["item_hash"], decision="REJECT"))
        self.assertEqual([(e["seq"], e["subject"], e["decision"]) for e in s.ledger], [(1, a["item_id"], "APPROVE"), (2, b["item_id"], "REJECT")]); self.assertEqual(s.ledger[0]["result_hash"], sha(m)); self.assertIsNone(s.ledger[1]["result_hash"]); self.assertEqual((s.status[a["item_id"]], s.status[b["item_id"]]), ("APPROVED", "REJECTED"))
class ConfigOverrides(unittest.TestCase):
    def go(self, **ov):
        s, cd, pd = session(); return s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:crm.key", overrides=ov))
    def test_the_list_endpoint_cannot_be_replaced_wholesale_and_the_write_endpoint_not_by_a_scalar(self):
        s, cd, pd = session(); whole = copy.deepcopy(cd["config"]["entities"]["Account"]["list"])
        for key, val, why in (("entities.Account.list", whole, "list endpoint can only be removed"), ("entities.Account.write", "PATCH /x", "only the write endpoint can be replaced"), ("entities.Account.write", 5, "only the write endpoint can be replaced")):
            with self.subTest(key=key, val=str(val)[:20]): refused(self, why, s.approve_config, approval(cd["draft_hash"], credential_ref="secretref:crm.key", overrides={key: val}))
    def test_rev12_a_reviewer_may_remove_a_list_endpoint_which_excludes_the_entity(self):
        s, cd, pd = session(); out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:crm.key", overrides={"entities.Property.list": None})); self.assertEqual(list(out["config"]["entities"]), ["Account"])
    def test_the_write_endpoint_can_be_replaced_by_an_endpoint_object_or_removed(self):
        s, cd, pd = session(); w = copy.deepcopy(cd["config"]["entities"]["Account"]["write"]); w["path"] = "/accounts/{id}/v2"
        out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:crm.key", overrides={"entities.Account.write": w})); self.assertEqual(out["config"]["entities"]["Account"]["write"]["path"], "/accounts/{id}/v2")
        s, cd, pd = session(); out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:crm.key", overrides={"entities.Account.write": None})); self.assertIsNone(out["config"]["entities"]["Account"]["write"])
    def test_only_paging_attributes_of_an_endpoint_can_be_overridden(self):
        s, cd, pd = session()
        for attr in ("method", "path", "id_field", "record_path", "bogus"):
            with self.subTest(attr): refused(self, "attribute is not allowed", s.approve_config, approval(cd["draft_hash"], credential_ref="secretref:crm.key", overrides={"entities.Account.list." + attr: "x"}))
        out = s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:crm.key", overrides={"entities.Account.list.cursor_param": "after"})); self.assertEqual(out["config"]["entities"]["Account"]["list"]["cursor_param"], "after")
    def test_an_endpoint_that_does_not_exist_cannot_be_overridden_attribute_by_attribute(self):
        s, cd, pd = session(); self.assertIsNone(cd["config"]["entities"]["Property"]["write"])
        refused(self, "has no write endpoint", s.approve_config, approval(cd["draft_hash"], credential_ref="secretref:crm.key", overrides={"entities.Property.write.pagination": "cursor"}))
    def test_a_secret_that_got_into_a_consistently_rehashed_draft_is_stopped_at_approval(self):
        cd, _ = drafts(NAMES[0]); cd = copy.deepcopy(cd); cd["config"]["scope"] = "Bearer abcdefgh12345678xx"; cd["draft_hash"] = sha({k: v for k, v in cd.items() if k != "draft_hash"}); pd = pack_draft.draft_pack(cd, MODEL_DEF); s = ReviewSession(cd, pd, MODEL_DEF)
        with self.assertRaises(SecretLeak) as cm: s.approve_config(approval(cd["draft_hash"], credential_ref="secretref:crm.key"))
        self.assertIn("approved config", str(cm.exception)); self.assertNotIn("abcdefgh12345678xx", str(cm.exception)); self.assertIsNone(s.config_decision)
class Assembly(unittest.TestCase):
    def test_nothing_approved_means_nothing_to_assemble(self):
        s, cd, pd = session(); refused(self, "nothing to assemble", s.assemble_pack)
        i = first(s, "ENTITY"); s.decide(i["item_id"], approval(i["item_hash"], decision="REJECT")); refused(self, "nothing to assemble", s.assemble_pack)
if __name__ == "__main__": unittest.main()

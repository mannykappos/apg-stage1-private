import json, unittest
from auif_onboard import openapi
from auif_onboard.errors import SpecRejected
from auif_onboard.tests.support import CANARY, NAMES, THING, arr, get_list, mini, q, spec_bytes, spec_doc
def parse(doc): return openapi.parse(openapi.load(doc)[0])
class LoadTests(unittest.TestCase):
    def test_a_document_is_hashed_by_content_not_by_formatting(self):
        a = openapi.load(spec_bytes(NAMES[0]))[1]; b = openapi.load(json.dumps(spec_doc(NAMES[0]), separators=(",", ":")))[1]; self.assertEqual(a, b); self.assertEqual(len(a), 64)
    def test_hostile_or_unusable_input_is_refused_with_SpecRejected(self):
        for bad in (b"not json", b"openapi: 3.0.0\ninfo: {}\n", b"[1,2]", b"\xff\xfe", b'{"a": NaN}', b'{"a": Infinity}', b"[" * 5000):
            with self.subTest(bad[:12]), self.assertRaises(SpecRejected): openapi.load(bad)
        with self.assertRaises(SpecRejected): openapi.load(b" " * (openapi.MAX_BYTES + 1))
        with self.assertRaises(SpecRejected): openapi.load({"x": object()})
        with self.assertRaises(SpecRejected): openapi.parse({"swagger": "1.2"})
        with self.assertRaises(SpecRejected): openapi.parse({"openapi": "4.0.0"})
    def test_dialects_are_recognised(self):
        for n, want in zip(NAMES, ("openapi-3.0", "openapi-3.1", "swagger-2.0")): self.assertEqual(parse(spec_bytes(n))["dialect"], want)
    def test_x_extensions_descriptions_examples_and_defaults_are_never_read(self):
        for n in NAMES: self.assertNotIn(CANARY, json.dumps(parse(spec_bytes(n))))
class StructureTests(unittest.TestCase):
    def test_server_variables_use_their_declared_default_and_unresolved_ones_are_flagged(self):
        m = parse(mini({}, servers=[{"url": "https://{a}.x.invalid/{v}", "variables": {"a": {"default": "eu"}, "v": {"default": "v2"}}}, {"url": "https://{z}.x.invalid", "variables": {}}, {"url": "/relative"}]))
        self.assertEqual([(s["url"], s["relative"], s.get("unresolved_variables")) for s in m["servers"]], [("https://eu.x.invalid/v2", False, False), ("https://{z}.x.invalid", False, True), ("/relative", True, False)])
    def test_a_server_url_with_credentials_a_query_or_a_fragment_is_not_used_and_is_reported(self):
        for u in ("https://u:p@x.invalid/v1", "https://x.invalid/v1?key=abcd1234", "https://x.invalid/v1#frag"):
            with self.subTest(u): m = parse(mini({}, servers=[{"url": u}])); self.assertEqual(m["servers"], []); self.assertTrue(m["rejected"])
    def test_swagger2_servers_prefer_https_and_include_the_base_path(self):
        m = parse({"swagger": "2.0", "info": {"title": "t"}, "host": "h.invalid", "basePath": "/b", "schemes": ["http", "https"], "paths": {}}); self.assertEqual([s["url"] for s in m["servers"]], ["https://h.invalid/b", "http://h.invalid/b"])
        self.assertEqual(parse({"swagger": "2.0", "info": {}, "paths": {}})["servers"], [])
    def test_security_scheme_kinds(self):
        sch = {"k": {"type": "apiKey", "in": "header", "name": "X-K"}, "q": {"type": "apiKey", "in": "query", "name": "k"}, "b": {"type": "http", "scheme": "bearer"}, "ba": {"type": "http", "scheme": "Basic"}, "o": {"type": "openIdConnect", "openIdConnectUrl": "https://x.invalid"},
               "cc": {"type": "oauth2", "flows": {"clientCredentials": {"tokenUrl": "https://t.invalid/token", "scopes": {"a:b": "x", "bad scope!": "y"}}}}, "ac": {"type": "oauth2", "flows": {"authorizationCode": {"authorizationUrl": "https://a.invalid", "tokenUrl": "https://t.invalid", "scopes": {}}}},
               "bad": {"type": "apiKey", "in": "header", "name": "bad name!"}, "weird": {"type": "mutualTLS"}}
        s = parse(mini({}, schemes=sch))["security_schemes"]
        self.assertEqual({k: v["kind"] for k, v in s.items()}, {"k": "API_KEY_HEADER", "q": "API_KEY_OTHER", "b": "HTTP_BEARER", "ba": "HTTP_BASIC", "o": "OIDC", "cc": "OAUTH2_CC", "ac": "OAUTH2_OTHER", "bad": "API_KEY_HEADER", "weird": "UNKNOWN"})
        self.assertEqual((s["k"]["header"], s["bad"]["header"], s["cc"]["token_url"], s["cc"]["scopes"]), ("X-K", None, "https://t.invalid/token", ["a:b"]))
    def test_a_token_url_with_credentials_or_a_query_is_dropped(self):
        for u in ("https://u:p@t.invalid/token", "https://t.invalid/token?client_secret=abcdef"):
            with self.subTest(u): self.assertIsNone(parse(mini({}, schemes={"cc": {"type": "oauth2", "flows": {"clientCredentials": {"tokenUrl": u, "scopes": {}}}}}))["security_schemes"]["cc"]["token_url"])
    def test_swagger2_oauth2_application_flow_is_client_credentials(self):
        m = parse({"swagger": "2.0", "info": {}, "securityDefinitions": {"o": {"type": "oauth2", "flow": "application", "tokenUrl": "https://t.invalid/t", "scopes": {"s": "x"}}, "p": {"type": "oauth2", "flow": "password", "tokenUrl": "https://t.invalid/t", "scopes": {}}, "b": {"type": "basic"}}, "paths": {}})["security_schemes"]
        self.assertEqual((m["o"]["kind"], m["o"]["token_url"], m["o"]["scopes"], m["p"]["kind"], m["b"]["kind"]), ("OAUTH2_CC", "https://t.invalid/t", ["s"], "OAUTH2_OTHER", "HTTP_BASIC"))
    def test_operations_security_parameters_and_bodies(self):
        m = parse(spec_bytes(NAMES[0])); ops = {o["operation_id"]: o for o in m["operations"]}
        self.assertEqual(ops["updateAccount"]["method"], "PATCH"); self.assertEqual(ops["updateAccount"]["path_params"], ["accountId"]); self.assertEqual(ops["updateAccount"]["header_params"], ["Idempotency-Key"])
        self.assertIsNone(ops["updateAccount"]["security"]); self.assertEqual(m["default_security"], [["ApiKeyAuth"]]); self.assertEqual(ops["listAccounts"]["query_params"]["limit"]["schema"]["maximum"], 100)
        self.assertEqual(sorted(ops["updateAccount"]["request"]["properties"]), ["balance_cents", "profile", "status"]); self.assertEqual(ops["findByKey"]["success"]["schema"]["properties"]["external_reference"]["type"], "string")
        self.assertEqual(parse(mini({"/a": {"get": {"security": [], "responses": {"200": {"description": "x"}}}}}))["operations"][0]["security"], [])
    def test_swagger2_body_parameter_and_response_headers(self):
        m = parse(spec_bytes(NAMES[2])); ops = {(o["method"], o["path"]): o for o in m["operations"]}
        self.assertEqual(ops[("GET", "/tickets")]["success"]["headers"], ["link"]); self.assertEqual(ops[("POST", "/tickets/{id}/comments/{cid}")]["request"]["properties"]["text"]["type"], "string"); self.assertEqual(ops[("GET", "/tickets")]["query_params"]["limit"]["schema"]["maximum"], 25)
    def test_a_path_item_ref_and_parameter_refs_are_followed_when_local_and_dropped_when_not(self):
        doc = mini({"/a": {"$ref": "#/x-shared/a"}, "/b": {"$ref": "https://elsewhere.invalid/b"}}); doc["x-shared"] = {"a": get_list({"type": "array", "items": {"type": "object"}})}; m = parse(doc)
        self.assertEqual([o["path"] for o in m["operations"]], ["/a"]); self.assertTrue(any(r["where"] == "/b" for r in m["rejected"]))
    def test_bad_paths_are_rejected_and_the_operation_cap_is_enforced(self):
        m = parse(mini({"no-slash": {}, "/" + "x" * 400: {}})); self.assertEqual(m["operations"], []); self.assertEqual(len(m["rejected"]), 2)
        many = {"/p%d" % i: {"get": {"responses": {"200": {"description": "x"}}}} for i in range(openapi.MAX_OPERATIONS + 5)}; m = parse(mini(many)); self.assertEqual(len(m["operations"]), openapi.MAX_OPERATIONS); self.assertTrue(any("more than" in r["reason"] for r in m["rejected"]))
    def test_operation_id_must_be_a_plain_name(self):
        m = parse(mini({"/a": {"get": {"operationId": "ok_Name", "responses": {}}}, "/b": {"get": {"operationId": "bad name; drop table", "responses": {}}}})); self.assertEqual([o["operation_id"] for o in m["operations"]], ["ok_Name", None])
class SchemaTests(unittest.TestCase):
    def sch(self, node, extra=None):
        d = mini({"/t": get_list(node)}, schemas=extra or {}); return parse(d)["operations"][0]["success"]["schema"]
    def test_scalar_facts(self):
        s = self.sch({"type": "object", "required": ["a"], "properties": {"a": {"type": "string", "maxLength": 5, "format": "email", "enum": ["x", "y"]}, "b": {"type": "integer", "minimum": 1, "maximum": 9.5, "readOnly": True}, "c": {"type": ["string", "null"]}, "d": {"type": "boolean", "nullable": True, "writeOnly": True}}})
        p = s["properties"]; self.assertEqual((p["a"]["max_length"], p["a"]["format"], p["a"]["enum"]), (5, "email", ["x", "y"])); self.assertEqual((p["b"]["minimum"], p["b"]["maximum"], p["b"]["read_only"]), (1, 9.5, True))
        self.assertEqual((p["c"]["type"], p["c"]["nullable"], p["d"]["nullable"], p["d"]["write_only"]), ("string", True, True, True)); self.assertEqual(s["required"], ["a"])
    def test_unusable_facts_are_ignored(self):
        p = self.sch({"type": "object", "properties": {"a": {"type": "string", "maxLength": -1, "format": "bad format!", "enum": [True, "x"]}, "b": {"type": "string", "enum": ["z" * 101]}, "c": {"type": "string", "maxLength": True}, "d": {"type": "integer", "minimum": "1"}}})["properties"]
        self.assertEqual((p["a"]["max_length"], p["a"]["format"], p["a"]["enum"], p["b"]["enum"], p["c"]["max_length"], p["d"]["minimum"]), (None, None, None, None, None, None))
    def test_allOf_merges_properties_and_required_and_a_circular_reference_is_reported_not_followed(self):
        extra = {"A": {"type": "object", "properties": {"x": {"type": "string"}}}, "B": {"allOf": [{"$ref": "#/components/schemas/A"}, {"required": ["x"], "properties": {"y": {"type": "integer"}}}]},
                 "Loop": {"type": "object", "properties": {"me": {"$ref": "#/components/schemas/Loop"}}}}
        b = self.sch({"$ref": "#/components/schemas/B"}, extra); self.assertEqual((sorted(b["properties"]), b["required"], b["type"], b["ref_name"]), (["x", "y"], ["x"], "object", "B"))
        loop = self.sch({"$ref": "#/components/schemas/Loop"}, extra); self.assertEqual(loop["properties"]["me"]["problems"], ["circular reference"])
    def test_references_that_do_not_resolve_or_are_not_local_or_too_deep_are_problems(self):
        extra = {"R0": {"$ref": "#/components/schemas/R1"}, "R1": {"$ref": "#/components/schemas/R2"}}
        for i in range(2, 12): extra["R%d" % i] = {"$ref": "#/components/schemas/R%d" % (i + 1)}
        extra["R12"] = {"type": "string"}
        self.assertEqual(self.sch({"$ref": "#/components/schemas/Nope"})["problems"], ["reference is not local or does not resolve"]); self.assertEqual(self.sch({"$ref": "https://x.invalid/s"})["problems"], ["reference is not local or does not resolve"])
        self.assertEqual(self.sch({"$ref": "#/components/schemas/R0"}, extra)["problems"], ["reference chain is too deep"])
    def test_oneOf_anyOf_are_flagged_not_interpreted_and_depth_and_width_are_bounded(self):
        s = self.sch({"type": "object", "properties": {"v": {"oneOf": [{"type": "string"}, {"type": "integer"}]}}}); self.assertTrue(s["properties"]["v"]["variants"]); self.assertIn("oneOf/anyOf variants are not interpreted", s["properties"]["v"]["problems"])
        deep = {"type": "string"}
        for _ in range(10): deep = {"type": "object", "properties": {"n": deep}}
        node = self.sch(deep)
        while node["properties"]: node = node["properties"]["n"]
        self.assertIn("schema nesting is too deep", node["problems"])
        wide = self.sch({"type": "object", "properties": {"p%d" % i: {"type": "string"} for i in range(openapi.MAX_PROPERTIES + 1)}}); self.assertEqual(wide["properties"], {}); self.assertTrue(wide["problems"])
    def test_unrepresentable_property_names_are_skipped(self):
        s = self.sch({"type": "object", "properties": {"ok": {"type": "string"}, "a.b": {"type": "string"}, "has space": {"type": "string"}, "9x": {"type": "string"}}}); self.assertEqual(list(s["properties"]), ["ok"]); self.assertEqual(len(s["problems"]), 3)
    def test_arrays_and_untyped_objects(self):
        s = self.sch({"type": "array", "items": {"properties": {"a": {"type": "string"}}}}); self.assertEqual((s["type"], s["items"]["type"]), ("array", "object")); self.assertEqual(self.sch({"description": "x"})["type"], "unknown")
        self.assertEqual(self.sch({"type": "array"})["items"]["type"], "unknown")
    def test_success_prefers_the_lowest_2xx_that_has_a_schema(self):
        d = mini({"/t": {"get": {"responses": {"204": {"description": "none"}, "200": {"description": "no body"}, "201": {"description": "c", "content": {"application/json": {"schema": {"type": "string"}}}}, "404": {"description": "x"}}}}}); o = parse(d)["operations"][0]["success"]
        self.assertEqual((o["status"], o["schema"]["type"]), ("201", "string")); o = parse(mini({"/t": {"get": {"responses": {"404": {"description": "x"}}}}}))["operations"][0]["success"]; self.assertEqual((o["status"], o["schema"]), (None, None))
        o = parse(mini({"/t": {"get": {"responses": {"204": {"description": "none"}}}}}))["operations"][0]["success"]; self.assertEqual((o["status"], o["schema"]), ("204", None))
if __name__ == "__main__": unittest.main()

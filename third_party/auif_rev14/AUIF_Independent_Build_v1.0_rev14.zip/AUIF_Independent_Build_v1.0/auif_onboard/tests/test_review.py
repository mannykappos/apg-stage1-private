import copy, unittest
from auif.canonical import CanonicalModel
from auif.clock import FakeClock
from auif.errors import PackError
from auif.translation import PackRegistry, Translator
from auif.util import Ids, sha
from auif_onboard import review
from auif_onboard.errors import ApprovalRefused, SecretLeak
from auif_onboard.review import HumanApproval, ReviewSession, check_approval
from auif_onboard.tests.support import CANARY, NAMES, REVIEWER, STATEMENT, THING, WHEN, approval, arr, drafts, drafts_for_doc, get_list, mini, q
from synthetic.packs import MODEL_DEF
H = "a" * 64
def session(name=NAMES[0], doc=None):
    cd, pd = drafts_for_doc(doc) if doc is not None else drafts(name); return ReviewSession(cd, pd, MODEL_DEF), cd, pd
def item(s, kind, source=None, op=None):
    for i in s.items.values():
        if i["kind"] == kind and (source is None or (i["mapping"] or {}).get("source_ref", i.get("source_ref")) == source) and (op is None or i.get("operation") == op): return i
    raise KeyError((kind, source))
def decide(s, kind, source=None, decision="APPROVE", op=None, **params): i = item(s, kind, source, op); return s.decide(i["item_id"], approval(i["item_hash"], decision=decision, **params))
class ApprovalChecks(unittest.TestCase):
    def ok(self, **kw): return check_approval(HumanApproval(**dict(dict(reviewer=REVIEWER, statement=STATEMENT, subject_hash=H, decided_at=WHEN), **kw)), H)
    def test_a_named_bound_complete_approval_passes(self): self.assertEqual(self.ok().reviewer, REVIEWER)
    def test_only_a_HumanApproval_counts(self):
        for bad in ({"reviewer": REVIEWER}, "approved", None, object()):
            with self.subTest(type(bad).__name__), self.assertRaises(ApprovalRefused): check_approval(bad, H)
    def test_automated_empty_or_placeholder_reviewer_names_are_refused(self):
        for name in ("auto", "System", "AI Generator", "claude", "Alexandra Bot", "the-proposer", "LLM", "auif onboard", "CI", "unknown", "", " ", "A", "123", "x" * 81, None, 7, "agent smith"):
            with self.subTest(name), self.assertRaises(ApprovalRefused): self.ok(reviewer=name)
        for name in ("Robotham Jones", "Mary-Anne O'Neil", "Étienne Dupont", "Emmanuel Kappos"): self.ok(reviewer=name)
    def test_the_statement_must_say_what_is_approved(self):
        for st in ("ok", "approved approved approved", "x" * 19, "short words here ok", "a " * 600, None, 5):
            with self.subTest(st), self.assertRaises(ApprovalRefused): self.ok(statement=st)
    def test_timestamp_decision_and_hash_are_checked(self):
        for kw in ({"decided_at": "yesterday"}, {"decided_at": None}, {"decision": "MAYBE"}, {"subject_hash": "b" * 64}, {"subject_hash": "A" * 64}, {"subject_hash": "short"}, {"subject_hash": None}):
            with self.subTest(kw), self.assertRaises(ApprovalRefused): self.ok(**kw)
    def test_parameters_must_be_plain_json_and_free_of_secrets(self):
        for p in ({"x": object()}, {"x": {1, 2}}, [1]):
            with self.subTest(str(p)[:20]), self.assertRaises(ApprovalRefused): HumanApproval(REVIEWER, STATEMENT, H, WHEN, parameters=p)
        with self.assertRaises((ApprovalRefused, SecretLeak)): self.ok(parameters={"credential_ref": "secretref:ok", "note": "api_key=%s" % CANARY})
    def test_an_approval_cannot_be_altered_after_it_is_made(self):
        a = HumanApproval(REVIEWER, STATEMENT, H, WHEN, parameters={"k": 1})
        with self.assertRaises(Exception): a.reviewer = "someone else"
        rec = a.record(); rec["parameters"]["k"] = 2; self.assertEqual(a.parameters, {"k": 1})
class SessionIntegrity(unittest.TestCase):
    def test_a_tampered_or_foreign_draft_is_refused(self):
        cd, pd = drafts(NAMES[0])
        for label, mut in (("config state", lambda c, p: c.update(draft_state="APPROVED")), ("pack state", lambda c, p: p.update(draft_state="APPROVED")), ("config body", lambda c, p: c["config"].update(auth="NONE")), ("pack body", lambda c, p: p["items"].pop())):
            c, p = copy.deepcopy(cd), copy.deepcopy(pd); mut(c, p)
            with self.subTest(label), self.assertRaises(ApprovalRefused): ReviewSession(c, p, MODEL_DEF)
        c, p = copy.deepcopy(cd), copy.deepcopy(pd); p["pack"]["mappings"][0]["mapping_state"] = "VALIDATED"; p["draft_hash"] = sha({k: v for k, v in p.items() if k != "draft_hash"})
        with self.assertRaises(ApprovalRefused) as cm: ReviewSession(c, p, MODEL_DEF)
        self.assertIn("altered", str(cm.exception)); other = drafts(NAMES[1])[1]
        with self.assertRaises(ApprovalRefused): ReviewSession(cd, other, MODEL_DEF)
        with self.assertRaises(ApprovalRefused): ReviewSession(cd, {}, MODEL_DEF)
        with self.assertRaises(ApprovalRefused): ReviewSession("x", pd, MODEL_DEF)
    def test_a_session_starts_with_everything_pending_and_nothing_approved(self):
        s, cd, pd = session(); self.assertEqual(len(s.pending()), len(pd["items"])); self.assertEqual((s.approved, s.ledger, s.config_decision), ({}, [], None))
        with self.assertRaises(ApprovalRefused): s.assemble_pack()
class ItemDecisionTests(unittest.TestCase):
    def test_unknown_items_wrong_binding_and_second_decisions_are_refused(self):
        s, _, _ = session(); i = item(s, "FIELD", "Account.profile.name")
        with self.assertRaises(ApprovalRefused): s.decide("item-nope", approval(i["item_hash"]))
        with self.assertRaises(ApprovalRefused): s.decide(i["item_id"], approval(item(s, "FIELD", "Account.balance_cents")["item_hash"]))
        with self.assertRaises(ApprovalRefused): s.decide(i["item_id"], approval(i["item_hash"], reviewer="auto"))
        self.assertEqual(s.status[i["item_id"]], "PENDING"); s.decide(i["item_id"], approval(i["item_hash"]))
        with self.assertRaises(ApprovalRefused) as cm: s.decide(i["item_id"], approval(i["item_hash"]))
        self.assertIn("already", str(cm.exception)); self.assertEqual(len(s.ledger), 1)
    def test_a_rejection_is_recorded_and_approves_nothing(self):
        s, _, _ = session(); rec = decide(s, "FIELD", "Account.profile.name", decision="REJECT"); self.assertEqual((rec["decision"], rec["reviewer"], rec["kind"], rec["result_hash"]), ("REJECT", REVIEWER, "FIELD", None)); self.assertEqual(s.approved, {}); self.assertEqual(list(s.status.values()).count("REJECTED"), 1)
    def test_the_ledger_records_who_what_when_and_a_hash_of_the_result(self):
        s, _, _ = session(); m = decide(s, "FIELD", "Account.profile.name"); r = s.ledger[0]; self.assertEqual((r["seq"], r["reviewer"], r["statement"], r["decided_at"], r["decision"], r["kind"], r["result_hash"]), (1, REVIEWER, STATEMENT, WHEN, "APPROVE", "FIELD", sha(m)))
class BoundaryRouteTests(unittest.TestCase):
    def test_an_unmodified_candidate_is_promoted_through_the_audited_boundary_inbound_only(self):
        s, _, _ = session(); m = decide(s, "FIELD", "Account.profile.name"); self.assertEqual((m["mapping_state"], m["proposed_by"], m["deterministic_validation_performed"], m["outbound"]["supported"]), ("VALIDATED", "AI_ASSISTED", True, False))
        self.assertTrue(m["validation_ref"]["evidence_id"].startswith("val-ai-")); self.assertTrue(s.service.verify_promotion(m)); self.assertTrue(s.service.has_issued(m)); PackRegistry(**s.service.registry_hooks())
    def test_the_boundary_route_accepts_no_other_parameter_and_cannot_be_used_for_a_field_with_no_candidate(self):
        s, _, _ = session()
        with self.assertRaises(ApprovalRefused): decide(s, "FIELD", "Account.profile.name", outbound="PROPOSED")
        with self.assertRaises(ApprovalRefused): decide(s, "FIELD", "Account.profile.email", chosen_canonical_ref="Party.contact_email")
        with self.assertRaises(ApprovalRefused): decide(s, "FIELD_MANUAL", "Account.status")
        with self.assertRaises(ApprovalRefused): decide(s, "FIELD", "Account.profile.name", route="SIDEWAYS")
        self.assertEqual(s.approved, {})
    def test_an_ambiguous_mapping_stays_unpromotable_until_the_human_chooses_with_evidence(self):
        doc = mini({"/things": get_list({"type": "object", "properties": {"items": arr("Thing"), "next_cursor": {"type": "string"}}}, [q("cursor")])}, THING); s, _, pd = session(doc=doc); ev = {"evidence_id": "review-note-1", "evidence_hash": "c" * 64}
        for kw in ({}, {"chosen_canonical_ref": "Task.title"}, {"chosen_canonical_ref": "Task.title", "resolution_evidence": {"evidence_id": "x"}}, {"chosen_canonical_ref": "Party.nonsense", "resolution_evidence": ev}):
            with self.subTest(kw), self.assertRaises(ApprovalRefused): decide(s, "FIELD", "Thing.title", **kw)
            self.assertEqual(s.status[item(s, "FIELD", "Thing.title")["item_id"]], "PENDING")
        m = decide(s, "FIELD", "Thing.title", chosen_canonical_ref="Party.display_name", resolution_evidence=ev); self.assertEqual((m["canonical_ref"], m["mapping_state"]), ("Party.display_name", "VALIDATED")); self.assertTrue(s.service.verify_promotion(m))
        self.assertEqual(s.service.resolution_chain(m)["ambiguity_resolution"]["resolution_evidence"], ev)
    def test_promoted_mappings_register_with_the_boundarys_own_hooks_and_not_without_them(self):
        s, cd, pd = session(); decide(s, "ENTITY", "Account"); decide(s, "FIELD", "Account.profile.name"); out = s.assemble_pack(); reg = PackRegistry(**s.service.registry_hooks()); reg.register(out["pack"])
        with self.assertRaises(PackError): PackRegistry().register(out["pack"])
class HumanRouteTests(unittest.TestCase):
    def test_a_field_with_the_proposed_outbound_is_adopted_by_the_human(self):
        s, _, _ = session(); m = decide(s, "FIELD", "Account.balance_cents", route="HUMAN", outbound="PROPOSED"); self.assertEqual((m["mapping_state"], m["proposed_by"], m["outbound"]["supported"], m["outbound"]["transform"]["parameters"]), ("VALIDATED", "HUMAN", True, {"out": "decimal_to_cents"}))
        self.assertTrue(m["validation_ref"]["evidence_id"].startswith("val-hr-")); self.assertEqual(m["validation_ref"]["kind"], "human-reviewed-mapping-validation"); self.assertFalse(s.service.has_issued(m)); self.assertTrue(s.verify_human_evidence(m)); self.assertTrue(m["mapping_id"].startswith("hr-"))
        bad = copy.deepcopy(m); bad["outbound"]["transform"]["parameters"]["out"] = "decimal_to_dollars"; self.assertFalse(s.verify_human_evidence(bad)); bad = copy.deepcopy(m); bad["validation_ref"]["evidence_hash"] = "d" * 64; self.assertFalse(s.verify_human_evidence(bad))
        for junk in (None, {}, {"validation_ref": None}, {"validation_ref": {"evidence_id": 5}}, {"validation_ref": {"evidence_id": "val-hr-nope", "evidence_hash": H}}): self.assertFalse(s.verify_human_evidence(junk))
    def test_the_evidence_binds_the_approval_the_item_and_the_checks(self):
        s, _, _ = session(); m = decide(s, "FIELD", "Account.balance_cents", route="HUMAN", outbound="PROPOSED"); pl = s.evidence[m["validation_ref"]["evidence_id"]]; self.assertEqual(pl["approval"]["reviewer"], REVIEWER); self.assertEqual(pl["item_hash"], item(s, "FIELD", "Account.balance_cents")["item_hash"]); self.assertTrue(pl["checks"]["inbound"]["passed"]); self.assertEqual(sha(pl), m["validation_ref"]["evidence_hash"])
    def test_a_hand_written_mapping_for_a_field_the_generator_could_not_map(self):
        s, _, _ = session(); mp = {"act": "ACTIVE", "sus": "INACTIVE", "cls": "ARCHIVED"}; ob = {"target_type": "string", "transform": {"kind": "ENUM_MAP", "parameters": {"map": mp}, "deterministic": True}, "target_constraints": [{"constraint_id": "c-enum", "kind": "ENUM", "spec": {"values": ["act"]}}, {"constraint_id": "c-type", "kind": "TYPE", "spec": {"type": "string"}}]}
        m = decide(s, "FIELD_MANUAL", "Account.status", route="HUMAN", canonical_ref="Party.lifecycle_state", transform={"kind": "ENUM_MAP", "parameters": {"map": mp}, "deterministic": True}, outbound=ob); self.assertEqual((m["canonical_ref"], m["proposed_by"], m["inbound"]["source_type"], m["inbound"]["canonical_type"], m["outbound"]["supported"]), ("Party.lifecycle_state", "HUMAN", "string", "ENUM", True))
    def test_a_human_adoption_is_still_deterministically_validated_and_refused_when_it_fails(self):
        s, _, _ = session(); H_ = lambda **kw: decide(s, "FIELD_MANUAL", "Account.status", route="HUMAN", **kw)
        bad_map = {"kind": "ENUM_MAP", "parameters": {"map": {"act": "ACTIVE"}}, "deterministic": True}
        for kw in ({}, {"canonical_ref": "Party.lifecycle_state"}, {"transform": bad_map}, {"canonical_ref": "Party.nonsense", "transform": bad_map}, {"canonical_ref": "Party.lifecycle_state", "transform": {"kind": "EVIL", "parameters": {}, "deterministic": True}}, {"canonical_ref": "Party.lifecycle_state", "transform": bad_map, "extra": 1}):
            with self.subTest(kw), self.assertRaises(ApprovalRefused): H_(**kw)
        self.assertEqual(s.approved, {})
    def test_outbound_cannot_be_enabled_without_a_write_endpoint_or_a_proposal_or_with_malformed_constraints(self):
        s, _, _ = session(); good = {"target_type": "string", "transform": {"kind": "IDENTITY", "parameters": {}, "deterministic": True}, "target_constraints": [{"constraint_id": "c1", "kind": "TYPE", "spec": {"type": "string"}}]}
        for src, kw in (("Property.address.city", {"outbound": "PROPOSED"}), ("Property.address.city", {"outbound": good}), ("Account.profile.name", {"outbound": "WHATEVER"}), ("Account.profile.name", {"outbound": {"target_type": "string"}}), ("Account.profile.name", {"outbound": dict(good, extra=1)}),
                        ("Account.profile.name", {"outbound": dict(good, target_constraints=[])}), ("Account.profile.name", {"outbound": dict(good, target_constraints="x")}), ("Account.profile.name", {"outbound": dict(good, target_constraints=[{"constraint_id": "c", "kind": "PATTERN", "spec": {"regex": "(a+)+$"}}])}),
                        ("Account.profile.name", {"outbound": dict(good, target_constraints=[{"constraint_id": "c", "kind": "TYPE", "spec": {}}])}), ("Account.profile.name", {"outbound": dict(good, target_constraints=[{"constraint_id": "c", "kind": "TYPE", "spec": {"type": "string"}}, "junk"])}),
                        ("Account.profile.name", {"outbound": dict(good, transform={"kind": "ENUM_MAP", "parameters": {"map": {"a": "X", "b": "X"}}, "deterministic": True})}), ("Account.id", {"outbound": good})):
            with self.subTest(msg=src), self.assertRaises(ApprovalRefused): decide(s, "FIELD" if src != "Account.id" else "FIELD_MANUAL", src, route="HUMAN", **kw)
        self.assertEqual(s.approved, {})
    def test_a_field_the_description_marks_read_only_has_no_outbound_proposal_to_adopt(self):
        s, _, _ = session(); doc = None
        with self.assertRaises(ApprovalRefused) as cm: decide(s, "FIELD", "Property.owner_id", route="HUMAN", outbound="PROPOSED")
        self.assertIn("no write endpoint", str(cm.exception))
    def test_an_explicit_outbound_for_a_field_the_write_body_does_not_accept_is_refused(self):
        s, _, _ = session(); good = {"target_type": "string", "transform": {"kind": "IDENTITY", "parameters": {}, "deterministic": True}, "target_constraints": [{"constraint_id": "c1", "kind": "TYPE", "spec": {"type": "string"}}]}
        with self.assertRaises(ApprovalRefused) as cm: decide(s, "FIELD_MANUAL", "Account.audit_created_by", route="HUMAN", canonical_ref="Party.display_name", transform={"kind": "IDENTITY", "parameters": {}, "deterministic": True}, outbound=good)
        self.assertIn("does not accept", str(cm.exception))
    def test_entity_approval(self):
        s, _, _ = session(); m = decide(s, "ENTITY", "Account", outbound="ENABLE"); self.assertEqual((m["kind"], m["canonical_ref"], m["proposed_by"], m["outbound"]["supported"], m["outbound"]["target_type"], m["mapping_state"]), ("ENTITY", "Party", "HUMAN", True, "Account", "VALIDATED")); self.assertTrue(s.verify_human_evidence(m))
        p = decide(s, "ENTITY", "Property"); self.assertFalse(p["outbound"]["supported"])
        s2, _, _ = session()
        with self.assertRaises(ApprovalRefused): decide(s2, "ENTITY", "Property", outbound="ENABLE")
    def test_entity_approval_refusals(self):
        s, _, _ = session()
        for kw in ({"outbound": "ENABLE"}, {"outbound": "maybe"}, {"canonical_ref": "Nonexistent"}, {"bogus": 1}):
            src = "Property" if kw.get("outbound") == "ENABLE" else "Account"
            with self.subTest(kw), self.assertRaises(ApprovalRefused): decide(s, "ENTITY", src, **kw)
        self.assertEqual(s.approved, {})
    def test_an_ambiguous_entity_must_be_resolved_by_choosing_one_of_its_candidates(self):
        doc = mini({"/things": get_list({"type": "object", "properties": {"items": arr("Thing"), "next_cursor": {"type": "string"}}}, [q("cursor")])}, THING); s, _, _ = session(doc=doc)
        for kw in ({}, {"canonical_ref": "Event"}, {"canonical_ref": "Nonexistent"}):
            with self.subTest(kw), self.assertRaises(ApprovalRefused): decide(s, "ENTITY", "Thing", **kw)
        m = decide(s, "ENTITY", "Thing", canonical_ref="Party"); self.assertEqual(m["canonical_ref"], "Party")
    def test_an_entity_the_generator_could_not_map_is_mapped_by_naming_a_concept(self):
        doc = mini({"/gizmos": get_list({"type": "object", "properties": {"items": arr("Gizmo"), "next_cursor": {"type": "string"}}}, [q("cursor")])}, {"Gizmo": {"type": "object", "properties": {"zork": {"type": "string"}}}}); s, _, _ = session(doc=doc)
        with self.assertRaises(ApprovalRefused): decide(s, "ENTITY_MANUAL", "Gizmo")
        with self.assertRaises(ApprovalRefused): decide(s, "ENTITY_MANUAL", "Gizmo", canonical_ref="Nope")
        m = decide(s, "ENTITY_MANUAL", "Gizmo", canonical_ref="Task"); self.assertEqual((m["canonical_ref"], m["mapping_id"].startswith("hr-ent-")), ("Task", True))
    def test_action_approval_needs_a_human_chosen_name_and_a_writable_entity(self):
        s, _, _ = session()
        for kw in ({}, {"canonical_action": "x"}, {"canonical_action": "bad name!"}, {"canonical_action": 5}, {"canonical_action": "ok.name", "extra": 1}):
            with self.subTest(kw), self.assertRaises(ApprovalRefused): decide(s, "ACTION", None, **kw)
        m = decide(s, "ACTION", None, canonical_action="crm.update_party"); self.assertEqual((m["kind"], m["source_ref"], m["canonical_ref"], m["outbound"]["target_type"], m["proposed_by"]), ("ACTION", "updateAccount", "crm.update_party", "Account", "HUMAN")); self.assertTrue(s.verify_human_evidence(m))
class ConfigApprovalTests(unittest.TestCase):
    def go(self, s, cd, **params): return s.approve_config(approval(cd["draft_hash"], **params))
    def test_an_approved_config_carries_the_named_approval_and_a_reference_never_a_secret(self):
        s, cd, _ = session(); out = self.go(s, cd, credential_ref="secretref:crm.api-key"); self.assertEqual((out["artifact_kind"], out["config"]["credential_ref"], out["approval"]["reviewer"], out["draft_hash"], out["overrides_applied"]), ("ApprovedConnectorConfig", "secretref:crm.api-key", REVIEWER, cd["draft_hash"], []))
        self.assertEqual(out["approved_hash"], sha({k: v for k, v in out.items() if k != "approved_hash"})); self.assertIsNone(cd["config"]["credential_ref"]); self.assertEqual(s.config_decision, out); self.assertEqual(s.ledger[-1]["kind"], "CONFIG")
    def test_the_credential_reference_is_required_well_formed_and_never_a_raw_secret(self):
        s, cd, _ = session()
        for cref in (None, "", CANARY, "secretref:", "secretref:has space", "http://x", "secretref:" + "a" * 101, 5):
            with self.subTest(cref), self.assertRaises(ApprovalRefused): self.go(s, cd, **({} if cref is None else {"credential_ref": cref}))
        self.assertIsNone(s.config_decision)
    def test_a_credential_reference_for_an_unauthenticated_api_is_refused(self):
        s, cd, _ = session(doc=mini({"/things": get_list({"type": "object", "properties": {"items": arr("Thing"), "next_cursor": {"type": "string"}}}, [q("cursor")])}, THING, security=[]))
        with self.assertRaises(ApprovalRefused): self.go(s, cd, credential_ref="secretref:x")
        self.assertEqual(self.go(s, cd)["config"]["auth"], "NONE")
    def test_blocking_undetermined_settings_need_an_explicit_override_and_the_override_must_be_allowed(self):
        doc = mini({"/things": get_list({"type": "object", "properties": {"items": arr("Thing")}}, [q("limit")])}, THING, security=[]); s, cd, _ = session(doc=doc)
        with self.assertRaises(ApprovalRefused) as cm: self.go(s, cd)
        self.assertIn("entities.Thing.list.pagination", str(cm.exception))
        for ov in ({"entities.Thing.list.pagination": "bogus"}, {"entities.Nope.list.pagination": "cursor"}, {"entities.Thing.list.nonsense": 1}, {"connector_id": "x"}, {"credential_ref": "secretref:x"}, {"lookup": 5}, {"entities.Thing.list": {}}, {"entities.Thing.write": 5}, {"entities.Thing.read.pagination": "cursor"}, {"entities.Thing.list.pagination": "cursor", "base_url": "http://plain.invalid"}, {"entities.Thing.list.pagination": "cursor", "max_page_size": 0}, {"entities.Thing.list.pagination": "cursor", "max_page_size": True}, {"entities.Thing.list.pagination": "cursor", "max_page_size": 10001}, {"entities.Thing.list.pagination": "cursor", "auth_header": 5}, {"entities.Thing.list.pagination": "cursor", "scope": "x" * 501}):
            with self.subTest(ov), self.assertRaises(ApprovalRefused): self.go(s, cd, overrides=ov)
        out = self.go(s, cd, overrides={"entities.Thing.list.pagination": "single_page"}); ep = out["config"]["entities"]["Thing"]["list"]; self.assertEqual((ep["pagination"], ep["next_cursor_path"], out["overrides_applied"]), ("cursor", ["__no_next_cursor__"], ["entities.Thing.list.pagination"]))
    def test_overrides_can_set_endpoints_and_recompute_the_allowed_hosts(self):
        s, cd, _ = session(); out = self.go(s, cd, credential_ref="secretref:k", overrides={"base_url": "https://other.invalid/v9", "lookup": None, "entities.Account.write": None, "entities.Account.list.pagination": "offset", "entities.Account.list.total_items_path": ["n"], "idempotency_header": None})
        c = out["config"]; self.assertEqual((c["allowed_hosts"], c["lookup"], c["entities"]["Account"]["write"], c["entities"]["Account"]["list"]["pagination"], c["idempotency_header"]), (["other.invalid"], None, None, "offset", None))
        s, cd, _ = session(); out = self.go(s, cd, credential_ref="secretref:k", overrides={"lookup": {"path": "/by/{key}", "id_field": "ref"}, "entities.Account.write": {"method": "POST", "path": "/accounts"}}); self.assertEqual((out["config"]["lookup"]["path"], out["config"]["entities"]["Account"]["write"]["method"]), ("/by/{key}", "POST"))
    def test_a_config_that_the_connector_would_refuse_is_never_approved(self):
        s, cd, _ = session()
        for ov in ({"auth": "OAUTH2_CLIENT_CREDENTIALS"}, {"base_url": None}, {"entities.Account.list.page_size_param": ""}, {"entities.Account.write": {"method": "GET", "path": "relative"}}):
            with self.subTest(ov), self.assertRaises(ApprovalRefused): self.go(s, cd, credential_ref="secretref:k", overrides=ov)
    def test_a_rejection_of_the_config_is_recorded(self):
        s, cd, _ = session(); self.assertIsNone(s.approve_config(approval(cd["draft_hash"], decision="REJECT"))); self.assertEqual(s.config_decision, "REJECTED"); self.assertEqual(s.ledger[-1]["decision"], "REJECT")
    def test_config_approval_is_bound_to_the_draft(self):
        s, cd, _ = session()
        with self.assertRaises(ApprovalRefused): s.approve_config(approval("e" * 64, credential_ref="secretref:k"))
        with self.assertRaises(ApprovalRefused): s.approve_config(approval(cd["draft_hash"], reviewer="bot", credential_ref="secretref:k"))
        with self.assertRaises(ApprovalRefused): self.go(s, cd, credential_ref="secretref:k", bogus=1)
        with self.assertRaises(ApprovalRefused): self.go(s, cd, credential_ref="secretref:k", overrides=[1])
class AssemblyTests(unittest.TestCase):
    def ready(self):
        s, cd, pd = session(); decide(s, "ENTITY", "Account", outbound="ENABLE"); decide(s, "ENTITY", "Property"); decide(s, "FIELD", "Account.profile.name"); decide(s, "FIELD", "Account.balance_cents", route="HUMAN", outbound="PROPOSED"); decide(s, "ACTION", None, canonical_action="crm.update_party"); return s, cd, pd
    def test_the_preview_is_a_candidate_pack_of_approved_mappings_only(self):
        s, _, pd = self.ready(); out = s.assemble_pack(); p = out["pack"]; self.assertEqual((p["pack_state"], p["pack_id"], out["approval"]), ("CANDIDATE", pd["pack_identity"]["pack_id"], None)); self.assertEqual(len(p["mappings"]), 5); self.assertEqual({m["mapping_state"] for m in p["mappings"]}, {"VALIDATED"})
        self.assertEqual(len(out["left_out"]), len(pd["items"]) - 5); self.assertTrue(all(x["status"] == "PENDING" for x in out["left_out"])); self.assertEqual([m["kind"] for m in p["mappings"]], ["ENTITY", "ENTITY", "FIELD", "FIELD", "ACTION"])
    def test_a_validated_pack_needs_a_pack_level_approval_bound_to_the_assembly(self):
        s, _, _ = self.ready(); h = s.assemble_pack()["assembly_hash"]
        for a in (approval("f" * 64), approval(h, reviewer="pipeline"), approval(h, decision="REJECT"), approval(h, bogus=1)):
            with self.subTest(msg="%s/%s" % (a.reviewer, a.decision)), self.assertRaises(ApprovalRefused): s.assemble_pack(a)
        out = s.assemble_pack(approval(h, version="1.0.0")); p = out["pack"]; self.assertEqual((p["pack_state"], p["pack_version"], p["pack_id"].endswith("-draft"), out["approval"]["reviewer"]), ("VALIDATED", "1.0.0", False, REVIEWER)); self.assertEqual(s.ledger[-1]["kind"], "PACK")
    def test_the_assembly_hash_changes_when_an_approval_is_added(self):
        s, _, _ = self.ready(); h1 = s.assemble_pack()["assembly_hash"]; decide(s, "FIELD", "Account.profile.email"); self.assertNotEqual(h1, s.assemble_pack()["assembly_hash"])
        with self.assertRaises(ApprovalRefused): s.assemble_pack(approval(h1))
    def test_the_assembled_pack_registers_with_both_routes_and_works_in_the_core_translator(self):
        s, cd, pd = self.ready(); out = s.assemble_pack(approval(s.assemble_pack()["assembly_hash"])); pack = out["pack"]; reg = PackRegistry(**s.service.registry_hooks()); reg.register(pack)
        for m in pack["mappings"]: self.assertTrue(s.service.verify_promotion(m) if m["proposed_by"] == "AI_ASSISTED" else s.verify_human_evidence(m))
        tr = Translator(CanonicalModel(MODEL_DEF), reg, Ids(), FakeClock()); ref = {"id": pack["pack_id"], "version": pack["pack_version"], "hash": pack["artifact_hash"]}; ctx = type("C", (), {"tenant_id": "t"})()
        obj = tr.translate_inbound(ctx, ref, "Account", {"id": "a1", "profile": {"name": "Ann", "email": "a@x.invalid"}, "balance_cents": 1234, "status": "act"}, source_system="crm", observation_id="o", schema_fingerprint="0" * 64, source_id="a1")
        self.assertEqual(obj["canonical_type"], "Party"); self.assertEqual(obj["validation_state"], "VALID")
        ob, info = tr.translate_outbound(ref, "Party", {"balance": "12.34"}); self.assertEqual((ob["entity"], ob["fields"]), ("Account", {"balance_cents": 1234})); self.assertEqual(tr.action_mapping(ref, "crm.update_party"), {"operation": "updateAccount", "entity": "Account"})
    def test_consistency_is_enforced(self):
        s, cd, pd = session(); decide(s, "FIELD", "Account.profile.name")
        with self.assertRaises(ApprovalRefused) as cm: s.assemble_pack(); 
        self.assertIn("no approved entity mapping", str(cm.exception))
        decide(s, "ENTITY", "Account"); decide(s, "FIELD", "Account.balance_cents", route="HUMAN", outbound="PROPOSED")
        with self.assertRaises(ApprovalRefused) as cm: s.assemble_pack()
        self.assertIn("not", str(cm.exception))
        s2, _, _ = session(); decide(s2, "ENTITY", "Account", outbound="ENABLE"); decide(s2, "ACTION", None, canonical_action="crm.update_party")
        s2.assemble_pack()
        s3, _, _ = session(); decide(s3, "ACTION", None, canonical_action="crm.update_party")
        with self.assertRaises(ApprovalRefused) as cm: s3.assemble_pack()
        self.assertIn("needs an approved, writable entity", str(cm.exception))
        s4, _, _ = session(); decide(s4, "ENTITY", "Account"); decide(s4, "ACTION", None, canonical_action="crm.update_party")
        with self.assertRaises(ApprovalRefused): s4.assemble_pack()
    def test_a_field_cannot_map_into_another_concept_than_its_entity_and_two_fields_cannot_share_an_attribute(self):
        s, _, _ = session(); decide(s, "ENTITY", "Account", canonical_ref="Party"); mp = lambda: {"kind": "IDENTITY", "parameters": {}, "deterministic": True}
        decide(s, "FIELD_MANUAL", "Account.audit_created_by", route="HUMAN", canonical_ref="Party.display_name", transform=mp()); decide(s, "FIELD", "Account.profile.name")
        with self.assertRaises(ApprovalRefused) as cm: s.assemble_pack()
        self.assertIn("two approved fields map to Party.display_name", str(cm.exception))
        s, _, _ = session(); decide(s, "ENTITY", "Account"); decide(s, "FIELD_MANUAL", "Account.audit_created_by", route="HUMAN", canonical_ref="Task.title", transform=mp())
        with self.assertRaises(ApprovalRefused) as cm: s.assemble_pack()
        self.assertIn("different concept", str(cm.exception))
    def test_two_entity_mappings_for_one_source_entity_are_refused(self):
        s, _, _ = session(); decide(s, "ENTITY", "Account"); m = copy.deepcopy(next(iter(s.approved.values()))); m["mapping_id"] = "other"; s.approved["x"] = m
        with self.assertRaises(ApprovalRefused): s.assemble_pack()
    def test_nothing_approved_means_nothing_to_assemble_even_with_rejections(self):
        s, _, _ = session(); decide(s, "FIELD", "Account.profile.name", decision="REJECT")
        with self.assertRaises(ApprovalRefused): s.assemble_pack()
if __name__ == "__main__": unittest.main()

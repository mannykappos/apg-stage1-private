"""TEST-ONLY synthetic vendors: real HTTP servers on 127.0.0.1 that behave as the three synthetic API descriptions in tests/fixtures say they do. They were written by hand from those descriptions and share no code with the generator, so
checking a draft against them is a real check, not the generator agreeing with itself. They implement the conformance Target protocol (see auif_ext/conformance/suite.py) plus the few extras the synthetic validator needs.
Nothing outside auif_onboard/tests imports this module. None of them is, or stands in for, a real system."""
import base64, json, threading, time, urllib.parse
from auif_ext.tests.loopback import DROP, LoopbackServer, jresp
from auif_ext.conformance.suite import FAULTS
CANARY = "CANARY-s3cr3t-7731"
class Vendor:
    SYNTHETIC = True; faults = set(FAULTS); canary = CANARY; base_path = ""; token_path = None; profile = "base"; entities = (); WRITE = None
    def __init__(self): self.fault_q, self.store, self.lock, self.srv, self.data = [], {}, threading.Lock(), None, {}
    def start(self): self.srv = LoopbackServer(self.handle).start(); return self
    def stop(self): self.srv.stop()
    @property
    def url(self): return self.srv.url
    @property
    def host(self): return self.srv.host
    def credentials(self): return {"secret": CANARY}
    def seed(self, n, entity=None): self.data[entity or self.ENTITY] = [self.record(entity or self.ENTITY, i) for i in range(1, n + 1)]
    def records(self, entity): return list(self.data.get(entity, []))
    def inject(self, fault, count=1):
        assert fault in FAULTS
        with self.lock: self.fault_q += [fault] * count
    def requests(self): return list(self.srv.requests)
    def effects(self, key): return 1 if key in self.store else 0
    def authorized(self, h): return h.get("x-api-key") == CANARY
    def handle(self, method, path, q, h, body):
        if self.token_path and path == self.token_path: return self.token(method, h, body)
        with self.lock: fault = self.fault_q.pop(0) if self.fault_q else None
        if fault == "unauthorized": return jresp({"error": "no"}, 401)
        if fault == "forbidden": return jresp({"error": "no"}, 403)
        if fault == "rate_limited": return jresp({"error": "slow"}, 429, {"Retry-After": "7"})
        if fault == "server_error": return jresp({"error": "down"}, 503)
        if fault == "timeout": time.sleep(1.2); return jresp({})
        if fault == "malformed": return 200, {"Content-Type": "text/html"}, b"<html>oops</html>"
        if fault == "redirect": return 302, {"Location": "/elsewhere"}, b""
        if fault == "dropped_before_apply" or (fault == "dropped_after_apply" and method == "GET"): return DROP
        if not path.startswith(self.base_path + "/") and path != self.base_path: return jresp({"error": "not found"}, 404)
        if not self.authorized(h): return jresp({"error": "unauthorised"}, 401)
        return self.route(method, path[len(self.base_path):], q, h, body, fault)
    def token(self, method, h, body): return jresp({"error": "not found"}, 404)
    def idempotent(self, key, ref, fault):
        ref = self.store.setdefault(key, ref); return DROP if fault == "dropped_after_apply" else jresp({"external_reference": ref})
class CrmVendor(Vendor):
    """Serves tests/fixtures/crm_cursor_apikey.openapi.json: API key in X-Api-Key, cursor paging, PATCH /accounts/{id} with an Idempotency-Key header, GET /idempotency/{key}."""
    profile, ENTITY, ID_FIELD, base_path, entities = "crm", "Account", "id", "/api/v2", ("Account", "Property")
    WRITE = {"entity": "Account", "id": "a1", "fields": {"balance_cents": 5}}
    def record(self, entity, i):
        if entity == "Account": return {"id": "a%d" % i, "profile": {"name": "Name %d" % i, "email": "n%d@example.invalid" % i}, "status": "act", "balance_cents": 1000 + i, "audit_created_by": "sys"}
        return {"id": "p%d" % i, "address": {"street": "%d Synthetic St" % i, "city": "Testville"}, "state": "listed", "owner_id": "a%d" % i}
    def route(self, method, path, q, h, body, fault):
        if method == "GET" and path in ("/accounts", "/properties"):
            ent = "Account" if path == "/accounts" else "Property"; lim = int(q.get("limit", 5))
            if lim > 100: return jresp({"error": "limit too large"}, 400)
            recs = self.records(ent); a = int(q.get("cursor", 0)); b = a + lim; return jresp({"items": recs[a:b], "next_cursor": str(b) if b < len(recs) else None})
        if method == "PATCH" and path.startswith("/accounts/"):
            key = h.get("idempotency-key")
            if not key: return jresp({"error": "Idempotency-Key required"}, 400)
            try: b = json.loads(body)
            except ValueError: return jresp({"error": "bad json"}, 400)
            ok = isinstance(b, dict) and set(b) <= {"profile", "status", "balance_cents"} and (not isinstance(b.get("balance_cents"), int) or b["balance_cents"] >= 0) and b.get("status", "act") in ("act", "sus", "cls") and isinstance(b.get("profile", {}), dict) and set(b.get("profile", {})) <= {"name", "email"} and len(str(b.get("profile", {}).get("name", ""))) <= 100
            if not ok: return jresp({"error": "invalid body"}, 422)
            return self.idempotent(key, "ext-" + urllib.parse.unquote(path.rsplit("/", 1)[1]), fault)
        if method == "GET" and path.startswith("/idempotency/"):
            ref = self.store.get(urllib.parse.unquote(path.rsplit("/", 1)[1])); return jresp({"external_reference": ref}) if ref else jresp({"error": "none"}, 404)
        if method == "GET" and path == "/health": return jresp({})
        return jresp({"error": "not found"}, 404)
class LedgerVendor(Vendor):
    """Serves tests/fixtures/ledger_offset_oauth2.openapi.json: OAuth2 client credentials (Basic client authentication at /oauth/token), offset paging with a total, PUT /customers/{id} with X-Idempotency-Key and a wrapped answer."""
    profile, ENTITY, ID_FIELD, base_path, token_path, entities = "ledger", "Customer", "cust_id", "/rest/v1", "/oauth/token", ("Customer",)
    CLIENT = "client-1"; WRITE = {"entity": "Customer", "id": "c1", "fields": {"full_name": "Full Name", "email_addr": "x@example.invalid", "state_code": 1, "amount_dollars": "1.00"}}
    def __init__(self): super().__init__(); self.tokens, self.n = set(), 0
    def credentials(self): return {"secret": "%s:%s" % (self.CLIENT, CANARY)}
    def record(self, entity, i): return {"cust_id": "c%d" % i, "full_name": "Customer %d" % i, "email_addr": "c%d@example.invalid" % i, "state_code": i % 3, "amount_dollars": "%d.50" % i, "audit_created_at": "2026-01-01T00:00:00Z"}
    def token(self, method, h, body):
        want = "Basic " + base64.b64encode(("%s:%s" % (self.CLIENT, CANARY)).encode()).decode(); form = dict(urllib.parse.parse_qsl(body.decode()))
        if method != "POST" or h.get("authorization") != want or form.get("grant_type") != "client_credentials": return jresp({"error": "invalid_client"}, 401)
        self.n += 1; t = "tok-%d" % self.n; self.tokens.add(t); return jresp({"access_token": t, "token_type": "Bearer", "expires_in": 3600})
    def authorized(self, h): return h.get("authorization", "")[7:] in self.tokens and h.get("authorization", "").startswith("Bearer ")
    def route(self, method, path, q, h, body, fault):
        if method == "GET" and path == "/customers":
            lim = int(q.get("limit", 5)); off = int(q.get("offset", 0))
            if lim > 50: return jresp({"error": "limit too large"}, 400)
            recs = self.records("Customer"); return jresp({"results": recs[off:off + lim], "total": len(recs), "offset": off})
        if method == "PUT" and path.startswith("/customers/"):
            key = h.get("x-idempotency-key")
            if not key: return jresp({"error": "X-Idempotency-Key required"}, 400)
            try: b = json.loads(body)
            except ValueError: return jresp({"error": "bad json"}, 400)
            need = {"full_name", "email_addr", "state_code", "amount_dollars"}
            if not (isinstance(b, dict) and need <= set(b) <= need and b["state_code"] in (0, 1, 2) and isinstance(b["amount_dollars"], str) and len(str(b["full_name"])) <= 100): return jresp({"error": "invalid body"}, 422)
            ref = self.store.setdefault(key, "c-" + urllib.parse.unquote(path.rsplit("/", 1)[1]))
            return DROP if fault == "dropped_after_apply" else jresp({"data": {"id": ref}})
        if method == "GET" and path == "/ping": return jresp({})
        return jresp({"error": "not found"}, 404)
class HelpdeskVendor(Vendor):
    """Serves tests/fixtures/helpdesk_link_swagger2.openapi.json: token in X-Auth-Token, RFC 8288 Link-header paging, a wrapped list, and no write operation at all (read-only)."""
    profile, ENTITY, ID_FIELD, base_path, entities = "helpdesk", "Ticket", "id", "/v3", ("Ticket",)
    WRITE = {"entity": "Ticket", "id": "t1", "fields": {}}
    def authorized(self, h): return h.get("x-auth-token") == CANARY
    def record(self, entity, i): return {"id": "t%d" % i, "title": "Ticket %d" % i, "state": "open" if i % 2 else "closed", "reporter": {"name": "Rep %d" % i, "email": "r%d@example.invalid" % i}, "labels": ["a"], "created_at": "2026-01-01T00:00:00Z"}
    def route(self, method, path, q, h, body, fault):
        if method == "GET" and path == "/tickets":
            lim = int(q.get("limit", 5)); pg = int(q.get("page", 1))
            if lim > 25: return jresp({"error": "limit too large"}, 400)
            recs = self.records("Ticket"); a = (pg - 1) * lim; link = {"Link": '<%s/v3/tickets?limit=%d&page=%d>; rel="next"' % (self.srv.url, lim, pg + 1)} if a + lim < len(recs) else None
            return jresp({"data": recs[a:a + lim]}, headers=link)
        if method == "GET" and path == "/status": return jresp({})
        return jresp({"error": "not found"}, 404)
VENDORS = {"crm_cursor_apikey": CrmVendor, "ledger_offset_oauth2": LedgerVendor, "helpdesk_link_swagger2": HelpdeskVendor}

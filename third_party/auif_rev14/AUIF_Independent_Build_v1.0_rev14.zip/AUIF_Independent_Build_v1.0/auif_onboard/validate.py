"""Validation report: STRICTLY SYNTHETIC. It checks a generated draft against a SYNTHETIC LOOPBACK VENDOR (a local server on 127.0.0.1 that behaves as a synthetic API description says). It requires no fact, credential, behaviour or access
of any real system and refuses to touch anything that is not loopback. Its outcome is information for the human reviewer: it carries no approval, promotes nothing (this module imports neither auif_onboard.review nor any promote/approve capability) and
says so in the report itself (`synthetic_only`, `real_system_validated: False`, `authority: NONE`). Real-system validation is a separate, explicitly gated phase.
Check results: PASS, FAIL (a defect in the draft or the connector it configures), ATTENTION (the draft is incomplete in a way only a human can complete: not a defect), NOT_APPLICABLE (with the reason)."""
import copy, io, unittest
from auif.canonical import CanonicalModel, split_ref
from auif.errors import AuifError, MalformedResponse, TranslationFailure, TransportError
from auif.translation import apply_transform, check_constraint, get_path, set_path
from auif.util import sha
from auif_ext.conformance.suite import ConnectorConformanceCases
from auif_ext.connectors import rest as rest_module
from auif_ext.connectors.http_client import LOOPBACK
from auif_ext.connectors.rest import RestConnector
from . import AUTHORITY
from .errors import RealSystemRefused
from .rest_adapter import to_rest_config
from .secrets_scan import assert_clean, scan
import urllib.parse
SYNTHETIC_CREDENTIAL_REF = "secretref:synthetic-validation"; SYNTHETIC_TENANT_ID = "synthetic-tenant"; PAGE = 7; SAMPLE = 23
WRITE_TESTS = frozenset({"test_a_failed_write_is_maybe_applied_exactly_when_the_request_may_have_reached_the_target", "test_an_idempotent_write_takes_effect_once_and_sends_its_key", "test_a_write_whose_answer_was_lost_can_be_reconciled_when_the_connector_claims_it_can"})
IDEMPOTENCY_TESTS = frozenset({"test_an_idempotent_write_takes_effect_once_and_sends_its_key"})
def loopback_only(vendor):
    host = (urllib.parse.urlsplit(vendor.url).hostname or "").lower()
    if host not in LOOPBACK or not getattr(vendor, "SYNTHETIC", False): raise RealSystemRefused("the synthetic validator only talks to synthetic vendors on loopback")
def harness_overrides(cfg, vendor):
    """(RestConfig field overrides, a list describing each override). The draft's own base path, entities, auth and endpoints are kept: only the destination, the stand-in credential reference and the timeouts change."""
    loopback_only(vendor); base_path = urllib.parse.urlsplit(cfg["base_url"]).path.rstrip("/"); notes = ["base_url host replaced by the synthetic loopback vendor (path kept)", "allowed_hosts replaced by the loopback host", "allow_insecure_loopback enabled", "timeouts shortened"]
    extra = {"base_url": vendor.url + base_path, "allowed_hosts": (vendor.host,), "allow_insecure_loopback": True, "connect_timeout": 0.4, "request_timeout": 0.4, "total_deadline": 1.0}
    if cfg["auth"] != "NONE": extra["credential_ref"] = SYNTHETIC_CREDENTIAL_REF; notes.append("credential_ref set to a stand-in reference name (the draft's is empty)")
    if cfg.get("tenant_header"): extra["tenant_id"] = SYNTHETIC_TENANT_ID; notes.append("tenant_id set to a stand-in value (the draft's is empty)")
    if cfg.get("token_url"): extra["token_url"] = vendor.url + urllib.parse.urlsplit(cfg["token_url"]).path; notes.append("token_url host replaced by the loopback vendor (path kept)")
    return extra, notes
class DraftTarget:
    """The conformance Target for a DRAFT: everything about the vendor from the vendor, the connector from the draft."""
    def __init__(self, config_draft, vendor):
        self.cfg, self.v = config_draft["config"], vendor; self.canary, self.faults, self.ENTITY, self.WRITE = vendor.canary, set(vendor.faults), vendor.ENTITY, vendor.WRITE; self.ID_FIELD = vendor.ID_FIELD
    def start(self): self.v.start()
    def stop(self): self.v.stop()
    def credentials(self): return self.v.credentials() if self.cfg["auth"] != "NONE" else {}
    def seed(self, n): self.v.seed(n, self.ENTITY)
    def inject(self, fault, count=1): self.v.inject(fault, count)
    def requests(self): return self.v.requests()
    def effects(self, key): return self.v.effects(key)
    def connector(self): return harness_connector(self.cfg, self.v)
def harness_connector(cfg, vendor): extra, _ = harness_overrides(cfg, vendor); return RestConnector(to_rest_config(cfg, **extra))
def run_conformance(config_draft, vendor_factory):
    """The extension conformance kit, run programmatically against the connector the draft configures. Write-specific tests are NOT_APPLICABLE when the draft has no writable entity or claims no idempotency; each such skip is listed."""
    cfg = config_draft["config"]; writable = any(e.get("write") for e in cfg["entities"].values()); na = {}
    if not writable: na.update({t: "the draft has no write endpoint" for t in WRITE_TESTS})
    elif cfg["idempotency_header"] is None: na.update({t: "the draft declares no idempotency header and does not claim idempotent writes" for t in IDEMPOTENCY_TESTS})
    class Cases(ConnectorConformanceCases, unittest.TestCase): target_factory = staticmethod(lambda: DraftTarget(config_draft, vendor_factory())); connector_modules = (rest_module,)
    suite = unittest.TestLoader().loadTestsFromTestCase(Cases); keep = unittest.TestSuite(); skipped = []
    for t in suite:
        if t._testMethodName in na: skipped.append({"test": t._testMethodName, "reason": na[t._testMethodName]})
        else: keep.addTest(t)
    res = unittest.TextTestRunner(stream=io.StringIO(), verbosity=0).run(keep)
    bad = {}
    for t, _ in res.failures: bad[t.id().rsplit(".", 1)[-1]] = "AssertionError"
    for t, _ in res.errors: bad[t.id().rsplit(".", 1)[-1]] = "error"
    return {"ran": res.testsRun, "failed": [{"test": k, "kind": v} for k, v in sorted(bad.items())], "not_applicable": sorted(skipped, key=lambda s: s["test"]), "passed": res.testsRun - len(bad) - len(res.skipped), "skipped_by_suite": len(res.skipped)}
def _read_all(conn, entity):
    out, cur = [], None
    for _ in range(100):
        r = conn.read({"entity": entity, "page_size": PAGE, "cursor": cur}); out += r["items"]
        if r["next_cursor"] is None: return out
        cur = r["next_cursor"]
    raise MalformedResponse("paging did not terminate")
def _check(cid, title, result, detail=None): return {"id": cid, "title": title, "result": result, "detail": detail}
def validate_synthetic(config_draft, pack_draft, vendor_factory, model_definition, *, run_conformance_suite=True):
    """-> ValidationReport (plain data, hashed). `vendor_factory` returns a NEW unstarted synthetic vendor (it is called for each independent run)."""
    vendor = vendor_factory()
    if not getattr(vendor, "SYNTHETIC", False): raise RealSystemRefused("the synthetic validator only talks to synthetic vendors on loopback")
    vendor.start()
    try: return _validate(config_draft, pack_draft, vendor, vendor_factory, model_definition, run_conformance_suite)
    finally: vendor.stop()
def _validate(config_draft, pack_draft, vendor, vendor_factory, model_definition, run_conformance_suite):
    cfg = config_draft["config"]; model = CanonicalModel(model_definition); checks, coverage = [], {"entities": {}, "candidates": []}; loopback_only(vendor); extra, notes = harness_overrides(cfg, vendor)
    maps = pack_draft["pack"]["mappings"] if pack_draft["pack"] else []; vendor_canary = vendor.canary
    bad = [m["mapping_id"] for m in maps if m["mapping_state"] in ("VALIDATED", "TRUSTED")]
    intact = (config_draft.get("draft_state") == pack_draft.get("draft_state") == "DRAFT_NOT_APPROVED" and cfg["credential_ref"] is None and not bad and config_draft.get("authority") == pack_draft.get("authority") == AUTHORITY)
    checks.append(_check("draft_is_unapproved", "the drafts are unapproved, hold no credential and contain no validated mapping", "PASS" if intact else "FAIL", {"validated_or_trusted_mappings": bad}))
    leaks = scan([config_draft, pack_draft], "drafts", extra_literals=(vendor_canary,)); checks.append(_check("no_secret_material", "no secret-like material in the drafts", "PASS" if not leaks else "FAIL", {"findings": [{"path": p, "rule": r} for p, r in leaks[:5]]}))
    try: RestConnector(to_rest_config(cfg, **extra)); checks.append(_check("connector_constructs", "the draft configures a connector the generic REST connector accepts", "PASS", {"harness_overrides": notes}))
    except (ValueError, KeyError, TypeError) as e: checks.append(_check("connector_constructs", "the draft configures a connector the generic REST connector accepts", "FAIL", {"error_type": type(e).__name__})); return _finish(config_draft, pack_draft, vendor, checks, coverage, notes, None)
    rec = pack_draft["discovery_record"]; need = {"ENTITY", "FIELD", "OPERATION"}; got = set(rec["coverage"]["obtained_kinds"])
    checks.append(_check("discovery_record", "the discovery record is contract-valid and covers entities, fields and operations", "PASS" if need <= got and len(rec["schema_fingerprint"]["value"]) == 64 else "FAIL", {"record_state": rec["record_state"], "not_obtained": rec["coverage"]["not_obtained_kinds"]}))
    conf = None
    if run_conformance_suite:
        conf = run_conformance(config_draft, vendor_factory); checks.append(_check("conformance_kit", "the connector passes the extension conformance kit against the synthetic vendor", "PASS" if not conf["failed"] and conf["ran"] > 0 else "FAIL", {"ran": conf["ran"], "failed": conf["failed"], "not_applicable": conf["not_applicable"]}))
    conn = RestConnector(to_rest_config(cfg, **extra)); conn.connect(vendor.credentials() if cfg["auth"] != "NONE" else {}); samples = {}
    for ent in cfg["entities"]:
        vendor.seed(SAMPLE, ent); idf = _id_field(vendor, ent)
        try: got_ = _read_all(conn, ent); ids = [r.get(idf) for r in got_]; ok = len(got_) == SAMPLE and len(set(ids)) == SAMPLE; samples[ent] = got_
        except (TransportError, MalformedResponse) as e: ok = False; samples[ent] = []; got_ = []
        checks.append(_check("read_all:%s" % ent, "every seeded record of %s is read, once, through the drafted paging" % ent, "PASS" if ok else "FAIL", {"seeded": SAMPLE, "read": len(got_), "pagination": cfg["entities"][ent]["list"]["pagination"]}))
    _shadow(pack_draft, model, samples, checks, coverage)
    _attention(pack_draft, checks)
    for ent, e in cfg["entities"].items(): _write_roundtrip(ent, e, config_draft, pack_draft, model, samples, conn, vendor, checks)
    return _finish(config_draft, pack_draft, vendor, checks, coverage, notes, conf)
def _id_field(vendor, ent): return vendor.ID_FIELD if ent == vendor.ENTITY else "id"
def _shadow(pack_draft, model, samples, checks, coverage):
    """Apply each CANDIDATE mapping's inbound transform to the synthetic records and check the result against the canonical model. Nothing is promoted: this only measures what a human would be approving."""
    for m in (pack_draft["pack"] or {"mappings": []})["mappings"]:
        if m["kind"] != "FIELD": continue
        ent, _, path = m["source_ref"].partition("."); ctype, attr = split_ref(m["canonical_ref"]); n = ok = 0
        for rec in samples.get(ent, []):
            found, val = get_path(rec, path)
            if not found: continue
            n += 1
            try: v = apply_transform(m["inbound"]["transform"], val, "in")
            except TranslationFailure: continue
            if not [p for p in model.problems(ctype, {attr: v}) if "required attribute" not in p]: ok += 1
        coverage["candidates"].append({"mapping_id": m["mapping_id"], "source_ref": m["source_ref"], "canonical_ref": m["canonical_ref"], "state": m["mapping_state"], "samples": n, "ok": ok, "failed": n - ok})
        checks.append(_check("shadow_translate:%s" % m["source_ref"], "candidate %s -> %s yields valid canonical values on synthetic data (not promoted)" % (m["source_ref"], m["canonical_ref"]), "PASS" if n > 0 and ok == n else ("NOT_APPLICABLE" if n == 0 else "FAIL"), {"samples": n, "ok": ok} if n else {"reason": "no synthetic record carries this field"}))
def _attention(pack_draft, checks):
    todo = pack_draft["unresolved"]; kinds = {}
    for u in todo: kinds[u["kind"]] = kinds.get(u["kind"], 0) + 1
    checks.append(_check("human_work_remaining", "what only a human can settle before approval", "ATTENTION" if todo else "PASS", {"unresolved_by_kind": dict(sorted(kinds.items())), "required_attributes_uncovered": [u["ref"] for u in todo if u["kind"] == "REQUIRED_ATTRIBUTE_UNCOVERED"]}))
def _write_roundtrip(ent, e, config_draft, pack_draft, model, samples, conn, vendor, checks):
    cid = "write_roundtrip:%s" % ent; title = "a write drafted for %s is accepted by the synthetic vendor exactly once" % ent
    if not e.get("write"): checks.append(_check(cid, title, "NOT_APPLICABLE", {"reason": "the draft has no write endpoint for this entity"})); return
    items = [i for i in pack_draft["items"] if i["kind"] == "FIELD" and i["mapping"]["source_ref"].startswith(ent + ".") and i["outbound_proposal"]["supported"]]; paths = {i["mapping"]["source_ref"].split(".", 1)[1] for i in items}
    required = {f["name"] for f in config_draft.get("write_fields", {}).get(ent, []) if f["required"] and not f["read_only"]}; missing = sorted(required - paths)
    if missing: checks.append(_check(cid, title, "ATTENTION", {"reason": "required writable fields have no outbound mapping yet (a human must supply them)", "missing": missing})); return
    rec = (samples.get(ent) or [None])[0]
    if rec is None: checks.append(_check(cid, title, "FAIL", {"reason": "no sample record was read"})); return
    body = {}
    try:
        for i in items:
            m = i["mapping"]; ob = i["outbound_proposal"]; path = m["source_ref"].split(".", 1)[1]; found, val = get_path(rec, path)
            if not found: continue
            canon = apply_transform(m["inbound"]["transform"], val, "in"); out = apply_transform(ob["transform"], canon, "out")
            if not all(check_constraint(c, out) for c in ob["target_constraints"]): checks.append(_check(cid, title, "FAIL", {"reason": "a generated target constraint rejects a value read from the synthetic vendor", "field": path})); return
            set_path(body, path, out)
    except TranslationFailure: checks.append(_check(cid, title, "FAIL", {"reason": "a generated transform could not round-trip a synthetic value"})); return
    key = "onb-validation-%s-1" % ent
    try:
        r = conn.write({"entity": ent, "id": rec.get(_id_field(vendor, ent)), "fields": body, "idempotency_key": key}); conn.write({"entity": ent, "id": rec.get(_id_field(vendor, ent)), "fields": body, "idempotency_key": key})
    except (TransportError, MalformedResponse) as ex: checks.append(_check(cid, title, "FAIL", {"error": getattr(ex, "code", type(ex).__name__), "applied": getattr(ex, "applied", None)})); return
    once = vendor.effects(key) == 1 if config_draft["config"]["idempotency_header"] else True; ref = bool(r.get("external_reference"))
    checks.append(_check(cid, title, "PASS" if once and ref else "FAIL", {"fields_written": sorted(_leaves(body)), "effects": vendor.effects(key), "idempotency_declared": bool(config_draft["config"]["idempotency_header"])}))
def _leaves(d, prefix=""):
    for k, v in d.items():
        if isinstance(v, dict) and v: yield from _leaves(v, prefix + k + ".")
        else: yield prefix + k
def _finish(config_draft, pack_draft, vendor, checks, coverage, notes, conf):
    summary = {r: sum(1 for c in checks if c["result"] == r) for r in ("PASS", "FAIL", "ATTENTION", "NOT_APPLICABLE")}
    rep = {"report_kind": "OnboardingSyntheticValidationReport", "synthetic_only": True, "real_system_validated": False, "authority": AUTHORITY, "status": "PRESENTED_FOR_HUMAN_APPROVAL", "vendor": {"profile": vendor.profile, "synthetic": True}, "harness_overrides": notes,
           "subject": {"config_draft_hash": config_draft["draft_hash"], "pack_draft_hash": pack_draft["draft_hash"]}, "checks": checks, "summary": summary, "all_checks_passed": summary["FAIL"] == 0, "coverage": coverage}
    assert_clean(rep, "validation report", extra_literals=(vendor.canary,)); rep["report_hash"] = sha(rep); return rep

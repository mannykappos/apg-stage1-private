"""Deterministic, standard-library name matching used by the proposer and the pack drafter. Pure functions of their arguments: no state, no I/O, no clock, no randomness, so a draft is reproducible byte for byte.
The synonym groups below are generic English field-name vocabulary; they contain no canonical-model facts and no target-system facts. Every result is a SUGGESTION that a human reviews; nothing here decides anything."""
import re
GROUPS = ({"name", "title", "label", "fullname"}, {"email", "mail", "emailaddress"}, {"status", "state", "lifecycle", "stage", "phase"}, {"balance", "amount", "total", "outstanding"}, {"street", "address", "addr", "line1"}, {"owner", "holder"}, {"city", "town", "locality"})
ENTITY_GROUPS = ({"party", "account", "customer", "client", "contact", "person", "user", "organisation", "organization", "company"}, {"task", "ticket", "issue", "todo", "case", "job"}, {"property", "listing", "estate", "premises", "realty"})
STOP = {"id", "ref", "code", "value", "val", "num", "no"}; FIELD_MIN, ENTITY_MIN, ENTITY_MARGIN, FIELD_MARGIN, PARENT_WEIGHT, SYNONYM_WEIGHT = 0.3, 1.0, 0.5, 0.1, 0.25, 0.7
def _entity_group(t):
    t = t[:-1] if len(t) > 3 and t.endswith("s") else t
    for i, g in enumerate(ENTITY_GROUPS):
        if t in g: return "e%d" % i
    return t
def tokens(name):
    """snake_case, kebab-case, camelCase and dotted names -> a list of lower-case tokens."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(name)); return [t for t in re.split(r"[^A-Za-z0-9]+", s.lower()) if t]
def _group(t):
    for i, g in enumerate(GROUPS):
        if t in g: return "g%d" % i
    return t[:-1] if len(t) > 3 and t.endswith("s") else t
def keys(name):
    ks = {_group(t) for t in tokens(name)}; return ks - {_group(t) for t in STOP} if len(ks) > 1 else ks
def raw(name):
    ts = set(tokens(name)); return ts - STOP if len(ts) > 1 else ts
def score(source_path, canonical_attr):
    """0..1 similarity of a (possibly dotted) source field path to a canonical attribute name. The last path part counts fully; its parents count a quarter each.
    A shared word counts 1, a shared SYNONYM GROUP (name~title) counts SYNONYM_WEIGHT, so an exact word always beats a synonym."""
    parts = str(source_path).split("."); leaf, parents = keys(parts[-1]), set().union(*[keys(p) for p in parts[:-1]]) if len(parts) > 1 else set(); a = keys(canonical_attr)
    if not a or not leaf: return 0.0
    exact = {_group(t) for t in raw(parts[-1]) & raw(canonical_attr)}; syn = (leaf & a) - exact; extra = (parents & a) - leaf
    if not exact and not syn and not extra: return 0.0
    return round((len(exact) + SYNONYM_WEIGHT * len(syn) + PARENT_WEIGHT * len(extra)) / len(a | leaf), 4)
def concept_name_score(entity, concept):
    """1.0 when the entity's name and the concept's name are the same word or generic synonyms (ticket~task); else 0."""
    e, c = {_entity_group(t) for t in tokens(entity)}, {_entity_group(t) for t in tokens(concept.split(".")[-1])}; return 1.0 if e and c and e == c else 0.0
def assign(fields, attrs, compatible=lambda f, a: True):
    """Greedy one-to-one assignment of source fields to canonical attributes by descending score (ties broken by name, so the result is deterministic).
    Returns (pairs, ties): pairs = [(field, attr, score, runner_ups)], ties = fields that could not be placed because another field scored identically for the same attribute."""
    cand = sorted(((score(f, a), f, a) for f in fields for a in attrs if compatible(f, a)), key=lambda x: (-x[0], x[1], x[2])); cand = [c for c in cand if c[0] >= FIELD_MIN]
    used_f, used_a, pairs, ties = set(), set(), [], []
    for sc, f, a in cand:
        if f in used_f or a in used_a: continue
        rivals = [x for x in cand if x[2] == a and x[1] != f and x[1] not in used_f and abs(x[0] - sc) < 1e-9]
        if rivals: ties += [f] + [r[1] for r in rivals]; used_a.add(a); used_f.update([f] + [r[1] for r in rivals]); continue
        runners = sorted(x[2] for x in cand if x[1] == f and x[2] != a and sc - x[0] <= FIELD_MARGIN and x[2] not in used_a)
        used_f.add(f); used_a.add(a); pairs.append((f, a, sc, runners))
    return pairs, sorted(set(ties))
def enum_match(source_values, canonical_values):
    """Map each source enum value to a canonical enum value by (1) equality ignoring case, (2) one being a prefix of the other (act -> ACTIVE). Returns (mapping, unmatched). A value that matches
    more than one canonical value, or that is not matched, is left UNMATCHED: the proposer never guesses a meaning."""
    out, unmatched = {}, []
    for sv in source_values:
        s = str(sv).lower(); exact = [c for c in canonical_values if str(c).lower() == s]
        hits = exact or [c for c in canonical_values if len(s) >= 2 and (str(c).lower().startswith(s) or s.startswith(str(c).lower()))]
        if len(hits) == 1: out[str(sv)] = hits[0]
        else: unmatched.append(str(sv))
    if len(set(out.values())) != len(out): dup = {v for v in out.values() if list(out.values()).count(v) > 1}; unmatched += sorted(k for k, v in out.items() if v in dup); out = {k: v for k, v in out.items() if v not in dup}
    return out, sorted(set(unmatched))

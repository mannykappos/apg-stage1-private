"""Draft translation-pack generator. config draft + canonical model -> PackDraft: a contract-valid CANDIDATE pack plus the review items a human works through. The mapping boundary does the proposing and the
validating (auif.ai_boundary: AIMappingService.propose); this module only ASSEMBLES what it returns and adds what the boundary cannot carry (entity candidates, action candidates, outbound proposals). Every mapping is a CANDIDATE or
AMBIGUOUS; none is VALIDATED or TRUSTED; ambiguity stays unresolved. This module never calls promote or resolve_ambiguity and never imports auif_onboard.review: it has no capability to approve anything."""
import copy, types
from auif.ai_boundary import AIMappingService
from auif.canonical import CanonicalModel
from auif.clock import FakeClock
from auif.contracts import validate
from auif.discovery import DiscoveryEngine
from auif.translation import pack_hash
from auif.util import Ids, sha
from . import AUTHORITY, DRAFT_STATE, VERSION, planner
from .proposer import DeterministicProposer
from .secrets_scan import assert_clean
INVERSE = {"cents_to_decimal": "decimal_to_cents", "dollars_to_decimal": "decimal_to_dollars"}; NUMERIC = ("integer", "number")
POLICY = {"default_outcome": "UNMAPPED", "optional_and_unused": [], "ignored_by_rule": []}
OUTBOUND_OFF = {"supported": False, "reason": "candidate only: outbound is enabled by an explicit human decision"}
def outbound_proposal(field, transform, writable_names, entity_writable):
    """A PROPOSED outbound half for a field candidate (never applied by itself). Returns {"supported": False, "reason"} whenever the conversion cannot be reversed or the description does not allow writing the field."""
    no = lambda r: {"supported": False, "reason": r}
    if not entity_writable: return no("the entity has no write endpoint in the draft")
    if field.get("read_only"): return no("the API description marks this field read-only")
    if field["name"] not in writable_names: return no("the write operation's request body does not accept this field")
    k, p, st = transform["kind"], transform.get("parameters", {}), field.get("type", "string")
    if k in ("IDENTITY", "RENAME"): out = copy.deepcopy(transform)
    elif k == "ENUM_MAP":
        if st != "string": return no("ENUM_MAP keys are text, so a %s-coded enumeration cannot be written back" % st)
        if len(set(p["map"].values())) != len(p["map"]): return no("the enum map is many-to-one and cannot be inverted")
        out = copy.deepcopy(transform)
    elif k == "DETERMINISTIC_FUNCTION" and p.get("in") in INVERSE:
        if p["in"] == "dollars_to_decimal" and st != "string": return no("decimal_to_dollars yields text but the source field is numeric")
        out = planner.tr("DETERMINISTIC_FUNCTION", out=INVERSE[p["in"]])
    else: return no("no inverse transform exists for %s" % k)
    cons = [{"constraint_id": "c-type", "kind": "TYPE", "spec": {"type": st}}] if st in ("string", "integer", "number", "boolean") else []
    if not cons: return no("source type %s cannot be checked on write" % st)
    if field.get("enum") and k != "ENUM_MAP": cons.append({"constraint_id": "c-enum", "kind": "ENUM", "spec": {"values": list(field["enum"])}})
    if field.get("max_length") is not None and st == "string": cons.append({"constraint_id": "c-length", "kind": "LENGTH", "spec": {"max": field["max_length"]}})
    if st in NUMERIC and (field.get("minimum") is not None or field.get("maximum") is not None) and k in ("IDENTITY", "RENAME", "DETERMINISTIC_FUNCTION"):
        spec = {n: field[n] for n in ("minimum", "maximum") if field.get(n) is not None}; cons.append({"constraint_id": "c-range", "kind": "RANGE", "spec": {{"minimum": "min", "maximum": "max"}[n]: v for n, v in spec.items()}})
    return {"supported": True, "target_type": st, "transform": out, "target_constraints": cons}
def _item(kind, mapping, **extra):
    it = {"item_id": "item-" + mapping["mapping_id"] if mapping else extra.pop("item_id"), "kind": kind, "status": "PENDING", "mapping": mapping}; it.update(extra); it["item_hash"] = sha({k: v for k, v in it.items() if k != "status"}); return it
def build_pack(pack_id, version, kind, fingerprints, mappings, model_version, state="CANDIDATE", classes=None, policy=None):
    p = {"contract_kind": "TranslationPack", "pack_id": pack_id, "pack_version": version, "artifact_hash": "0" * 64, "immutable": True, "contains_governance_logic": False, "contains_secrets": False, "pack_state": state, "target_system_kind": kind,
         "schema_expectations": {"compatible_fingerprints": list(fingerprints)}, "canonical_model_compat": {"min": model_version, "max": model_version}, "auif_contract_compat": {"min": "1.0.0", "max": "1.0.99"}, "mappings": mappings,
         "unmapped_field_policy": copy.deepcopy(policy or POLICY), "classification_mappings": list(classes or []), "provenance_rules": {"preserve_source_object": True, "preserve_source_field": True, "preserve_pack_identity": True}}
    p["artifact_hash"] = pack_hash(p); return validate("translation#TranslationPack", p)
def draft_pack(config_draft, model_definition, *, proposer=None, clock=None):
    """Deterministic: the same inputs always give the same draft, hash included."""
    model = CanonicalModel(model_definition); ids = Ids(); clk = clock or FakeClock(); cfg = config_draft["config"]; doc = config_draft["discovery_document"]
    rec = DiscoveryEngine(clk, ids).build_record(types.SimpleNamespace(tenant_id="onboarding-draft"), "onboarding-draft", "target-" + config_draft["source"]["openapi_sha256"][:12], "draft", {"id": cfg["connector_id"], "version": cfg["version"]}, doc)
    prop = proposer or DeterministicProposer(model_definition); service = AIMappingService(prop, model, ids); res = service.propose(rec)
    concept_defs = planner.concepts(model_definition); fields_by_entity = {e["name"]: e["fields"] for e in doc["entities"]}; write_fields = config_draft.get("write_fields", {}); items, mappings, unresolved = [], [], []
    plans = {e: planner.plan_entity(e, fs, concept_defs) for e, fs in sorted(fields_by_entity.items())}
    for ent, plan in plans.items():                                                                                                                 # ENTITY candidates
        if not plan["chosen"]:
            why = "the entity resembles no canonical concept (best scores: %s)" % ", ".join("%s=%s" % kv for kv in sorted(plan["scores"].items(), key=lambda kv: (-kv[1], kv[0]))[:3]); unresolved.append({"kind": "ENTITY_UNMAPPED", "ref": ent, "reason": why})
            items.append(_item("ENTITY_MANUAL", None, item_id="item-manual-" + sha(["entity", ent])[:10], source_ref=ent, reason=why, writable=bool(cfg["entities"][ent]["write"]))); continue
        amb = plan["ambiguous"]; m = {"mapping_id": "onb-ent-" + sha([ent] + (plan["chosen"] if amb else plan["chosen"][:1]))[:10], "kind": "ENTITY", "source_ref": ent, "canonical_ref": plan["chosen"][0], "mapping_state": "AMBIGUOUS" if amb else "CANDIDATE", "proposed_by": "DETERMINISTIC_TOOL",
                                                                                                             "inbound": {"source_type": "entity", "canonical_type": plan["chosen"][0], "transform": copy.deepcopy(planner.ID_T)}, "outbound": dict(OUTBOUND_OFF)}
        if amb: m["ambiguity"] = {"candidate_meanings": list(plan["chosen"]), "resolution_required": True}; unresolved.append({"kind": "AMBIGUOUS", "ref": m["mapping_id"], "reason": "entity %s resembles several concepts: %s" % (ent, ", ".join(plan["chosen"]))})
        validate("translation#Mapping", m); mappings.append(m)
        w = cfg["entities"][ent]["write"]; items.append(_item("ENTITY", m, scores=plan["scores"], writable=bool(w), write_endpoint=({"method": w["method"], "path": w["path"]} if w else None)))
    fmap_by_src = {}
    for m in res["candidates"]:
        ent, _, path = m["source_ref"].partition("."); fld = next(f for f in fields_by_entity[ent] if f["name"] == path); w = cfg["entities"][ent]["write"]; note = prop.notes.get((m["source_ref"], m["canonical_ref"]), {}) if isinstance(prop, DeterministicProposer) else {}
        ob = outbound_proposal(fld, m["inbound"]["transform"], {f["name"] for f in write_fields.get(ent, [])}, bool(w)); mappings.append(m); fmap_by_src[m["source_ref"]] = m
        items.append(_item("FIELD", m, outbound_proposal=ob, rationale=note.get("rationale"), score=note.get("score")))
        if m["mapping_state"] == "AMBIGUOUS": unresolved.append({"kind": "AMBIGUOUS", "ref": m["mapping_id"], "reason": "%s could mean: %s" % (m["source_ref"], ", ".join(m["ambiguity"]["candidate_meanings"]))})
    for r in res["rejected"]: unresolved.append({"kind": "FIELD_PROPOSAL_REJECTED", "ref": r["proposal"], "reason": "; ".join(r["problems"])[:300]})
    skipped = prop.skipped if isinstance(prop, DeterministicProposer) else {}
    for ent in sorted(fields_by_entity):
        for f in fields_by_entity[ent]:
            src = "%s.%s" % (ent, f["name"])
            if src not in fmap_by_src and not any(u["ref"] == src for u in unresolved):
                why = skipped.get(src, "no candidate was proposed"); unresolved.append({"kind": "FIELD_UNMAPPED", "ref": src, "reason": why}); w = cfg["entities"][ent]["write"]
                items.append(_item("FIELD_MANUAL", None, item_id="item-manual-" + sha(src)[:10], source_ref=src, field=copy.deepcopy(f), reason=why, entity_writable=bool(w), accepted_by_write=f["name"] in {x["name"] for x in write_fields.get(ent, [])}))
    for ent, plan in plans.items():                                                                                                                 # required canonical attributes no candidate covers
        for c in plan["chosen"][:1]:
            covered = {m["canonical_ref"] for m in mappings if m["kind"] == "FIELD" and m["source_ref"].startswith(ent + ".")}
            for a, d in sorted(concept_defs[c].items()):
                if d["required"] and "%s.%s" % (c, a) not in covered: unresolved.append({"kind": "REQUIRED_ATTRIBUTE_UNCOVERED", "ref": "%s.%s" % (c, a), "reason": "no candidate maps a field of %s to the required attribute %s.%s" % (ent, c, a)})
    for o in doc["operations"]:
        if o["kind"] == "write":
            ent = o["entities"][0]; items.append(_item("ACTION", None, item_id="item-action-" + sha([o["name"], ent])[:10], operation=o["name"], entity=ent, canonical_action=None, needs="the canonical action name, supplied by a human"))
            unresolved.append({"kind": "ACTION_NAME_NEEDED", "ref": o["name"], "reason": "the canonical action vocabulary is not known to the generator: a human names the canonical action for %s" % o["name"]})
    ident = {"pack_id": "onb-%s-draft" % cfg["connector_id"][4:], "pack_version": VERSION, "target_system_kind": "openapi:%s" % cfg["connector_id"], "fingerprints": [rec["schema_fingerprint"]["value"]], "canonical_model_version": model.version}
    pack = build_pack(ident["pack_id"], VERSION, ident["target_system_kind"], ident["fingerprints"], mappings, model.version) if mappings else None            # the pack contract cannot be empty: with no candidate there is no pack, only manual items
    draft = {"artifact_kind": "TranslationPackDraft", "draft_state": DRAFT_STATE, "authority": AUTHORITY, "pack_identity": ident, "pack": pack, "items": items, "unresolved": unresolved, "rejected": res["rejected"], "flags": res["flags"] + [("instruction-like text in field: %s" % f) for f in res["instruction_like_fields"]], "discovery_record": rec,
             "source": {"config_draft_hash": config_draft["draft_hash"], "openapi_sha256": config_draft["source"]["openapi_sha256"], "proposer": getattr(prop, "NAME", type(prop).__name__), "canonical_model_version": model.version}}
    assert_clean(draft, "pack draft"); draft["draft_hash"] = sha(draft); return draft

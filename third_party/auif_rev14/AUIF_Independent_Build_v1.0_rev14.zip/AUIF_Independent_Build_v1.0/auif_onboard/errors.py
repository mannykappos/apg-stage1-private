"""Errors of the onboarding accelerator. None of them ever carries the text that caused it when that text could be a secret."""
from auif.errors import AuifError
class OnboardError(AuifError): pass
class SpecRejected(OnboardError): """The supplied API description cannot be used (too large, malformed, hostile)."""
class SecretLeak(OnboardError): """Secret-like material was found where none may exist. The message names WHERE and WHICH RULE, never the material."""
class ApprovalRefused(OnboardError): """A human approval was missing, malformed, not bound to what it claims to approve, or the requested approval is not permitted."""
class RealSystemRefused(OnboardError): """The synthetic validator was pointed at something that is not a local loopback vendor."""

"""Command line: `python -m auif_onboard draft --spec API.json --canonical-model MODEL.json --out DIR`.
Reads ONE local API description and ONE local canonical model definition; writes config_draft.json, pack_draft.json and SUMMARY.txt into DIR (created if absent; an existing file is never overwritten). It makes no network call, reads no credential and
approves nothing. Every file is screened for secret-like material BEFORE it is written; a finding aborts with nothing written. Review and approval are done through auif_onboard.review (a named human act), not from here."""
import argparse, json, os, sys
from auif.errors import AuifError
from auif.util import canon
from . import AUTHORITY, DRAFT_STATE, config_gen, openapi, pack_draft
from .secrets_scan import assert_clean
def summarise(cd, pd):
    cfg = cd["config"]; blocking = [u["field"] for u in cd["undetermined"] if u["blocking"]]; kinds = {}
    for u in pd["unresolved"]: kinds[u["kind"]] = kinds.get(u["kind"], 0) + 1
    states = {}
    for m in (pd["pack"] or {"mappings": []})["mappings"]: states[m["mapping_state"]] = states.get(m["mapping_state"], 0) + 1
    lines = ["AUIF onboarding DRAFT (%s, authority: %s): nothing here is approved." % (DRAFT_STATE, AUTHORITY), "connector id: %s" % cfg["connector_id"], "authentication: %s" % cfg["auth"], "entities: %s" % (", ".join(sorted(cfg["entities"])) or "none"),
             "determined settings: %d; assumed defaults: %d; undetermined: %d (blocking: %s)" % (len(cd["determined"]), len(cd["assumed_defaults"]), len(cd["undetermined"]), ", ".join(blocking) or "none"),
             "mappings by state: %s" % (", ".join("%s=%d" % kv for kv in sorted(states.items())) or "none"), "human work remaining: %s" % (", ".join("%s=%d" % kv for kv in sorted(kinds.items())) or "none"), "config draft hash: %s" % cd["draft_hash"], "pack draft hash: %s" % pd["draft_hash"]]
    return "\n".join(lines) + "\n"
def main(argv=None, out=None):
    out = out or sys.stdout; ap = argparse.ArgumentParser(prog="auif_onboard", description="Drafting and review accelerator: it drafts, a human approves."); sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("draft", help="draft a connector configuration and a candidate translation pack from an OpenAPI/Swagger JSON file"); d.add_argument("--spec", required=True); d.add_argument("--canonical-model", required=True); d.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    try:
        with open(a.spec, "rb") as f: doc, h = openapi.load(f.read())
        with open(a.canonical_model, "r", encoding="utf-8") as f: model = json.load(f)
        cd = config_gen.draft_config(openapi.parse(doc), h); pd = pack_draft.draft_pack(cd, model)
        files = {"config_draft.json": json.dumps(cd, indent=1, sort_keys=True) + "\n", "pack_draft.json": json.dumps(pd, indent=1, sort_keys=True) + "\n", "SUMMARY.txt": summarise(cd, pd)}
        for name, text in files.items(): assert_clean(text, name)
    except (AuifError, OSError, ValueError) as e:
        out.write("refused: %s\n" % (str(e)[:300] if isinstance(e, AuifError) else type(e).__name__)); return 2
    created = []
    try:
        os.makedirs(a.out, exist_ok=True)
        if [n for n in files if os.path.lexists(os.path.join(a.out, n))]: raise FileExistsError(a.out)             # checked up front so a refusal leaves the directory exactly as it was
        for name, text in files.items():
            with open(os.path.join(a.out, name), "x", encoding="utf-8") as f: created.append(os.path.join(a.out, name)); f.write(text)
    except OSError as e:
        for path in created:                                                                                   # only files THIS run created are removed
            try: os.remove(path)
            except OSError: pass
        out.write("refused: an output file already exists; nothing was overwritten\n" if isinstance(e, FileExistsError) else "refused: the output directory is not usable (%s); nothing was written\n" % type(e).__name__); return 2
    out.write(files["SUMMARY.txt"]); return 0

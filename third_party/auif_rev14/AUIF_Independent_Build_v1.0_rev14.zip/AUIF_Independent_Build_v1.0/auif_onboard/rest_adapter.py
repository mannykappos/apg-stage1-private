"""Plain-data config (as drafted and as approved) <-> the RestConfig/Endpoint objects of auif_ext. It only builds objects: it opens no socket (RestConnector's constructor does not), reads no credential, and holds no authority."""
from auif_ext.connectors.rest import Endpoint, RestConfig
def endpoint(d):
    t = lambda v: tuple(v) if v is not None else None
    return Endpoint(method=d["method"], path=d["path"], items_path=tuple(d["items_path"]), next_cursor_path=tuple(d["next_cursor_path"]), cursor_param=d["cursor_param"], page_size_param=d["page_size_param"], record_path=tuple(d["record_path"]), id_field=d["id_field"],
                    pagination=d["pagination"], offset_param=d["offset_param"], page_param=d["page_param"], total_items_path=t(d["total_items_path"]), total_pages_path=t(d["total_pages_path"]))
def to_rest_config(cfg, **extra):
    """cfg: the `config` dict of a draft or approved config. `extra` overrides RestConfig fields (the synthetic validator uses it for loopback and timeouts)."""
    if not cfg.get("base_url") or not cfg.get("entities"): raise ValueError("the configuration is incomplete: it has no base_url or no entity")
    kw = dict(connector_id=cfg["connector_id"], version=cfg["version"], base_url=cfg["base_url"], allowed_hosts=tuple(cfg["allowed_hosts"]), credential_ref=cfg["credential_ref"], auth=cfg["auth"], auth_header=cfg["auth_header"], auth_prefix=cfg["auth_prefix"], token_url=cfg["token_url"], scope=cfg["scope"],
              token_auth_style=cfg["token_auth_style"], discover_path=cfg["discover_path"], health_path=cfg["health_path"], idempotency_header=cfg["idempotency_header"], max_page_size=cfg["max_page_size"], tenant_header=cfg.get("tenant_header"), tenant_id=cfg.get("tenant_id"),
              entities={n: {"list": endpoint(e["list"]), "write": endpoint(e["write"]) if e.get("write") else None} for n, e in cfg["entities"].items()}, lookup=endpoint(cfg["lookup"]) if cfg.get("lookup") else None)
    kw.update(extra); return RestConfig(**kw)

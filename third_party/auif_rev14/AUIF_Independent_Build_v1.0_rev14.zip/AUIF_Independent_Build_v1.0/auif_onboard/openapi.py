"""OpenAPI 3.0 / 3.1 and Swagger 2.0 (JSON) -> a small, plain-data API model. The document is UNTRUSTED INPUT: it is size-bounded, only local `$ref`s are followed (with a depth and cycle guard), and only STRUCTURE is
read (names, types, enums, formats, limits). Descriptions, summaries, examples, defaults (other than a server-variable default) and every `x-` extension are never read, so a credential pasted into any of them cannot reach an output.
Everything the document does not say stays absent here (None / not listed); deciding what to do about it belongs to config_gen, which reports it as undetermined. Standard library only; no network; YAML is not supported (convert to JSON first)."""
import json, re
from auif.util import sha
from .errors import SpecRejected
MAX_BYTES, MAX_OPERATIONS, MAX_PROPERTIES, MAX_REF_DEPTH, MAX_SCHEMA_DEPTH = 5_000_000, 2000, 500, 8, 6
METHODS = ("get", "put", "post", "delete", "patch"); FIELD_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_-]{0,63}$"); SCOPE_NAME = re.compile(r"^[A-Za-z0-9._:/-]{1,100}$")
def _bad_constant(c): raise SpecRejected("the document contains a non-JSON constant")
def load(source):
    """bytes | str | dict -> (document, sha256 of its canonical JSON). Refuses oversize, non-JSON and non-object input."""
    if isinstance(source, (bytes, bytearray, str)):
        raw = source.encode("utf-8") if isinstance(source, str) else bytes(source)
        if len(raw) > MAX_BYTES: raise SpecRejected("the document is larger than %d bytes" % MAX_BYTES)
        try: doc = json.loads(raw.decode("utf-8"), parse_constant=_bad_constant)
        except (ValueError, UnicodeDecodeError, RecursionError): raise SpecRejected("the document is not valid JSON (YAML is not supported: convert it to JSON first)")
    else: doc = source
    if not isinstance(doc, dict): raise SpecRejected("the document is not a JSON object")
    try: size = len(json.dumps(doc))
    except (TypeError, ValueError, RecursionError): raise SpecRejected("the document is not plain JSON data")
    if size > MAX_BYTES: raise SpecRejected("the document is larger than %d bytes" % MAX_BYTES)
    return doc, sha(doc)
def _dialect(doc):
    v = doc.get("openapi")
    if isinstance(v, str) and re.match(r"^3\.[01](\.\d+)?$", v): return "openapi-" + v[:3]
    if doc.get("swagger") == "2.0": return "swagger-2.0"
    raise SpecRejected("not an OpenAPI 3.0/3.1 or Swagger 2.0 document")
def _pointer(doc, ref):
    if not (isinstance(ref, str) and ref.startswith("#/")): return None
    cur = doc
    for part in ref[2:].split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        if not isinstance(cur, dict) or part not in cur: return None
        cur = cur[part]
    return cur
def _deref(doc, node, trail=()):
    """Follow a chain of local $refs. Returns (node, ref_name, problem, trail): `trail` lists every reference followed so far, so a cycle is caught the second time round."""
    name = None
    for _ in range(MAX_REF_DEPTH):
        if not (isinstance(node, dict) and "$ref" in node): return node, name, None, trail
        ref = node["$ref"]
        if ref in trail: return None, name, "circular reference", trail
        trail += (ref,); target = _pointer(doc, ref)
        if target is None: return None, name, "reference is not local or does not resolve", trail
        name = ref.rsplit("/", 1)[-1] if isinstance(ref, str) else None; node = target
    return None, name, "reference chain is too deep", trail
def _d3(doc, node): return _deref(doc, node)[:3]
def _num(v): return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None
def _nint(v): return v if isinstance(v, int) and not isinstance(v, bool) and v >= 0 else None
def schema(doc, node, depth=0, trail=()):
    """A normalised schema node: {type, ref_name, properties, required, items, enum, format, nullable, read_only, write_only, max_length, minimum, maximum, variants, problems}."""
    out = {"type": "unknown", "ref_name": None, "properties": {}, "required": [], "items": None, "enum": None, "format": None, "nullable": False, "read_only": False, "write_only": False, "max_length": None, "minimum": None, "maximum": None, "variants": False, "problems": []}
    node, rname, prob, trail = _deref(doc, node, trail)
    out["ref_name"] = rname
    if prob: out["problems"].append(prob); return out
    if not isinstance(node, dict): return out
    if depth > MAX_SCHEMA_DEPTH: out["problems"].append("schema nesting is too deep"); return out
    for part in node.get("allOf", []) if isinstance(node.get("allOf"), list) else []:
        sub = schema(doc, part, depth + 1, trail)
        for k in ("properties",): out[k].update(sub[k])
        out["required"] = sorted(set(out["required"]) | set(sub["required"])); out["problems"] += sub["problems"]; out["variants"] = out["variants"] or sub["variants"]
        if out["type"] == "unknown" and sub["type"] != "unknown": out["type"] = sub["type"]
        for k in ("items", "enum", "format", "max_length", "minimum", "maximum"):
            if out[k] is None: out[k] = sub[k]
    if any(isinstance(node.get(k), list) and node[k] for k in ("oneOf", "anyOf")): out["variants"] = True; out["problems"].append("oneOf/anyOf variants are not interpreted")
    t = node.get("type"); nullable = bool(node.get("nullable") is True)
    if isinstance(t, list): nullable = nullable or "null" in t; t = next((x for x in t if x != "null"), None)
    if isinstance(t, str) and t in ("object", "array", "string", "integer", "number", "boolean"): out["type"] = t
    elif t is None and out["type"] == "unknown" and isinstance(node.get("properties"), dict): out["type"] = "object"
    out["nullable"] = out["nullable"] or nullable
    out["read_only"] = node.get("readOnly") is True; out["write_only"] = node.get("writeOnly") is True
    if isinstance(node.get("format"), str) and re.match(r"^[A-Za-z0-9._-]{1,40}$", node["format"]): out["format"] = node["format"]
    if isinstance(node.get("enum"), list) and 0 < len(node["enum"]) <= 200 and all(isinstance(v, (str, int)) and not isinstance(v, bool) and (not isinstance(v, str) or len(v) <= 100) for v in node["enum"]): out["enum"] = list(node["enum"])
    if out["type"] == "string": ml = _nint(node.get("maxLength")); out["max_length"] = ml if ml is not None else out["max_length"]                      # a limit inherited through allOf is kept unless this node states its own
    else: out["max_length"] = None
    if out["type"] in ("integer", "number"): mn, mx = _num(node.get("minimum")), _num(node.get("maximum")); out["minimum"] = mn if mn is not None else out["minimum"]; out["maximum"] = mx if mx is not None else out["maximum"]
    else: out["minimum"] = out["maximum"] = None
    props = node.get("properties")
    if isinstance(props, dict):
        if len(props) > MAX_PROPERTIES: out["problems"].append("too many properties; the schema was not read"); return out
        for pn, pv in props.items():
            if not isinstance(pn, str) or not FIELD_NAME.match(pn): out["problems"].append("a property name is not representable and was skipped"); continue
            out["properties"][pn] = schema(doc, pv, depth + 1, trail)
    if isinstance(node.get("required"), list): out["required"] = sorted(set(out["required"]) | {r for r in node["required"] if isinstance(r, str)})
    if out["type"] == "array" or isinstance(node.get("items"), dict): out["items"] = out["items"] or schema(doc, node.get("items"), depth + 1, trail); out["type"] = "array" if out["type"] in ("unknown", "array") else out["type"]
    return out
def _server_urls(doc, dialect):
    out, rejected = [], []
    def clean(url):
        if not isinstance(url, str) or len(url) > 2048: return None
        if re.search(r"://[^/]*@", url) or "?" in url or "#" in url: rejected.append("a server URL carries credentials, a query or a fragment and was not used"); return None
        return url
    if dialect == "swagger-2.0":
        host, base = doc.get("host"), doc.get("basePath", "")
        if not isinstance(host, str) or not host: return [], []
        schemes = [s for s in doc.get("schemes", []) if isinstance(s, str)] or ["https"]
        for s in sorted(schemes, key=lambda s: s != "https"):
            u = clean("%s://%s%s" % (s, host, base if isinstance(base, str) else "")); u and out.append({"url": u.rstrip("/") if len(u) > len(s) + 4 else u, "relative": False})
        return out, rejected
    for s in doc.get("servers", []) if isinstance(doc.get("servers"), list) else []:
        if not isinstance(s, dict): continue
        url, unresolved = s.get("url"), False
        for vn in re.findall(r"\{([^{}]+)\}", url) if isinstance(url, str) else []:
            d = (s.get("variables") or {}).get(vn, {}).get("default") if isinstance(s.get("variables"), dict) and isinstance(s["variables"].get(vn), dict) else None
            if isinstance(d, str) and re.match(r"^[A-Za-z0-9._-]{1,63}$", d): url = url.replace("{%s}" % vn, d)
            else: unresolved = True
        url = clean(url)
        if url is None: continue
        out.append({"url": url.rstrip("/"), "relative": not re.match(r"^https?://", url), "unresolved_variables": unresolved})
    return out, rejected
def _security_schemes(doc, dialect):
    raw = doc.get("securityDefinitions") if dialect == "swagger-2.0" else (doc.get("components") or {}).get("securitySchemes")
    out = {}
    for name, s in (raw.items() if isinstance(raw, dict) else []):
        s, _, prob = _d3(doc, s)
        if prob or not isinstance(s, dict) or not isinstance(name, str): continue
        t = s.get("type"); e = {"kind": "UNKNOWN", "header": None, "token_url": None, "scopes": []}
        if t == "apiKey": e["kind"] = "API_KEY_HEADER" if s.get("in") == "header" else "API_KEY_OTHER"; e["header"] = s.get("name") if s.get("in") == "header" and isinstance(s.get("name"), str) and re.match(r"^[A-Za-z0-9-]{1,64}$", s["name"]) else None
        elif t == "http": e["kind"] = {"bearer": "HTTP_BEARER", "basic": "HTTP_BASIC"}.get(str(s.get("scheme", "")).lower(), "UNKNOWN")
        elif t == "basic": e["kind"] = "HTTP_BASIC"
        elif t == "openIdConnect": e["kind"] = "OIDC"
        elif t == "oauth2":
            flows = s.get("flows") if isinstance(s.get("flows"), dict) else None
            if dialect == "swagger-2.0": flows = {{"application": "clientCredentials"}.get(s.get("flow"), "other"): s}
            cc = (flows or {}).get("clientCredentials")
            if isinstance(cc, dict):
                e["kind"] = "OAUTH2_CC"; tu = cc.get("tokenUrl"); e["token_url"] = tu if isinstance(tu, str) and len(tu) <= 2048 and not re.search(r"://[^/]*@|[?#]", tu) else None
                sc = cc.get("scopes"); e["scopes"] = sorted(k for k in sc if isinstance(k, str) and SCOPE_NAME.match(k))[:50] if isinstance(sc, dict) else []
            elif flows: e["kind"] = "OAUTH2_OTHER"
        out[name] = e
    return out
def _params(doc, path_item, op, dialect):
    merged = {}
    for src in (path_item.get("parameters"), op.get("parameters")):
        for p in src if isinstance(src, list) else []:
            p, _, prob = _d3(doc, p)
            if prob or not isinstance(p, dict) or not isinstance(p.get("name"), str) or p.get("in") not in ("path", "query", "header", "body"): continue
            merged[(p["name"], p["in"])] = p
    return merged
def _json_media(content):
    if not isinstance(content, dict): return None
    for mt in sorted(content):
        if isinstance(mt, str) and (mt.lower() == "application/json" or mt.lower().endswith("+json")): return content[mt]
    return None
def _success(doc, op, dialect):
    """The lowest 2xx response that declares a body schema (else the lowest 2xx, schema None)."""
    resp = op.get("responses") if isinstance(op.get("responses"), dict) else {}
    codes = sorted(c for c in resp if isinstance(c, str) and re.match(r"^2(\d\d|XX)$", c)); first = None
    for code in codes:
        r, _, prob = _d3(doc, resp[code])
        if prob or not isinstance(r, dict): continue
        sch = r.get("schema") if dialect == "swagger-2.0" else (_json_media(r.get("content")) or {}).get("schema")
        hdrs = sorted(h.lower() for h in r.get("headers", {}) if isinstance(h, str)) if isinstance(r.get("headers"), dict) else []
        found = {"status": code, "schema": schema(doc, sch) if sch is not None else None, "headers": hdrs}
        if found["schema"] is not None: return found
        first = first or found
    return first or {"status": None, "schema": None, "headers": []}
def _request(doc, op, params, dialect):
    if dialect == "swagger-2.0":
        b = next((p for (n, i), p in params.items() if i == "body"), None)
        return schema(doc, b.get("schema")) if b and b.get("schema") is not None else None
    rb, _, prob = _d3(doc, op.get("requestBody")) if op.get("requestBody") is not None else (None, None, None)
    if prob or not isinstance(rb, dict): return None
    m = _json_media(rb.get("content")); return schema(doc, m.get("schema")) if isinstance(m, dict) and m.get("schema") is not None else None
def parse(doc):
    """doc (a dict from load()) -> the API model. Never raises for a merely unusual document: what cannot be understood is listed in `rejected`."""
    dialect = _dialect(doc); servers, rej = _server_urls(doc, dialect); rejected = [{"where": "servers", "reason": r} for r in rej]
    info = doc.get("info") if isinstance(doc.get("info"), dict) else {}
    title = info.get("title") if isinstance(info.get("title"), str) else None; ver = info.get("version") if isinstance(info.get("version"), str) and len(info["version"]) <= 64 else None
    schemes = _security_schemes(doc, dialect); gsec = doc.get("security") if isinstance(doc.get("security"), list) else None
    def sec(x):
        if not isinstance(x, list): return None
        return [sorted(k for k in r if isinstance(k, str)) for r in x if isinstance(r, dict)]
    ops = []; paths = doc.get("paths") if isinstance(doc.get("paths"), dict) else {}
    for path in sorted(p for p in paths if isinstance(p, str)):
        item, _, prob = _d3(doc, paths[path])
        if prob or not isinstance(item, dict): rejected.append({"where": path, "reason": "path item could not be read"}); continue
        if not path.startswith("/") or len(path) > 300: rejected.append({"where": "a path", "reason": "path is not acceptable"}); continue
        for m in METHODS:
            op = item.get(m)
            if not isinstance(op, dict): continue
            if len(ops) >= MAX_OPERATIONS: rejected.append({"where": "paths", "reason": "more than %d operations: the rest were not read" % MAX_OPERATIONS}); break
            params = _params(doc, item, op, dialect); oid = op.get("operationId")
            ops.append({"operation_id": oid if isinstance(oid, str) and re.match(r"^[A-Za-z][A-Za-z0-9_.-]{0,63}$", oid) else None, "method": m.upper(), "path": path,
                        "path_params": re.findall(r"\{([^{}]+)\}", path), "query_params": {n: {"required": p.get("required") is True, "schema": schema(doc, p if dialect == "swagger-2.0" else p.get("schema", {}))} for (n, i), p in sorted(params.items()) if i == "query"},
                        "header_params": sorted(n for (n, i) in params if i == "header"), "required_header_params": sorted(n for (n, i), q in params.items() if i == "header" and q.get("required") is True), "security": sec(op["security"]) if "security" in op else None, "request": _request(doc, op, params, dialect), "success": _success(doc, op, dialect)})
    return {"dialect": dialect, "title": title, "api_version": ver, "servers": servers, "security_schemes": schemes, "default_security": sec(gsec) if gsec is not None else None, "operations": ops, "rejected": rejected}

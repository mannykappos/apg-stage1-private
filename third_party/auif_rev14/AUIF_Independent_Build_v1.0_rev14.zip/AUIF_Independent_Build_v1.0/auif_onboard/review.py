"""Human review and sign-off: THE ONLY MODULE IN auif_onboard THAT CAN APPROVE OR PROMOTE ANYTHING.
Nothing the generator produces is approved; every mapping starts as a CANDIDATE and every ambiguity stays unresolved. Approval is an explicit, NAMED human act, represented by a HumanApproval that
  - names a reviewer (an automated or placeholder name is refused) and states, in words, what is being approved,
  - is BOUND by hash to the exact item the human was shown (an approval of anything else, or of an item that has since changed, is refused),
  - carries every choice the human made (`parameters`), so the record is complete.
Two routes, both deterministic-validated before anything becomes VALIDATED:
  BOUNDARY  an unmodified FIELD candidate is promoted through the audited AI boundary (AIMappingService.resolve_ambiguity / promote): inbound-only, AI_ASSISTED, hash-bound validation record `val-ai-...`.
  HUMAN     everything the boundary cannot carry (ENTITY and ACTION mappings, outbound halves, hand-written or modified mappings): the human ADOPTS the definition, proposed_by is HUMAN, and a hash-bound record
            `val-hr-...` binds the complete mapping together with the approval. rev10's PackRegistry has no verification hook for this route; verify_human_evidence() is the check an integrator runs.
This module cannot authenticate that a person is behind an approval; it enforces that one is NAMED, that what they approved is what they were shown, and that the record is complete and tamper-evident. That limit is stated in KNOWN_LIMITATIONS."""
import copy, json, re
from dataclasses import dataclass, field
from auif.ai_boundary import AIMappingService, PromotionRefused
from auif.canonical import CanonicalModel, split_ref
from auif.contracts import validate
from auif.errors import AuifError, ContractViolation
from auif.translation import check_constraint, transform_problems
from auif.util import Ids, sha
from auif_ext.connectors.rest import RestConnector
from . import pack_draft, planner
from .config_gen import ep_dict
from .errors import ApprovalRefused
from .proposer import DeterministicProposer
from .rest_adapter import to_rest_config
from .secrets_scan import REFERENCE, assert_clean
import urllib.parse
AUTOMATED = frozenset({"auto", "automated", "automatic", "system", "generator", "proposer", "bot", "ai", "model", "claude", "anthropic", "llm", "assistant", "script", "cron", "ci", "pipeline", "default", "unknown", "anonymous", "none", "nobody", "auif", "onboard", "accelerator", "validator", "service", "daemon", "agent"})
TS = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]+)?(Z|[+-][0-9]{2}:[0-9]{2})$"); HEX64 = re.compile(r"^[0-9a-f]{64}$"); NAME = re.compile(r"^[^\W\d_][\w .'\-]{1,79}$"); ACTION_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9._:-]{2,100}$")
TOP_KEYS = frozenset({"base_url", "auth", "auth_header", "auth_prefix", "token_url", "scope", "token_auth_style", "discover_path", "health_path", "idempotency_header", "max_page_size", "tenant_header", "tenant_id"}); EP_ATTRS = frozenset({"pagination", "cursor_param", "offset_param", "page_param", "page_size_param", "next_cursor_path", "total_items_path", "total_pages_path", "items_path"})
OVERRIDE_KEY = re.compile(r"^entities\.([A-Za-z][A-Za-z0-9_-]{0,63})\.(list|write)(?:\.([a-z_]+))?$"); CONSTRAINT_KINDS = frozenset({"TYPE", "ENUM", "RANGE", "REQUIRED", "LENGTH"}); NO_NEXT = ["__no_next_cursor__"]
@dataclass(frozen=True)
class HumanApproval:
    """What a named human signs. `subject_hash` is the hash of the exact thing shown (an item's item_hash, a config draft's draft_hash, or an assembly_hash). `parameters` holds every choice the human made."""
    reviewer: str; statement: str; subject_hash: str; decided_at: str; decision: str = "APPROVE"; parameters: dict = field(default_factory=dict)
    def __post_init__(self):
        try: plain = json.loads(json.dumps(self.parameters))
        except (TypeError, ValueError): raise ApprovalRefused("approval parameters must be plain JSON data")
        if not isinstance(plain, dict): raise ApprovalRefused("approval parameters must be an object")
        object.__setattr__(self, "parameters", plain)
    def record(self): return {"reviewer": self.reviewer, "statement": self.statement, "subject_hash": self.subject_hash, "decided_at": self.decided_at, "decision": self.decision, "parameters": copy.deepcopy(self.parameters)}
def check_approval(a, subject_hash):
    """Refuses anything that is not an explicit, named, hash-bound human decision about `subject_hash`."""
    if not isinstance(a, HumanApproval): raise ApprovalRefused("an approval must be a HumanApproval made by a named reviewer")
    if not (isinstance(a.reviewer, str) and NAME.match(a.reviewer.strip())): raise ApprovalRefused("the reviewer must be a person's name")
    if {t for t in re.split(r"[^a-z0-9]+", a.reviewer.lower()) if t} & AUTOMATED: raise ApprovalRefused("the reviewer name is an automated or placeholder name: approval is a named human act")
    if not (isinstance(a.statement, str) and 20 <= len(a.statement.strip()) <= 1000 and len(a.statement.split()) >= 4): raise ApprovalRefused("the approval must state in words what is being approved (at least 20 characters and 4 words)")
    if not (isinstance(a.decided_at, str) and TS.match(a.decided_at)): raise ApprovalRefused("decided_at must be an ISO timestamp")
    if a.decision not in ("APPROVE", "REJECT"): raise ApprovalRefused("decision must be APPROVE or REJECT")
    if not (isinstance(a.subject_hash, str) and HEX64.match(a.subject_hash)) or a.subject_hash != subject_hash: raise ApprovalRefused("the approval is not bound to the item it is applied to (the item changed, or it was meant for another)")
    assert_clean(a.record(), "approval"); return a
def assembly_hash(mappings): return sha(sorted((copy.deepcopy(m) for m in mappings), key=lambda m: m["mapping_id"]))
def _hosts(cfg): return sorted({urllib.parse.urlsplit(u).netloc.lower() for u in (cfg.get("base_url"), cfg.get("token_url")) if u})
def _excluded(field, cfg):
    """A blocking item about an entity the reviewer excluded needs no override: the entity is no longer part of the connector."""
    m = re.match(r"^entities\.([A-Za-z][A-Za-z0-9_-]{0,63})(?:\.|$)", field); return bool(m) and m.group(1) not in cfg["entities"]
def _entity_of(m):
    """The source entity an approved mapping belongs to."""
    return m["source_ref"].split(".", 1)[0] if m["kind"] in ("ENTITY", "FIELD") else m["outbound"]["target_type"]
class ReviewSession:
    def __init__(self, config_draft, pack_draft_, model_definition, *, proposer=None, clock=None):
        for d, label in ((config_draft, "configuration"), (pack_draft_, "pack")):
            if not isinstance(d, dict) or d.get("draft_state") != "DRAFT_NOT_APPROVED" or d.get("draft_hash") != sha({k: v for k, v in d.items() if k != "draft_hash"}): raise ApprovalRefused("the %s draft is not an intact, unapproved draft" % label)
        fresh = pack_draft.draft_pack(config_draft, model_definition, proposer=proposer, clock=clock)
        if fresh["draft_hash"] != pack_draft_["draft_hash"]: raise ApprovalRefused("the pack draft is not what the generator produces for this configuration draft: it was altered or comes from another configuration")
        self.config_draft, self.draft, self.model_def = copy.deepcopy(config_draft), copy.deepcopy(pack_draft_), copy.deepcopy(model_definition); self.model = CanonicalModel(model_definition); self.ids = Ids()
        self.service = AIMappingService(proposer or DeterministicProposer(model_definition), self.model, self.ids); self.record = self.draft["discovery_record"]; self.service.propose(self.record)           # repopulates the boundary's own registry of ambiguous mappings
        self.items = {i["item_id"]: i for i in self.draft["items"]}; self.status = {k: "PENDING" for k in self.items}; self.approved, self.evidence, self.ledger, self.config_decision = {}, {}, [], None
    # --- reading ------------------------------------------------------------------------------------------------------------------------------------------------------------------
    def pending(self): return [{"item_id": k, "kind": self.items[k]["kind"], "item_hash": self.items[k]["item_hash"]} for k in self.items if self.status[k] == "PENDING"]
    def _log(self, subject, kind, a, result=None):
        rec = dict(a.record(), seq=len(self.ledger) + 1, subject=subject, kind=kind, result_hash=sha(result) if result is not None else None); assert_clean(rec, "review ledger"); self.ledger.append(rec); return rec
    # --- items --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    def decide(self, item_id, approval):
        item = self.items.get(item_id)
        if item is None: raise ApprovalRefused("unknown item")
        check_approval(approval, item["item_hash"])
        if self.status[item_id] != "PENDING": raise ApprovalRefused("this item has already been decided")
        if approval.decision == "REJECT": rec = self._log(item_id, item["kind"], approval); self.status[item_id] = "REJECTED"; return rec                  # the ledger entry is screened and written BEFORE the decision takes effect: a refusal leaves the item pending
        k = item["kind"]
        try:
            mapping = {"FIELD": self._field, "FIELD_MANUAL": self._field, "ENTITY": self._entity, "ENTITY_MANUAL": self._entity, "ACTION": self._action}[k](item, approval)
        except PromotionRefused as e: raise ApprovalRefused(str(e))
        except ContractViolation: raise ApprovalRefused("the resulting mapping is not contract-valid")
        self._log(item_id, k, approval, mapping); self.approved[item_id] = mapping; self.status[item_id] = "APPROVED"; return mapping
    def _cfg_entities(self):
        """The entities of the connector as it stands: the APPROVED configuration once one exists (a reviewer may have excluded entities or changed write endpoints), the draft before that."""
        return (self.config_decision["config"] if isinstance(self.config_decision, dict) else self.config_draft["config"])["entities"]
    def _unknown(self, params, allowed):
        extra = set(params) - allowed
        if extra: raise ApprovalRefused("unknown approval parameters: %s" % sorted(extra))
    def _evidence(self, body, approval, item, checks):
        payload = {"mapping_body": body, "approval": approval.record(), "item_hash": item["item_hash"], "checks": checks}; h = sha(payload)
        ref = {"evidence_id": "val-hr-%s-%s" % (body["mapping_id"], h[:8]), "evidence_hash": h, "kind": "human-reviewed-mapping-validation"}; self.evidence[ref["evidence_id"]] = payload; return ref
    def _human(self, item, approval, mapping, checks):
        body = dict(mapping, mapping_state="VALIDATED", proposed_by="HUMAN", deterministic_validation_performed=True); ref = self._evidence(copy.deepcopy(body), approval, item, checks); out = dict(body, validation_ref=ref); validate("translation#Mapping", out); return out
    def _field(self, item, approval):
        p, cand = approval.parameters, item["mapping"]; route = p.get("route", "BOUNDARY")
        if route == "BOUNDARY":
            if item["kind"] != "FIELD": raise ApprovalRefused("a field the generator could not propose has no candidate to promote: use route HUMAN and write the mapping")
            self._unknown(p, {"route", "chosen_canonical_ref", "resolution_evidence"}); m = copy.deepcopy(cand)
            if m["mapping_state"] == "AMBIGUOUS": m = self.service.resolve_ambiguity(m, p.get("chosen_canonical_ref"), p.get("resolution_evidence"))
            elif "chosen_canonical_ref" in p or "resolution_evidence" in p: raise ApprovalRefused("this mapping is not ambiguous: nothing to resolve")
            return self.service.promote(m, self.record)
        if route != "HUMAN": raise ApprovalRefused("route must be BOUNDARY or HUMAN")
        self._unknown(p, {"route", "canonical_ref", "transform", "outbound"}); src = item["mapping"]["source_ref"] if cand else item["source_ref"]; ent, _, path = src.partition(".")
        canon = p.get("canonical_ref", cand["canonical_ref"] if cand else None); tr = p.get("transform", cand["inbound"]["transform"] if cand else None)
        if canon is None or tr is None: raise ApprovalRefused("a hand-written mapping needs canonical_ref and transform")
        r = self.service.validator.check(src, canon, tr, [], self.record)
        if not r["passed"]: raise ApprovalRefused("the mapping does not pass deterministic validation: %s" % "; ".join(r["problems"][:3]))
        ob = self._outbound(item, p.get("outbound", "OFF"), ent, path, cand)
        m = {"mapping_id": "hr-" + sha([src, canon])[:10], "kind": "FIELD", "source_ref": src, "canonical_ref": canon, "inbound": {"source_type": r["source_type"], "canonical_type": r["canonical_type"], "transform": copy.deepcopy(tr)}, "outbound": ob, "mapping_state": "CANDIDATE", "proposed_by": "HUMAN"}
        return self._human(item, approval, m, {"inbound": r, "outbound_problems": []})
    def _outbound(self, item, spec, ent, path, cand):
        off = {"supported": False, "reason": "outbound was not enabled by the reviewer"}
        if spec == "OFF": return off
        w = self._cfg_entities().get(ent, {}).get("write")
        if not w: raise ApprovalRefused("%s has no write endpoint in the configuration: outbound cannot be enabled" % ent)
        if spec == "PROPOSED":
            ob = item.get("outbound_proposal")
            if not (isinstance(ob, dict) and ob.get("supported")): raise ApprovalRefused("the generator has no outbound proposal for this field%s" % (": " + ob["reason"] if isinstance(ob, dict) and "reason" in ob else ""))
            ob = copy.deepcopy(ob)
        elif isinstance(spec, dict):
            if set(spec) - {"target_type", "transform", "target_constraints"} or not {"target_type", "transform", "target_constraints"} <= set(spec): raise ApprovalRefused("an explicit outbound needs exactly target_type, transform and target_constraints")
            if path not in {f["name"] for f in self.config_draft.get("write_fields", {}).get(ent, [])}: raise ApprovalRefused("the write operation's request body does not accept this field")
            ob = dict(copy.deepcopy(spec), supported=True)
        else: raise ApprovalRefused("outbound must be OFF, PROPOSED or an explicit definition")
        bad = transform_problems(ob["transform"], "out")
        if bad: raise ApprovalRefused("outbound transform: %s" % bad[0])
        if not isinstance(ob["target_constraints"], list) or not ob["target_constraints"]: raise ApprovalRefused("outbound needs at least one target constraint")
        for c in ob["target_constraints"]:
            if not (isinstance(c, dict) and c.get("kind") in CONSTRAINT_KINDS and isinstance(c.get("spec"), dict) and isinstance(c.get("constraint_id"), str)): raise ApprovalRefused("an outbound constraint is malformed or of a kind that is not accepted")
            try: check_constraint(c, "probe")
            except (KeyError, TypeError, AuifError): raise ApprovalRefused("an outbound constraint is malformed")
        return ob
    def _entity(self, item, approval):
        p = approval.parameters; self._unknown(p, {"canonical_ref", "outbound"}); cand = item["mapping"]; ent = cand["source_ref"] if cand else item["source_ref"]
        concept = p.get("canonical_ref", cand["canonical_ref"] if cand else None)
        if concept is None: raise ApprovalRefused("an entity the generator could not map needs canonical_ref")
        if cand and cand["mapping_state"] == "AMBIGUOUS" and "canonical_ref" not in p: raise ApprovalRefused("this entity mapping is ambiguous: the reviewer must choose canonical_ref")
        if cand and cand["mapping_state"] == "AMBIGUOUS" and concept not in cand["ambiguity"]["candidate_meanings"]: raise ApprovalRefused("the chosen concept is not one of the candidates")
        if not (isinstance(concept, str) and self.model.has(concept)): raise ApprovalRefused("the canonical concept does not exist in the model")
        if ent not in self._cfg_entities(): raise ApprovalRefused("the source entity does not exist in the configuration")
        mid = cand["mapping_id"] if cand else "hr-ent-" + sha([ent, concept])[:10]; spec = p.get("outbound", "OFF")
        if spec not in ("OFF", "ENABLE"): raise ApprovalRefused("outbound must be OFF or ENABLE")
        if spec == "ENABLE" and not self._cfg_entities()[ent]["write"]: raise ApprovalRefused("%s has no write endpoint in the configuration" % ent)
        ob = {"supported": True, "target_type": ent, "transform": copy.deepcopy(planner.ID_T), "target_constraints": [{"constraint_id": "c-%s-present" % mid, "kind": "REQUIRED", "spec": {}}]} if spec == "ENABLE" else {"supported": False, "reason": "outbound was not enabled by the reviewer"}
        m = {"mapping_id": mid, "kind": "ENTITY", "source_ref": ent, "canonical_ref": concept, "inbound": {"source_type": "entity", "canonical_type": concept, "transform": copy.deepcopy(planner.ID_T)}, "outbound": ob, "mapping_state": "CANDIDATE", "proposed_by": "HUMAN"}
        return self._human(item, approval, m, {"concept_exists": True, "entity_exists": True, "outbound": spec})
    def _action(self, item, approval):
        p = approval.parameters; self._unknown(p, {"canonical_action"}); name = p.get("canonical_action")
        if not (isinstance(name, str) and ACTION_NAME.match(name)): raise ApprovalRefused("the reviewer must name the canonical action (letters, digits, . _ : -; 3 to 101 characters)")
        ent = item["entity"]
        if not self._cfg_entities().get(ent, {}).get("write"): raise ApprovalRefused("%s has no write endpoint in the configuration" % ent)
        m = {"mapping_id": "act-" + sha([item["operation"], name])[:10], "kind": "ACTION", "source_ref": item["operation"], "canonical_ref": name, "inbound": {"source_type": "operation", "canonical_type": name, "transform": copy.deepcopy(planner.ID_T)},
             "outbound": {"supported": True, "target_type": ent, "transform": copy.deepcopy(planner.ID_T), "target_constraints": [{"constraint_id": "c-act-present", "kind": "REQUIRED", "spec": {}}]}, "mapping_state": "CANDIDATE", "proposed_by": "HUMAN"}
        return self._human(item, approval, m, {"operation_exists": True, "entity_writable": True})
    def verify_human_evidence(self, mapping):
        """True only if `mapping` is exactly the HUMAN-route mapping this session validated and a named human approved."""
        ref = mapping.get("validation_ref") if isinstance(mapping, dict) else None; eid = ref.get("evidence_id") if isinstance(ref, dict) else None; pl = self.evidence.get(eid) if isinstance(eid, str) else None
        return bool(pl) and sha(pl) == ref.get("evidence_hash") and pl["mapping_body"] == {k: v for k, v in mapping.items() if k != "validation_ref"}
    # --- configuration ------------------------------------------------------------------------------------------------------------------------------------------------
    def approve_config(self, approval):
        d = self.config_draft; check_approval(approval, d["draft_hash"])
        if approval.decision == "REJECT": self.config_decision = "REJECTED"; self._log("config", "CONFIG", approval); return None
        p = approval.parameters; self._unknown(p, {"credential_ref", "overrides"}); ov = p.get("overrides", {}); cref = p.get("credential_ref")
        if not isinstance(ov, dict): raise ApprovalRefused("overrides must be an object")
        cfg = copy.deepcopy(d["config"])
        for key, val in sorted(ov.items()): self._override(cfg, key, val)
        cfg["allowed_hosts"] = _hosts(cfg)
        gone = sorted({_entity_of(m) for m in self.approved.values()} - set(cfg["entities"]))
        if gone: raise ApprovalRefused("mappings were already approved for entities this configuration excludes: %s" % ", ".join(gone))
        unwritable = sorted({_entity_of(m) for m in self.approved.values() if m["outbound"]["supported"] and not cfg["entities"].get(_entity_of(m), {}).get("write")})
        if unwritable: raise ApprovalRefused("outbound mappings were already approved for entities this configuration makes unwritable (no write endpoint): %s" % ", ".join(unwritable))
        left = [u["field"] for u in d["undetermined"] if u["blocking"] and u["field"] != "credential_ref" and u["field"] not in ov and not _excluded(u["field"], cfg)]
        if left: raise ApprovalRefused("blocking undetermined settings have no explicit override: %s" % ", ".join(left))
        if cfg["auth"] != "NONE":
            if not (isinstance(cref, str) and REFERENCE.match(cref)): raise ApprovalRefused("authentication needs credential_ref, a secret reference NAME of the form secretref:<name> (never the secret itself)")
            cfg["credential_ref"] = cref
        elif cref is not None: raise ApprovalRefused("credential_ref was given but the configuration uses no authentication")
        try: RestConnector(to_rest_config(cfg))
        except (ValueError, KeyError, TypeError) as e: raise ApprovalRefused("the configuration is not acceptable to the connector: %s" % str(e)[:200])
        out = {"artifact_kind": "ApprovedConnectorConfig", "config": cfg, "approval": approval.record(), "overrides_applied": sorted(ov), "draft_hash": d["draft_hash"]}; assert_clean(out, "approved config"); out["approved_hash"] = sha(out)
        self.config_decision = out; self._log("config", "CONFIG", approval, out); return out
    def _override(self, cfg, key, val):
        if key in TOP_KEYS:
            if key == "max_page_size":
                if isinstance(val, bool) or not isinstance(val, int) or not 1 <= val <= 10000: raise ApprovalRefused("max_page_size must be an integer from 1 to 10000")
            elif val is not None and not (isinstance(val, str) and len(val) <= 500): raise ApprovalRefused("%s must be a short text value or null" % key)
            cfg[key] = val; return
        if key == "lookup":
            if val is not None and not isinstance(val, dict): raise ApprovalRefused("lookup must be an endpoint object or null")
            cfg["lookup"] = None if val is None else ep_dict(**val); return
        m = OVERRIDE_KEY.match(key) if isinstance(key, str) else None
        if not m or m.group(1) not in cfg["entities"]: raise ApprovalRefused("override key is not allowed or names an unknown entity")
        ent, which, attr = m.groups()
        if attr is None:
            if which == "list":
                if val is not None: raise ApprovalRefused("the list endpoint can only be removed (null: the reviewer excludes this entity from the connector), not replaced")
                del cfg["entities"][ent]; return                                                                  # rev12: a human may exclude an entity; nothing else about the draft changes
            if not (val is None or isinstance(val, dict)): raise ApprovalRefused("only the write endpoint can be replaced, by an endpoint object or null")
            cfg["entities"][ent]["write"] = None if val is None else ep_dict(**val); return
        if attr not in EP_ATTRS: raise ApprovalRefused("override attribute is not allowed")
        ep = cfg["entities"][ent][which]
        if ep is None: raise ApprovalRefused("the entity has no %s endpoint" % which)
        if attr == "pagination" and val == "single_page": ep["pagination"] = "cursor"; ep["next_cursor_path"] = list(NO_NEXT); return
        ep[attr] = val
    # --- the pack -------------------------------------------------------------------------------------------------------------------------------------------------------------
    def assemble_pack(self, approval=None):
        """The pack of APPROVED mappings only. Without an approval the pack is a CANDIDATE preview; with a pack-level approval bound to the assembly hash it is a VALIDATED pack."""
        order = {"ENTITY": 0, "FIELD": 1, "ACTION": 2}; ms = sorted((copy.deepcopy(m) for m in self.approved.values()), key=lambda m: (order[m["kind"]], m["source_ref"], m["mapping_id"])); self._consistent(ms); h = assembly_hash(ms)
        left_out = [{"item_id": k, "status": s} for k, s in self.status.items() if s != "APPROVED"]; ident = self.draft["pack_identity"]; pid = ident["pack_id"]; ver = ident["pack_version"]
        if approval is not None:
            check_approval(approval, h)
            if approval.decision != "APPROVE": raise ApprovalRefused("a pack is assembled by an APPROVE decision")
            self._unknown(approval.parameters, {"version"}); ver = approval.parameters.get("version", ver); pid = pid[:-len("-draft")] if pid.endswith("-draft") else pid
        if not ms: raise ApprovalRefused("no mapping has been approved: there is nothing to assemble")
        built = pack_draft.build_pack(pid, ver, ident["target_system_kind"], ident["fingerprints"], ms, self.model.version, state="VALIDATED" if approval else "CANDIDATE")
        out = {"pack": built, "assembly_hash": h, "left_out": left_out, "approval": approval.record() if approval else None}; assert_clean(out, "assembled pack")
        if approval: self._log("pack", "PACK", approval, built)
        return out
    def _consistent(self, ms):
        ents = {m["source_ref"]: m for m in ms if m["kind"] == "ENTITY"}; seen = set()
        if len([m for m in ms if m["kind"] == "ENTITY"]) != len(ents): raise ApprovalRefused("two approved entity mappings share a source entity")
        for m in ms:
            if m["kind"] == "FIELD":
                ent = m["source_ref"].split(".", 1)[0]; e = ents.get(ent)
                if e is None: raise ApprovalRefused("%s is approved but its entity %s has no approved entity mapping" % (m["source_ref"], ent))
                if split_ref(m["canonical_ref"])[0] != e["canonical_ref"]: raise ApprovalRefused("%s maps into a different concept than the approved mapping of %s" % (m["source_ref"], ent))
                if m["outbound"]["supported"] and not e["outbound"]["supported"]: raise ApprovalRefused("%s is writable but the entity mapping of %s is not" % (m["source_ref"], ent))
                if m["canonical_ref"] in seen: raise ApprovalRefused("two approved fields map to %s" % m["canonical_ref"])
                seen.add(m["canonical_ref"])
            elif m["kind"] == "ACTION":
                e = ents.get(m["outbound"]["target_type"])
                if e is None or not e["outbound"]["supported"]: raise ApprovalRefused("action %s needs an approved, writable entity mapping for %s" % (m["source_ref"], m["outbound"]["target_type"]))

"""Shared planning logic of the proposer and the pack drafter: which canonical concept does a source entity most resemble, and which canonical attribute does each of its fields most resemble, with a transform
that can express the conversion. Pure and deterministic. It reads the canonical model DEFINITION as plain data. Its output is only ever a proposal."""
import copy
from auif.ai_boundary import SOURCE_TO_CANON
from . import matching
CENTS = {"cents", "minor", "pence"}; ID_T = {"kind": "IDENTITY", "parameters": {}, "deterministic": True}
def tr(kind, **p): return {"kind": kind, "parameters": p, "deterministic": True}
def concepts(model_definition):
    """{concept: {attribute: {type, values, required}}} for the CORE concepts only: module-owned concepts are not proposed as targets."""
    out = {}
    for c in model_definition["concepts"]:
        if c.get("namespace") != "CORE": continue
        out[c["name"]] = {a["name"]: {"type": a["type"], "values": list(a.get("constraints", {}).get("values", [])) or None, "required": bool(a["required"])} for a in c["attributes"]}
    return out
def _supported(field): return field.get("type") in SOURCE_TO_CANON and not field.get("write_only")
def _compatible(field, adef): return adef["type"] in SOURCE_TO_CANON.get(field.get("type", "string"), set())
def plan_entity(entity, fields, concept_defs):
    """fields: [{name (path inside the entity), type, enum?, ...}]. Returns {"scores": {concept: total}, "chosen": [concepts], "ambiguous": bool, "assignments": {concept: (pairs, ties)}}."""
    byname = {f["name"]: f for f in fields if _supported(f)}; scores, assign = {}, {}
    for cname, attrs in sorted(concept_defs.items()):
        pairs, ties = matching.assign(sorted(byname), sorted(attrs), lambda f, a, c=attrs: _compatible(byname[f], c[a])); assign[cname] = (pairs, ties); scores[cname] = round(sum(p[2] for p in pairs) + matching.concept_name_score(entity, cname), 4)
    ranked = sorted(scores.items(), key=lambda kv: (-kv[1], kv[0])); top = ranked[0] if ranked else (None, 0.0)
    if top[1] < matching.ENTITY_MIN: return {"scores": scores, "chosen": [], "ambiguous": False, "assignments": assign}
    chosen = [c for c, s in ranked if top[1] - s < matching.ENTITY_MARGIN and s >= matching.ENTITY_MIN]
    return {"scores": scores, "chosen": chosen, "ambiguous": len(chosen) > 1, "assignments": assign}
def name_hint_cents(path): return bool(CENTS & set(matching.tokens(path.split(".")[-1])))
def choose_transform(field, attr_name, adef):
    """(transform, note) or (None, reason). The reason is what a human needs to know to supply the mapping by hand."""
    st, ct, leaf = field.get("type", "string"), adef["type"], field["name"].split(".")[-1]
    if ct == "ENUM":
        senum = field.get("enum")
        if not senum: return None, "the source field is not an enumeration but %s is" % attr_name
        mapping, unmatched = matching.enum_match(senum, adef["values"] or [])
        if unmatched: return None, "source values with no unambiguous counterpart in %s: %s" % (attr_name, ", ".join(unmatched))
        if set(map(str, senum)) == set(map(str, adef["values"] or [])) and all(str(k) == str(v) for k, v in mapping.items()): return copy.deepcopy(ID_T), "enumerations are identical"
        return tr("ENUM_MAP", map=mapping), "enum values matched by equality or prefix"
    if ct == "DECIMAL":
        if st == "integer" and name_hint_cents(field["name"]): return tr("DETERMINISTIC_FUNCTION", **{"in": "cents_to_decimal"}), "the name says cents"
        if st in ("string", "number", "integer", "decimal"): return tr("DETERMINISTIC_FUNCTION", **{"in": "dollars_to_decimal"}), "ASSUMES major currency units and two decimal places: a human must confirm"
        return None, "no transform to a decimal from %s" % st
    if ct in ("STRING", "REFERENCE") and st == "string": return (copy.deepcopy(ID_T) if matching.tokens(leaf) == matching.tokens(attr_name) else tr("RENAME")), "text copied unchanged"
    if ct == "TIMESTAMP" and st == "string" and field.get("format") in ("date-time", "date"): return copy.deepcopy(ID_T), "ISO timestamp copied unchanged"
    if ct == "BOOLEAN" and st == "boolean": return copy.deepcopy(ID_T), "boolean copied unchanged"
    if ct == "INTEGER" and st == "integer": return copy.deepcopy(ID_T), "integer copied unchanged"
    return None, "no deterministic transform from %s to %s" % (st, ct)

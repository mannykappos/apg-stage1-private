"""The deterministic standard-library proposer. It plugs into the audited mapping boundary exactly as a model-backed proposer would (auif.ai_boundary.MappingProposer): it receives ONLY the read-only ProposerSandbox
(discovery fields, canonical attribute names) and returns plain proposals; AIMappingService then re-validates every proposal, labels it a CANDIDATE or AMBIGUOUS, and discards any state it claims. It additionally holds a COPY of the
canonical model definition as plain data, so it can match enumerations and types (a model-backed proposer would be given the same). It has no handle on anything else: no promote, no approval, no store, no network, no clock.
A future model-backed proposer replaces this class; nothing else changes (not part of this milestone)."""
import copy
from auif.ai_boundary import MappingProposer
from . import matching, planner
class DeterministicProposer(MappingProposer):
    NAME = "deterministic-stdlib@1"
    def __init__(self, model_definition):
        self._concepts = planner.concepts(copy.deepcopy(model_definition)); self.notes = {}; self.skipped = {}           # filled during propose(): rationale per proposal, reason per field that got no proposal
    def propose(self, sandbox):
        self.notes, self.skipped = {}, {}; by_entity = {}
        for f in sandbox.fields():
            ent, _, path = str(f["name"]).partition("."); by_entity.setdefault(ent, []).append(dict({k: (str(v) if isinstance(v, str) else v) for k, v in f["detail"].items()}, name=path))
        out = []
        for ent in sorted(by_entity):
            fields = by_entity[ent]; plan = planner.plan_entity(ent, fields, self._concepts); byname = {f["name"]: f for f in fields}
            for f in fields:
                if f.get("write_only"): self.skipped["%s.%s" % (ent, f["name"])] = "write-only field: it is never returned by a read"
                elif f.get("type") not in planner.SOURCE_TO_CANON: self.skipped["%s.%s" % (ent, f["name"])] = "source type %s is not mappable" % f.get("type")
                elif matching.tokens(f["name"].split(".")[-1]) in (["id"], ["uuid"], ["guid"]): self.skipped["%s.%s" % (ent, f["name"])] = "identifier field: a record's identity is carried by the runtime, so leaving it unmapped is usual"
            if not plan["chosen"]:
                for f in fields: self.skipped.setdefault("%s.%s" % (ent, f["name"]), "the entity resembles no canonical concept")
                continue
            main = plan["chosen"][0]; pairs, ties = plan["assignments"][main]; done = set()
            for fname, attr, sc, runners in pairs:
                done.add(fname); f = byname[fname]; adef = self._concepts[main][attr]; transform, note = planner.choose_transform(f, attr, adef); src = "%s.%s" % (ent, fname)
                if transform is None: self.skipped[src] = "best match %s.%s (score %s): %s" % (main, attr, sc, note); continue
                alts = ["%s.%s" % (main, r) for r in runners]
                for other in plan["chosen"][1:]:                                                    # the entity itself is ambiguous: the same field's best attribute in the other concept is an alternative meaning
                    op = [p for p in plan["assignments"][other][0] if p[0] == fname]
                    if op: alts.append("%s.%s" % (other, op[0][1]))
                self.notes[(src, "%s.%s" % (main, attr))] = {"score": sc, "rationale": note, "alternatives_considered": alts}
                out.append({"source_ref": src, "canonical_ref": "%s.%s" % (main, attr), "transform": transform, "alternatives": alts, "rationale": note})
            for fname in ties: self.skipped["%s.%s" % (ent, fname)] = "tied with another field for the same canonical attribute: a human decides"; done.add(fname)
            for f in fields:
                key = "%s.%s" % (ent, f["name"])
                if f["name"] not in done and key not in self.skipped: self.skipped[key] = "no canonical attribute resembles this field"
        return out

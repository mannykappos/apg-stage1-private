"""auif_onboard: the Onboarding Accelerator (rev11; rev12 adds wrapped-list, tenant-header and entity-exclusion handling found by the first real-system proof). A DRAFTING AND REVIEW ACCELERATOR, not an onboarding authority.

    Discover -> Draft -> Propose -> Validate (synthetic only) -> Present for human approval.
    NOT: Discover -> Decide -> Approve -> Deploy.

What it does: reads an OpenAPI/Swagger document the integrator supplies, drafts a connector configuration and a candidate translation pack, proposes mappings through the audited
mapping boundary (auif.ai_boundary), checks the draft against SYNTHETIC loopback vendors, and presents the result. What it never does: promote or approve anything (only auif_onboard.review can,
and only on an explicit, named, hash-bound human approval), hold or emit a secret, contact a real system, or change the core. It sits ABOVE the audited core and the extensions: nothing in `auif` or `auif_ext`
imports it (tools/ext_reverse_contamination.py proves that), and it imports nothing that opens a socket. Standard library only."""
AUTHORITY = "NONE"                       # the accelerator holds no authority: Governor decides governance; a named human approves mappings
DRAFT_STATE = "DRAFT_NOT_APPROVED"
VERSION = "0.1.0"

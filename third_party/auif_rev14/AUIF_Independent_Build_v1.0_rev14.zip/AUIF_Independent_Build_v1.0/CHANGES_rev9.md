# rev9: what changed, and why (versus rev8)

rev9 is a **core revision**. It fixes two findings from the Layer 1 work and nothing else.

## Changed (the full list of differences from rev8's package, apart from generated reports)
| File | Change |
|---|---|
| `auif/integration.py` | **CF-1.** New `_report_drift()`; `check_drift()` uses it. Any failure of the Governor drift report is an unacknowledged report: PENDING, evidence stored, state SCHEMA_DRIFT, governed operations wait. |
| `auif/action.py` | **CF-2.** New `ActionService.recover_stale_sent(ctx, stale_after_seconds)`: SENT to UNKNOWN_OUTCOME to the existing reconciliation. Never re-sent; no Governor decision requested. |
| `tests/test_cf1_report_condition_failure.py`, `tests/test_cf2_stale_sent_recovery.py` | New: 9 and 17 regression tests (the CF-1 tests fail on rev8's core). |
| `tools/mutation_test.py` | 24 new mutants (M91 to M114) for the new guards; all killed. |
| `tools/gen_final.py` | Wording made true for a revised core; a measured section 12 in the report. |
| `auif_ext/tests/test_extension_boundary.py` | The pinned core hash literal only. Everything else in `auif_ext/` is byte-identical to rev8. |
| `KNOWN_LIMITATIONS.md`, `DRAFT_FEEDBACK_AND_DESIGN_DECISIONS.md`, `AUIF_EXTENSIONS.md` | Limitations 28 to 31, decisions D-39 to D-41, a rev9 note. |
| `evidence/cf4_reproduction.*` | New: the CF-4 reproduction (see below). |
`contracts/`, `synthetic/`, `auif_ref/` and `port_contracts/` are byte-identical to rev8's. rev8, the GD-05 overlay, the locked Layer 1 specification and the Governor are untouched.

## Deliberately NOT changed
- **CF-3** (a restart after a crash before the durable SENT asks the Governor for a second decision): accepted behaviour under G4 and G5, so left alone.
- **CF-4** (new, found while fixing CF-2): a crash between ACKNOWLEDGED and COMPLETED also strands an action whose effect the target confirmed. Outside the authorised scope, so it is **recorded, not fixed**: `evidence/cf4_reproduction.py`.
- Nothing about Layer 2, a production Governor binding, the Engine or any real system.

## Using the CF-2 sweep
Call `fabric.actions.recover_stale_sent(ctx, stale_after_seconds)` periodically and serially with dispatch. `stale_after_seconds` must exceed the longest a live dispatch can take (the runtime's retry and deadline budget). It reports what it recovered, how each ended (COMPLETED, FAILED, or awaiting an operator for a target that cannot be queried), and anything it could not resolve.

## Evidence
See `BUILD_REPORT.md` section 12, `ACCEPTANCE_RESULTS.md`, `evidence/mutation_results.json` (core mutation) and `evidence/ext_verification.json`. Everything is for independent audit; none of it is a closure.

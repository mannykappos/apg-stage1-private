# Scoped check: APG Data Readiness Change Request, revision 3

Your re-check of revision 2 found it NOT READY because of two blocking items, plus 6 should-fix, 1 optional and 1 minor. Revision 3 answers all of them. It also adds what the owner asked for on 2026-11-12: a survey of the systems builders and developers use and what data each provides, and a design in which APG has its own way to supply every entity it needs, whatever share the builder's systems cover (the 80% / 20% split was only an example).

This is a **scoped check in ONE pass**. Review all of it and list every problem now; do not stop at the first one. The owner decides after this; no further round unless you find something BLOCKING.

## What is in the attached zip
- `01_CHANGE_REQUEST_REV3.md`: revision 3. Its last section maps each of your points to where it is answered.
- `03_registers/`: `ENTITY_REGISTER.csv` (99 entities, one row each), `RULE_INPUT_CONTRACTS.csv` (every detection rule's and financial figure's inputs), `SYSTEMS_SURVEY.csv` (16 systems and 2 data sources), `CHART_DATA_PATHS.csv`, the field and template registers, and the scripts that generated the CSVs.
- `04_code_read/apg/`: the source files the rule contracts were read from. You can check the contracts against the code directly.
- `05_blueprint_sources/`: the locked blueprint Sections 03-13 and Section 18, the Master RTM, and two 8 Intelligence Layers files (02 shared financial foundation, 11 data contracts).
- `06_previous/`: revision 2 and your re-check of it.
- `AUDIT.txt`: an independent agent audit of revision 3's first draft (28 findings) and the fix made for each. Revision 3 as sent includes those fixes.

## Check exactly these
1. **Blocking 1, the entity model.** Is `ENTITY_REGISTER.csv` now one row per logical entity, including the separate entities of 8-layer §11.2 and Section 13 §3? Are the counts in the document (99 entities: 11 covered, 41 partial, 47 missing, and the per-class table) correct, and does each status follow from its "APG today" and "gap" columns?
2. **Blocking 2, exact inputs.** Does `RULE_INPUT_CONTRACTS.csv` state, for every rule and figure, the record kinds and fields the code in `04_code_read` actually reads, the code's own behaviour when an input is missing, and the known limits? Name any rule, field or reason code that is wrong or missing.
3. **Your other 8 points and the partly-resolved items**: for each row of the document's last table, RESOLVED / PARTLY / NOT RESOLVED, one line each.
4. **New material** (the systems survey, the design principle, the features section and its chart's numbers): list only problems that are BLOCKING or SHOULD FIX, for example a survey claim its cited source does not support, or an unbuilt feature presented as working.
5. **The owner's question**, in at most five sentences: if its decisions are approved, does revision 3 give a design in which APG states exactly what data each insight needs and has its own way to get every piece the builder's systems do not supply, at any split? Where does it still fall short?

## Rules
- Class every problem BLOCKING (the owner should not decide until it is fixed), SHOULD FIX, OPTIONAL or MINOR, with a rough cost (small, medium, large).
- Quote the text or the CSV row id you are judging.
- Do not widen the scope: no new features, insights or integration design. A gap in the blueprint itself goes in a separate short list.
- Say "not verifiable from the pack" where the pack cannot settle a point.

## Output
1. Blocking 1: verdict and reasons.
2. Blocking 2: verdict, and every wrong or missing contract entry.
3. Verdict table for the last table's rows.
4. New material: numbered problems with class and cost.
5. The owner's question.
6. Totals, and whether anything is BLOCKING.

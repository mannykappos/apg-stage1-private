"""Revision 3 (corrected after the independent agent audit of 2026-11-12): the entity register, one row per logical entity.
Classes: B builder-source, C configuration/policy, I APG internal, D evidence/document, X external reference, V developer (optional).
Status: covered (every required field group present, no gap listed), partial (a record kind or field exists, with gaps), missing.
Systems: 'supported by the survey' is computed from SYSTEMS_SURVEY.csv (only what the cited sources support); 'likely also' is Claude's
judgement, unverified, to be checked with pilot builders.
APG paths: T import template (file: CSV, spreadsheet, or a system export file), D document/email capture with a person confirming material
values (S04 s12), E entry screen, P phone site capture, S setup question, A created by APG, I integration (accelerator; always proposed,
after the Section 01 discovery and AUIF).  Path status per path: exists, partly, proposed.
Blueprint references use the section's own numbering: 'S12 s8' = Section 12 heading 12.8."""
import csv, collections

ROWS = [
# id, domain, entity, class, blueprint, required field groups, APG today, gap, likely held in (judgement), paths, path status, owner, links to
('E01','Common','Record provenance and lifecycle fields (on every record)','I','S03 s3; S04 s10, s13, s17','source, source record id, revision, ingestion state, verification, supersession','partly: source_record_id on 22 of 35 kinds; the intake states on every kind','source_record_id missing on 13 kinds; verification and supersession not uniform','-','A','A partly','APG','all'),
('E02','Common','Source registry entry (one per source system)','C','S04 s4','source, fields supplied, cadence, limits, schema version, health','missing as a builder-facing record','no record of which system supplies what','-','S, A','S proposed; A proposed','builder admin','E03'),
('E03','Common','Source Authority Register entry (field level)','C','S04 s5; PG-DI-AC-01/02','field, authoritative source, fallback, approver','partly: apg/source_authority.py (synthetic; per the builder inventory, not read for this revision)','not set up or approved by a builder','-','S','S proposed','builder admin','E02'),
('E04','Common','Cost-code map (builder codes to the APG cost structure)','C','S03 s2; 8-layer 02 s2.4','builder code, APG category, effective dates, confirmed by','missing','codes are carried as given; no map','ERP, ACC, XLS','S (APG suggests; the builder confirms), T','S proposed; T proposed','estimator / finance','E21, E23, E38, E41'),
('E05','Common','Organisation (tenant)','B','S03 s2; S04 s16','tenant, users, roles','partly: tenant scope in code','no setup screen','-','S','S proposed','builder admin','E06'),
('E06','Common','Legal entity','B','S03 s2; 8-layer 11 Project','entity, ABN, GST registration','missing as a record','projects do not name their legal entity','ACC','S','S proposed','finance','E05'),
('E07','Commercial','Project','B','S03 s2; 8-layer 11 Project','project id, legal entity, type, location/jurisdiction, currency, reporting calendar, stage, status','partial: project (project_ref, project_name, contract_value_cents, start_date, planned_finish)','legal entity, type, jurisdiction, currency, reporting calendar, stage, status','PM, ERP, ACC','T, E, I','T exists; E proposed; I proposed','contract administrator','E06'),
('E08','Commercial','Head contract','B','S03 s2, s6.1; S11 s3','parties, form, value, payment terms, retention and security terms, time-bar clauses','partial: contract (original_contract_cents, approved_variations_cents)','parties, form, terms, clauses, retention and security terms','PM, ERP, DOC','D, T, E','D partly; T exists; E proposed','contract administrator','E07'),
('E09','Commercial','Variation (client side)','B','S03 s6.1; S11 s4; 8-layer 11 Variation','instruction link, scope, status, estimated cost, claimed amount/date, approved amount/date, potential entitlement, accounting treatment, contract references, approval history, evidence','partial: variation (raised_date, source_status, value_cents, description_text)','instruction link, claimed vs approved amounts and dates, entitlement, treatment, contract references, approval history, evidence','PM, ERP, CLM, XLS','T, D, E, I','T exists; D partly; E proposed; I proposed','contract administrator','E08, E10'),
('E10','Commercial','Site instruction / direction','B','S11 s4','issuer, date, scope, linked variation, evidence','partial: notice (notice_date, notice_type_text, linked_variation_ref, description_text)','issuer and evidence; instructions often arrive by email or on site','PM, DOC, SITE','D, P, T, E','D partly; P proposed; T exists; E proposed','site manager','E07, E09'),
('E11','Commercial','Contract notice (delay, variation, claim notices)','B','S07 s11; S11 s7','type, date, clause, sender, recipient, evidence','partial: notice (shared kind with E10)','clause and recipient; one kind serves both E10 and E11','PM, DOC','D, T, E','D partly; T exists; E proposed','contract administrator','E08'),
('E12','Commercial','Deadline / time bar','I','S11 s7, s7.1','source clause, trigger, computed date, verification','missing','no deadline record; the S11 s7.1 gate applies (CR-06 in the owner\'s programme)','-','A (from E08 and E11), S','A proposed; S proposed','contract administrator','E08, E11'),
('E13','Commercial','Client progress claim','B','S03 s6.1; S11 s5; S12 s10','claim number, period, amount by item, variations claimed, retention, date served','missing','no record kind','CLM, PM, ERP, XLS','T, D, E, I','T proposed; D proposed; E proposed; I proposed','contract administrator','E08, E09'),
('E14','Commercial','Client payment schedule / certificate','B','S11 s5; S12 s10','claim ref, scheduled amount, reasons for difference, date','missing','no record kind','CLM, DOC','D, T, E','D proposed; T proposed; E proposed','contract administrator','E13'),
('E15','Commercial','Receivable and receipt','B','S03 s6.1; S12 s10','invoice, due date, amount, received amount and date, disputed amount','missing','no record kind (bank_txn has no allocation to a claim)','ACC','T, I','T proposed; I proposed','bookkeeper','E13, E14, E73'),
('E16','Subcontract','Subcontract','B','S03 s2; S04 s2','trade, value, retention, scope, terms','partial: purchase_order serves for orders; no subcontract kind','subcontract terms and retention from trades','ERP, PM, CLM','T, D, E','T proposed; D partly; E proposed','contract administrator','E07, E20'),
('E17','Subcontract','Subcontractor progress claim','B','S03 s7; S12 s4','subcontract, period, amount claimed by item, variations claimed','missing','no record kind','CLM, ERP, PM, DOC','T, D, I','T proposed; D proposed; I proposed','contract administrator','E16'),
('E18','Subcontract','Subcontractor assessment / payment schedule','B','S03 s7; S12 s4','claim ref, assessed amount, reasons, date','missing','no record kind','CLM, ERP','T, E','T proposed; E proposed','contract administrator','E17'),
('E19','Subcontract','Subcontractor payment','B','S12 s4','assessment ref, amount, date, retention withheld','missing as its own kind (payment exists for supplier invoices)','no link from payment to subcontract claim','ACC, ERP','T, I','T proposed; I proposed','bookkeeper','E18, E73'),
('E20','Procurement','Supplier / subcontractor','B','S03 s2; S04 s11','name, ABN, trade, contacts, status','partial: supplier (supplier_name, abn_text)','trade and status','ACC, ERP, PM','T, E','T exists; E proposed','bookkeeper','-'),
('E21','Procurement','Purchase order','B','S03 s7; S05 s6','revision, approval, status, cost code, lines (qty, unit, rate)','partial: purchase_order (order_date, material_ref, quantity, unit_of_measure, unit_rate_cents, amount_ex_gst_cents, source_status)','revision and approval state','ERP, PM, ACC','T, I','T exists; I proposed','procurement','E20, E26, E04'),
('E22','Procurement','Purchase-order amendment','B','S03 s7','order ref, delta, approved change ref, reason','partial: po_amendment (delta_cents, approved_change_ref, reason_text)','approval state of the change','ERP, PM','T, E','T exists; E proposed','procurement','E21, E09'),
('E23','Procurement','Supplier invoice','B','S03 s7; S04 s11','lines (qty, unit, rate), order line link, cost code, GST','partial: ap_invoice (amount only), pm_invoice','line quantity and unit rate (finding F-09); order line link','ACC, ERP, DOC','T, D, I','T exists; D partly; I proposed','bookkeeper','E20, E21'),
('E24','Procurement','Credit note','B','S03 s7','invoice ref, amount, reason','partial: credit_note (amount, against_invoice_ref)','reason','ACC','T, I','T exists; I proposed','bookkeeper','E23'),
('E25','Procurement','Supplier payment','B','S12 s4','invoice ref, amount, date','covered: payment (invoice_ref, payment_date, amount_cents)','-','ACC','T, I','T exists; I proposed','bookkeeper','E23, E73'),
('E26','Procurement','Material','B','S03 s8.1; S08 s4','description, unit, specification','partial: material (description_text, unit_text)','specification link','ERP, EST','T, E','T exists; E proposed','procurement','E27'),
('E27','Procurement','Specification requirement','B','S08 s4','material, basis, approver','covered: spec_requirement','-','DOC, EST','T, D','T exists; D partly','estimator','E26'),
('E28','Procurement','Material demand','B','S03 s8.2; S08 s4','material, quantity, unit, required date','covered: material_demand','-','EST, SCH, XLS','T, E','T exists; E proposed','project manager','E26, E07'),
('E29','Procurement','Delivery','B','S03 s8.2; S08 s9, s13','order ref, quantity delivered and accepted, date','covered: delivery','-','PM, SITE','T, P','T exists; P proposed','site manager','E21, E26'),
('E30','Procurement','Supplier quote','B','S03 s8.3; S08 s5-7','supplier, material, spec, quantity, validity, rate, currency, delivery basis, freight, lead time','partial: supplier_quote (no quantity or unit of measure)','quoted quantity and unit of measure; decision-specific freshness thresholds are policy (S08 s7.1)','DOC, EST','D, T','D partly; T exists','procurement','E20, E26'),
('E31','Procurement','Quote price tier','B','S08 s5','quote, minimum quantity, rate','covered: quote_tier','-','DOC','D, T','D partly; T exists','procurement','E30'),
('E32','Procurement','Quote term','B','S08 s5','quote, term, value','covered: quote_term','-','DOC','D, T','D partly; T exists','procurement','E30'),
('E33','Procurement','Landed-cost component','B','S03 s8.3; S08 s6','quote, component, rate, basis, source','covered: landed_assumption','-','XLS, DOC','T, E','T exists; E proposed','procurement','E30'),
('E34','Procurement','Import compliance check','B','S08 s12','quote, check, status, evidence, checker','covered: import_check','-','DOC','T, E','T exists; E proposed','procurement','E30'),
('E35','Procurement','Quote reading (extracted value and its verification)','D','S04 s12; S08 s5','quote, attribute, value, extractor, verified by','covered: quote_reading','-','DOC','T, D','T exists; D partly','procurement','E30, E83'),
('E36','Market','Market observation','X','S08 s7','material, date, value, unit, source type, geography','partial: market_observation','decision-specific freshness thresholds are policy (S08 s7.1)','EXT','T, I','T exists; I proposed','APG / market feed','E26'),
('E37','Market','FX rate','X','S08 s6, s7','pair, date, rate, source','partial: fx_rate (no source)','rate source','EXT','T, I','T exists; I proposed','APG / market feed','-'),
('E38','Cost and forecast','Budget line','B','S03 s4, s6.2','cost code, amount, revision label, revision date','covered: budget_line','-','ERP, EST, XLS','T, E','T exists; E proposed','project manager','E04, E07, E98'),
('E39','Cost and forecast','Budget revision approval','B','S03 s6.2; S05 s5.3','revision, approver, date, reason','missing','who approved a budget revision (R01 names it as missing evidence)','ERP, XLS','E, T','E proposed; T proposed','project manager','E38'),
('E40','Cost and forecast','Estimate line','B','8-layer 11 EstimateLine; Layer 1','estimate version, scope/trade/package, quantity/unit/rate, amount, pricing source and date, inclusion status, assumptions','missing','no record kind (budget lines only)','EST, XLS','T, I','T proposed; I proposed','estimator','E07, E98'),
('E41','Cost and forecast','Cost-to-complete line (the builder forecast)','B','S05 s5-5.2; 8-layer 02 s2.4','cost code, version, date, amount, basis, movement reason, owner, approval, tax and currency basis','partial: ctc_line (no owner, approval or tax/currency basis)','owner, approval and tax/currency basis of the forecast version (S05 s5.1)','ERP, XLS','E, T','E proposed; T exists','project manager','E04, E07'),
('E42','Cost and forecast','Accrual','C','S03 s6.3','period, cost code, amount, reversal','missing','actual cost holds supplier invoices only (finding F-17)','ACC, ERP','T, E','T proposed; E proposed','finance','E04'),
('E43','Cost and forecast','Overhead allocation rule','C','S03 s6.3','basis, rate, effective dates','missing','not in actual cost (F-17)','ACC, XLS','S','S proposed','finance','-'),
('E44','Cost and forecast','Baseline','I','8-layer 11 Baseline; S05 s5.1','version, source snapshot, model version, assumptions, approval, prior baseline','partial: forecast versions in apg/fin/forecast.py','approval metadata and the prior-baseline chain','-','A','A partly','APG','E45'),
('E45','Cost and forecast','Assessment (calculation run)','I','8-layer 11 Assessment; S03 s2 (calculation run)','baseline, version, trigger, calculation version, input set, measures, warnings','partial: snapshots and qualified figures (apg/fin/snap.py, figure.py; per the builder inventory, not read for this revision)','not one record with its baseline and trigger','-','A','A partly','APG','E44'),
('E46','Cost and forecast','Scenario','I','8-layer 11 Scenario; S12 s11; S07 s10','base, assumptions, outputs, isolation from the authoritative forecast','partial: in the mkt and fin modules','not a shared record','-','A','A partly','APG','E44'),
('E47','Schedule','Programme version','B','S03 s9; S07 s3, s4.1','version, data date, approval','missing','no record kind','SCH','T (XER or MS Project XML or a simple activity spreadsheet), E, I','T proposed; E proposed; I proposed','project manager','E07'),
('E48','Schedule','Programme activity','B','S07 s3','id, WBS, dates (planned, actual), duration, calendar','missing (delay_event carries activity_ref only)','no activity record','SCH, PM','T (XER or MS Project XML or a simple activity spreadsheet), E, I','T proposed; E proposed; I proposed','project manager','E47, E98'),
('E49','Schedule','Activity dependency','B','S07 s4.1','predecessor, successor, type, lag','missing','needed for critical-path analysis (S07 s4.1 gate)','SCH','T (XER or MS Project XML or a simple activity spreadsheet), E, I','T proposed; E proposed; I proposed','project manager','E48'),
('E50','Schedule','Work calendar','B','S07 s3','working days, holidays','missing (rules use calendar days)','working-day calendar not applied (DLY limit)','SCH','T, S','T proposed; S proposed','project manager','E47'),
('E51','Schedule','Progress record','B','S07 s3; S09 s3','activity, date, percent complete or quantity, by whom','missing','no record kind','SCH, PM, SITE','P, E, T','P proposed; E proposed; T proposed','site manager','E48'),
('E52','Schedule','Delay event','B','S03 s9; S07 s3, s5','dates, activity, recorded cause, attribution state, evidence, holding rate','partial: delay_event','attribution state and evidence','PM, SITE, DOC','P, T, E','P proposed; T exists; E proposed','site manager','E48, E53'),
('E53','Schedule','Holding-cost rate','C','S07 s6; S03 s9','category, rate, basis, source','partial: holding_rate_cents_per_day on delay_event','rates are per event, not a register','XLS, ACC','S','S proposed','finance','-'),
('E54','Labour','Worker (pseudonymous)','B','S09 s3, s14','pseudonym, trade, employer, crew','partial: worker_pseudonym on timesheet','trade, employer and crew','PAY, SITE','T, I','T exists; I proposed','payroll','E55, E56'),
('E55','Labour','Employer (direct or labour hire)','B','S09 s3','name, type','missing','no record kind','PAY, SITE','T, E','T proposed; E proposed','payroll','-'),
('E56','Labour','Crew','B','S09 s3, s9','crew, members, supervisor','missing','no record kind','SITE, PAY','E, T','E proposed; T proposed','site manager','E54'),
('E57','Labour','Timesheet entry','B','S09 s3, s4','worker, date, hours (ordinary, overtime), allowances and premiums, absences, breaks, adjustments, work package, rate','partial: timesheet (worker_pseudonym, work_date, ordinary_hours, overtime_hours, work_package_ref, rate_cents_per_hour)','allowances, premiums, absences, breaks and adjustments','PAY, SITE, ERP','T, I, P','T exists; I proposed; P proposed','payroll','E54, E98'),
('E58','Labour','Work allocation','B','S09 s3, s9','worker or crew, package, period','missing (timesheet carries work_package_ref)','no allocation record','SITE, PM','E, P','E proposed; P proposed','site manager','E54, E56, E98'),
('E59','Labour','Labour rate and classification','C','S09 s3, s4','classification, base rate, award or agreement, effective dates','missing (rate_cents_per_hour optional on timesheet)','no rate register; generic award rates are not used as cost','PAY','S, T, I','S proposed; T proposed; I proposed','payroll','E54'),
('E60','Labour','On-cost and allowance rule','C','S09 s3, s7','on-cost type, rate, allowance rules, overtime premiums','missing','no record kind','PAY','S','S proposed','payroll','E59'),
('E61','Labour','Accepted work output','B','S09 s5','package, week, quantity, unit, accepted by','partial: work_output (no acceptance)','who accepted the output','SITE, PM','P, E, T','P proposed; E proposed; T exists','site manager','E98'),
('E62','Labour','Productivity baseline','I','S09 s5, s5.1','package, period, rate, comparability basis','partial: computed by the LAB rule','not stored with its comparability basis','-','A','A partly','APG','E57, E61'),
('E63','Labour','Work conditions record','B','S09 s6','date, package, condition (weather, access, design change, waiting, interruption)','missing','no record kind','SITE','P, E','P proposed; E proposed','site manager','E98'),
('E64','Plant','Plant hire','B','S06 s5.2 (rule 8); S07 s6','on/off-hire, off-hire request and confirmation, minimum hire, rate basis, need date, usage evidence','partial: plant_hire','off-hire request and confirmation, minimum hire, usage evidence; hire invoices not linked (F-17)','PM, ACC, SITE','T, D, P','T exists; D partly; P proposed','site manager','E07, E20'),
('E65','Quality','Quality observation','B','S13 s3','date, location, work package, observer, description, evidence','missing','no record kind','SITE, PM','P, E','P proposed; E proposed','site manager','E98'),
('E66','Quality','Defect','B','S03 s10.3; S13 s3','location, work package, trade, subcontractor, severity, status, evidence, responsible parties, change history, rework cost','partial: defect (subcontractor_text, trade_text, raised_date, severity_text, rework_cost_cents, status_text)','location, work package, evidence, responsible parties, change history','SITE, PM','P, T, E','P proposed; T exists; E proposed','site manager','E65, E20, E98'),
('E67','Quality','Rework event','B','S13 s3, s5','defect, work done, hours and materials, cost','missing (rework_cost_cents on defect)','no rework record','SITE, PM','P, E','P proposed; E proposed','site manager','E66'),
('E68','Quality','Root-cause hypothesis','I','S13 s3, s7','defect, hypothesis, evidence, confidence, raised by','missing','no record kind','-','A, E','A proposed; E proposed','quality manager','E66'),
('E69','Quality','Confirmed cause','I','S13 s3, s7','defect, cause, evidence, confirmed by','missing','no record kind','-','E','E proposed','quality manager','E68'),
('E70','Quality','Rectification action','I','S13 s3, s8','defect, action, owner, timing, required outcome','missing','no record kind','PM, SITE','E, P','E proposed; P proposed','quality manager','E66'),
('E71','Quality','Quality cost','I','S13 s3, s5','defect, cost type (observed, estimated, forecast, recovery), amount','missing (rework_cost_cents only)','no record kind','-','A, E','A proposed; E proposed','quality manager','E66, E67'),
('E72','Quality','Closure verification','I','S13 s3, s8','defect, verified by, date, evidence','missing','no record kind','PM, SITE','P, E','P proposed; E proposed','quality manager','E70'),
('E97','Quality','Prevention opportunity','I','S13 s3, s7','recurrence pattern, recommendation, expected effect','missing','no record kind','-','A, E','A proposed; E proposed','quality manager','E69'),
('E73','Cash','Bank transaction','B','S12 s4','date, amount, description, allocation','partial: bank_txn (no allocation)','allocation to claims, invoices and payments','ACC, BANK','T, I','T exists; I proposed','bookkeeper','E15, E19, E25'),
('E74','Cash','Funding facility','B','S12 s7','limit, drawn, rate, fees, statement date','partial: facility (no fees)','fees','BANK, ACC','T, D','T exists; D partly','finance','-'),
('E75','Cash','Retention held by the client','B','S03 s10.1; S12 s8','clause, basis, withheld, claimed for release, approved, released, due date, conditions','partial: retention (held, due, released, hold reason)','clause, conditions, claimed and approved release','CLM, ERP, XLS','T, D','T exists; D partly','contract administrator','E08'),
('E76','Cash','Retention held from trades','B','S03 s10.1; S12 s8','subcontract, withheld, release due, linked defects','missing','no record kind','CLM, ERP','T, E','T proposed; E proposed','contract administrator','E16, E66'),
('E77','Cash','Retention event','I','S12 s8','retention, event, amount, actor and role, evidence','partial: apg/fin/cash_states.py record_event, recorded by a named person with role and evidence','no entry screen to record the events','-','E, A','E proposed; A partly','contract administrator','E75, E73'),
('E78','Cash','Security instrument','B','S03 s10.2; S12 s9','type, issuer, beneficiary, face value, dates, release conditions, fees','partial: security (kind, face value, expiry)','issuer, beneficiary, release conditions, fees','BANK, DOC','D, T','D partly; T exists','finance','E08'),
('E79','Cash','Payable (aged)','B','S12 s3, s4','supplier, due date, amount, disputed','partial: ap_invoice plus payment','due dates and disputed amounts','ACC','T, I','T exists; I proposed','bookkeeper','E23'),
('E80','Cash','Statutory liability (GST, PAYG, super)','B','S12 s4','type, period, amount, due date','missing','no record kind','ACC, PAY','T, I','T proposed; I proposed','finance','E06'),
('E81','Cash','Payroll outflow','B','S12 s4','pay run, date, amount','missing','no record kind','PAY','T, I','T proposed; I proposed','payroll','E57'),
('E82','Compliance','Supplier / subcontractor compliance evidence','D','S04 s2; S09; S13','type, holder, trade/work, jurisdiction, coverage/limit, dates, source, verification','partial: compliance (supplier, type, expiry)','coverage/limit, jurisdiction, issue date, verification','SITE, CLM, DOC','D, T, I','D partly; T exists; I proposed','procurement','E20'),
('E83','Evidence','Document','D','S04 s12, s18','type, source, received, hash, links','partly: apg/ingest/documents.py (per the builder inventory, not read for this revision)','no builder-facing capture','DOC, PM','D','D partly','anyone','all'),
('E84','Intelligence','Finding','I','S03 s12; S06 s6','rule, evidence, quantification, confidence, limits','covered: apg/det/findings.py','-','-','A','A exists','APG','E85'),
('E85','Intelligence','Alert','I','8-layer 11 Alert; S06 s8; S10 s4','finding, priority, recipient, state','missing as a stored record','prioritisation (S10 s4) not stored','-','A','A proposed','APG','E84'),
('E86','Intelligence','Recommendation','I','S10','finding, action, conditions','missing','no record kind','-','A','A proposed','APG','E84'),
('E87','Intelligence','Decision / approval','I','8-layer 11 Decision/Approval','subject, decision, by whom, when, basis','missing','no record kind','-','E','E proposed','owner of the decision','E86'),
('E88','Intelligence','Outcome','I','S06 s11; S10','decision, realised result, date','missing','no record kind','-','E, A','E proposed; A proposed','commercial manager','E87'),
('E89','Intelligence','Readiness record (per insight)','I','this request; S04 s14; S06 s10','insight, inputs, states, eligibility, gaps, owners','missing','the record this change request adds','-','A','A proposed','APG','E84'),
('E90','Configuration','Financial policy (the ten foundation decisions)','C','8-layer 02 s2.4, s2.11; S03 s5, s6.3','margin measures, revenue basis, cost taxonomy, contingencies, tax basis, CTC method, variation treatment, approval roles, freshness, rounding and currency','partly: apg/fin/policy.py (variation_status_map, po_status_map, cost_scope, ctc_method and others)','no builder setup; the M4 figures and R02, R03, R04 stop when their maps are not configured','-','S','S partly','owner / finance','-'),
('E96','Common','Financial record and its value status','I','8-layer 11 FinancialRecord; S12 s3','record id, project, account or cost code, amount, currency, tax basis, value status (actual, committed, forecast, assumption, claimed, disputed, potential, scenario), effective date, source, verification, baseline or scenario, idempotency key','partial: realised by separate kinds (E21 to E25, E38, E41, E09) and the classes of the M4 figures','no shared value-status field across kinds; currency not on records','-','A','A partly','APG','E21, E22, E23, E24, E25, E38, E41, E09'),
('E98','Common','Work package','B','S03 s2; S09 s3; S13 s3','package, scope, trade, cost codes, programme activities','partial: work_package_ref on timesheet and work_output; no record','no record of packages, their scope or trade','ERP, PM','T, E, S','T proposed; E proposed; S proposed','project manager','E07, E04'),
('E99','Schedule','Schedule milestone and contractual date','B','S03 s2; S07 s3, s11','milestone, planned and actual date, contractual source, linked activity','missing','no record kind','DOC','T, E, D','T proposed; E proposed; D proposed','contract administrator','E47, E08'),
('E91','Developer (optional)','Sales contract (lot or unit)','V','owner decision 2026-11 (developer capability); not in the locked blueprint','lot, buyer, price, deposit, conditions, settlement date','missing','needs a blueprint change','DEV, XLS, DOC','T, D, E','T proposed; D proposed; E proposed','developer','E07'),
('E92','Developer (optional)','Settlement','V','as E91','sales contract, date, amount received, adjustments','missing','needs a blueprint change','DEV, ACC','T, E','T proposed; E proposed','developer','E91, E73'),
('E93','Developer (optional)','Development finance draw and interest','V','as E91','facility, draw, date, interest, fees','missing (facility covers a builder facility only)','needs a blueprint change','DEV, BANK','T, D','T proposed; D proposed','developer','E74'),
('E94','Developer (optional)','Land and development cost (acquisition, statutory, holding)','V','as E91','cost type, amount, date, project','missing','needs a blueprint change','DEV, XLS, ACC','T, E','T proposed; E proposed','developer','E07'),
('E95','Developer (optional)','Development feasibility version','V','as E91','version, revenue, costs, margin, assumptions','missing','needs a blueprint change','DEV, XLS','T','T proposed','developer','E07'),
]

HDR = ['id', 'domain', 'entity', 'class', 'blueprint', 'required field groups', 'APG today (record kind: fields)', 'status', 'gap',
       'systems supported by the survey (codes)', 'likely also (judgement, unverified)', 'APG supply paths', 'path status', 'likely data owner', 'links to']


def status(today):
    t = today.split(':')[0].strip()
    return {'covered': 'covered', 'partial': 'partial', 'partly': 'partial'}.get(t, 'missing')


SUP = collections.defaultdict(set)
for s in csv.DictReader(open('SYSTEMS_SURVEY.csv')):
    for e in s['APG entities the cited source supports (ids in ENTITY_REGISTER.csv)'].split():
        SUP[e].add(s['code'])
ROWS.sort(key=lambda r: int(r[0][1:]))
with open('ENTITY_REGISTER.csv', 'w', newline='') as fh:
    w = csv.writer(fh, lineterminator='\n')
    w.writerow(HDR)
    for r in ROWS:
        sup = sorted(SUP[r[0]])
        judged = [c.strip() for c in r[8].split(',') if c.strip() and c.strip() != '-' and c.strip() not in sup]
        w.writerow(list(r[:6]) + [r[6], status(r[6]), r[7], ', '.join(sup) or '-', ', '.join(judged) or '-'] + list(r[9:]))

ids = [r[0] for r in ROWS]
assert len(ids) == len(set(ids)), 'duplicate id'
for r in ROWS:
    paths = [p.strip()[0] for p in r[9].split(',') if p.strip()]
    marked = {part.strip().split()[0] for part in r[10].split(';')}
    assert set(paths) == marked, (r[0], paths, marked)
    if status(r[6]) == 'covered':
        assert r[7] == '-', r[0]
    else:
        assert r[7] != '-', r[0]
c = collections.Counter(status(r[6]) for r in ROWS)
print('entities', len(ROWS), dict(c))
for cls in 'BCIDXV':
    print(cls, sum(1 for r in ROWS if r[3] == cls), {s: sum(1 for r in ROWS if r[3] == cls and status(r[6]) == s) for s in ('covered', 'partial', 'missing')})

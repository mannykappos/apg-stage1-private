APG Data Readiness Change Request, revision 3: pack for the owner and for a scoped GPT check (2026-11-12)
01_CHANGE_REQUEST_REV3.md   revision 3 (the text of the owner's Claude doc; its one chart is described in place)
02_GPT_CHECK_PROMPT.md      the prompt to paste into GPT with this zip (one pass, scoped to the re-check's points and the new material)
03_registers/               ENTITY_REGISTER.csv (99 entities), RULE_INPUT_CONTRACTS.csv (39 rows, 29 rules and figures),
                            SYSTEMS_SURVEY.csv (16 systems, 2 data sources), CHART_DATA_PATHS.csv, FIELD_REGISTER.csv,
                            TEMPLATE_REGISTER.csv, and the scripts that generated them
04_code_read/apg/           the APG source files the rule contracts were read from (identical in M10 and stage 1)
05_blueprint_sources/       locked blueprint Sections 03-13 and 18, the Master RTM, 8-layer files 02 and 11
06_previous/                revision 2 and GPT's re-check of it
AUDIT.txt                   the independent read-only agent audit of revision 3's first draft (28 findings) and the fix for each
The registers, the survey and the document are Claude's work (builder), not independent evidence. The systems survey is vendor-level
(vendor pages, developer documents, third-party pages), searched 2026-11-12; it is to be confirmed with pilot builders' sample exports.

# Brief: the entity register checked against every row of the requirements matrix (M15, row level)

You are a fresh, independent agent. Your work is labelled **INDEPENDENT READ-ONLY (agent)**. It is design work only: nothing is built.

## What this is for

Anchor Profit Guardian (APG) is construction-finance software. Its blueprint is locked: Sections 00 to 18, version 1.0. Every requirement paragraph of the blueprint is one row of the Master Requirements Traceability Matrix (RTM).

A change request proposes a controlled **entity register**: the list of every kind of data APG must hold. It has 100 entities (E01 to E99, plus N01). The register must be complete before it can become an annex of the blueprint. "Complete" means every requirement that needs APG to hold some kind of data has an entity that carries that data.

A first check worked at heading level (`in/M15_ENTITY_CROSSCHECK.md`). It found 2 missing entities and 4 field gaps, and proposes fixes for them:
- E100, material movement and stock;
- E101, cash-flow forecast;
- field groups added to E27, E08, E64, E73 and E96;
- E38 gains the budget part (stage, trade or area).

That check did not read the rows one at a time. **You do**, for your part of the matrix.

## Inputs (all under `<WORKSPACE>/m15rtm/in/`)

- `RTM_PART_<X>.csv`: your rows. The columns are requirement_id, section, anchor (the paragraph index) and requirement_text (the paragraph's full text).
- `ENTITY_REGISTER.csv`: the 100 entities. Columns include id, domain, entity, blueprint basis and required field groups.
- `FIELD_REGISTER.csv`: their fields.
- `M15_ENTITY_CROSSCHECK.md`: the heading-level result and its proposed fixes.
- `Section_00.txt` to `Section_18.txt`: plain text of each locked section, for context. A row's meaning often depends on its heading or the list it sits in, so read around it.

## What to do, for every row of your part

1. Does this requirement need APG to **hold** a kind of data?
   - Yes: it names records, fields, documents, statuses, dates, amounts, settings, history, evidence, approvals or audit entries that APG must keep, receive or calculate and store.
   - No: it is purpose, scope, a principle, a process or delivery instruction, a test or acceptance rule with no new data, a UI behaviour that uses data already named, or a heading.
   - When unsure, say yes and explain.
2. If yes, which entity or entities carry that data, and is the needed field group there?
3. Give a verdict:
   - `COVERED`: an existing entity and field group carry it (give the IDs);
   - `COVERED-BY-PROPOSED`: covered only by one of the M15 heading-level fixes (name which);
   - `GAP`: no entity or field group carries it. Describe what is missing, and propose the smallest fix: a field group on an existing entity, or a new entity;
   - `NO-DATA-NEED`.
4. Be strict but fair. A generic entity like E01 (provenance fields on every record) or E96 (financial record) only counts if it really carries that data. Do not invent needs the text does not state.

## Output

1. Write `out/M15_PART_<X>.csv` with exactly these columns: requirement_id, data_need (Y/N), data_named (short), entities (IDs, `;` separated), verdict, note.
   - Include **every** row of your part, in order. The row count must equal your input's.
   - Quote any CSV field containing commas.
2. Write `out/M15_PART_<X>_SUMMARY.md` with:
   - counts by verdict;
   - every GAP, with its row ID, the requirement's words, what is missing and the proposed fix;
   - every COVERED-BY-PROPOSED, grouped by fix;
   - anything in the M15 heading-level result you think is wrong;
   - any rows you could not judge.

## Rules

- Read-only. Write only under `m15rtm/out/`. No network.
- You may use short `python3 -I -S` scripts to read the files or to check your output's row count. Do not hand off the judgement to keyword matching: read each row.
- Finish all rows. If you run short, say exactly which rows you did not judge.

When you finish, reply with the counts by verdict and the list of GAP rows only.

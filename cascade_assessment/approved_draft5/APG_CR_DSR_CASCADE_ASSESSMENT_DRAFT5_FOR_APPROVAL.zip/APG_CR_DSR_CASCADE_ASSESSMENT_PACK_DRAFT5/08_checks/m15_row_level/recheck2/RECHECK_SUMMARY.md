# Re-check of entity register revision 4.1 (second round): summary

**INDEPENDENT READ-ONLY (agent).** Design work only; nothing built. Inputs: the 81 rows in `in/ROWS.csv`, `in/ENTITY_REGISTER_REV41B.csv`, `in/M15_REGISTER_CHANGES.csv`, Sections 00 to 18. Every row read individually; the sections were consulted where the wording mattered (S04 s3, s4, s7, s12; S06 s6, s8; S10 s3, s4; S11 s5; S13 s13.6; S15 s15.3 to s15.5; S16).

## Counts

| Verdict | Rows |
|---|---|
| CARRIED | 67 |
| STILL-GAP | 14 |
| NOT-A-DATA-NEED | 0 |
| Total | 81 |

## STILL-GAP rows

| Row | Entity | Missing | Smallest fix |
|---|---|---|---|
| APG-S04-L0032 | E103 | Downstream processing errors. E103 names intake validation results and warnings only, and S04 s12 lists those separately from downstream results. | R41-05 add "downstream processing errors per attempt" (or link each receipt to the E109 jobs that processed it). |
| APG-S04-L0041 | E02 | Idempotency keys. R41-03 has the duplicate, retry, back-off, dead-letter and replay policy, but not the key basis. | R41-03 add "idempotency key basis (key fields, or the documented composite identity and ambiguity policy, S04 s7)". |
| APG-S06-C0087 | N01 | Prioritisation weights. S06 s8 says "thresholds and weights must be documented, testable and approved". Thresholds are in N01; weights are on no entity. | N01 add prioritisation or ranking weights and the ranking-method version, with approved by and when. |
| APG-S10-C0016 | E86 | "The result of the eligibility checks before ranking" is a single result with no named checks. Financial status (authoritative, qualified or scenario-only) is held nowhere on E86. Decision deadline is now carried. | R41-19: the result of each S10 s3 check: evidence sufficiency, data freshness, duplication/overlap, financial status (authoritative, qualified, scenario-only), user authority, mandatory safety/quality/legal/contractual reviews, continued actionability. |
| PG-CR-AC-04 | E13 | Valuation evidence. Quantity and rate per item (R41-54) are now carried, but E13 has no evidence link. | R41-54 add "valuation evidence per claimed item (E83 links: measured quantities, valuation calculations)". |
| APG-S13-L0079 | E44 | Comparable project, work-package or activity characteristics. | E44 add for a quality-improvement baseline (S13 s13.6): comparability characteristics. |
| APG-S13-L0080 | E44 | Historical defect or rework frequency. | E44 add "historical defect or rework frequency". |
| APG-S13-L0082 | E44 | Exposure volume or number of relevant activities. "Quantities" does not say what it counts (in S05 s10.1 it is the priced quantity). | E44 add "exposure volume or number of relevant activities". |
| APG-S13-L0084 | E44 | Relevant changes in scope, specification, design, workforce or operating conditions. "Conditions" covers the baseline's own conditions only, and the reason one version replaced another is version history, not this. | E44 add "relevant changes in scope, specification, design, workforce or operating conditions". |
| APG-S13-C0155 | E44 (E88 part carried) | Whether the baseline is sufficiently comparable. E44 has no comparability characteristics or assessment. | E44 add comparability characteristics and "comparability assessment and material limitations" (S13 s13.6 last paragraph). |
| APG-S13-L0163 | E44 (E88 part carried) | Comparability (same gap as the row above). | Same fix as APG-S13-C0155. |
| APG-S16-C0034 | E45 | Correlation id on the calculation run. E102, E103 and E109 now carry one; E45 and E01 do not. | R41-23 add "correlation id". |
| APG-S16-L0067 | E111 | Restore test: exceptions and evidence are missing. Versions are only partly covered by "backup used". | R41-46 restore test add "versions restored (application, schema, data), exceptions, evidence references". |
| APG-S16-L0087 | E111 | Release: configuration and migration versions ("contents" is not this), operator or deployment identity, verification results, known exceptions and repair decisions are missing. Rollback is carried. | R41-46 release add "configuration and migration versions, deployed by, verification results, known exceptions, rollback or forward-repair decision". |

One edit to E44 (the seven S13 s13.6 fields plus a comparability assessment and its limitations) closes six of the 14 rows.

## Problems found in revision 4.1

1. **R41-24b names the wrong section's fields.** It says "for a savings baseline (S05 s10.1, S13 s13.6)" but lists only procurement-style contents (scope, period, quantities, unit costs, conditions, source records, approval, adjustments allowed). Of the seven S13 s13.6 quality-baseline fields it carries only scope and period, and it has no comparability assessment. The change claims to consolidate C-G-BEN for S13 but does not do so.
2. **R41-19 eligibility checks.** The wording does not deliver the per-check result that C-G-REC named. Ranking factors are "held separately", but eligibility results are not.
3. **R41-46 (E111) is thinner than S16.** The release and restore-test lists leave out fields that S16 s8 and s10 name word for word. The re-check had already given the fix, and it was not applied.
4. **R41-03** consolidates B5, but the first item B5 named (idempotency keys) is missing.
5. **R41-34 (E30)** carries the class as "the five S08 s5 classes" without listing them. I accepted this because it points to a closed list in a locked section. Listing the five names would remove any doubt and match how R41-19 lists the E86 states.
6. **Entity count.** The register has 114 rows (N01 plus E01 to E113). The brief's "113 entities, 13 new" predates E113: the new entities are E100 to E113, which is 14.
7. **E05 overlaps E113.** E05 still lists "tenant, users, roles" as field groups, while R41-28 says identity and access are E113 (class P). Users and roles are listed on both. Suggest changing E05 to "tenant; users and roles: see E113".
8. **Class P markings** (E102, E108, E109, E110, E111, E112, E113) all fit the owner's rule (audit, identity and access, jobs, incidents, operations records, data classification and retention policy, AI context). None looks wrong. E103 (ingestion receipt) is class I; it could be platform or AUIF-held depending on discovery, but class I is defensible because S04 makes APG responsible for the receipt record.
9. **Text check.** A text match confirmed that every R41 "what" in the changes file appears in the matching register entity's field groups. No change is listed but missing from the register.

## Judgement calls (rows judged, but close)

- APG-S04-L0032: I ruled STILL-GAP because S04 s12 lists validation results separately from downstream processing results, so "validation results and warnings" does not cover downstream errors.
- APG-S10-L0093 and APG-S10-C0016: I counted the gate as present (L0093 CARRIED) but the named checks as not held (C0016 STILL-GAP).
- APG-S13-C0123: I ruled uncertainty carried through the "ranking factors held separately", because S10 s4 lists Confidence as one of those factors.
- APG-S15-L0060 and APG-S16-L0051: I ruled tenant scope on E109 carried by E01 ("on every record": organisation and project scope).

No rows were left unjudged.

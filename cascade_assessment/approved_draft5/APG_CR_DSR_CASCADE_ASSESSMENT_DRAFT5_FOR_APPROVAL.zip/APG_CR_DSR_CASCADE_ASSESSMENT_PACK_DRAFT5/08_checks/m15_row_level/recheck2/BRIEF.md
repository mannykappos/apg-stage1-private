# Brief: scoped re-check of the entity register, revision 4.1 (second round), against the 81 rows a first re-check still found uncarried

You are a fresh, independent agent. Label your work **INDEPENDENT READ-ONLY (agent)**. This is design work: nothing is built.

Anchor Profit Guardian's locked blueprint (Sections 00 to 18) has a requirements matrix of 2,712 rows. A first independent check read every row and found 430 rows whose data the entity register (revision 4, 100 entities) did not carry, plus 52 rows carried only by proposed fixes. The builder has now written revision 4.1 of the register (113 entities). It adds field groups to existing entities and 13 new entities. Each change has an ID R41-xx and lists which first-check fixes it consolidates.

The owner decided that records probably held by the Anchor platform underneath APG (audit log, identity and access, background jobs, incidents, operations records, data classification and retention policy) are listed, marked "held by the Anchor platform, to be confirmed in discovery" (class P). A row carried by such an entity counts as carried.

## Inputs (under `<WORKSPACE>/m15recheck2/in/`)
- `ROWS.csv`: the 81 rows a first re-check found STILL-GAP, with what it said was missing, and the requirement text. The builder has since revised revision 4.1 to close them (the R41 changes were widened, and E09 R41-36, E13 R41-54, E16 R41-55 and the class P entity E113 were added).
- `ENTITY_REGISTER_REV41B.csv`: the revised register (column "required field groups" holds each entity's field groups; revision 4.1 additions are marked [R41-xx]).
- `M15_REGISTER_CHANGES.csv`: the changes and what each consolidates.
- `Section_00.txt` to `Section_18.txt`: the locked sections, for context.

## What to do
For every row of ROWS.csv, decide whether revision 4.1 now carries the data the requirement needs:
- `CARRIED`: name the entity and the [R41-xx] change or the existing field group that carries it.
- `STILL-GAP`: say exactly what is still missing, and the smallest fix.
- `NOT-A-DATA-NEED`: only if you are sure the first check was wrong that the row needs APG to hold data; say why.

Be strict: a field group must actually carry what the requirement names. Do not count vague wording as carrying a specific field.

## Output
1. `out/RECHECK.csv` with columns: requirement_id, verdict, entity, change, note. Every row of the input, in order.
2. `out/RECHECK_SUMMARY.md`: counts by verdict; every STILL-GAP with its row, the missing data and the fix; anything in revision 4.1 you think is wrong (an R41 change that does not say what it claims, a wrong class, a platform marking that seems wrong); rows you could not judge.

Read-only: write only under `m15recheck2/out/`. No network. Short `python3 -I -S` scripts to read files or check your row count are fine, but read each row yourself. When done, reply with the counts and the STILL-GAP rows only.

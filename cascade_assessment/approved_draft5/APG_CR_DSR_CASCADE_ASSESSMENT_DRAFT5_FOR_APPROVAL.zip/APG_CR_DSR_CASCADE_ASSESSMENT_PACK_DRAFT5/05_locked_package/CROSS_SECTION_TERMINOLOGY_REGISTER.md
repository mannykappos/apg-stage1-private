# Controlled Terminology and Cross-Section Consistency Register

Status: Initial consolidation review register. Definitions below are review anchors extracted from the locked blueprint context; they must be checked against the full locked source text during implementation and final human review.

| Canonical term | Primary source sections | Required consistency check |
|---|---|---|
| Recognised margin | 03, 05 | Same canonical meaning, inputs, timing and authoritative status across all references. |
| Forecast final margin | 03, 05 | Forecast state remains distinct from recognised margin and scenario outputs; version/as-of state is traceable. |
| Cash-position-adjusted margin | 03, 05, 12 | Cash timing/financing effects are not silently substituted for accounting margin or realised profit. |
| Authoritative forecast | 05, 06, 10, 12, 17 | One formally approved authoritative forecast per project/scope/as-of state; scenarios/prior versions isolated. |
| Provisional/qualified value | 03–12, 17 | Missing/stale/conflicting inputs remain labelled and are not silently promoted to authoritative values. |
| Realised saving / net benefit | 05, 08–10, 13, 17 | Requires approved baseline, implementation evidence, verified outcome and offsetting-cost treatment. |
| Potential / estimated / approved / recognised / invoiced / collected revenue | 11 | Lifecycle states remain distinct; no silent transitions. |
| Cash, scheduled receipts/payments and scenarios | 12 | Actual cash, scheduled values, disputed/conditional values and scenarios remain separate. |
| Source authority | 04, 17 | Field-level authority; newest timestamp alone does not establish authority. |
| Cross-domain overlap / net impact | 05–13, 17 | Correlated/overlapping exposure is linked and deduplicated; no blind summation. |
| Unknown external outcome | 04, 16–18 | Timeout does not imply failure; reconcile before potentially duplicative retry. |
| Closed database-dependent item | 14, 17, 18 | Requires required staging evidence and authorised human sign-off. |

Automated checks are a detection aid. Human reviewers must verify definitions and conflicts against the actual locked source paragraphs. Record conflicts, disposition, reviewer, date and evidence in the final consistency report.

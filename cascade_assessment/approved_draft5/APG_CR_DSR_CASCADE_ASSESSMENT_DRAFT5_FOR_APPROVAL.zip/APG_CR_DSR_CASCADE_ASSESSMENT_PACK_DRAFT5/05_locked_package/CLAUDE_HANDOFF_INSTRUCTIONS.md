# CLAUDE HANDOFF INSTRUCTIONS — ANCHOR PROFIT GUARDIAN (CONSTRUCTION EDITION)

## Governing rule
Read all locked Sections 00–18 before making material implementation changes. These documents are requirements, not proof that code exists or passes tests. Preserve locked requirements. Do not claim production readiness without evidence from the required target environment.

## Phase 0 — Repository discovery and baseline (mandatory)
1. Confirm the repository root and inspect the current branch and working tree:
   - `pwd`
   - `git rev-parse --show-toplevel`
   - `git status --short --branch`
   - `git rev-parse HEAD`
2. Inspect top-level files and project guidance:
   - `ls -la`
   - Find and read applicable `README*`, `AGENTS.md`, `CONTRIBUTING*`, `pyproject.toml`, `package.json`, lockfiles, Docker/compose files, CI configuration and deployment configuration where present.
3. Identify actual runtimes and installed tools from the repository's own configuration. Do not assume the examples below exist:
   - `python --version`
   - `node --version`
   - `npm --version`
   - `docker --version`
4. Discover actual test commands from repository documentation/configuration before running tests. Run the existing baseline suite where safe; record commands, exit codes, counts, environment and failures. Do not turn skipped/blocked tests into passes.
5. Map the architecture: API entry points, database engine/schema/migrations, tenant boundaries, authorization, audit logs, financial calculations, source ingestion, background workers/queues, integrations, AUIF, Governor, storage, AI retrieval, CI/CD and deployment.
6. Create/update the RTM for every material requirement in Sections 00–18. Record source IDs or stable source anchors, implementation locations, tests, evidence, status, owner and closure condition.
7. Update the DB-Dependent Closure Register with every blocked database/environment requirement. Include the exact prerequisite, precise instructions for Amir, validation procedure, expected result, evidence required and authorised closure workflow. Never include credentials or secrets.
8. Phase 0 exit deliverable: baseline inventory, architecture/dependency map, test report, known defects, RTM, DB blocker register and implementation plan. Do not claim Phase 0 is complete without these artefacts.

## Implementation phase gates
- Phase 1 — Control foundations: identity, tenant isolation, permissions, audit, canonical entities, source authority and durable state invariants.
- Phase 2 — Authoritative financial core: canonical formulas, calculation versioning, immutable/reconstructable input snapshots, locked regression fixtures and mutation testing.
- Phase 3 — Domain intelligence: implement against locked domain contracts; AI is assistive and must not silently modify authoritative state.
- Phase 4 — Cross-domain integration: overlap/double-counting controls, linked provenance, deduplicated net impact and cross-domain regression suite.
- Phase 5 — Security, reliability and recovery: actual implementation verification for Sections 15–17, including real database checks, safe retry/reconciliation, restore and operational evidence.
- Phase 6 — Acceptance and release: complete mandatory tests, evidence, RTM status, open-defect review, DB verification, release gates and authorised sign-off.

Do not advance past a phase gate when its mandatory prerequisite fails or remains blocked. Work that can safely proceed without database access should continue, but DB-dependent items remain blocked until the required environment verification and sign-off.

## Status vocabulary
Keep these states distinct: Specified; Implemented; Local-tested; Integration-tested; Staging-verified; Operationally verified; Blocked; Failed; Accepted; Closed. A status change requires its defined evidence. Mock-only tests cannot close database-dependent requirements. A deployment command succeeding does not prove release acceptance.

## Mandatory integrity and release controls
- Maintain requirement-to-code-to-test-to-evidence traceability.
- Run the relevant financial-core suite after formula, rounding, tax, allocation, currency or authoritative-state changes.
- Run the mandatory cross-domain overlap suite before release.
- Test replay/idempotency and reconcile unknown external outcomes before potentially duplicative retries.
- Preserve human approvals, tenant isolation, source authority and auditability through failures and recovery.
- Generate build-linked test evidence and distinguish pass, fail, skip and blocked counts.
- Every change to a locked requirement requires an approved Change Request and a Cascade Impact Assessment.
- Never alter a locked section silently. Update versions, hashes, RTM, terminology report, tests and package manifest after approved changes.
- Do not claim production readiness from the blueprint, mocks, local tests alone or a high aggregate pass count.

## Final reporting
Report what was implemented, what tests were actually executed, what environment they used, what passed/failed/skipped/blocked, what remains database-dependent, and what evidence supports each closure. Preserve all unresolved blockers and limitations.

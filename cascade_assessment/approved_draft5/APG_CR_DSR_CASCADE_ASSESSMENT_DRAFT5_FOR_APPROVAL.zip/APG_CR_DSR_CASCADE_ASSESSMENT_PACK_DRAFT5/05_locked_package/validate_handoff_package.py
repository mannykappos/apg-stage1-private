#!/usr/bin/env python3
"""Validate a final Anchor Profit Guardian handoff package after ZIP extraction."""
import csv, hashlib, json, sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
manifest_path = root / "manifest.json"
errors = []
if not manifest_path.exists():
    print("FAIL: manifest.json missing")
    sys.exit(2)
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
entries = manifest.get("files", [])
listed = set()
for entry in entries:
    rel = entry["path"]
    listed.add(rel)
    path = root / rel
    if not path.is_file():
        errors.append(f"MISSING: {rel}")
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != entry.get("sha256"):
        errors.append(f"HASH MISMATCH: {rel}: expected {entry.get('sha256')} got {digest}")
    if entry.get("size_bytes") is not None and path.stat().st_size != entry["size_bytes"]:
        errors.append(f"SIZE MISMATCH: {rel}")
for i in range(19):
    matches = [p for p in root.glob(f"Anchor_Profit_Guardian_Construction_Blueprint_Section_{i:02d}_v1.0_LOCKED.docx")]
    if not matches:
        errors.append(f"REQUIRED SECTION DOCUMENT MISSING: {i:02d}")
unlisted = []
for p in root.rglob("*"):
    if p.is_file() and p.name != "manifest.json" and p.name != "PACKAGE_VALIDATION_REPORT.txt":
        rel = p.relative_to(root).as_posix()
        if rel not in listed:
            unlisted.append(rel)
if unlisted:
    errors.append("UNLISTED FILES: " + ", ".join(sorted(unlisted)))
rtm = root / "MASTER_REQUIREMENTS_TRACEABILITY_MATRIX.csv"
if not rtm.exists():
    errors.append("RTM missing")
else:
    with rtm.open(newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    ids = [r.get("requirement_id", "") for r in rows]
    if not rows:
        errors.append("RTM contains no rows")
    if any(not x for x in ids):
        errors.append("RTM contains blank requirement IDs")
    if len(ids) != len(set(ids)):
        errors.append("RTM contains duplicate requirement IDs")
    if any(not r.get("source_file") or not r.get("source_anchor") for r in rows):
        errors.append("RTM has rows missing source file/anchor")
# DB register should preserve explicit blocker statuses; this validator intentionally does not auto-close blockers.
db = root / "DB_DEPENDENT_CLOSURE_REGISTER.md"
if not db.exists():
    errors.append("DB-Dependent Closure Register missing")
elif "Blocked" not in db.read_text(encoding="utf-8"):
    errors.append("DB-Dependent Closure Register has no explicit blocked state")
if errors:
    print("FAIL — package validation found issues:")
    for e in errors: print(" - " + e)
    sys.exit(1)
print(f"PASS — {len(entries)} manifest files hash/size verified; 19 section documents present; RTM has {len(rows)} unique source-anchored rows; DB blocker register present.")

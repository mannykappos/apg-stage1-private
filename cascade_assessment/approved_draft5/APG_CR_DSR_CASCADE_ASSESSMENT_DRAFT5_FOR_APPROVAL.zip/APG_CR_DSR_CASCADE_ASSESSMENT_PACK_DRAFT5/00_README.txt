APG change request APG-CR-DSR (Data Supply System + Data Readiness): Section 18 cascade impact assessment, draft 5 (2026-11-13)
Pack for the owner's formal approval. GPT's targeted confirmation of draft 5 (the last review round, owner record item 31) found
0 blocking, 4 should fix, 2 minor, and said it is ready for approval once those are made; they are made (08_checks/GPT5_FIXES_CIA.md).

01_ASSESSMENT_DRAFT5.md          the assessment (the same text as the Word file sent with this pack)
02_GPT_TARGETED_CONFIRMATION_PROMPT.md   the prompt GPT was given for its targeted confirmation (kept as a record)
03_tables/                       CIA_PROPOSED_TEXT.csv (87 additions; 12 reworded version lines and 2 reworded sentences, each an
                                 owner-approved relaxation, with the locked text at each anchor), CIA_RTM_IMPACT.csv (1,887 rows over 1,410
                                 locked items), CIA_DEPENDENT_TEXT.txt (full locked text of every dependent), CIA_COUNTS.txt
04_tools/                        build_cia.py + cia_data.py (generate 03_tables from 05_locked_package); fill_v5.py + FILL_v5.json and
                                 assemble.py (build 01 from CIA_SOURCE.md). Run from 04_tools/ (needs python-docx):
                                   python3 -I build_cia.py ../05_locked_package <out>
                                   python3 -I fill_v5.py CIA_SOURCE.md <out> <out>/CIA_SOURCE_filled.md
                                   python3 -I assemble.py <out>/CIA_SOURCE_filled.md <out> <out>/draft5.md
                                 These reproduce 03_tables and 01 byte for byte.
05_locked_package/               the locked blueprint v1.0 package as received (19 sections, Master RTM, registers, manifest, validator);
                                 unchanged
06_change_request_sources/       the data supply design (draft 7), the Data Readiness CR (revision 4) and its registers (rev4_registers/),
                                 the entity register revision 4.1 with its addendum and change list (rev41_registers/, matter M15), the
                                 owner's decisions record (items 1 to 31), the data supply decisions, GPT's re-check of revision 4, and the
                                 8-layer design blueprint v0.1 (not locked)
07_stage1_code_read/             the stage 1 production modules the registers were read from (freeze ee1ce3ec) and the list of stage 1 test
                                 files
08_checks/                       GPT's review of draft 4 and the fix for each finding (GPT_FIXES_CIA.md); GPT's targeted confirmation of
                                 draft 5 (GPT_REVIEW_DRAFT5.md) and its fixes (GPT5_FIXES_CIA.md); the three agent checks of drafts
                                 1 to 3 and their fix lists; the three agent checks of draft 5 (CHECK_DRAFT5, RECHECK_DRAFT5,
                                 FINAL_CHECK_DRAFT5), each with its brief and the builder's fix list; m15_row_level/ (the four agents' reading
                                 of all 2,712 RTM rows and the two scoped re-checks, with briefs). The last fix list (FINAL5_FIXES_CIA.md)
                                 is wording only and was not checked by an agent again, to avoid a loop.

The assessment, tables and tools are Claude's work (BUILDER-EXECUTED: NOT INDEPENDENT). Agent checks are INDEPENDENT READ-ONLY (agent).
Design only: no build is authorised, stage 2 is not authorised, and nothing here claims implementation, acceptance or production
readiness. All owner questions are answered (section 11). Workspace paths in the briefs are masked as <WORKSPACE>.

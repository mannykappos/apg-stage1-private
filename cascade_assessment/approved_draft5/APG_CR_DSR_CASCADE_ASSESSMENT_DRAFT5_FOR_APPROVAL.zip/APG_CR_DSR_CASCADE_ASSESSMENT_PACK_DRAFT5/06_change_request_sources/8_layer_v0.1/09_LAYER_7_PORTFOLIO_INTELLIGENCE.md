# 9. Layer 7 — Portfolio Intelligence
## Multi-Project Profitability and Capital Allocation Intelligence

### Purpose
Provide an executive view across projects while preserving the meaning, quality and provenance of each project's financial assessment. It should show portfolio-level movement and which projects contribute to it, not simply add unlike figures together.

### Required inputs
- qualified project assessments;
- common financial definitions and reporting periods;
- project/entity/currency metadata;
- baseline and assessment versions;
- data freshness and verification status;
- cash-flow and resource data where allocation analysis is required;
- access permissions and entity boundaries.

### Core behaviours
1. Aggregate comparable project values using approved definitions.
2. Show project contribution to portfolio movement.
3. Distinguish total profit dollars, margin percentages, averages and weighted measures.
4. Show data coverage, age and confidence alongside financial results.
5. Identify concentration of exposure and projects requiring review using explainable criteria.
6. Compare portfolio scenarios only when constraints and assumptions are explicit.
7. Allow drill-down from portfolio result to project, source inputs and calculation version.

### Data confidence
A data-confidence indicator should explain completeness, freshness, verification and source quality. It must not silently weight or rewrite financial totals. Show the reported financial rollup and confidence information separately unless a separately approved statistical method explicitly calls for weighting.

### Outputs
- portfolio snapshot and reporting period;
- project-level current/prior financial values;
- contributions to portfolio change;
- concentration and exposure indicators;
- data confidence/freshness view;
- optional resource/capital allocation scenarios;
- source and version traceability.

### Required safeguards
- Do not aggregate different currencies, periods or financial definitions without approved normalisation.
- Do not replace missing values with zero without explicit semantics.
- Do not imply that a ranking proves cause.
- Do not recommend cash transfer across legal entities without relevant entity, liquidity and governance constraints.
- Keep access boundaries between projects and entities.

### Acceptance tests
- Portfolio totals reconcile to eligible project values under the approved aggregation rule.
- Incomparable or stale project data is visibly qualified.
- Data-confidence indicators do not silently change totals.
- A project can be traced from the rollup to its assessment version and source values.
- Cross-project allocation scenarios expose constraints and assumptions.

### Deferred / owner decision
Cash pooling, cross-project resource levelling and subcontractor default risk rollups require additional data, entity constraints and validation.

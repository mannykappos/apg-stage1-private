# 1. Product Definition and Target Architecture

## 1.1 Product purpose

Anchor Profit Guardian (APG) is intended to help construction businesses and property developers understand, protect, stabilise, recover and improve project profitability. Its value is not merely to report that costs rose or schedules slipped. It should connect changing project evidence to its financial implications, show which assumptions drive the result, compare defensible alternatives, and preserve the reasoning and evidence behind each assessment.

APG is a decision-support product. It must distinguish observed facts from forecasts, assumptions, scenarios and recommendations. It must not represent potential outcomes as guaranteed results.

## 1.2 The eight product capabilities

1. **Estimation Intelligence** — pre-construction profitability exposure intelligence.
2. **Profit Drift Intelligence** — continuous profitability movement detection.
3. **Holding Cost Intelligence** — time-based profitability movement intelligence.
4. **Profit Recovery Engine** — profitability stabilisation and recovery intelligence.
5. **Profit Increase Engine** — profitability optimisation and upside intelligence.
6. **Re-Evaluation Engine** — continuous project reassessment intelligence. Architecturally this is a cross-cutting governance/service capability, not a duplicate financial calculator.
7. **Portfolio Intelligence** — multi-project profitability and capital allocation intelligence.
8. **Scenario Decision Engine** — multi-outcome profitability modelling and decision intelligence.

These are product-level capabilities. They do not have to be eight independent microservices. Shared services should be used wherever they prevent inconsistent financial logic.

## 1.3 Target architecture

### Tier A — Financial Baseline and Governance
- Common financial definitions and data contracts.
- Baseline creation and version history.
- Estimate evidence and assumptions.
- Calculation/version metadata.
- Audit and approval records.

Supports Layer 1 and the cross-cutting functions of Layer 6.

### Tier B — Continuous Financial Monitoring
- Actual and committed cost ingestion.
- Forecast-to-complete updates.
- Baseline comparisons.
- Cost and margin movement detection.
- Holding-cost/time-dependent calculations.
- Variation reconciliation.
- Materiality, velocity and data-quality checks.

Supports Layers 2 and 3 using common calculation services.

### Tier C — Recovery and Optimisation
- Candidate intervention definitions.
- Incremental financial impact assessment.
- Recovery cost-benefit comparison.
- Upside and value-engineering scenario comparison.
- Constraints, dependencies, approvals and risks.

Supports Layers 4 and 5.

### Tier D — Scenario and Sensitivity Analysis
- Named, reproducible scenarios.
- Baseline/downside/recovery/upside comparisons.
- Sensitivity analysis.
- Scenario versioning and evidence.
- Probabilistic methods only after separately approved calibration.

Supports Layer 8 and may be consumed by Layers 4, 5 and 7.

### Tier E — Portfolio Intelligence
- Comparable project-level snapshots.
- Portfolio rollups and project contribution analysis.
- Data-confidence visibility.
- Concentration and exposure views.
- Capital/resource allocation scenarios when approved constraints exist.

Supports Layer 7.

### Cross-cutting Re-Evaluation service
- Trigger detection.
- Reassessment requests.
- Baseline version governance.
- Preservation of old assessments.
- Reconciliation of old and new financial views.
- Approval and audit requirements.

This service coordinates reassessment across tiers. It must not independently recalculate financial figures using a separate set of rules.

## 1.4 System flow

Project documents and data → normalisation and validation → financial records and assumptions → versioned baseline → event/change detection → shared financial calculation services → layer-specific analysis → scenario/recovery comparison → human review/decision → outcome capture → forecast-vs-actual review → reassessment.

Not every deployment will have every input integration. The system must expose missing or unavailable data rather than imply that all data sources are connected.

## 1.5 Product boundaries

APG should:
- detect and quantify financial movement;
- explain the inputs and assumptions behind results;
- identify missing or contradictory evidence;
- compare alternative financial outcomes;
- surface review triggers and candidate interventions;
- preserve baseline and decision history;
- track outcomes against prior forecasts where data is available.

APG should not, by default:
- certify legal entitlement or contract interpretation;
- certify NCC or Australian Standards compliance;
- autonomously issue contractual notices or approve variations;
- automatically change project budgets or baseline values;
- guarantee savings, profitability, recovery or forecast accuracy;
- silently update financial assumptions or learning rules;
- imply that an integration exists when it has not been implemented and tested.

## 1.6 Key user roles to support in the design

Exact role names and permissions require owner confirmation, but the design should consider:
- Project/commercial manager: reviews project-level changes and scenarios.
- Estimator: prepares or reviews the initial estimate and assumptions.
- Finance/controller: reviews cost, revenue, margin and accounting treatment.
- Project director/executive: reviews material exposure and portfolio view.
- APG administrator: manages configuration and access.
- Auditor/reviewer: read-only access to evidence, calculation history and decision records.

Use least-privilege access. Do not assume all users can approve baselines, change thresholds or see all projects.

## 1.7 Design principle

**One financial truth, multiple intelligence views.** The layers may ask different questions, but they must not maintain competing definitions of cost, revenue, margin, holding exposure, or baseline.

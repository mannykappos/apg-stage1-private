# 7. Layer 5 — Profit Increase Engine
## Profitability Optimisation and Upside Intelligence

### Purpose
Identify and evaluate opportunities to improve projected profitability beyond the current qualified case. This is distinct from recovery: recovery aims to reduce or reverse deterioration; increase aims to identify additional upside.

### Candidate opportunity classes
- improved procurement or supplier conditions;
- reduced avoidable labour inefficiency or downtime;
- sequencing/staging improvements;
- design-stage value engineering;
- construction-stage alternatives or substitutions;
- release/sales timing scenarios where relevant;
- improved use of capacity/resources;
- other evidence-backed operational or commercial opportunities.

These are candidate classes, not automatic recommendations.

### Required inputs
- current approved/qualified financial assessment;
- opportunity description and evidence;
- current scope, design and project stage;
- estimated cost/time effect;
- implementation cost and dependencies;
- relevant specification, design, certification and compliance evidence;
- market assumptions if the opportunity depends on external conditions.

### Core behaviours
1. Separate controllable operational opportunities from external market scenarios.
2. Identify which financial inputs the opportunity changes.
3. Calculate an upside case using shared calculation services.
4. Include costs, delays, risks and constraints needed to capture the upside.
5. Identify required technical, design, contract and compliance reviews.
6. Show the evidence and conditions under which the upside case is plausible.
7. Keep proposed, reviewed, approved and implemented statuses distinct.

### Compliance boundary
The system may flag required checks and link relevant documents or references. Automated matching does not certify compliance with the National Construction Code, Australian Standards, engineering requirements, contract specifications or other applicable obligations. A qualified responsible reviewer must approve the relevant technical decision.

### Outputs
- opportunity register;
- current case versus upside case;
- financial impact range and assumptions;
- required actions/dependencies;
- project-stage and compliance/technical review flags;
- risk and uncertainty notes;
- decision and outcome history.

### Required safeguards
- No guaranteed savings or market uplift.
- Do not mix design-stage opportunities with post-contract substitutions without stage-specific review.
- Do not treat an unverified market forecast as fact.
- Avoid counting an improvement already included in the current forecast.
- Do not label a substitution compliant solely because a document reference was found.
- Human review is required before a real-world change.

### Acceptance tests
- Opportunity calculation shows changed assumptions and costs.
- A proposal with missing mandatory technical review is visibly blocked from “approved” status.
- Benefits overlapping another scenario are not automatically added.
- External-market upside is clearly labelled as scenario-dependent.
- Approval and outcome records remain traceable.

### Deferred / owner decision
Automated value-engineering generation, code/standard interpretation and market prediction require separate risk assessment, evidence sources and validation.

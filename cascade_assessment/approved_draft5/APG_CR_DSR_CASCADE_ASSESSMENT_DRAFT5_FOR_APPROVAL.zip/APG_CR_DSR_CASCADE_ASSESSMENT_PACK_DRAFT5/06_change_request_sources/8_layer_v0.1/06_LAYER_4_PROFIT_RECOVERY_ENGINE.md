# 6. Layer 4 — Profit Recovery Engine
## Profitability Stabilisation and Recovery Intelligence

### Purpose
Evaluate practical interventions that may stabilise or recover projected profitability. The engine must compare a supported current case with one or more intervention cases and show the assumptions, incremental costs, dependencies, timing and risks.

### Required inputs
- current qualified financial assessment;
- baseline and drift history;
- cost and schedule drivers;
- candidate intervention options;
- intervention cost and timing assumptions;
- contract or specification references when the option depends on contractual rights or requirements;
- constraints, dependencies and approvals;
- evidence quality.

### Core behaviours
1. Identify the deterioration or exposure the intervention is intended to address.
2. Describe the intervention and which model inputs it changes.
3. Calculate the before/after financial range using shared calculation services.
4. Include implementation/acceleration costs and material side effects where known.
5. Compare alternatives, including a “no intervention” case.
6. Show the conditions required for the outcome and the evidence supporting them.
7. Present options for human review; do not execute actions.

### Recovery comparison
Do not reduce recovery to gross savings. The comparison should include, where applicable:
- incremental financial benefit;
- direct implementation or acceleration cost;
- timing and holding-cost effect;
- expected disruption or risk cost if a defensible basis exists;
- contractual exposure or liquidated-damages comparison when relevant and supported;
- uncertainty and dependencies.

No universal “net recovery yield” formula should be hard-coded until its financial definition and required inputs are approved.

### Outputs
- problem/exposure addressed;
- candidate intervention;
- baseline and intervention scenario comparison;
- incremental benefit/cost range and calculation basis;
- assumptions, dependencies and evidence;
- relevant contract/design checks;
- human review/approval status;
- outcome tracking fields for later comparison.

### Required safeguards
- No guarantee of recovery.
- No unqualified legal or contractual conclusion.
- Do not recommend an intervention whose cost, scope or assumptions are unknown without flagging that limitation.
- Do not double-count benefits also claimed by Profit Increase or Scenario Decision.
- Human approval is required before consequential action.

### Acceptance tests
- Intervention result is reproducible and tied to its input scenario.
- An intervention with costs exceeding its supported benefit is not presented as a positive financial recovery.
- Missing contract context is flagged where contractual rights are relied upon.
- Two interventions affecting the same cost component do not have their benefits blindly added together.
- Rejected options remain auditable if the product's workflow records them.

### Deferred / owner decision
Contract clause parsing, historical intervention-effectiveness analysis and automated intervention generation require separate validation and approval.

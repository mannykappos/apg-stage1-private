# 13. Testing Strategy and Acceptance Gates

## 13.1 Evidence categories

Report each test result as one of:
- **Not run**
- **Run by builder**
- **Run independently**
- **Failed**
- **Blocked**
- **Not applicable with rationale**

Do not call a capability accepted merely because unit tests pass. Acceptance requires the relevant calculation, data, integration, governance and regression evidence.

## 13.2 Test layers

### Unit tests
Test individual formulas, validators, state transitions, rules and status mappings.

### Contract tests
Validate schema compatibility and legal value/status transitions across shared services.

### Integration tests
Demonstrate data entering through the actual interface and resulting in a traceable assessment/alert/scenario.

### Regression tests
Confirm existing APG behaviour remains intact. Preserve prior release/package hashes and do not overwrite the source release during audit.

### Adversarial tests
Test missing, stale, contradictory, duplicated, reordered and malformed inputs; boundary values; repeated events; unauthorised transitions; baseline tampering attempts; and overlapping cost effects.

### Independent expected-value tests
For key financial examples, calculate expected outputs separately from the implementation and compare the results. The expected-value calculation must not simply call the same production formula under test.

## 13.3 Minimum cross-cutting acceptance criteria

- Identical input snapshot and calculation version produce reproducible results within approved rounding.
- Invalid or unavailable inputs cannot silently create authoritative-looking figures.
- Every material output links to its baseline/assessment version and source evidence.
- Duplicate imports/events do not double-count values.
- Cost categories reconcile and shared effects are not counted twice.
- Historical baselines and assessments remain reproducible.
- Permissions prevent unauthorised edits/approvals.
- Reassessment and approval transitions are auditable.
- Financial status types remain distinct.
- Scenarios use the same financial model as the baseline.
- Portfolio totals reconcile to eligible underlying project records.
- No production claim is made about a capability without source and test evidence.

## 13.4 Layer-specific acceptance summaries

### Layer 1
Baseline structure, assumption register, source evidence, stale/missing input flags, reproducibility, baseline approval and version preservation.

### Layer 2
Correct variance calculation, alert materiality, idempotent imports, variation reconciliation, no duplicate alerts/costs, source traceability.

### Layer 3
Correct time-cost calculation, schedule versioning, distinct cost categories, missing finance terms handling, no double-counting.

### Layer 4
Before/after scenario comparison, intervention cost inclusion, uncertainty disclosure, contract-context flags, human approval and no guaranteed-recovery language.

### Layer 5
Opportunity scenario traceability, project-stage controls, required technical review, no unsupported compliance certification, no double-counted benefits.

### Layer 6
Trigger correctness, version preservation, no silent re-baseline, approval gates, no event loops, historical reconstruction.

### Layer 7
Aggregation reconciliation, currency/period compatibility, confidence visibility, access separation, drill-down to project evidence.

### Layer 8
Scenario reproducibility, shared calculation model, sensitivity traceability, invalid-input handling, no unsupported probabilities, no automatic execution.

## 13.5 Acceptance gate before implementation
Before coding a feature, define:
- requirement ID;
- data contract;
- expected behaviour;
- failure/unknown-data behaviour;
- permission/audit effects;
- tests and expected values;
- integration target;
- rollback or feature-flag strategy if relevant.

## 13.6 Acceptance gate before release
Before release, provide:
- package manifest and hashes;
- source diff against the accepted base;
- test commands and actual outputs;
- known failures and exclusions;
- independent review results where required;
- requirement traceability;
- explicit release disposition: accepted, accepted with conditions, or not accepted.

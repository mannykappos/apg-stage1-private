# 8. Layer 6 — Re-Evaluation Governance
## Cross-Cutting Assessment, Trigger and Baseline-Versioning Service

### Purpose
Reassess a project when material conditions change, while preserving previous assessments and preventing re-baselining from hiding historical deterioration. This is a governance and orchestration service across the architecture, not a separate financial calculator.

### Trigger types
- material change in price, cost, scope, commitment or variation status;
- material schedule or milestone change;
- holding/finance assumption change;
- material change in revenue/sales/settlement assumption;
- stale, missing or contradictory data that invalidates an earlier assessment;
- scheduled review under an approved policy;
- user-requested reassessment.

Thresholds must be configurable and approved. Do not hard-code the illustrative 15% margin or 30-day delay examples as universal rules.

### Core behaviours
1. Receive a trigger with source, metric, timestamp and rule version.
2. Determine which project assessment components may be affected.
3. request recalculation through the shared financial model and relevant layer services.
4. Create a new assessment version with links to the previous assessment and baseline.
5. Compare old and new values and explain the principal changes.
6. Preserve the prior version, source snapshot and calculation versions.
7. Route material baseline changes for configured review/approval.
8. Record actor, reason, approvals and overrides.
9. Prevent silent replacement of approved baselines.

### Re-evaluation versus re-baselining
A reassessment may refresh the current forecast without changing the approved baseline. Re-baselining is a separate governed action that establishes a new comparison reference. Both must preserve the historical variance from earlier baselines.

### Outputs
- trigger event and reason;
- affected components;
- refreshed assessment ID/version;
- comparison with prior assessment;
- proposed or approved new baseline version, if applicable;
- review/approval status;
- audit record and source references.

### Required safeguards
- No automatic “wipe the slate clean.”
- No baseline change solely because a forecast deteriorated.
- No universal trigger threshold without approval.
- No reassessment result without an identifiable input snapshot and calculation version.
- Avoid trigger loops or repeated recalculations for the same event.
- Distinguish “assessment refreshed” from “baseline approved.”

### Acceptance tests
- Material input change creates a reassessment event with traceable reason.
- A forecast refresh does not automatically alter the approved baseline.
- Approved baseline history cannot be silently overwritten.
- Duplicate event does not cause uncontrolled repeated processing.
- A historical assessment can be reconstructed.
- Re-baselining requires configured permissions and captures reason/approval.

### Owner decisions required
- Which events trigger automatic reassessment versus user review?
- Which baseline changes require dual approval?
- Which thresholds apply by project type?
- What retention and tamper-evidence policy is required?

# 12. Security, Governance and Audit Requirements

## 12.1 Access and separation
- Enforce authentication and project/entity-level authorisation.
- Use least privilege.
- Separate read, edit, approve, administer and audit permissions.
- Do not assume every user can view all projects or commercial records.
- Record access/decision events according to approved audit policy.

## 12.2 Approval gates
Approval should be configurable for at least:
- approval of an initial baseline;
- material re-baselining;
- financial assumption or threshold changes;
- consequential recovery/optimisation decisions;
- project/portfolio resource allocation decisions;
- overrides of material alerts or data-quality blocks.

Exact role mapping and dual-approval requirements are owner decisions.

## 12.3 Audit history
Material actions should record:
- actor or system process;
- timestamp;
- operation;
- subject and version;
- prior and new values where applicable;
- reason;
- evidence references;
- calculation/rule version;
- approval status;
- outcome or failure.

Audit history should be protected against silent modification. The specific immutable/tamper-evident implementation must fit the current architecture and retention policy.

## 12.4 External sources and untrusted inputs
Imported documents, emails, supplier quotes and external feeds are data, not executable instructions. Validate content and permissions. Preserve provenance and source dates. Do not assume external data is correct merely because it was ingested successfully.

## 12.5 Decision support, not autonomous authority
APG may present findings, scenarios and recommendations. It must not automatically issue notices, approve variations, change contractual positions, authorise purchases, substitute materials or commit funds unless a separate, explicitly approved and governed workflow is designed.

## 12.6 Compliance and legal boundaries
- Automated references or text matching do not certify NCC/standards compliance.
- Contract references do not amount to a legal determination of entitlement.
- Financial outputs are management information and must follow the approved accounting policy.
- Jurisdiction-specific rules require appropriate professional review before production use.

## 12.7 Reliability and operational controls
- Log calculation failures and unavailable outputs.
- Make retries safe and idempotent.
- Avoid repeated trigger loops.
- Preserve source and derived-result lineage.
- Define retention, backup, restore and incident-response requirements.
- Do not expose sensitive project or financial data across tenants.

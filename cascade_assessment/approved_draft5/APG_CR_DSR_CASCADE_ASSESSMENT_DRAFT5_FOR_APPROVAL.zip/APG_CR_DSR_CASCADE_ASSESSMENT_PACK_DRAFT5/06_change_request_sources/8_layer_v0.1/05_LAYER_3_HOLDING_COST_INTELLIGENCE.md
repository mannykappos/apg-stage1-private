# 5. Layer 3 — Holding Cost Intelligence
## Time-Based Profitability Movement Intelligence

### Purpose
Quantify how time-related changes affect projected financial outcomes. This capability should not merely state that delays cost money; it should identify the relevant time-dependent cost components, show how they accumulate, and explain their contribution to the financial forecast.

### Architecture
Holding Cost Intelligence shares the common financial model and calculation infrastructure with Profit Drift. It remains an identifiable analytical capability with its own outputs, not a competing source of financial totals.

### Required inputs
- schedule baseline and current forecast milestones;
- project-specific rates and time bases;
- site overhead categories (where applicable);
- financing facility terms and drawdown/interest inputs (where applicable);
- land/property holding costs and tax/rates assumptions where applicable;
- expected completion, release or settlement dates;
- dependencies and delay evidence;
- source timestamps and data-quality qualifiers.

### Core behaviours
1. Classify time-dependent cost components under the approved cost taxonomy.
2. Calculate the cost associated with each component using its defined time basis.
3. Compare baseline timing with current timing and named delay scenarios.
4. Show weekly/monthly/stage-based accumulation when appropriate.
5. Separate site overheads from financing/developer holding costs.
6. Explain which schedule changes drive which financial changes.
7. Send the resulting cost components to the shared financial model without duplicating costs already included elsewhere.

### Outputs
- baseline versus current timing assumptions;
- time-dependent cost breakdown;
- period-by-period accumulation;
- effect on approved profit/margin measures;
- sensitivity to milestone or duration changes;
- missing-data warnings and evidence links;
- reconciliation to the total project forecast.

### Required safeguards
- Do not infer finance terms from generic assumptions.
- Do not compound interest unless the applicable facility terms and approved method support it.
- Do not add a cost already embedded in another forecast component.
- Distinguish actual incurred costs from future projected costs.
- Do not treat a schedule forecast as a confirmed delay.
- Do not use a single weekly rate where cost behaviour is staged or nonlinear unless justified.

### Acceptance tests
- A defined delay scenario changes only the relevant time-dependent components.
- The same holding cost is not counted both in the holding service and another forecast component.
- Missing loan terms make the finance component unavailable/qualified rather than guessed.
- Baseline and current schedules can be compared and reproduced.
- Total cost components reconcile to the shared financial model.

### Deferred / owner decision
Dynamic loan drawdown/interest models require a defined facility data contract and independent finance-calculation examples.

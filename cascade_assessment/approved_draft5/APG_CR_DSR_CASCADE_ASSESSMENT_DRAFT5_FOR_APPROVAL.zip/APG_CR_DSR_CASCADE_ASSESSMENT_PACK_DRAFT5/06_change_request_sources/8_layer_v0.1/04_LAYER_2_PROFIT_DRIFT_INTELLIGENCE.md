# 4. Layer 2 — Profit Drift Intelligence
## Continuous Profitability Movement Detection

### Purpose
Detect and explain material changes in projected project profitability against a versioned baseline. The differentiator is not a generic cost-overrun alert; it is a traceable explanation of how observed changes and revised assumptions move the current financial view.

### Required inputs
- approved baseline and subsequent assessment versions;
- actual cost/revenue transactions;
- commitments and purchase orders;
- forecast-to-complete;
- progress and scope status where reliable;
- variation/instruction register;
- schedule and milestone changes;
- relevant holding-cost calculations;
- source timestamps, verification and data-quality status.

### Core behaviours
1. Reconcile incoming records to project, category, scope, supplier/trade and baseline.
2. Compare current financial position with the chosen baseline and prior assessment.
3. Detect material absolute variance, percentage variance, repeated movement and rate-of-change where data supports it.
4. Distinguish observed variance from forecast change and scenario change.
5. Identify unmatched instructions/work/claims against variation records.
6. Explain contributing factors with evidence; label correlation or inferred contribution appropriately.
7. Suppress duplicate alerts while retaining a traceable event history.
8. Escalate stale or missing data as a data-quality issue rather than treating it as a zero variance.

### Alert contract
Each alert should include:
- unique alert ID;
- project and affected scope/category;
- baseline and assessment version;
- detected event/change and timestamp;
- metric, value, units and comparison period;
- materiality/velocity rule that fired;
- source evidence;
- data-quality qualification;
- explanation and any known limitations;
- review status and disposition.

Thresholds are configurable and must be approved; examples are not universal defaults.

### Variation reconciliation
Flag work/instructions/claims that have no matching variation record or approved alternative record. The alert should say “unmatched / review required,” not automatically “recoverable revenue.”

### Required safeguards
- Avoid double-counting direct costs, site overhead and holding costs.
- Keep actual, committed, forecast and scenario values distinct.
- Do not assert causal attribution without evidence.
- Avoid alert fatigue using materiality, aggregation, deduplication and configurable thresholds.
- Preserve history even when alerts are dismissed or superseded.

### Acceptance tests
- Material cost variance produces an alert with source and baseline references.
- Duplicate import does not double-count the cost or repeatedly create equivalent active alerts.
- Unmatched work record creates a reconciliation exception, not automatic revenue recognition.
- Stale/missing inputs result in a visible qualification.
- A new baseline changes the comparison basis but does not erase prior drift history.
- Alert calculations can be reproduced from the input snapshot and rule version.

### Deferred / owner decision
Labour productivity drift and subcontractor financial-health scoring require approved metrics, lawful/reliable data sources, false-positive analysis and pilot validation.

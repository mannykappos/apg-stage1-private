# 14. Implementation Roadmap and Open Decisions

## 14.1 Required workflow

### Phase 0 — Source audit and traceability
- Inspect the actual APG source package and identify the true baseline/release.
- Record file inventory and hashes.
- Map every requirement to code, tests and interfaces.
- Mark each capability: found and verified, partially present, not found in reviewed scope, or unable to verify.
- Preserve all source packages unchanged.
- Produce a gap list and proposed implementation plan.

**Gate:** Owner reviews the source audit and scope before implementation.

### Phase 1 — Financial foundation and governance
- Approve core financial definitions and reporting bases.
- Define canonical data contracts and cost taxonomy.
- Define baseline/assessment versioning.
- Define variation states and treatment.
- Define data quality, source provenance and audit requirements.
- Implement/verify shared calculation services and independent expected-value tests.

**Gate:** Financial outputs are reproducible, status-aware, auditable and protected from double-counting.

### Phase 2 — Baseline and monitoring
- Implement or complete Estimation Intelligence.
- Implement or complete Profit Drift Intelligence.
- Add Holding Cost calculations under the common model.
- Add variation reconciliation.
- Validate alerts and data-quality behaviour.

**Gate:** Pilot project records can be ingested and reconciled; results pass independent expected-value and adversarial tests.

### Phase 3 — Re-evaluation and decision support
- Implement cross-cutting reassessment triggers and baseline governance.
- Add recovery and increase scenario comparisons.
- Add approval flows and decision records.
- Ensure shared financial logic and no double-counting.

**Gate:** Reassessment preserves history; proposed actions are advisory and traceable.

### Phase 4 — Portfolio and scenarios
- Implement portfolio aggregation and confidence visibility.
- Implement named scenarios and sensitivity analysis.
- Add outcome tracking and forecast-versus-actual review.
- Defer probabilistic simulation until calibration criteria are approved.

**Gate:** Rollups reconcile; scenarios reproduce; limitations are disclosed.

### Phase 5 — Advanced features
Potential later items: Monte Carlo distributions, external macroeconomic scenarios, subcontractor financial-health scoring, advanced document extraction, cross-project resource levelling, cash pooling, automated compliance-reference support. Each requires separate owner approval, source/data review, risk analysis and validation plan.

## 14.2 Open decisions that must not be guessed

1. What is the authoritative project revenue basis for each project type?
2. Which profit/margin measures must APG show?
3. What is the approved cost taxonomy and chart-of-accounts mapping?
4. What is the official treatment of GST and tax basis in each calculation?
5. How are contingency, risk allowance and builder margin buffer represented?
6. How are CTC/FTC and EAC defined?
7. How are claimed, disputed and potential variations treated in management reporting?
8. Which data sources/integrations exist and which are planned?
9. Which source is authoritative when data conflicts?
10. What freshness thresholds apply to each source?
11. Which users can create, approve and supersede baselines?
12. What event/threshold should trigger reassessment?
13. What project types and customer segment are first priority?
14. Which financial calculations must be independently verified before pilot?
15. What retention and tamper-evidence policy applies to financial/audit records?
16. Which compliance/contract references may be stored and used, and under what review process?
17. What target metrics define a successful pilot?
18. What forecast-error metric and target, if any, will be approved after baseline data is collected?

## 14.3 Suggested first implementation scope

The initial commercially useful release should prioritise:
- reliable baseline and financial definitions;
- actual/committed/forecast distinctions;
- material drift detection;
- time-dependent cost impact without double-counting;
- variation reconciliation exceptions;
- reassessment and versioned history;
- clear source and data-quality warnings;
- explainable, named scenarios only where calculation integrity is established.

Do not build all advanced capabilities at full sophistication simultaneously.

## 14.4 Status reporting template

For every capability, report:
- requirement IDs;
- source files/interfaces;
- existing tests;
- missing behaviours;
- changes proposed;
- test plan;
- dependencies;
- owner decisions needed;
- implementation status;
- verification status;
- release disposition.

# 10. Layer 8 — Scenario Decision Engine
## Multi-Outcome Profitability Modelling and Decision Intelligence

### Purpose
Compare explicit alternative conditions and decisions using the same financial definitions and calculation services as the baseline and monitoring layers. The engine should show how outcomes differ and which assumptions drive those differences.

### Initial scope
Start with deterministic, transparent named scenarios and sensitivity analysis. Probabilistic Monte Carlo or P10/P50/P90 outputs are deferred until distributions, correlations, historical data and validation are approved.

### Scenario types
- baseline/current case;
- downside/deterioration case;
- stabilisation case;
- recovery/intervention case;
- upside/optimisation case;
- timing/holding-cost case;
- portfolio case where supported.

### Required inputs
- baseline or qualified assessment version;
- scenario ID/name and purpose;
- explicitly changed assumptions/variables;
- value ranges and source/rationale;
- relevant cost/time/finance/market inputs;
- constraints and dependencies;
- calculation and rule versions.

### Core behaviours
1. Create a scenario as a versioned set of input changes against a named base.
2. Validate that changed variables are allowed and correctly typed.
3. Calculate using the same authoritative financial model.
4. Show baseline versus scenario results using identical definitions.
5. Explain the material drivers of the difference.
6. Run sensitivity checks for selected variables where supported.
7. Prevent overlapping effects from being counted twice.
8. Preserve scenario versions, author, timestamp and decision status.
9. Compare scenario output with actual outcome later where possible.

### Outputs
- named scenario and base version;
- changed inputs and assumptions;
- financial outputs and ranges where supported;
- delta from baseline;
- sensitivity summary;
- missing-data and uncertainty qualifications;
- decision/review status;
- reproducible calculation record.

### Required safeguards
- Scenario values are conditional, not guarantees.
- Do not invent probability values or call a range a statistical confidence interval without a valid method.
- Do not expose P10/P50/P90 until the probability model is approved and tested.
- Do not mix different revenue/cost bases between scenarios.
- Do not execute actions based on a preferred scenario.
- Do not hide uncertainty behind a single score.

### Acceptance tests
- Scenario results can be reproduced from base version and changes.
- Changing one variable has a traceable effect on relevant outputs.
- Invalid or missing inputs are qualified or rejected according to contract.
- Alternative scenarios use the same calculation version and financial definitions.
- Overlapping cost effects cannot be blindly added.
- A scenario is not described as a prediction or guarantee.

### Deferred / owner decision
Historical macroeconomic stress tests and probabilistic distributions require a defined data source, calibration method, correlation assumptions and back-testing plan.

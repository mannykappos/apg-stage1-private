# Anchor Profit Guardian (APG)
## Eight Intelligence Layers — Design Blueprint for Claude
**Document set:** APG-8L-BLUEPRINT v0.1  
**Status:** Design baseline for technical refinement; not implementation approval  
**Audience:** Claude, software architects, implementation engineers, verification engineers, APG product owner

## Purpose

This package defines what APG's eight profitability-intelligence capabilities are intended to do, how they should work together, the shared financial foundations they must use, and how implementation should be verified. It is written to give Claude a clear, stable specification to reason from before modifying or building code.

This is a design blueprint, not evidence that these capabilities already exist in the APG codebase. The current APG code candidate and verification-stage package previously discussed are not sufficient by themselves to prove that the eight capabilities have been implemented or integrated.

## Instructions to Claude

You are assisting with the design and implementation planning of Anchor Profit Guardian (APG), a construction and property-development profitability intelligence product.

1. Read this entire package before proposing code changes.
2. Preserve the eight product capabilities and their intent. They may share internal services; do not collapse them merely to simplify a diagram.
3. Do not assume a feature is implemented because it is described here. Inspect the actual source package and label findings as **found and verified**, **partially present**, **not found in reviewed scope**, or **unable to verify**.
4. Do not modify, overwrite, or replace an existing APG release unless explicitly instructed. Preserve the original package and hashes.
5. Before implementing, map each requirement to existing source files, interfaces, tests, and gaps. Produce a traceability matrix.
6. Do not invent business rules, accounting treatment, contract rights, thresholds, data sources, or formulas. Where this blueprint says “TBD / owner decision”, identify the question and propose options with trade-offs.
7. Treat all financial examples as illustrative only. They are not calibrated formulas, promised savings, validated forecasts, or default thresholds.
8. Use one authoritative financial model and shared calculation services. Avoid duplicated financial logic across layers.
9. Make all material outputs traceable to input values, source evidence, timestamps, baseline version, calculation version, and rules used.
10. Unknown, stale, invalid, contradictory, or incomplete data must not silently become authoritative. Represent data quality and uncertainty explicitly.
11. Do not automatically execute contractual, financial, procurement, construction, compliance, or site actions. APG provides decision support unless an explicitly governed action is separately authorised.
12. Do not add machine learning, predictive scoring, Monte Carlo simulation, external-data subscriptions, or automated compliance certification without an approved design decision and validation plan.
13. Do not claim acceptance or completion based only on builder-reported test results. Report exact tests run, scope, results, gaps, and whether verification was independent.
14. When a requirement cannot be implemented responsibly because information is missing, stop at the design boundary, document the blocker, and ask for a decision rather than guessing.
15. Keep language understandable to construction and commercial users; technical implementation details belong in the engineering design.

## Required first response from Claude

After reading this pack and receiving the relevant APG source ZIP, Claude should first produce:
- an inventory of the package and its integrity;
- an implementation-status audit against all requirements in this blueprint;
- a source-to-requirement traceability matrix;
- an explicit list of contradictions, missing inputs and owner decisions;
- a recommended implementation sequence with acceptance gates.

Do not start coding until that audit and plan have been reviewed and approved.

## Document index

- `01_PRODUCT_AND_ARCHITECTURE.md` — product purpose, architecture, boundaries and system flow.
- `02_SHARED_FINANCIAL_FOUNDATION.md` — common financial model, statuses, baselines, calculations and safeguards.
- `03_LAYER_1_ESTIMATION_INTELLIGENCE.md`
- `04_LAYER_2_PROFIT_DRIFT_INTELLIGENCE.md`
- `05_LAYER_3_HOLDING_COST_INTELLIGENCE.md`
- `06_LAYER_4_PROFIT_RECOVERY_ENGINE.md`
- `07_LAYER_5_PROFIT_INCREASE_ENGINE.md`
- `08_LAYER_6_RE_EVALUATION_GOVERNANCE.md`
- `09_LAYER_7_PORTFOLIO_INTELLIGENCE.md`
- `10_LAYER_8_SCENARIO_DECISION_ENGINE.md`
- `11_DATA_CONTRACTS_AND_INTERFACES.md`
- `12_SECURITY_GOVERNANCE_AND_AUDIT.md`
- `13_TESTING_AND_ACCEPTANCE.md`
- `14_IMPLEMENTATION_ROADMAP_AND_DECISIONS.md`
- `15_REQUIREMENT_TRACEABILITY_TEMPLATE.csv`

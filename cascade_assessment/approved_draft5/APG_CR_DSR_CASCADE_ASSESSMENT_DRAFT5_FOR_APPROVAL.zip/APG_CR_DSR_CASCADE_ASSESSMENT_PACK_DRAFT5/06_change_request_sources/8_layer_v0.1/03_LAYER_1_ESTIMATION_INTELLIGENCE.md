# 3. Layer 1 — Estimation Intelligence
## Pre-Construction Profitability Exposure Intelligence

### Purpose
Create a versioned pre-construction financial baseline and show how exposed its profitability is to changes in key assumptions. It should answer: “How vulnerable is this estimate if its underlying conditions change?” rather than merely repeating a total tender value.

### Primary users
Estimator, commercial manager, project director, finance/controller.

### Required inputs
- project scope and estimate version;
- line items/trade packages and quantities where available;
- unit rates and pricing source/date;
- supplier/subcontractor quotes and validity dates;
- inclusions, exclusions and scope assumptions;
- provisional/prime-cost or equivalent classifications where applicable;
- labour and programme assumptions;
- contingency and risk allowances under the approved policy;
- revenue/contract or development-sales assumptions appropriate to the project;
- source references and data-quality indicators.

### Core behaviours
1. Validate estimate structure and required fields.
2. Preserve the original estimate and create a versioned baseline candidate.
3. Identify missing, stale, inconsistent or unpriced scope.
4. Compare important estimate assumptions against available current evidence.
5. Show sensitivity of projected profitability to selected assumption changes.
6. Identify material exposures and explain which inputs drive them.
7. Create an approved Baseline_vN only through the configured approval process.

### Functional outputs
- estimate/baseline summary;
- detailed line/trade breakdown;
- scope gaps and exclusions;
- assumption register with source and validity;
- baseline financial measures using the approved shared model;
- exposure/sensitivity report;
- data-quality warnings;
- draft/approved baseline record and audit trail.

### Example user question
“If the quoted steel price expires before procurement and the supplier's lead time slips, what changes in the forecast under the stated price and programme assumptions?”

The output must show the changed assumptions and calculation, not state that a loss will definitely occur.

### Required safeguards
- Do not infer unpriced scope as zero cost.
- Do not silently use stale quotes as current.
- Do not mix contingency with forecast cost without explicit policy.
- Do not label a baseline approved before required approval.
- Do not treat an illustrative risk range as calibrated probability.
- Do not apply estimator-bias corrections unless historical data and a validated method are approved.

### Acceptance tests
- Missing line-item cost is surfaced and cannot silently produce an unqualified total.
- Expired supplier quote is marked stale and affects the assessment's data-quality status.
- Baseline creation preserves source snapshot, version, assumptions and calculation version.
- Sensitivity output changes only when the relevant input changes and explains that change.
- Re-running the same calculation with the same snapshot/version yields the same result within approved rounding.
- No approved baseline is overwritten by a draft estimate.

### Deferred / owner decision
Monte Carlo, estimator-bias correction, automated historical rate benchmarking and advanced document extraction require separate data, calibration and validation decisions.

APG Data Readiness Change Request, revision 4: pack for the owner and for a scoped GPT check (2026-11-12)
01_CHANGE_REQUEST_REV4.md   revision 4 (its last section maps each point of GPT's check of revision 3 to where it is answered)
02_GPT_CHECK_PROMPT.md      the prompt to paste into GPT with this zip (one pass, scoped to its check's points)
03_registers/               ENTITY_REGISTER.csv (100 entities), RULE_INPUT_CONTRACTS.csv (56 rows, 43 rules and figures),
                            FIELD_COVERAGE.csv (one row per contract row), FIELD_SUPPLY_ROUTES.csv (155 fields and 55 settings rows),
                            NOT_ASSESSED_MESSAGES.csv (579 messages found by scanning the code, each with what the builder is to do),
                            SYSTEMS_SURVEY.csv (16 systems, 2 data sources), CHART_DATA_PATHS.csv, FIELD_REGISTER.csv,
                            TEMPLATE_REGISTER.csv, and the scripts that generate them. Run, in this order, each as: python3 -I <script> .
                            build_systems.py, build_entities.py, build_rule_contracts.py, build_chart_data.py, build_field_coverage.py
                            (build_field_coverage.py writes both field files). Each reproduces its CSV byte for byte.
                            build_message_list.py reads the code: python3 -I build_message_list.py ../04_code_read/apg .
04_code_read/apg/           every production module of det, fin, mkt and ingest (test, demo and reference modules left out),
                            source_authority.py, policy_approval.py, materiality.py (stage 1 code, freeze ee1ce3ec; unchanged since
                            revision 3)
05_blueprint_sources/       locked blueprint Sections 03-13 and 18, the Master RTM, 8-layer files 02 and 11
06_previous/                revisions 2 and 3, revision 3's agent audit, and GPT's check of revision 3
07_decisions/               the owner's decisions of 2026-11-12, the 12 decisions document, GPT's and Gemini's opinions on it,
                            and the data supply design (draft 7, with revision 4 and the owner's later decisions folded in);
                            supply_plan/: SUPPLY_PLAN.csv, RELEASE_A_COVERAGE.csv and build_supply_plan.py
                            (python3 -I build_supply_plan.py ../../03_registers)
AUDIT.txt                   the fresh independent read-only agent check of revision 4 (28 findings), its scoped re-check
                            (0 blocking, 5 should fix, 16 minor), a third check of the last changes and a fourth focused on its fixes,
                            and the fix for each

The owner's change-request list (New 8), as the owner stated it to Claude; it is the owner's own record, not a blueprint document:
CR-01 roadmap reconciliation; CR-02 financial integrity completion; CR-03 Builder Profit Clock; CR-04 opportunity and margin-fade
intelligence; CR-05 site-to-claim capture (phone site capture); CR-06 Australian rule packs (extended to claims and contract
protection); CR-07 builder integrations; CR-08 builder pilot and acceptance scenarios; CR-10 verified profit ledger.

The registers, the survey and the document are Claude's work (BUILDER-EXECUTED: NOT INDEPENDENT); AUDIT.txt's reports are
INDEPENDENT READ-ONLY (agent). Everything is tested on synthetic data only. No production-readiness claim is made. The systems survey
is vendor-level (vendor pages, developer documents, third-party pages), searched 2026-11-12; it is to be confirmed with pilot
builders' sample exports.

# 11. Data Contracts and Internal Interfaces

## 11.1 General rules

These are logical contracts, not a mandate for a particular programming language or database schema. Claude must inspect the current APG stack and propose compatible interfaces without assuming the existing system can be replaced.

All identifiers should be stable and globally unique within their intended scope. Timestamps should use an agreed timezone/UTC convention. Currency and tax basis must be explicit. Every derived record should link to its inputs and calculation version.

## 11.2 Core logical entities

### Project
- project_id
- legal_entity_id
- project_name/code
- project_type
- location/jurisdiction
- currency
- reporting_period/calendar
- lifecycle stage
- status
- access/tenant scope

### FinancialRecord
- record_id
- project_id
- category/account_code
- amount
- currency
- tax_basis
- value_status (actual/committed/forecast/assumption/claimed/disputed/potential/scenario/other approved enum)
- effective_date
- recorded_at
- source_type/source_reference
- related supplier/trade/package/scope/variation where applicable
- verification_status
- baseline_id or scenario_id where relevant
- duplicate/idempotency key
- metadata and audit references

### EstimateLine
- estimate_line_id
- project_id
- estimate_version
- scope/trade/package
- description
- quantity/unit/rate where available
- amount and tax basis
- pricing source and date
- inclusion/exclusion status
- provisional/prime-cost or applicable classification
- assumption/exclusion references
- confidence/data-quality metadata

### Baseline
- baseline_id
- project_id
- version
- status
- created_at/created_by
- source snapshot references
- financial model version
- assumptions
- approval metadata
- prior_baseline_id
- reason for version
- hash/tamper-evidence field if supported by architecture

### Assessment
- assessment_id
- project_id
- baseline_id
- assessment_version
- created_at
- trigger/source
- calculation version
- input snapshot/reference set
- financial measures and qualifications
- warnings/unavailable values
- prior_assessment_id

### Variation
- variation_id
- project_id
- related instruction/work/scope
- description/source evidence
- status
- estimated cost impact
- claimed amount/date
- approved amount/date
- potential revenue/entitlement amount where applicable
- accounting/reporting treatment
- contract references
- approval/audit history

### Alert
- alert_id
- project_id
- alert_type
- affected metric/category
- baseline/assessment version
- trigger rule/version
- detected_at
- materiality/velocity values
- source evidence
- data-quality status
- workflow status/disposition

### Scenario
- scenario_id
- project_id or portfolio_id
- base_assessment_id
- scenario_name/type
- changed_inputs
- assumptions/rationale/source
- calculation_version
- output values/ranges
- warnings
- created_by/at
- review/decision status

### Decision/Approval
- decision_id
- subject type/id
- decision type
- requested action/change
- evidence references
- status
- requested_by/at
- decided_by/at
- rationale
- prior/new values
- audit reference

## 11.3 Required internal service boundaries

Claude should map these logical responsibilities to existing modules before creating anything new:
- Financial model/calculation service.
- Baseline and assessment version service.
- Source ingestion/normalisation and validation.
- Variation reconciliation.
- Drift/event detection.
- Holding-cost calculation.
- Scenario evaluation.
- Re-evaluation orchestration.
- Portfolio aggregation.
- Approval and audit service.

Avoid duplicating formula code inside each layer. If a shared service already exists, verify it and reuse it where appropriate.

## 11.4 Events / triggers

Candidate event types include:
- financial_record_imported;
- financial_record_corrected;
- commitment_changed;
- variation_status_changed;
- milestone_forecast_changed;
- supplier_quote_expired;
- baseline_approval_requested;
- baseline_approved;
- materiality_threshold_crossed;
- assessment_requested;
- scenario_created;
- decision_recorded.

These names are illustrative. Use the existing APG event conventions if present, and document any mapping.

## 11.5 Idempotency and reconciliation

Imports and event processing must be idempotent where duplicate delivery is possible. Store source identifiers and stable idempotency keys. Corrections should create a traceable correction/reversal rather than silently rewriting historical derived results where the audit policy requires preservation.

## 11.6 API requirements

Exact route names and request/response schemas must be derived from the existing APG codebase. Do not invent routes and claim they exist. For each existing or proposed endpoint, document:
- purpose and caller;
- request schema;
- response schema;
- authentication/authorisation;
- validation;
- errors and unavailable-data behaviour;
- audit effects;
- idempotency;
- tests.

## 11.7 Error states

At minimum, distinguish:
- invalid input;
- unknown project/baseline;
- unavailable required data;
- stale data;
- conflicting sources;
- calculation failure;
- unauthorised request;
- invalid state transition;
- approval required;
- duplicate/replayed event;
- unsupported calculation or data status.

An error must not return a plausible but unqualified financial result.

# 2. Shared Financial Foundation

## 2.1 Status and purpose

This document defines the minimum shared financial concepts that all eight capabilities must use. It is a design contract proposal. The exact accounting policies, margin definitions, tax treatment and project-specific rules require owner and appropriate professional approval before production use.

## 2.2 Required distinctions

Every material financial value must have a clear classification. At minimum distinguish:
- **Actual:** recorded transaction or cost/revenue supported by an identified source.
- **Committed:** contractual or purchase-order obligation recorded under the approved commitment policy.
- **Forecast:** estimate of future cost or revenue under a stated basis.
- **Assumption:** an input adopted for modelling but not yet verified as actual.
- **Claimed:** amount submitted or asserted for payment/recovery.
- **Disputed:** amount whose entitlement, value or treatment is contested.
- **Potential:** possible future amount or entitlement not yet approved/recognised under the relevant policy.
- **Scenario:** value that exists only within a named hypothetical case.
- **Approved adjustment:** change accepted through the configured approval process.
- **Unknown/unavailable:** value that cannot responsibly be calculated from available evidence.

Do not collapse these statuses into one “cost” or “revenue” field.

## 2.3 Financial dimensions

Every financial amount should have, as applicable:
- project and legal entity;
- amount and currency;
- tax basis (e.g. GST-inclusive or GST-exclusive);
- category/account mapping;
- actual/committed/forecast/etc. status;
- source reference and source type;
- effective date and recorded timestamp;
- supplier/trade/package or other relevant entity;
- baseline/scenario/version reference;
- approval status;
- confidence/data-quality qualifiers;
- calculation method/version if derived.

## 2.4 Proposed core financial definitions — owner approval required

The following are candidate definitions, not approved APG accounting policy.

- **Revenue basis:** must be explicitly defined for each report, including whether it uses contract value, approved changes, recognised revenue, claimed amounts, or forecast sales/settlements.
- **Direct cost:** cost attributable to direct project delivery, including appropriate labour, materials, subcontractor packages and direct variations according to the approved cost taxonomy.
- **Indirect/site overhead:** time- or project-dependent costs such as site supervision, temporary facilities and eligible plant/overhead costs.
- **Financing/holding cost:** eligible financing interest, land holding costs, rates and related costs according to the approved project model.
- **Head-office overhead allocation:** included only under an explicitly approved allocation method; do not silently mix it with project direct costs.
- **Gross project profit:** candidate formula = chosen revenue basis minus defined direct costs. The revenue and cost bases must be stated.
- **Net project profit:** candidate formula = chosen revenue basis minus the defined total cost basis, including applicable direct, indirect, finance/holding and allocated overhead items. Exact inclusion rules must be approved.
- **Margin percentage:** profit divided by a specifically named revenue denominator. Do not display a percentage without identifying the denominator and reporting basis.
- **Committed cost:** value of obligations included under the approved commitment policy; treatment of contingencies, unapproved changes and cancellable orders must be specified.
- **Forecast-to-complete (FTC/CTC):** forecast of remaining cost required to complete defined scope, with basis and exclusions disclosed.
- **Estimate at completion (EAC):** defined total cost estimate combining incurred/recognised cost and remaining forecast under the approved methodology. Do not assume one universal formula without defining cost statuses.
- **Contingency:** must be separated from expected cost and profit. Distinguish project/client contingency, risk allowance and any builder-controlled margin buffer if those concepts are used; approval and accounting treatment require owner review.

## 2.5 GST and tax treatment

A proposed default for internal comparisons is to use a consistent tax basis, often excluding recoverable GST where appropriate. This must not be hard-coded as universal accounting advice. The data contract must store tax basis and the implementation must follow the approved accounting policy for the relevant entity and transaction. GST accounts and cash-flow liabilities/credits may need separate treatment from margin calculations.

## 2.6 Variations

Represent a variation as a record with:
- unique identifier;
- project and related scope/work/instruction;
- origin/source evidence;
- description and reason;
- status (e.g. identified, pricing in progress, submitted/claimed, approved, disputed, rejected, withdrawn);
- estimated cost impact;
- estimated revenue/entitlement impact where applicable;
- claimed amount and date, if any;
- approved amount and date, if any;
- accounting treatment/status;
- contractual reference where relevant;
- approval and audit history.

An unmatched instruction or performed-work record is a reconciliation exception, not automatic proof of recoverable revenue. The system must distinguish potential entitlement from approved or recognised amounts under the approved policy.

## 2.7 Avoiding double-counting

A single economic impact may affect several forecast components but must not be counted twice. For example, a delay may increase site overheads and financing/holding costs; those are separate cost components if independently calculated, but a cost already embedded in a package forecast must not be added again.

Required controls:
- canonical cost categories and mappings;
- explicit ownership of each calculation component;
- unique source/event references;
- documented allocation rules;
- cross-layer calculation contracts;
- tests for repeated events and overlapping forecasts;
- reconciliation from source components to total result.

## 2.8 Baselines and versions

Each baseline or material assessment must include:
- unique ID and version;
- project and scope/version;
- creation time and creator/process;
- source snapshot or references;
- financial assumptions and estimate basis;
- calculation/rule version;
- status (draft, reviewed, approved, superseded, withdrawn or other approved states);
- approver and approval timestamp where required;
- reason for a new version;
- links to prior version and impact comparison.

Never overwrite an approved baseline silently. A new baseline does not erase the historical result or the variance against it.

## 2.9 Uncertainty and data confidence

For each material output, expose:
- source coverage;
- data age/freshness;
- verification status;
- key assumptions;
- known missing or contradictory inputs;
- range/method where applicable;
- whether the output is actual, forecast or scenario-derived.

Do not create a single confidence score unless its components and interpretation are documented. A portfolio confidence indicator must not silently change the financial totals or hide low-confidence projects.

## 2.10 Calculation contract

Every derived financial result should be reproducible from:
- input snapshot/references;
- financial status and tax basis of each input;
- baseline and scenario version;
- formula/rule version;
- calculation timestamp;
- rounding and currency rules;
- validation outcome;
- warnings, unavailable values and assumptions.

## 2.11 Owner decisions required before production

1. Which margin measures are required (gross, project net, developer net, other)?
2. What is the approved revenue basis for each measure and project type?
3. What cost taxonomy and chart-of-accounts mapping will be used?
4. How are contingencies represented and approved?
5. Which tax basis is authoritative for each calculation?
6. How are committed costs, forecast-to-complete and EAC calculated?
7. How are variations treated in management reporting versus formal accounting?
8. Which user roles can approve a baseline or material adjustment?
9. Which data freshness rules apply to each source?
10. What are the approved rounding, currency and reporting-period conventions?

APG Data Supply System, blueprint amendment draft 5: pack for the owner's decisions (2026-11-12)

01_DATA_SUPPLY_SYSTEM_DRAFT5.md  the design as text (the Word file sent with this zip is the same, with the diagram)
03_plan/                         SUPPLY_PLAN.csv, RELEASE_A_COVERAGE.csv, FIELD_COVERAGE.csv and the two scripts that generate them
                                 (cd 03_plan; python3 -I build_supply_plan.py ../05_inputs/rev3; python3 -I build_field_coverage.py ../05_inputs/rev3)
04_reviews/                      three INDEPENDENT READ-ONLY (agent) checks with the builder's fixes; the GPT and Gemini design reviews of draft 3
                                 and the builder's answers (REVIEW_FIXES_DRAFT4.md)
05_inputs/                       revision 3's doc and registers (incl. FIELD_REGISTER.csv); blueprint Sections 04, 06, 10, 18 and 8-layer file 11;
                                 the stage 1 code the design cites (apg/...)

The design, plan and fix lists are the builder's (Claude's) work, not independent evidence. Stage 1 code is reference code tested on synthetic data only.
Design only: no build is authorised; stage 2 is not authorised. Builds wait for the Section 01 Discovery Exit Report (S04 s20) and the owner.

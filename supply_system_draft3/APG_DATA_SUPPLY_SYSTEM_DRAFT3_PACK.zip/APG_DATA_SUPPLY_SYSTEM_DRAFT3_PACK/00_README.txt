APG Data Supply System, blueprint amendment draft 3: pack for the owner and for one scoped GPT check (2026-11-12)

01_DATA_SUPPLY_SYSTEM_DRAFT3.md   the design (text of the owner's Claude doc; its diagram is described in words). The Word file sent with this zip is the same doc with the diagram.
02_GPT_CHECK_PROMPT.md            the prompt to paste into GPT with this zip (one pass; every problem at once)
03_plan/                          SUPPLY_PLAN.csv (100 rows: rev 3's 99 entities + N01), RELEASE_A_COVERAGE.csv (39 contract rows), build_supply_plan.py
                                  (regenerate: cd 03_plan; python3 -I build_supply_plan.py ../05_inputs/rev3  -> identical CSVs)
04_audits/                        INDEPENDENT READ-ONLY (agent) audit of draft 1 (37 findings) and re-check of draft 2 (26 points), each with the builder's fix list
05_inputs/                        revision 3's doc and registers; blueprint Sections 04, 06, 10, 18 (text) and 8-layer file 11; the stage 1 code the design cites (apg/...)

The design, plan and fix lists are the builder's (Claude's) work, not independent evidence. All code is stage 1 reference code tested on synthetic data only.
Design only: no build is authorised; stage 2 is not authorised. Builds wait for the Section 01 Discovery Exit Report (S04 s20) and the owner.

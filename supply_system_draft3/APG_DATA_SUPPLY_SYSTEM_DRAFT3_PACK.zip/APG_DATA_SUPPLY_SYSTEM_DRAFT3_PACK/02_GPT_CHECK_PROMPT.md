# Scoped check: APG Data Supply System (blueprint amendment, draft 3)

The owner asked for APG to be able to get every piece of data it needs, whatever share a builder's own systems (Excel, Procore, Xero and so on) can supply. Revision 3 of the Data Readiness Change Request (in `05_inputs/rev3/`) listed what APG needs. This amendment designs how APG gets it: one Section 04 intake, six ways to supply data in three levels plus the records APG derives, a minimum way in for every entity, and releases A and B.

This is a **scoped check in ONE pass**. Review all of it and list every problem now; do not stop at the first one. The owner decides after this; there is no further round unless you find something BLOCKING.

## What is in the attached zip
- `01_DATA_SUPPLY_SYSTEM_DRAFT3.md`: the design.
- `03_plan/`: `SUPPLY_PLAN.csv`, `RELEASE_A_COVERAGE.csv` and the script that generates them from revision 3's registers.
- `04_audits/`: two independent agent checks (37 findings on draft 1, 26 points on draft 2) and the fix made for each. Draft 3 includes those fixes.
- `05_inputs/`: revision 3's doc and registers, the locked blueprint Sections 04, 06, 10 and 18 (text), the 8-layer data contracts file, and the stage 1 code the design describes.

## Check exactly these
1. **Architecture.** Does the design keep every Section 04 control for every way in (registration and authentication, scanning, delivery decisions, mapping, authority, outcomes and quarantine, reconciliation, human verification, freshness, audit)? Is its description of the stage 1 code (reference intake, second delivery loop, direct writes) accurate against `05_inputs/code`?
2. **The supply plan.** Is the minimum-way-in rule and the release rule applied as stated? Is any entity in the wrong release, or given a minimum way in that cannot actually supply it (for example a value Section 04 says a person must verify)? Do the numbers in the doc match the CSVs?
3. **Release A.** Does it give every current detection rule and M4 figure a way to get every input it reads, without phone capture or integrations? Is the minimum build list complete and honest about what changes rule behaviour?
4. **Acceptance criteria PG-DS-AC-01 to 11.** Testable, consistent with Section 04 (PG-DI-AC-01 to 18), anything important missing?
5. **Overclaims.** Anything presented as built that is not, any production-readiness claim, any build presented as authorised, any judgement presented as sourced.
6. **The owner's question**, in at most five sentences: if the decisions are approved, does this design let APG get the data each insight needs at any split between the builder's systems and APG's own capture? Where does it still fall short?

## Rules
- Class every problem BLOCKING (the owner should not decide until it is fixed), SHOULD FIX, OPTIONAL or MINOR, with a rough cost (small, medium, large).
- Quote the text or the CSV row you are judging.
- Do not widen the scope: no new insights, no integration design. A gap in the locked blueprint itself goes in a separate short list.
- Say "not verifiable from the pack" where the pack cannot settle a point.

## Output
1. Numbered problems, each with class, cost, quote and fix.
2. The owner's question.
3. Totals per class, and whether anything is BLOCKING.
